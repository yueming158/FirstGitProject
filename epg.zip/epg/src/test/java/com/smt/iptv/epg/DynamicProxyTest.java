package com.smt.iptv.epg;

import java.util.List;

import javax.jws.WebMethod;

import org.apache.ibatis.annotations.Param;
import org.springframework.web.bind.annotation.PathVariable;

import com.smt.iptv.epg.entity.Hotel;
import com.smt.iptv.epg.entity.Hotelcall;
import com.smt.iptv.epg.entity.Musiccategorytype;

/**
 */
public class DynamicProxyTest {

    public static void main(String[] args) {

       Userinterface user = RemoteProxy.getInstance(Userinterface.class);
       Userinterface2 user2 = RemoteProxy.getInstance(Userinterface2.class);
       Userinterface3 user3 = RemoteProxy.getInstance(Userinterface3.class);
       //List<Hotelcall> list =user.getHotelcallList("10001");
       List list =user.getHotelcallList("10001");
       List list2 =user2.getMusicCategoryList();
       Hotel hotel =user3.getHotel("10001");
       System.out.println(list);
       System.out.println(list2);
       System.out.println(hotel);
    }

}
interface Userinterface {
    @WebMethod(action="json/hotelcall/list/12/{iptvusername}")
    public List<Hotelcall> getHotelcallList(@PathVariable("iptvusername")String iptvusername);
    @WebMethod(action="json/hotel")
    public Hotel getHotel(@Param("iptvusername")String iptvusername);
}

interface Userinterface2 {
    @WebMethod(action="json/music/categorytypelist")
    public List<Musiccategorytype> getMusicCategoryList();
}

interface Userinterface3 {
    @WebMethod(action="json/hotel")
    public Hotel getHotel(@Param("iptvusername")String iptvusername);
}