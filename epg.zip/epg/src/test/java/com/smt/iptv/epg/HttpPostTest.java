package com.smt.iptv.epg;

import java.io.IOException;

import org.apache.http.HttpEntity;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.http.MediaType;

public class HttpPostTest {
    public static void main(String[] args) throws ClientProtocolException, IOException {

//        String token = HttpPostTest.post("http://61.28.23.147:9093/Authenticate",
//                "<?xml version='1.0' encoding=\"UTF-8\" ?><Authenticate client=\"testdx58\"  action=\"Login\"/>");
//        System.out.println(token);
//        
//        String source = "1234$" + token.split("\"")[5] + "$testdx58$$$AC:4A:FE:39:F9:DF$$";
//        String encryptedData = AuthenticatorUtils.decrypt("123456", source);
//        String xml="<?xml version='1.0' encoding=\"UTF-8\" ?><Authenticate  authenticator =\"\"  client=\"testdx58\"/>";
//        String response = HttpPostTest.post("http://61.28.23.147:9093/Authenticate",xml);
//        System.out.println(response);
        String s = get();
       System.out.println(s);
       
        
    }

    String encryptTo3DES(String info) {

        return null;
    }

    public static String post(String url, String requestXml) throws ClientProtocolException, IOException {

        // List <NameValuePair> nvps = new ArrayList <NameValuePair>();
        // nvps.add(new BasicNameValuePair("username", "vip"));
        // nvps.add(new BasicNameValuePair("password", "secret"));
        // httpPost.setEntity(new UrlEncodedFormEntity(nvps));

        CloseableHttpClient httpclient = HttpClients.createDefault();
        HttpPost httpPost = new HttpPost(url);
        HttpEntity entity = new StringEntity(requestXml, "utf-8");
        httpPost.setEntity(entity);
        httpPost.setHeader("Content-Type", MediaType.TEXT_XML_VALUE);
        CloseableHttpResponse response2 = httpclient.execute(httpPost);
        try {
            System.out.println(response2.getStatusLine());
            HttpEntity entity2 = response2.getEntity();
            // do something useful with the response body
            // and ensure it is fully consumed
            String content = EntityUtils.toString(entity2, "utf-8");
            EntityUtils.consume(entity2);
            return content;
        } finally {
            response2.close();
        }
    }
    
    public static String get() throws ClientProtocolException, IOException {

        // List <NameValuePair> nvps = new ArrayList <NameValuePair>();
        // nvps.add(new BasicNameValuePair("username", "vip"));
        // nvps.add(new BasicNameValuePair("password", "secret"));
        // httpPost.setEntity(new UrlEncodedFormEntity(nvps));

        CloseableHttpClient httpclient = HttpClients.createDefault();
        HttpGet httpGet = new HttpGet("http://192.168.1.248:9999/portal/static/image/decrypt");

        httpGet.setHeader("X-Playback-Session-Id", "FB1E16E4-9C29-42DE-A67D-E113E3BF5CCA");
        httpGet.setHeader("Connection", "keep-alive");
        httpGet.setHeader("Accept", "*/*");
        httpGet.setHeader("Accept-Encoding", "identity");
        httpGet.setHeader("Accept-Language", "zh-cn");
        httpGet.setHeader("User-Agent", "AppleCoreMedia/1.0.0.10B329 (iPad; U; CPU OS 6_1_3 like Mac OS X; zh_cn)");

        CloseableHttpResponse response2 = httpclient.execute(httpGet);
        try {
            System.out.println(response2.getStatusLine());
            HttpEntity entity2 = response2.getEntity();
            // do something useful with the response body
            // and ensure it is fully consumed
           // entity2.writeTo(new FileOutputStream("d:\\playlist.m3u8"));
            //String content = EntityUtils.toString(entity2, "utf-8");
            EntityUtils.consume(entity2);
            return "";
        } finally {
            response2.close();
        }
    }
}
