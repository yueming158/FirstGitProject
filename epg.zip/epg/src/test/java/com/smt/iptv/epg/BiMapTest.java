package com.smt.iptv.epg;

import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;

public class BiMapTest {
    private static BiMap<String, String> aBiMap = HashBiMap.<String, String> create();
    public static void main(String[] args) {
        BiMap<String, String> bBiMap = aBiMap.inverse();
        aBiMap.put("a", "1");
        aBiMap.put("b", "2");
        aBiMap.put("c", "3");
        aBiMap.put("d", "4");
        aBiMap.put("e", "5");
        System.out.println(bBiMap.get("1"));
        System.out.println(bBiMap.get("2"));
        bBiMap.remove("1");
        bBiMap.remove("100");
        System.out.println(aBiMap.get("a"));
    }
}
