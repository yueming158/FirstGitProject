package com.smt.iptv.epg;

import java.io.IOException;
import java.net.InetSocketAddress;

import org.apache.mina.core.service.IoAcceptor;
import org.apache.mina.core.service.IoHandlerAdapter;
import org.apache.mina.core.session.IdleStatus;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.filter.codec.serialization.ObjectSerializationCodecFactory;
import org.apache.mina.filter.logging.LoggingFilter;
import org.apache.mina.transport.socket.nio.NioSocketAcceptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;

public class MyServer {

    private static final Logger logger = LoggerFactory.getLogger(MyServer.class);
    public static BiMap<String, IoSession> sessionMap = HashBiMap.<String, IoSession> create();
    private static MyServer  myserver=null;
    public synchronized static  void init(int port){
        if(myserver==null){
            myserver= new MyServer(port);
        }
    }
    private MyServer(int port){
        IoAcceptor acceptor = new NioSocketAcceptor();

        acceptor.getFilterChain().addLast("logger", new LoggingFilter());
        // acceptor.getFilterChain().addLast("codec", new
        // ProtocolCodecFilter(new
        // TextLineCodecFactory(Charset.forName("UTF-8"))));
        acceptor.getFilterChain().addLast("codec", new ProtocolCodecFilter(new ObjectSerializationCodecFactory()));
        // acceptor.getFilterChain().addLast("json", new JsonFilter());
        acceptor.setHandler(new IoHandlerAdapter() {

            @Override
            public void sessionCreated(IoSession session) throws Exception {
                logger.info("server created");
            }

            @Override
            public void sessionOpened(IoSession session) throws Exception {
                logger.info("server opened");
            }

            @Override
            public void sessionClosed(IoSession session) throws Exception {
                sessionMap.inverse().remove(session);
                logger.info("server closed");
                // clientMap.remove();
            }

            @Override
            public void sessionIdle(IoSession session, IdleStatus status) throws Exception {
                // sessionMap.remove(session.getId());
                logger.info("server idle");
            }

            @Override
            public void exceptionCaught(IoSession session, Throwable cause) throws Exception {
                logger.error(cause.getMessage(), cause);
                session.close(true);
            }

            @Override
            public void messageReceived(IoSession session, Object message) throws Exception {
                PushMessage pushMessage = (PushMessage) message;
                if ("login".equals(pushMessage.getType())) {
                    sessionMap.remove(pushMessage.getContent());
                    sessionMap.put(pushMessage.getContent(), session);
                    logger.info("用户" + pushMessage.getContent() + "成功连接服务器，sessionId=" + session.getId());
                } else if ("ack".equals(pushMessage.getType())) {
                    logger.info("客户端收到消息的ACK:" + pushMessage.getContent());
                } else {
                    logger.info("客户端收到消息" + pushMessage.getContent());
                }
            }

            @Override
            public void messageSent(IoSession session, Object message) throws Exception {
                logger.info("Sent message " + message);
            }
        });

        try {
            acceptor.bind(new InetSocketAddress(port));
        } catch (IOException ex) {
            logger.error(ex.getMessage(), ex);
        }
    }

    public static void sendMsg(String userId,PushMessage msg){
        if (MyServer.sessionMap.get(userId) != null) {
            MyServer.sessionMap.get(userId).write(msg);
        }
    }
    public static void sendMsgToAll(PushMessage msg){
        for (String userId : MyServer.sessionMap.keySet()) {
            if (MyServer.sessionMap.get(userId) != null) {
                MyServer.sessionMap.get(userId).write(msg);
            }
        }
    }
    
    public static void main(String[] args) throws IOException, InterruptedException {
         MyServer.init(10000);
    }
}   