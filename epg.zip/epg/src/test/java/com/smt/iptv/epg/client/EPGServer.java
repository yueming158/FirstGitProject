package com.smt.iptv.epg.client;

import com.alibaba.fastjson.JSON;
import com.smt.iptv.epg.core.HttpJDKUtil;
import com.smt.iptv.epg.entity.Hotel;

public class EPGServer {
    public static String EPG_SERVER_ADDRESS="http://192.168.1.248:9999/epg/";
    public static Hotel getHotel(String iptvusername){
        
        String  json =HttpJDKUtil.executeHttpGet(EPG_SERVER_ADDRESS+"json/hotel", "utf-8");
        if(json!=null){
            return JSON.parseObject(json, Hotel.class);
        }else{
            return null;
           // throw new NeworkInterfaceException("601" ,"null");
        }
    }
    public static void main(String[] args) {
        Hotel hotel =EPGServer.getHotel("10001");
        System.out.println(hotel);
    }
}
