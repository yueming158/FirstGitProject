/**
 * Copyright (c) 2013--2016
 * All rights reserved.
 * @author Jhonson
 * 2013-8-16 下午3:22:41
 */
package com.smt.iptv.epg;

import org.apache.http.NameValuePair;


public interface HttpUtils {
	public  String executeRemoteMethod(String strUrl,
			NameValuePair... nameValuePairs);
}
