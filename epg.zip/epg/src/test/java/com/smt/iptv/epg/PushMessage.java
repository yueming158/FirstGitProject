package com.smt.iptv.epg;

import java.io.Serializable;

public class PushMessage implements Serializable {

    private static final long serialVersionUID = 1L;
    private String msgid;
    private String type;
    private String content;

    public PushMessage(String type, String content) {
        super();
        this.type = type;
        this.content = content;
    }

    public String getMsgid() {
        return msgid;
    }

    public void setMsgid(String msgid) {
        this.msgid = msgid;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

}
