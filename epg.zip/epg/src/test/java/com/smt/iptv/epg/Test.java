package com.smt.iptv.epg;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.http.client.ClientProtocolException;
import org.springside.modules.mapper.JsonMapper;

import com.smt.iptv.epg.entity.billing.Attr;
import com.smt.iptv.epg.entity.billing.Productofferattrs;
import com.smt.iptv.epg.service.mail.SimpleMailUtil;

//@RunWith(SpringJUnit4ClassRunner.class) 
//@ContextConfiguration(locations = {"classpath*:/applicationContext.xml"})
//@TransactionConfiguration(defaultRollback = false)
//@ActiveProfiles("production") 
public class Test{// extends AbstractTransactionalJUnit4SpringContextTests{
  
//  @Autowired
//  private MusicDao musicDao;
//
//  @org.junit.Test
//  public void testDao() {
//      List<Musiccategory> list= musicDao.getMusiccategoryList(14L);
//      Musiccategory c =list.get(0);
//      System.out.println(list);
//  }
//  public static void main(String[] args) {
//      Date d = new Date();
//      d.setTime(1392135120000L);
//      System.out.println(d);
//  }
    public static void main(String[] args) throws ClientProtocolException, IOException {
//        byte[] b = {(byte) 0xa0,0x44};
//        System.out.println(new String (b,"GB18030"));
//        System.out.println(Integer.toHexString("圳".getBytes()[0]));
//        System.out.println(Integer.toHexString("圳".getBytes()[1]));
//        System.out.println(Integer.toHexString("圳".getBytes("unicode")[0]));
//        System.out.println(Integer.toHexString('嗨'));
    /*	
    	JsonMapper jsonmapper = new JsonMapper();
    	jsonmapper.toJson("");
    	String jsonObject = "";
    	jsonmapper.fromJson(jsonObject, jsonmapper.createCollectionType(ArrayList.class, String.class));
        ArrayList<Attr> attrs = new ArrayList<Attr>();
        Attr attr = new Attr();
        attr.setName("attr1");
        attr.setType("T");
        attr.setValue("独享1000+部高清影片,每月更新数百部");
        attrs.add(attr);
        attr.setName("attr2");
        attr.setType("T");
        attr.setValue("精选时下最热内容、高清画质");
        attrs.add(attr);
        System.out.println(jsonmapper.toJson(attrs));
    	SimpleMailUtil.sendNotificationMail(new String[]{"xujw@szhhzt.com"}, "ceshi", "测试静态邮件发送");*/
    	
    	
    	Integer a = 10;
    	int b =100;
    	System.out.println(a+b);
    }

} 

