package com.smt.iptv.epg;

import java.lang.annotation.Annotation;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Proxy;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.util.ArrayList;
import java.util.List;

import javax.jws.WebMethod;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.apache.ibatis.annotations.Param;
import org.springframework.web.bind.annotation.PathVariable;

import com.alibaba.fastjson.JSON;
import com.smt.iptv.epg.core.HttpJDKUtil;

class RemoteProxy implements InvocationHandler {

    private RemoteProxy(){
        super();
    }
    private static RemoteProxy dynamicProxy =null;
    public synchronized static <T> T getInstance(Class<T> clazz){
        if(dynamicProxy==null){
            dynamicProxy = new RemoteProxy();
        }
        return (T)Proxy.newProxyInstance(clazz.getClassLoader(), new Class[]{clazz}, dynamicProxy);
    }
    
    // 该方法负责集中处理动态代理类上的所有方法调用。
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {

        String action =method.getAnnotation(WebMethod.class).action();
        List<NameValuePair> NameValuePairs = new ArrayList<NameValuePair>();
        if(args!=null){
            for(int i=0;i<args.length;i++){
                Annotation[] annotations = method.getParameterAnnotations()[i];
                if(annotations.length==1){
                    Annotation annotation = annotations[0];
                    if(Param.class.isInstance(annotation)){ 
                        NameValuePairs.add(new BasicNameValuePair(((Param)annotation).value(),args[i].toString()));
                    }else if(PathVariable.class.isInstance(annotation)){
                        action = action.replace("{"+((PathVariable)annotation).value()+"}", args[i].toString());
                    }
                }
            }
        }
        //服务器连接失败等抛出自定义异常
        String urlprefix="http://192.168.1.248:9999/epg/";
        String json = HttpJDKUtil.executeHttpGet(urlprefix+action,"utf-8");
        //String json =http.executeRemoteMethod(action,NameValuePairs.toArray(new NameValuePair[NameValuePairs.size()]));     
        
        //判断是否是集合
        Type type  = method.getGenericReturnType();
        if (type instanceof ParameterizedType) { // 处理泛型类型     
            return JSON.parseArray(json,  getGenericClass((ParameterizedType) type, 0));     
        } else if (type instanceof TypeVariable) {     
            return JSON.parseArray(json, getClass(((TypeVariable<?>) type).getBounds()[0], 0)); // 处理泛型擦拭对象     
        } else {// class本身也是type，强制转型     
            return JSON.parseObject(json, (Class) type);
        }
    }
    private static Class<?> getClass(Type type, int i) {     
        if (type instanceof ParameterizedType) { // 处理泛型类型     
            return getGenericClass((ParameterizedType) type, i);     
        } else if (type instanceof TypeVariable) {     
            return (Class<?>) getClass(((TypeVariable<?>) type).getBounds()[0], 0); // 处理泛型擦拭对象     
        } else {// class本身也是type，强制转型     
            return (Class<?>) type;     
        }     
    }     
    private static Class<?> getGenericClass(ParameterizedType parameterizedType, int i) {     
        Object genericClass = parameterizedType.getActualTypeArguments()[i];     
        if (genericClass instanceof ParameterizedType) { // 处理多级泛型     
            return (Class<?>) ((ParameterizedType) genericClass).getRawType();     
        } else if (genericClass instanceof GenericArrayType) { // 处理数组泛型     
            return (Class<?>) ((GenericArrayType) genericClass).getGenericComponentType();     
        } else if (genericClass instanceof TypeVariable) { // 处理泛型擦拭对象     
            return (Class<?>) getClass(((TypeVariable<?>) genericClass).getBounds()[0], 0);     
        } else {     
            return (Class<?>) genericClass;     
        }     
    }  
}