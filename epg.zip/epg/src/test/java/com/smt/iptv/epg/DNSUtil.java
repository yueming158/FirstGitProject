package com.smt.iptv.epg;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.lang.reflect.Field;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;

public class DNSUtil {

    public static void main(String[] args) throws Exception {
        DNSUtil.updateHostName("d:/hosts","api.fptplay.net.vn","119.9.65.32");
    }
    
    public static List<String> readLines(Reader input) throws IOException {
        BufferedReader reader = new BufferedReader(input);
        List<String> list = new ArrayList<String>();
        String line = reader.readLine();
        while (line != null) {
            list.add(line);
            line = reader.readLine();
        }
        return list;
    }
    public static void writeLines(Collection lines, String lineEnding,
            OutputStream output) throws IOException {
        if (lines == null) {
            return;
        }
        if (lineEnding == null) {
            lineEnding = "\n";
        }
        for (Iterator it = lines.iterator(); it.hasNext(); ) {
            Object line = it.next();
            if (line != null) {
                output.write(line.toString().getBytes());
            }
            output.write(lineEnding.getBytes());
        }
    }
    
    public synchronized static boolean updateHostName(String fileName,String hostName, String ip) throws IOException  {
        if (StringUtils.isEmpty(hostName) || StringUtils.isEmpty(ip)) {
            return false;
        }
        // 更新设定文件
        FileInputStream in =new FileInputStream(fileName);
        List <String> lines = readLines(new InputStreamReader(in));
        in.close();
        for (String strLine : lines) {
            if (StringUtils.isNotEmpty(strLine) && !strLine.startsWith("#")) {
                if (strLine.indexOf(hostName)!= -1) {
                    if(strLine.indexOf(ip)!= -1){
                        return true;//无需修改
                    }else{
                        lines.remove(strLine);
                        break;
                    }
                }
            }
        }
        lines.add(new StringBuilder(ip).append(" ").append(hostName).toString());
        FileOutputStream out =new FileOutputStream(fileName);
        writeLines(lines,null,out);
        out.close();
        return true;
    }
    
}
