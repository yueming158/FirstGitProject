//用于保存频道号
var channelId="";
//用于保存隐藏频道号的事件句柄
var handle;
//用于保存隐藏提示信息的事件句柄
var handleOSD;

 /**
 * 用于处理直播播放的按键事件
 */
function handleKeypress(){
	var event=event||window.event;
	var eventTarget = event.srcElement||event.target;
	//按键事件发生在出入框中，则不作任何处理
	if((eventTarget.tagName.toLowerCase()=="input"&&eventTarget.type.toLowerCase()=="text")
		||eventTarget.tagName.toLowerCase()=="textarea"||eventTarget.tagName.toLowerCase()=="area")
	{
		return true;
	}
	var currKey=event.keyCode||event.which
	//数字按键
	if(currKey>=48&&currKey<=57){
		//刚进入新频道时候 旧频道还在！如果此时按数字键 则取消旧频道号3秒后消失的定时器
		channelId+= String.fromCharCode(currKey);
		showChannelId(1);
		if(channelId.length==3){
			//validChannel(channelId);
			var groupId;
			try{
				groupId = Authentication.CTCGetConfig("UserGroupNMB");
			}
			catch(e){}
			finally
			{
				if(groupId == null || groupId == "" || groupId == undefined){
					groupId = 'test1';
				}
				window.location.href = basePath+"/channel/play?channelnumber="+channelId+"&groupId="+groupId;
			}
		}
		if(handle)
			clearTimeout(handle);
		handle = window.setTimeout("showChannelId()",3000);
	}
	//确认键
	if(currKey==13){
		var channelIdDiv = document.getElementById("channelIdDiv");
		if(channelIdDiv&&channelIdDiv.innerHTML!=""&&channelIdDiv.style.display!="none"){//如果频道信息存在，并且按了确认键则跳转到直播播放页
			//validChannel(channelId);
			var groupId;
			try{
				groupId = Authentication.CTCGetConfig("UserGroupNMB");
			}
			catch(e){}
			finally
			{
				if(groupId == null || groupId == "" || groupId == undefined){
					groupId = 'test1';
				}
				window.location.href = basePath+"/channel/play?channelnumber="+channelId+"&groupId="+groupId;
				return false;
			}
		}else{
			return true;	
		}
	}
}
/**
 * 用于显示频道号
 */
function showChannelId(display){
	var channelIdDiv = document.getElementById("channelIdDiv");
	//用于判断显示频道号的div是否存在，不存在就创建，存在就显示或者隐藏
	if(channelIdDiv){
		if(display==1){
			channelIdDiv.innerHTML = channelId;
			channelIdDiv.style.display = "";
		}else{
			channelId = "";
			channelIdDiv.style.display = "none";
		}
	}else{
		
		var body = document.getElementsByTagName("body")[0];
		/*
		channelIdDiv = document.createElement("div");
		channelIdDiv.id = "channelIdDiv";
		channelIdDiv.style.position = "absolute";
		channelIdDiv.style.left = "850px";
		channelIdDiv.style.top = "40px";
		channelIdDiv.style.fontSize = "32px";
		channelIdDiv.style.color = "green";
		channelIdDiv.innerHTML = channelId;
		body.appendChild(channelIdDiv);
		*
		*/ 
		channelIdDiv.innerHTML = channelId;
	}
	
}
/**
 * 用于显示/隐藏osd，或者跳转url
 * @param display 1,显示 其他，隐藏
 * @param type 1：跳转url；0：显示没有权限的osd；其他：显示没有该频道osd
 */
function showChannelAuthOSD(display,type){
	var channelAuthDiv = document.getElementById("channelAuthDiv");
	//用于判断显示频道号的div是否存在，不存在就创建，存在就显示或者隐藏
	if(channelAuthDiv){
		if(display==1){
			channelAuthDiv.style.display = "";
		}else{
			channelAuthDiv.style.display = "none";
		}
	}else{
		var body = document.getElementsByTagName("body")[0];
		channelAuthDiv = document.createElement("div");
		channelAuthDiv.id = "channelAuthDiv";
		channelAuthDiv.style.position = "absolute";
		channelAuthDiv.style.left = "380px";
		channelAuthDiv.style.top = "160px";
		if(type==1)
			channelAuthDiv.innerHTML = '<img border="0" width="522" height="267" src="'+basePath+'/images/not_auth.png">';
		else
			channelAuthDiv.innerHTML = '<img border="0" width="522" height="267" src="'+basePath+'/images/not_exist.png">';
		body.appendChild(channelIdDiv);
	}
}
/**
 * 验证用户有没有权限看该频道（1：有权限；0：没有权限；其他：没有该频道）
 * @param channelId 频道Id
 * @return 1：有权限；0：没有权限；其他：没有该频道
 */
function validChannel(channelId){
	
	var channelAuth = "{1:0,2:1}";
	if(typeof(channelAuth)&&channelAuth!=""){
		eval("var channelAuths = " + channelAuth);
		if(channelAuths[channelId]==1)//跳到直播播放页
			{
			var groupId;
			try{
				groupId = Authentication.CTCGetConfig("UserGroupNMB");
			}
			catch(e){}
			finally
			{
				if(groupId == null || groupId == "" || groupId == undefined){
					groupId = 'test1';
				}
				window.location.href = basePath+"/channel/play?channelnumber="+channelId+"&groupId="+groupId;
			}
		}
		else if(channelAuths[channelId]==0){
			showChannelAuthOSD(1,0);
			handleOSD = window.setTimeout("showChannelAuthOSD()",3000);
		}else{
			showChannelAuthOSD(1,1);
			handleOSD = window.setTimeout("showChannelAuthOSD()",3000);
		}
	}
}
//addPressEvent(handleKeypress);
keypressList+="handleKeypress(e);";

