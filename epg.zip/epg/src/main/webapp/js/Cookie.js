/**
 * @author yookien
 * @version 1.0
 * @date 2010-01-08
 * 这是一个操作cookie的构造方法

 * 保存一组数据到本地浏览器cookie，调用store()方法.
 * 删除一组数据调用remove()方法.
 *
 * 静态方法 Cookie.enabled( )主要用于判断cookie是否可用 
 */
function Cookie(name) {
	//用于记录cookie的名字
    this.$name = name;  

   //首先我们得到浏览器中cookie所有内容，并且去掉空格
    var allcookies = document.cookie.replace(new RegExp(" ","gm"),"");
    if (allcookies == "") return;

    var cookies = allcookies.split(';');
    var cookie = null;
    for(var i = 0; i < cookies.length; i++) {
        if (cookies[i].substring(0, name.length+1) == (name + "=")) {
            cookie = cookies[i];
            break;
        }
    }

    if (cookie == null) return;

    var cookieval = cookie.substring(name.length+1);

    var a = cookieval.split('&'); 
    for(var i=0; i < a.length; i++)  
        a[i] = a[i].split(':');

    for(var i = 0; i < a.length; i++) {
       this[a[i][0]] = a[i][1];
    }
}

 /**
  * 用于保存cookie
  * @param daysToLive cookie保存时间（以天为单位）
  * @param path cookie保存路径（一般以默认为主）
  * @param domain cookie保存的域
  * @param secure 
  */
Cookie.prototype.store = function(daysToLive, path, domain, secure) {
   
    var cookieval = "";
    for(var prop in this) {
        if ((prop.charAt(0) == '$') || ((typeof this[prop]) == 'function'))
            continue;
        if (cookieval != "") 
        	cookieval += '&';
        cookieval += prop + ':' + this[prop];
    }
    var cookie = this.$name + '=' + cookieval;
    if (daysToLive || daysToLive == 0) {
        cookie += "; max-age=" + (daysToLive*24*60*60);
    }

    if (path) cookie += "; path=" + path;
    if (domain) cookie += "; domain=" + domain;
    if (secure) cookie += "; secure";

    document.cookie = cookie;
}

/**
  * 用于删除cookie
  * @param daysToLive cookie保存时间（以天为单位）
  * @param path cookie保存路径（一般以默认为主）
  * @param domain cookie保存的域
  */
Cookie.prototype.remove = function(path, domain, secure) {
    // Delete the properties of the cookie
    for(var prop in this) {
        if (prop.charAt(0) != '$' && typeof this[prop] != 'function')
            delete this[prop];
    }

    // Then, store the cookie with a lifetime of 0
    this.store(0, path, domain, secure);
}

/**
 * 检查cookie是否可用
 */
Cookie.enabled = function( ) {
    
    if (navigator.cookieEnabled != undefined) return navigator.cookieEnabled;

    if (Cookie.enabled.cache != undefined) return Cookie.enabled.cache;

    document.cookie = "testcookie=test; max-age=10000";  // Set cookie

    var cookies = document.cookie;
    if (cookies.indexOf("testcookie=test") == -1) {
       
        return Cookie.enabled.cache = false;
    }
    else {
        document.cookie = "testcookie=test; max-age=0";  // Delete cookie
        return Cookie.enabled.cache = true;
    }
}

/*
*使用示例如下
<script src="Cookie.js"></scripty><!-- include the cookie class -->
<script>
// Create the cookie we'll use to save state for this web page.
var cookie = new Cookie("vistordata");

// First, try to read data stored in the cookie. If the cookie doesn't
// exist yet (or doesn't have the data we expect), query the user
if (!cookie.name || !cookie.color) {
    cookie.name = prompt("What is your name:", "");
    cookie.color = prompt("What is your favorite color:", "");
}

// Keep track of how many times this user has visited the page
if (!cookie.visits) cookie.visits = 1;
else cookie.visits++;

// Store the cookie data, which includes the updated visit count. We set
// the cookie lifetime to 10 days. Since we don't specify a path, this
// cookie will be accessible to all web pages in the same directory as this
// one or "below" it.  We should be sure, therefore, that the cookie
// name, "visitordata" is unique among these pages.
cookie.store(10);

// Now we can use the data we obtained from the cookie (or from the
// user) to greet a user by name and in her favorite color.
document.write('<h1 style="color:' + cookie.color + '">' +
               'Welcome, ' + cookie.name + '!' + '</h1>' +
               '<p>You have visited ' + cookie.visits + ' times.' +
               '<button onclick="window.cookie.remove( );">Forget Me</button>;');
</script>
*/

