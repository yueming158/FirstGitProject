/**
 * 点播页面公共函数方法
 */
 //得到当前播放时间
 function getNowTime()
 {
 	var currentPlayTime=parseInt(vod.mp.getCurrentPlayTime());
 	if(currentPlayTime>timelength)
 	{
 		currentPlayTime=timelength;
 	}
 	return  parseInt(currentPlayTime);
 }

//格式化时间（npt 转化为 00:00:00作为显示使用）
 function fomattime(sec)
 {
 	var hour = parseInt(sec/3600);
 	var minu =parseInt((sec%3600)/60);
 	var second = sec%60;
 	if(hour<10)
 		hour="0"+hour;
 	if(minu<10)
 		minu="0"+minu;
 	if(second<10)
 		second="0"+second;
 	return hour+":"+minu+":"+second
 }



var VodMediaPlayer = function(url,id)
{
	this.type="vod";
	this.speedflag=1;
	this.url=url;
	this.id=id;
	this.mp=new MediaPlayer();
	this.toJson =function (url,id)
	{ 

		return '[{mediaUrl:"'+url
		+'",mediaCode: "vod_code_'+id
		+'",mediaType:2,'
		+'audioType:1,'
		+'videoType:1,'
		+'streamType:1,'
		+'drmType:1,'
		+'fingerPrint:0,'
		+'copyProtection:1,'
		+'allowTrickmode:1,'
		+'startTime:0,'
		+'endTime:0,'
		+'entryID:"vod_entry_'+id+'"}]';	
	}
	this.InstanceID = this.mp.getNativePlayerInstanceID();	
	//设置是否列表播放
	this.mp.setSingleOrPlaylistMode(0);
	this.mp.setVideoDisplayMode(1);
	this.mp.setAllowTrickmodeFlag(0);
	this.mp.setNativeUIFlag(0);
	this.mp.setVideoDisplayArea(0, 0, 640, 530);
	this.mp.refreshVideoDisplay();

	//设置媒体参数
	var mediaStr = this.toJson(this.url,this.id);
	this.mp.setSingleMedia( mediaStr );
	
	this.playFromStart=function()
	{
		this.mp.playFromStart();
		this.speedflag=1;
	}
	this.playByTime=function(timetype,time)
	{
		this.mp.playByTime(timetype,time);
		this.speedflag=1;
	}
	this.pause=function()
	{
		this.mp.pause();
		document.getElementById("pauseImg").style.display="";
		document.getElementById("fastpre").style.display="none";
		document.getElementById("fastnext").style.display="none";
		this.speedflag=0;
	}
	this.resume=function()
	{
		this.mp.resume();
		this.speedflag=1;
	}
	this.fastRewind=function(speed)
	{
		this.mp.fastRewind(speed);
		this.speedflag=speed;
 		document.getElementById("speedspan").innerHTML = "<img src='"+basePath+"/images/fast_rewind.png' />"+"×"+(-1*vod.speedflag);
		document.getElementById("fastpre").style.display="none";
		document.getElementById("fastnext").style.display="";
		document.getElementById("pauseImg").style.display="none";
	}
	this.fastForward=function(speed)
	{
		this.mp.fastForward(speed);
		this.speedflag=speed;
		document.getElementById("speedspan").innerHTML = "<img src='"+basePath+"/images/fast_forward.png' />"+"×"+vod.speedflag;
		document.getElementById("fastpre").style.display="";
		document.getElementById("fastnext").style.display="none";
		document.getElementById("pauseImg").style.display="none";
	}
	this.getCurrentPlayTime=function()
	{
		var currentPlayTime=parseInt(vod.mp.getCurrentPlayTime());
	 	if(currentPlayTime>timelength)
	 	{
	 		currentPlayTime=timelength;
	 	}
	 	return  parseInt(currentPlayTime);
	}
	this.stop =function()
	{
		this.mp.stop();
		this.mp.releaseMediaPlayer( this.InstanceID );
	}
	this.getMediaDuration =function()
	{
		return this.mp.getMediaDuration();
	}
}

