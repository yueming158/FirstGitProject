 //得到当前播放时间
 function getNowTime ()
 {
 	return vod.getCurrentPlayTime();
 }
 
 /**
  *格式化时间 参数Date
  */
  function formatClock(colocktime){
  	var newcolock="";
  	var h=colocktime.getHours();
  	if(colocktime.getHours()<10)
  	{
  		newcolock+="0";
  	}
  	newcolock+=colocktime.getHours()+":";
  	if(colocktime.getMinutes()<10)
  	{
  		newcolock+="0";
  	}
  	newcolock+=colocktime.getMinutes()+":";
  	if(colocktime.getSeconds()<10)
  	{
  		newcolock+="0";
  	}
  	newcolock+=colocktime.getSeconds();
  	return newcolock;
  }

//格式化时间（npt 转化为 00:00:00作为显示使用）
 function fomattime(sec)
 {
 	if(vod.type=="vod")
 	{
	 	var hour = parseInt(sec/3600);
	 	var minu =parseInt((sec%3600)/60);
	 	var second = sec%60;
	 	if(hour<10)
	 		hour="0"+hour;
	 	if(minu<10)
	 		minu="0"+minu;
	 	if(second<10)
	 		second="0"+second;
	 	return hour+":"+minu+":"+second
 	}
 	else
 	{
		document.getElementById("sumTime2").innerHTML = formatClock(new Date());
 		if(sec<0)
		{
			sec=0;
		}
		var now =new Date(new Date().getTime()-(timelength-sec)*1000);
		var h=now.getHours();
		if(h<10)
		{h="0"+h}
		var m=now.getMinutes();
		if(m<10)
		{m="0"+m}
		var s=now.getSeconds();
		if(s<10)
		{s="0"+s}
		return h+":"+m+":"+s;
 	}
 }




var LiveMediaPlayer = function(url,id)
{
	this.type="live";
	this.speedflag=1;
	this.url=url;
	this.id=id;
	this.mp=new MediaPlayer();
	this.toJson =function (url,id)
	{ 

		return '[{mediaUrl:"'+url
		+'",mediaCode: "vod_code_'+id
		+'",mediaType:2,'
		+'audioType:1,'
		+'videoType:1,'
		+'streamType:1,'
		+'drmType:1,'
		+'fingerPrint:0,'
		+'copyProtection:1,'
		+'allowTrickmode:1,'
		+'startTime:0,'
		+'endTime:0,'
		+'entryID:"vod_entry_'+id+'"}]';	
	}
	this.InstanceID = this.mp.getNativePlayerInstanceID();	
	//设置是否列表播放
	this.mp.setSingleOrPlaylistMode(0);
	this.mp.setVideoDisplayMode(1);
	this.mp.setAllowTrickmodeFlag(0);
	this.mp.setNativeUIFlag(0);
	this.mp.setVideoDisplayArea(0, 0, 640, 530);
	this.mp.refreshVideoDisplay();

	//设置媒体参数
	var mediaStr = this.toJson(this.url,this.id);
	this.mp.setSingleMedia( mediaStr );
	
	this.playFromStart=function()
	{
		this.mp.playFromStart();
		this.speedflag=1;
	}
	this.playByTime=function(type,time)
	{
		this.mp.playByTime(type,time);
		this.speedflag=1;
	}
	this.pause=function()
	{
		this.mp.pause();
		//document.getElementById("pauseImg").style.display="";
		//document.getElementById("fastpre").style.display="none";
		//document.getElementById("fastnext").style.display="none";
		this.speedflag=0;
	}
	this.resume=function()
	{
		this.mp.resume();
		this.speedflag=1;
	}
	this.fastRewind=function(speed)
	{
		this.mp.fastRewind(speed);
		this.speedflag=speed;
 		//document.getElementById("speedspan").innerHTML = "<img src='"+basePath+"/images/fast_rewind.png' />"+"×"+(-1*vod.speedflag);
		//document.getElementById("fastpre").style.display="none";
		//document.getElementById("fastnext").style.display="";
		//document.getElementById("pauseImg").style.display="none";
	}
	this.fastForward=function(speed)
	{
		this.mp.fastForward(speed);
		this.speedflag=speed;
		//document.getElementById("speedspan").innerHTML = "<img src='"+basePath+"/images/fast_forward.png' />"+"×"+vod.speedflag;
		//document.getElementById("fastpre").style.display="";
		//document.getElementById("fastnext").style.display="none";
		//document.getElementById("pauseImg").style.display="none";
	}
	this.getCurrentPlayTime=function()
	{
		var result = this.mp.getCurrentPlayTime().replace(new RegExp(" ","gm"),"").replace('T','');
		var year = result.substring(0,4);
		var month = parseInt(result.substring(4,6))-1;
		var day = result.substring(6,8);
		var hour = result.substring(8,10);
		var minute = result.substring(10,12);
		var sec = result.substring(12,14);
		var date = new Date(year,month,day,hour,minute,sec);
		//if(result.length==17)
		//{
		//	date= new Date(date.getTime()+28800000);
		//}
		var currentPlayTime = timelength-parseInt((new Date().getTime()-date.getTime())/1000);
	 	if(currentPlayTime>timelength)
	 	{
	 		currentPlayTime=timelength;
	 	}
	 	else if(currentPlayTime<0)
	 	{
	 		currentPlayTime=0
	 	}
	 	return  currentPlayTime;
	}
	this.stop =function()
	{
		this.mp.stop();
		this.mp.leaveChannel();
		this.mp.releaseMediaPlayer( this.InstanceID );
	}
	this.getMediaDuration =function()
	{
		return this.mp.getMediaDuration();
	}
	/**
		 * 播放下一个频道
		 */
	this.joinNextChannel=function()
	{
		maxchannelnum=channelArr[channelArr.length-1][0];
		this.mp.stop();
		this.mp.leaveChannel();
		var Num=this.mp.getChannelNum();
		if(Num==-1||Num==maxchannelnum)
		{
			this.mp.joinChannel(0);
			channelNo = 0;
		}
		else
		{
			this.mp.joinChannel(parseInt(Num)+1);
			channelNo = parseInt(Num)+1;
		}
		if(typeof(showOSD1)=="function")
		{
			showOSD1('hidden');
		}
		if(typeof(showOSD2)=="function")
		{
			showOSD2('hidden');
		}
		showChannelOSD("view",this.isExistChannel(this.mp.getChannelNum()));
		channelNo = "";
		operateOSD =10;
	}
	this.isExistChannel=function(num)
	{
		for(var i=0;i<channelArr.length;i++)
		{
			if(channelArr[i][0]==num)
			{
				return true;
				break;
			}
		}
		return false;
	}
		/**
		 * 播放上一个频道
		 */
	this.joinPreChannel=function()
	{
		maxchannelnum=channelArr[channelArr.length-1][0];
		this.mp.stop();
		this.mp.leaveChannel();
		var Num=this.mp.getChannelNum();
		if(Num==-1||Num==0)
		{
			this.mp.joinChannel(maxchannelnum);
			channelNo =maxchannelnum;
		}
		else
		{
			this.mp.joinChannel(Num-1);
			channelNo =Num-1;
		}
		if(typeof(showOSD1)=="function")
		{
			showOSD1('hidden');
		}
		if(typeof(showOSD2)=="function")
		{
			showOSD2('hidden');
		}
		showChannelOSD("view",this.isExistChannel(this.mp.getChannelNum()));
		channelNo = "";
		operateOSD =10;
	}
	this.join=function (num)
	{
		this.mp.stop();
		this.mp.leaveChannel();
		//显示info  显示频道号   加入频道  3秒后 去掉 
		num =parseInt(num)||1;
		channelNo=num; 
		
		vod.mp.joinChannel(num);
		channelNo=num;
		showChannelOSD("view",this.isExistChannel(num));	
		channelNo="";
		operateOSD =10;
	}
}

