function Ajax(){
	
	this.tip = null;//放置提示用户等待的信息的对象。
	this.disResponseObject = null;//显示服务器返回信息的对象。
	this.callMethod = null; //服务器返回后，调用的方法。

	/**
	 * 请求服务器
	 * @param	reqUrl           请求的url，String类型
	 * @param	postStr          发送给服务器的内容，当有post为null对象时，默认为get方式请求，反之是post
	 * @param	disResponseObj   显示服务器返回信息的html元素对象，可以是null。
	 * @param	callBack         接收到服务器返回信息后回调的函数，值是方法名称(不必加任何引号)，可以是null。方法也可以是这种形式：对象.方法名称，如:A.do。
	 * @param	flag             请求是否对用户匿名，参数是boolean类型。为false表示匿名，不显示提示用户等待的信息；反之则有。
	 * @param   synchronize      同步标志，为boolean值，可以为null。为true表示是同步请求，为null或者false表示异步请求
	 */
	this.callServer = function(reqUrl,postStr,disResponseObj,callBack,synchronize){
		this.disResponseObject = disResponseObj;
		this.callMethod = callBack;
		if(reqUrl.indexOf("pageCacheFlag")==-1){
        	if(reqUrl.indexOf("?")==-1)
        		reqUrl+="?pageCacheFlag=0";
        	else
        		reqUrl+="&pageCacheFlag=0";      	
        } 
		this.service(reqUrl,postStr,synchronize);
	}
	
	/**
	 * 提供ajax请求服务
	 */
	this.req;
	this.dataPage;
	this.service = function(reqUrl,postStr,synchronize){
		if (window.ActiveXObject)//for IE
			{this.req = new ActiveXObject("Microsoft.XMLHTTP");}
		else if (window.XMLHttpRequest) //for firefox etc..	
			{this.req = new XMLHttpRequest();}
		var method = null==postStr? "get":"post";
		if(synchronize&&Type.isBoolean(synchronize)) this.req.open(method,reqUrl,true);
		else this.req.open(method,reqUrl,true);
		if("post"==method){
			if(postStr==null) 
				{postStr=""}
			this.req.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
			this.req.setRequestHeader("Content-Length",postStr.length);	
			this.req.send(postStr);
		}
		else
			{this.req.send(null);}
		var a=this;
		this.req.onreadystatechange = function ()
		{
			var r ;
			if(this.ajax==undefined)
			{
				r=this;
			}
			else
			{
				r =this.ajax.req;
			}
			if(r.readyState==4)
			{
				if(null!=ajax.disResponseObject)//如果放置返回信息的html对象存在，就将内容转入。
				{
					var t =r.responseText;
					if(!ajax.dataPage)
					{		
						if(this.ajax==undefined)
						{	
							 t =ajax.filterPageTag(r.responseText);
						}
						else
						{
							t =ajax.filterPageTag2(r.responseText);
						}
					}
					ajax.disResponseObject.innerHTML = t;
				}
				if(ajax.callMethod){//如果回调函数存在，则调用。
					ajax.callMethod(r.responseText,r.responseXML);
				}
			}

		}
	}
	/**
	 * 过滤返回字符串
	 */
	this.filterPageTag2 = function(txt){
		//不存在更新对象 过滤返回字符串的html body及body以上级别的代码
			var re1 = /<body/gi;
			var re2= /<\/body/gi;
			if(re1.test(txt)&&re2.test(txt))
			{
				var index = txt.indexOf("<body")+5;
				var temp0 = txt.substring(index);
				index = temp0.indexOf(">")+1;
				var temp1 = temp0.substring(index);
				index = temp1.lastIndexOf("</body");
				temp2= temp1.substring(0,index);
				txt = temp2;
			}
			var contentId =ajax.disResponseObject.id
			if(txt.indexOf(contentId)==-1)
			{
				return txt;
			}
			//过滤其他部分 只更新当前需要更新部分
			var reg = new RegExp("/id=['\"]"+contentId+"['\"]/");
			var contentArr = txt.split(reg);//根据id分割txt
			if(contentArr.length==2)
			{
				var firstIndex = contentArr[0].lastIndexOf("<");//得到初始位置
				var tagNameArr = contentArr[0].split("<");
				var tagName = tagNameArr[tagNameArr.length-1].split(" ")[0];
		
				var text = contentArr[1];
				var tagEnd ="</"+tagName;
			 	var tagStart ="<"+tagName;
			 	var tagEnd2 ="00"+tagName;
			 	var tagStart2 ="0"+tagName;
			 	var text2 =text;
			 	var end;
			 	var start;
				do{
					var end =text.indexOf(tagEnd);
					var start =text.indexOf(tagStart);
					if(end>start&&start!=-1)
					{
						text=text.replace(tagEnd,tagEnd2);
						text=text.replace(tagStart,tagStart2);
					}
				}
				while(end>start)
				txt=text2.substring(text.indexOf(">")+1,text.indexOf(tagEnd));
			}
		return txt;
	}
	this.filterPageTag = function(txt){
		//不存在更新对象 过滤返回字符串的html body及body以上级别的代码
			var re1 = /<body/gi;
			var re2= /<\/body/gi;
			if(re1.test(txt)&&re2.test(txt))
			{
				var index = txt.indexOf("<body")+5;
				var temp0 = txt.substring(index);
				index = temp0.indexOf(">")+1;
				var temp1 = temp0.substring(index);
				index = temp1.lastIndexOf("</body");
				temp2= temp1.substring(0,index);
				txt = temp2;
			}
			var contentId =ajax.disResponseObject.id
			if(txt.indexOf(contentId)==-1)
			{
				return txt;
			}
			//过滤其他部分 只更新当前需要更新部分
			var reg = new RegExp("[\\s+]id\\s*=\\s*['\"]\\s*"+contentId+"\\s*['\"]");
			var contentArr = txt.split(reg);//根据id分割txt
			if(contentArr.length==2)
			{
				var firstIndex = contentArr[0].lastIndexOf("<");//得到初始位置
				var tagNameArr = contentArr[0].split("<");
				var tagName = tagNameArr[tagNameArr.length-1].split(" ")[0];
		
				var text = contentArr[1];
				var tagEnd ="</"+tagName;
			 	var tagStart ="<"+tagName;
			 	var tagEnd2 ="00"+tagName;
			 	var tagStart2 ="0"+tagName;
			 	var text2 =text;
			 	var end;
			 	var start;
				do{
					var end =text.indexOf(tagEnd);
					var start =text.indexOf(tagStart);
					if(end>start&&start!=-1)
					{
						text=text.replace(tagEnd,tagEnd2);
						text=text.replace(tagStart,tagStart2);
					}
				}
				while(end>start)
				txt=text2.substring(text.indexOf(">")+1,text.indexOf(tagEnd));
			}
		return txt;
	}
}
		

/**
 * 以get方式请求服务器
 * @param	reqUrl           请求的url，String类型
 * @param	disResponseObj   显示服务器返回信息的html元素对象，可以是null。
 * @param	callBack         接收到服务器返回信息后回调的函数，值是方法名称(不必加任何引号)，可以是null。方法也可以是这种形式：对象.方法名称，如:A.do
 * @param	flag             请求是否对用户匿名，参数是boolean类型。为false表示匿名，不显示提示用户等待的信息；反之则有。
 * @param   synchronize      同步标志，为boolean值，可以为null。为true表示是同步请求，为null或者false表示异步请求
 */
Ajax.doGet = function(reqUrl,disResponseObj,callBack,flag,synchronize){
	//ajax = new Ajax();
//	ajax.callServer(reqUrl,null,disResponseObj,callBack,flag,synchronize);
	var index = reqUrl.indexOf("?");
	var param = "";
	if(index>0){
		param = reqUrl.substr(index+1);
		reqUrl = reqUrl.substr(0,index);
	}
	ajax.callServer(reqUrl,param,disResponseObj,callBack,flag,synchronize);
}
/**
 * 以post方式请求服务器
 * @param	reqUrl           请求的url，String类型
 * @param	postStr          发送给服务器的内容。
 * @param	disResponseObj   显示服务器返回信息的html元素对象，可以是null。
 * @param	callBack         接收到服务器返回信息后回调的函数，值是方法名称(不必加任何引号)，可以是null。方法也可以是这种形式：对象.方法名称，如:A.do。
 * @param	flag             请求是否对用户匿名，参数是boolean类型。为false表示匿名，不显示提示用户等待的信息；反之则有。
 * @param   synchronize      同步标志，为boolean值，可以为null。为true表示是同步请求，为null或者false表示异步请求
 */
Ajax.doPost = function(reqUrl,postStr,disResponseObj,callBack,flag,synchronize){
	//ajax = new Ajax();
	if(postStr==null) postStr="";
	ajax.callServer(reqUrl,postStr,disResponseObj,callBack,flag,synchronize);
	
}
/**
 * 以post方式请求服务器
 * @param	reqUrl           请求的url，String类型
 * @param	postStr          发送给服务器的内容。
 * @param	htmlName   显示服务器返回信息的html元素对象，可以是null。
 * @param	callBack         接收到服务器返回信息后回调的函数，值是方法名称(不必加任何引号)，可以是null。方法也可以是这种形式：对象.方法名称，如:A.do。
 * @param	flag             请求是否对用户匿名，参数是boolean类型。为false表示匿名，不显示提示用户等待的信息；反之则有。
 * @param   synchronize      同步标志，为boolean值，可以为null。为true表示是同步请求，为null或者false表示异步请求
 *  */
Ajax.Updater=function(htmlName, reqUrl,Arr)
{

		//ajax = new Ajax();
		var postStr=Arr["parameters"];
		if(postStr==null) postStr="";
		if(Arr["dataPage"])
			ajax.dataPage=Arr["dataPage"];
		else
			ajax.dataPage=false;
		if(htmlName==null)
		{
			ajax.callServer(reqUrl,postStr,null,Arr["onComplete"],false);
		}
		else
		{
			ajax.callServer(reqUrl,postStr,document.getElementById(htmlName),Arr["onComplete"],false);
		}
}
var ajax= new Ajax();




