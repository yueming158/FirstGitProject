package com.smt.iptv.epg.json;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smt.iptv.epg.dao.ChannelDao;
import com.smt.iptv.epg.dao.ScheduleDao;
import com.smt.iptv.epg.entity.Channel;
import com.smt.iptv.epg.entity.Page;
import com.smt.iptv.epg.entity.Schedule;

/**
 * 直播频道节目时间表相关接口
 * 
 * @author mills
 */
@Controller
@RequestMapping(value = "/json/schedule")
public class ScheduleController {

    @Autowired
    private ScheduleDao scheduleDao;
    @Autowired
    private ChannelDao channelDao;

    /**
     * 获取一个频道的节目时间表 只返回最近10个 /json/schedule/{channelid}
     * 
     * @param channelid
     *            频道ID
     * @return 时间表列表
     */
    @RequestMapping(value = "/{channelid}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<Schedule> schedule(@PathVariable("channelid") Long channelid, Page<Schedule> page) {
        List<Schedule> list= scheduleDao.getOldSchedulelistPage(channelid, page);
        List forecast = scheduleDao.getSchedulelistPage(channelid, page);
        Collections.reverse(list);
        list.addAll(forecast);
        Channel channel = channelDao.getChannel(channelid);
        Long time = System.currentTimeMillis() - channel.getTimeshiftduration() * 1000;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
       // List<Schedule> list = tvod;//scheduleDao.getTvodSchedulelistPage(channelid, sdf.parse(day),new Date(time), page);
        SimpleDateFormat clocksdf = new SimpleDateFormat("yyyyMMddHHmmss");
        // 为返回结果设置endtime为下一个节目的starttime
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                Schedule schedule = list.get(i);
                if (i < list.size() - 1) {
                    schedule.setEndtime(list.get(i + 1).getStarttime());
                } else{
                    schedule.setEndtime(schedule.getStarttime());
                }
                if (schedule.getStarttime().getTime() < time) { //开始时间小于录制点
                    schedule.setPlaystatus("1");//不可观看
                } else if (schedule.getEndtime().getTime() < System.currentTimeMillis()) { //开始时间大于等于录制点并且结束时间小于当前
                        schedule.setPlaystatus("2");//已录制 可回看
                        schedule.setTvodurl(channel.getTimeshifturl() + "?startTime=" + clocksdf.format(schedule.getStarttime()) + "&endTime="
                                + clocksdf.format(schedule.getEndtime()));
                } else if (schedule.getStarttime().getTime()< System.currentTimeMillis()) { //开始时间大于等于录制点并且结束时间大于等于当前，开始时间小于当前
                        schedule.setPlaystatus("3");//正在播放
                } else {
                        schedule.setPlaystatus("4");// 以及未播放
                }
            }
        }
        return list;
    }

    /**
     * 获取回看的节目时间表 /json/schedule/{channelid}/{pageNo}/{pageSize}/{day}
     * 
     * @param channelid
     *            频道ID
     * @return 时间表列表
     * @throws ParseException
     */
    @RequestMapping(value = "/{channelid}/{day}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Page<Schedule> tvodschedule(@PathVariable("channelid") Long channelid, @PathVariable("day") String day, Page<Schedule> page) throws ParseException {
        Channel channel = channelDao.getChannel(channelid);
        Long time = System.currentTimeMillis() - channel.getTimeshiftduration() * 1000;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        List<Schedule> list = scheduleDao.getTvodSchedulelistPage(channelid, sdf.parse(day),new Date(time), page);
        SimpleDateFormat clocksdf = new SimpleDateFormat("yyyyMMddHHmmss");
        // 为返回结果设置endtime为下一个节目的starttime
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                Schedule schedule = list.get(i);
                if (i < list.size() - 1) {
                    schedule.setEndtime(list.get(i + 1).getStarttime());
                } else {
                    //当天最后一个节目的endtime 取第二天的第一个节目的starttime
                    //如第二天无节目则设为第二天的00时00分00秒
                    Calendar c = Calendar.getInstance();
                    c.setTime(sdf.parse(day));
                    c.add(Calendar.DAY_OF_MONTH, 1);
                    Schedule schedule2 = scheduleDao.getFirstSchedule(channelid, c.getTime());
                    if (schedule2 != null) {
                        schedule.setEndtime(schedule2.getStarttime());
                    } else {
                        schedule.setEndtime(c.getTime());
                    }
                }
                if (schedule.getStarttime().getTime() < time) { //开始时间小于录制点
                    schedule.setPlaystatus("1");//不可观看
                } else if (schedule.getEndtime().getTime() < System.currentTimeMillis()) { //开始时间大于等于录制点并且结束时间小于当前
                        schedule.setPlaystatus("2");//已录制 可回看
                        schedule.setTvodurl(channel.getTimeshifturl() + "?startTime=" + clocksdf.format(schedule.getStarttime()) + "&endTime="
                                + clocksdf.format(schedule.getEndtime()));
                } else if (schedule.getStarttime().getTime()< System.currentTimeMillis()) { //开始时间大于等于录制点并且结束时间大于等于当前，开始时间小于当前
                        schedule.setPlaystatus("3");//正在播放
                } else {
                        schedule.setPlaystatus("4");// 以及未播放
                }
                schedule.setTvodurl(channel.getTimeshifturl() + "?startTime=" + clocksdf.format(schedule.getStarttime()) + "&endTime="
                        + clocksdf.format(schedule.getEndtime()));
            }
        }
        page.setResult(list);
        return page;
    }
}
