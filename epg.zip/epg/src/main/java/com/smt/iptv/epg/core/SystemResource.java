package com.smt.iptv.epg.core;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Locale;
import java.util.Properties;
import java.util.ResourceBundle;

public class SystemResource {
    private static Locale locale = new Locale("zh", "CN"); 
    private static ResourceBundle resb = ResourceBundle.getBundle("system", locale); 
    
    public static String  getString(String key){
        return resb.getString(key);
    }
    public static Integer  getInteger(String key){
        return Integer.valueOf(resb.getString(key));
    }
}
