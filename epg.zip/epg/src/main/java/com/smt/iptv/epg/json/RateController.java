package com.smt.iptv.epg.json;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smt.iptv.epg.dao.RateDao;
import com.smt.iptv.epg.entity.Rate;
import com.smt.iptv.epg.entity.Symbol;

/**
 * 汇率相关接口
 * 
 * @author mills
 */
@Controller
@RequestMapping(value = "/json/rate")
public class RateController {

    @Autowired()
    private RateDao rateDao;
    /**
     * 返回指定币种的当天汇率 /json/rate/{selfsymbol}
     * @param selfsymbol 指定币种编码
     * @return 汇率列表
     */
    @RequestMapping(value = "/{selfsymbol}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<Rate> getRateToday(@PathVariable String selfsymbol) {
        return rateDao.findBySelfsymbolNewest(selfsymbol);
    }
    /**
     * 返回人民币的当天汇率/json/rate
     * @return 汇率列表
     */
    @RequestMapping(value = "", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<Rate> getRateToday2() {
        List<Rate> list = rateDao.findBySelfsymbolNewest("RMB");
        return list;
    }
    /**
     * 返回常用汇率的币种编码和名称/json/rate/symbol
     * @return List<Symbol> 币种列表
     */
    @RequestMapping(value = "/symbol", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<Symbol> getRateSymbols() {
        if("zh".equals(LocaleContextHolder.getLocale().getLanguage())){
            List<Symbol> list = new LinkedList<Symbol>();
            list.add(new Symbol("RMB", "人民币"));
            list.add(new Symbol("AUD", "澳大利亚元"));
            list.add(new Symbol("MOP", "澳门元"));
            list.add(new Symbol("DKK", "丹麦克朗"));
            list.add(new Symbol("PHP", "菲律宾比索"));
            list.add(new Symbol("HKD", "港币"));
            list.add(new Symbol("KRW", "韩元"));
            list.add(new Symbol("CAD", "加拿大元"));
            list.add(new Symbol("MYR", "林吉特"));
            list.add(new Symbol("RUB", "卢布"));
            list.add(new Symbol("USD", "美元"));
            list.add(new Symbol("NOK", "挪威克朗"));
            list.add(new Symbol("EUR", "欧元"));
            list.add(new Symbol("JPY", "日元"));
            list.add(new Symbol("SEK", "瑞典克朗"));
            list.add(new Symbol("CHF", "瑞士法郎"));
            list.add(new Symbol("THB", "泰国铢"));
            list.add(new Symbol("SGD", "新加坡元"));
            list.add(new Symbol("TWD", "新台币"));
            list.add(new Symbol("NZD", "新西兰元"));
            list.add(new Symbol("GBP", "英镑"));
            return list;
        }else{
            List<Symbol> list = new LinkedList<Symbol>();
            list.add(new Symbol("RMB", "Renminbi"));
            list.add(new Symbol("AUD", "Australian dollar"));
            list.add(new Symbol("MOP", "Patacas"));
            list.add(new Symbol("DKK", "Danish krone"));
            list.add(new Symbol("PHP", "Philippine Peso"));
            list.add(new Symbol("HKD", "Danish krone"));
            list.add(new Symbol("KRW", "Korean Won"));
            list.add(new Symbol("CAD", "Danish krone"));
            list.add(new Symbol("MYR", "Ringgit"));
            list.add(new Symbol("RUB", "rouble"));
            list.add(new Symbol("USD", "Dollar"));
            list.add(new Symbol("NOK", "Norwegian krone"));
            list.add(new Symbol("EUR", "Euro"));
            list.add(new Symbol("JPY", "Japanese yen"));
            list.add(new Symbol("SEK", "Swedish krona"));
            list.add(new Symbol("CHF", "Swiss franc"));
            list.add(new Symbol("THB", "Thai Baht"));
            list.add(new Symbol("SGD", "Singapore dollar"));
            list.add(new Symbol("TWD", "New Taiwan Currency"));
            list.add(new Symbol("NZD", "New Zealand dollar"));
            list.add(new Symbol("GBP", "Pound"));
            return list;
        }
    }
}
