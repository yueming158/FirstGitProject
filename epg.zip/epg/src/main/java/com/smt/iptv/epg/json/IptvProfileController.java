package com.smt.iptv.epg.json;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smt.iptv.epg.core.CryptCore;
import com.smt.iptv.epg.core.HttpJDKUtil;
import com.smt.iptv.epg.core.SystemConstant;
import com.smt.iptv.epg.dao.HotelDao;
import com.smt.iptv.epg.dao.ProfileDao;
import com.smt.iptv.epg.entity.ErrorCode;
import com.smt.iptv.epg.entity.Profile;
import com.smt.iptv.epg.entity.ProfileUserInfo;

/**
 * 用户登录相关接口
 * 
 * @author mills
 */
@Controller
@RequestMapping(value = "/json/profile")
public class IptvProfileController {

    @Autowired
    private ProfileDao profileDao;
    @Autowired
    private HotelDao hotelDao;
    /**
     * 获取登录数据必须加密的时间戳作为用户token 访问登录接口前必须使用 /json/profile/timesyn 用于DES加密
     */
    @RequestMapping(value = "/timesyn", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Long timesyn() {
        return System.currentTimeMillis();
    }

    /**
     * 登录接口 /json/profile/login 
     * //缺陷 明文  将来改进 密文
     */
    @RequestMapping(value = "/{iptvusername}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Object usernamelogin(@PathVariable("iptvusername")String iptvusername, String iptvpassword, String mac,
            @RequestParam(required=false)String token,
            @RequestParam(defaultValue="1.0",required=false)String stbversion, HttpServletRequest request) {
        
        //与西软同步start
//        final String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+request.getContextPath();
//        final String account=iptvusername;
//        if(StringUtils.isNotEmpty(SystemConstant.getValue("xr_pms_server"))){
//        new Thread(new Runnable() {
//            
//            @Override
//            public void run() {
//                // TODO Auto-generated method stub
//                Hotel hotel = hotelDao.getHotelRoomInfo(account);
//                if(hotel!=null){
//                    String guestname= PmsaController.guestinfo(hotel.getRoomno());
//                    if(guestname!=null){
//                        //如果客人名字有变化同步客房信息
//                        if(!guestname.equals(hotel.getCustomername())&&!guestname.equals(hotel.getEnglishname())){
//                            //1.2入住(包含数据不同步的退房逻辑)
//                           //String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+request.getContextPath();
//                            String url =basePath.replace("epg", "portal")+"/json/room/pmsacheckin";
//                            Calendar c = Calendar.getInstance();
//                            c.add(Calendar.DAY_OF_MONTH, 1);
//                            String param;
//                            try {
//                                param = "roomNo="+hotel.getRoomno()+"&name="+URLEncoder.encode(guestname, "UTF-8")
//                                        +"&beginTime="+new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date())
//                                        +"&endTime="+new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(c.getTime())
//                                        +"&identityCard=&sex=1&age=0";
//                                HttpJDKUtil.executeHttpPost(url, param);
//                            } catch (UnsupportedEncodingException e) {
//                                // TODO Auto-generated catch block
//                                e.printStackTrace();
//                            }
//                        }
//                    }
//                }
//            }
//        }).start();
//        }
      //与西软同步end
        
        // 新账号 账号中没有绑定mac 新盒子 盒子mac数据库中不存在 登录成功
        // 新账号 账号中没有绑定mac 旧盒子 盒子mac数据库中不存在
        // 旧账号 账号中绑定mac 账号查询出来的mac和盒子不匹配
        // 旧账号 账号中绑定mac 账号查询出来的mac和盒子匹配 登录成功

        // 1用mac macbak去查 如果存在 直接登录成功 无视账号密码
        // 2用mac macbak去查 数据库中都不存在这2个mac 
        // 2.1 新账号密码未通过 失败
        // 2.2 新账号密码通过 但绑定的其它mac 则失败
        // 2.3 新账号密码通过且未绑定过mac 则成功
        if(StringUtils.isEmpty(HttpJDKUtil.executeHttpGet(SystemConstant.getValue("license_server"), "utf-8"))){
            return new ErrorCode("608", "授权服务器无法访问");
        }
        if (StringUtils.isNotEmpty(mac)) {
            Profile macprofile = profileDao.getProfileByMac(mac);
            if (macprofile != null) {
                if(StringUtils.isNotEmpty(token)){
                    if(StringUtils.isNotEmpty(macprofile.getToken())&&!token.equals(macprofile.getToken())){
                        return new ErrorCode("606", "token不匹配，mac地址可能冲突");
                    }else{
                        macprofile.setToken(token);
                    }
                }
//                if(StringUtils.isNotEmpty(macprofile.getDistributeip())&&!macprofile.getDistributeip().equals(request.getRemoteHost())){
//                    return new ErrorCode("607", "IP不匹配，机顶盒未使用规定的IP地址");
//                }
                if(iptvusername.equals(macprofile.getIptvusername())){
                    macprofile.setIpaddress(request.getRemoteHost());
                    macprofile.setStbversion(stbversion);
                    profileDao.updateIpaddress(macprofile);
                    if(StringUtils.isEmpty(macprofile.getRoomname()) ){
                        return new ErrorCode("604", "该账号尚未绑定房间");
                    }
                    return macprofile;
                }else{
                    return new ErrorCode("601", "上次登录账号为"+macprofile.getIptvusername());
                }
            } else {
                Profile userprofile = profileDao.getProfile(iptvusername, iptvpassword);
                if (userprofile == null) {
                    return new ErrorCode("602", "账号或密码不正确");
                } else {
                    if (StringUtils.isEmpty(userprofile.getMacaddress())) {
                        userprofile.setMacaddress(mac);
                        userprofile.setToken(token);
                        userprofile.setIpaddress(request.getRemoteHost());
                        userprofile.setStbversion(stbversion);
                        userprofile.setStatus("1");
                        profileDao.updateInstallInfo(userprofile);
                        if(StringUtils.isEmpty(userprofile.getRoomname()) ){
                            return new ErrorCode("604", "该账号尚未绑定房间");
                        }
                        return userprofile;
                    } else {
                        return new ErrorCode("603", "该账号已被其它设备绑定");
                    }
                }
            }
        }else{
            return new ErrorCode("605", "设备ID不能为空");
        }
    }

    
//    /**
//     * 密文登录接口 /json/profile/login 
//     */
//    @RequestMapping(value = "/login/{cipher}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
//    @ResponseBody
//    public Object login(@PathVariable("cipher")String cipher,HttpServletRequest request) {
//        String ciphertext = CryptCore.decryptByDES(cipher);
//         if (ciphertext.length() > 13 && ciphertext.substring(0,13).matches("\\d+")) {
//             if (System.currentTimeMillis() - Long.parseLong(ciphertext.substring(0,13)) < 1200000)// 100秒
//             {
//                 String [] loginStr =ciphertext.substring(13).split(",");
//                 String iptvusername = loginStr[0];
//                 String iptvpassword = loginStr[1];
//                 String mac = loginStr[2];
//                 String stbversion = loginStr.length==4?loginStr[3]:"";
//                 return usernamelogin(iptvusername, iptvpassword, mac,stbversion, request);
//             }
//         }
//        return new ErrorCode("10006", "认证信息不正确或过期");
//    }
    
    
    // /**
    // * 登录接口 /json/profile/{mac}
    // * @param ciphertext 时间戳token（/json/profile/timesyn接口返回）+Mac地址之后再DES加密
    // * @return 登录失败返回 ErrorCode对象 登录成功返回Profile对象
    // http://localhost:8080/epg/json/profile/10003 ?iptvpassword=111111
    // */
    // @RequestMapping(value = "/maclogin/{ciphertext}", method =
    // RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    // @ResponseBody
    // public Object maclogin(@PathVariable("ciphertext")String ciphertext,
    // Profile loginProfile, HttpServletRequest request) {
    // //传递的是密文 则解密 解密后用mac登陆
    // ciphertext = CryptCore.decryptByDES(ciphertext);
    // if (ciphertext.length() > 13 && ciphertext.substring(0,
    // 13).matches("\\d+")) {
    // if (System.currentTimeMillis() - Long.parseLong(ciphertext.substring(0,
    // 13)) < 1200000)// 100秒
    // {
    // String mac = ciphertext.substring(13);
    // Profile profile = new Profile();
    // profile = profileDao.getProfile(mac);
    // if (profile == null) {
    // return new ErrorCode("10002", "该设备未激活");
    // } else {
    // if ("0".equals(profile.getStatus())||"1".equals(profile.getStatus()))
    // {//状态未激活则修改为激活
    // profile.setCode("200");
    // if(!request.getRemoteHost().equals(profile.getIpaddress())||"0".equals(profile.getStatus())){
    // profile.setStatus("1");
    // profile.setIpaddress(request.getRemoteHost());
    // profile.setInteracpassword(10000000+new Random().nextInt(90000000)+"");
    // profileDao.updateInstallInfo(profile);
    // }
    // return profile;
    // } else {
    // return new ErrorCode("10003", "无法登录，用户状态为：" + profile.getStatus());
    // }
    // }
    // }
    // }
    // return new ErrorCode("10001", "请求异常");
    // }

    /**
     * 获取用户的一些个人信息的接口 /json/profile/{iptvusername}/userinfo
     * 
     * @param iptvusername
     *            用户名
     * @return ProfileUserInfo对象
     */
    @RequestMapping(value = "/{iptvusername}/userinfo", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public ProfileUserInfo getprofileuserinfo(@PathVariable("iptvusername") String iptvusername) {
        return profileDao.getUserinfo(iptvusername);
    }

    /**
     * @param interacpassword wifi密码
     */
    @RequestMapping(value = "/interaction/{interacpassword}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Object login(@PathVariable("interacpassword") String interacpassword) {
        Profile p = profileDao.getProfileByInteracpassword(interacpassword);
        if (p != null) {
            return p;
        } else {
            return new ErrorCode("10004", "WIFI动态密码不正确");
        }
    }
}
