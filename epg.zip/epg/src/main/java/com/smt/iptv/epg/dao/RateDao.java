package com.smt.iptv.epg.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.smt.iptv.epg.entity.Rate;
@MyBatisRepository
public interface RateDao{
    public List<Rate> findBySelfsymbolNewest(@Param("selfsymbol")String selfsymbol);
    
    //public List<Rate> findBySelfsymbolNewest("RMB");
    
}
