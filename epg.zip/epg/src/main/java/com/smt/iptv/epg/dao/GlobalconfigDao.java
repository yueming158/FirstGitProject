package com.smt.iptv.epg.dao;

import java.util.List;

import com.smt.iptv.epg.entity.Globalconfig;

@MyBatisRepository
public interface GlobalconfigDao {
	List<Globalconfig> findAll();
}
