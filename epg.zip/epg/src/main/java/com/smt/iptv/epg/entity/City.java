package com.smt.iptv.epg.entity;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.epg.core.IdEntity;


public class City extends IdEntity {

    private String cityname;
    private String cityaircode;
    private String cityweathercode;

    public String getCityname() {
        return cityname;
    }

    public void setCityname(String cityname) {
        this.cityname = cityname;
    }

    public String getCityaircode() {
        return cityaircode;
    }

    public void setCityaircode(String cityaircode) {
        this.cityaircode = cityaircode;
    }

    public String getCityweathercode() {
        return cityweathercode;
    }

    public void setCityweathercode(String cityweathercode) {
        this.cityweathercode = cityweathercode;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}