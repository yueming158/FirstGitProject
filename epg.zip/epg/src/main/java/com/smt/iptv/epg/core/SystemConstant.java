package com.smt.iptv.epg.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;

import com.google.common.collect.Lists;
import com.smt.iptv.epg.service.mail.AlarmMailSendCallbackImpl;
import com.smt.iptv.epg.service.mail.SimpleMailUtil;

public class SystemConstant {

    private static HashMap<String, String> map = new HashMap<String, String>(48);
    //直播状态列表
    private static ConcurrentHashMap<String, String> liveserver = new ConcurrentHashMap<String, String>();
    //点播状态列表
    private static ConcurrentHashMap<String, String> vodserver = new ConcurrentHashMap<String, String>();
    //发送标志
    private static HashMap<String, Boolean> mailsendFlagMap = new HashMap<String, Boolean>();
    //取消发送标志
    public static void cancelSendFlag(String key){
        mailsendFlagMap.remove(key);
    }
    public static void put(String key ,String value){
        map.put(key, value);
    }
    
    public static String getValue(String name) {
        return map.get(name);
    }

    public static String getURLValue(String name) {
        String url = map.get(name);
        if (url == null) {
            return "";
        } else {
            return url.endsWith("/") ? url : url + "/";
        }
    }
//    //有多线程并发问题 但是可以忽略 几率太小
//    public static List<String> getNotEmptyURLWithLikeName(String likename) {
//        List<String> list =new ArrayList<String>();
//        for(String key:map.keySet()){
//            if(key.startsWith(likename)){
//                String url = map.get(key);
//                if (StringUtils.isNotBlank(url)) {
//                    url= url.endsWith("/") ? url : url + "/";
//                    list.add(url);
//                }
//            }
//        }
//        return list;
//    }
    
    public static List<String> getLiveServerList() {
        List<String> list = Lists.newArrayList();
        for(Entry<String, String> entry:liveserver.entrySet()){
            list.add(entry.getValue());
        }
        return list;
    }
    public static List<String> getVodServerList() {
        List<String> list = Lists.newArrayList();
        for(Entry<String, String> entry:vodserver.entrySet()){
            list.add(entry.getValue());
        }
        return list;
    }
    
    public static void checkServer() {
        List<String> list =new ArrayList<String>();
        for(String key:map.keySet()){
            if(key!=null&&key.startsWith("CDN_server_address") && "on".equals(SystemConstant.getValue("load_balancing"))){
                //直播
                String url = map.get(key);
                if (StringUtils.isNotBlank(url)) {
                    if(url.matches("http://\\d+\\.\\d+\\.\\d+\\.\\d+:\\d+/*")){
                        url= url.endsWith("/") ? url : url + "/";
                        int index =url.lastIndexOf(":");
                        String ip=url.substring(7, index);
                        String port=url.substring(index+1,url.length()-1);
                        if(TelnetUtil.getHostStatus(ip,Integer.parseInt(port))){
                            list.add(url);
                            liveserver.put(key, url);
                            //取消标记
                            mailsendFlagMap.remove(key);
                        }else{
                            liveserver.remove(key);
                            //发送邮件 回调函数处理发送失败 取消发送标志
                          if(mailsendFlagMap.get(key)==null){
                              if(getValue("alarm_mail_receiver")!=null){
                                  SimpleMailUtil.sendNotificationMail(getValue("alarm_mail_receiver").split(","), 
                                      getValue("alarm_mail_subject"),
                                      "项目:"+getValue("license_code")+",直播服务器("+key+"于"+DateFormatUtils.format(System.currentTimeMillis(), "yyyy-MM-dd HH:mm:ss")+"发生异常",
                                      new AlarmMailSendCallbackImpl(key,3600000));
                              }
                          }
                          //标记邮件已发送
                          mailsendFlagMap.put(key,true);
                        }
                    }else{
                        liveserver.remove(key);
                    }
                }
                else{
                    liveserver.remove(key);
                }
            }else if(key!=null&&key.startsWith("CDN_httpserver_address") && "on".equals(SystemConstant.getValue("load_balancing_vod"))){
                //点播
                String url = map.get(key);
                if (StringUtils.isNotBlank(url)) {
                    if(url.matches("http://\\d+\\.\\d+\\.\\d+\\.\\d+:\\d+/.*")){
                        url= url.endsWith("/") ? url : url + "/";
                        int index =url.lastIndexOf(":");
                        String ip=url.substring(7, index);
                        String port=url.substring(index+1);
                        port =port.substring(0, port.indexOf("/"));
                        if(TelnetUtil.getHostStatus(ip,Integer.parseInt(port))){
                            list.add(url);
                            vodserver.put(key, url);
                            //取消标记
                            mailsendFlagMap.remove(key);
                        }else{
                            vodserver.remove(key);
                            //发送邮件 回调函数处理发送失败 取消发送标志
                            if(mailsendFlagMap.get(key)==null){
                                if(getValue("alarm_mail_receiver")!=null){
                                    SimpleMailUtil.sendNotificationMail(getValue("alarm_mail_receiver").split(","), 
                                        getValue("alarm_mail_subject"),
                                        "项目:"+getValue("license_code")+",点播服务器("+key+"于"+DateFormatUtils.format(System.currentTimeMillis(), "yyyy-MM-dd HH:mm:ss")+"发生异常",
                                        new AlarmMailSendCallbackImpl(key,3600000));                            
                                }
                            }
                            //标记邮件已发送
                            mailsendFlagMap.put(key,true);
                        }
                    }
                    else{
                        vodserver.remove(key);
                    }
                }else{
                    vodserver.remove(key);
                }
            }
        }
    }
    
    public static void main(String[] args) {
        map.put("a", null);
        //map.put("a", "4");
        map.put("b", "2");
        map.put("c", "3");
        map.put(null, "3");
        System.out.println(map.get(null));//result:3
        System.out.println(map.get("a"));//result:4
        System.out.println(mailsendFlagMap.get("d")==null);//result:null
//        
//        
//        map.put("CDN_server_address", "http://192.168.11.247:8180/");
//        map.put("CDN_server_address1", "http://192.168.1.247:8180/");
//        map.put("CDN_server_address2", "http://192.168.1.242:8180");
//        map.put("CDN_server_address3", "http://10.18.1.247:80/");
//        
//        map.put("CDN_httpserver_address_f", "http://192.168.1.247:9999/vod/");
//        map.put("CDN_httpserver_address_f2", "http://192.168.1.248:9999/vod/");
//        map.put("CDN_httpserver_address_f3", "http://192.168.1.242:9999/vod");
//        map.put("CDN_httpserver_address_f4", "http://10.18.1.247:9999/vod");
//        
//        checkServer();
//        System.out.println(liveserver);
//        System.out.println(vodserver);
    }
}