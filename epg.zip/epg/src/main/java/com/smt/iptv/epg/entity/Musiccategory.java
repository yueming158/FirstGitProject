package com.smt.iptv.epg.entity;

import com.smt.iptv.epg.core.IdEntity;

public class Musiccategory extends IdEntity{
    public Musiccategory() {
    }

    public Musiccategory(Long id) {
        this.id = id;
    }
    private String name;
    private Integer typeid;
    private Integer sequence;
    
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public Integer getTypeid() {
        return typeid;
    }
    public void setTypeid(Integer typeid) {
        this.typeid = typeid;
    }
    public Integer getSequence() {
        return sequence;
    }
    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

}
