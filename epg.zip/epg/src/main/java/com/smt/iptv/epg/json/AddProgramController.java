package com.smt.iptv.epg.json;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smt.iptv.epg.dao.ProgramDao;
import com.smt.iptv.epg.entity.MediaContent;
import com.smt.iptv.epg.entity.Page;
import com.smt.iptv.epg.entity.Program;
import com.smt.iptv.epg.service.program.ProgramService;

/**
 * 点播相关接口
 * 
 * @author mills
 */
@Controller
@RequestMapping(value = "/addprogram")
public class AddProgramController {

    @Autowired
    private ProgramService programService;

    //http://192.168.1.248:9999/epg/addprogram
    //?programname=我的录像 Program
    //&year=2014 Program
    //&starrating=100 Program
    //&areaname=中国 Program
    //&programtype=10 Program
    //&genrenames=实时录像 Program
    //&actornames=name1 Program
    //&writernames=name2 Program
    //&description=内容简介 Program
    //&sourcefile=ftp://ftpusername:password@192.168.1.248/record/dir/xxx.mp4
    //&duration=7200000 Program
    @RequestMapping(value = "",method = {RequestMethod.POST,RequestMethod.GET},produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public String addprogram(Program program,String sourcefile) {
        try{
            programService.add( program, sourcefile);
        }catch (Exception e) {
            return "{\"code\":\"500\",\"desc\":\""+e.getMessage()+"\"}";
        }
        return "{\"code\":\"200\",\"desc\":\"\"}";
    }

}
