package com.smt.iptv.epg.dao;

import org.apache.ibatis.annotations.Param;

import com.smt.iptv.epg.entity.Profile;
import com.smt.iptv.epg.entity.ProfileUserInfo;

@MyBatisRepository
public interface ProfileDao {

	Profile getProfile(@Param("iptvusername") String iptvusername,@Param("iptvpassword") String iptvpassword);

	Profile getProfileByMac(@Param("macaddress") String macaddress);

	String getChannelgroup(String userId);
	
	void updateInstallInfo(Profile profile);
	
	void updateIpaddress(Profile profile);
	
	ProfileUserInfo getUserinfo(String iptvusername);
	
	Profile getProfileByInteracpassword(String password);
	
}
