package com.smt.iptv.epg.service.qrcode;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.imageio.ImageIO;

import jp.sourceforge.qrcode.QRCodeDecoder;
import jp.sourceforge.qrcode.exception.DecodingFailedException;

import com.swetake.util.Qrcode;

public class TwoDimensionCode {
    
    /**
     * 生成二维码(QRCode)图片
     * @param content 存储内容
     * @param imgPath 图片路径
     * @param imgPath logo文件
     */
    public void encoderQRCode(String content, String imgPath,File ccbFile) {
        this.encoderQRCode(content, imgPath, "png", 7,ccbFile);
    }
    
    /**
     * 生成二维码(QRCode)图片
     * @param content 存储内容
     * @param output 输出流
     * @param imgPath logo文件
     */
    public void encoderQRCode(String content, OutputStream output,File ccbFile) {
        this.encoderQRCode(content, output, "png", 7,ccbFile);
    }
    
    /**
     * 生成二维码(QRCode)图片
     * @param content 存储内容
     * @param imgPath 图片路径
     * @param imgType 图片类型
     * @param imgPath logo文件
     */
    public void encoderQRCode(String content, String imgPath, String imgType,File ccbFile) {
        this.encoderQRCode(content, imgPath, imgType, 7,ccbFile);
    }
    
    /**
     * 生成二维码(QRCode)图片
     * @param content 存储内容
     * @param output 输出流
     * @param imgType 图片类型
     * @param imgPath logo文件
     */
    public void encoderQRCode(String content, OutputStream output, String imgType,File ccbFile) {
        this.encoderQRCode(content, output, imgType, 7,ccbFile);
    }

    /**
     * 生成二维码(QRCode)图片
     * @param content 存储内容
     * @param imgPath 图片路径
     * @param imgType 图片类型
     * @param size 二维码尺寸
     * @param imgPath logo文件
     */
    public void encoderQRCode(String content, String imgPath, String imgType, int size,File ccbFile) {
        try {
            BufferedImage bufImg = this.qRCodeCommon(content, imgType, size,ccbFile);
            
            File imgFile = new File(imgPath);
            // 生成二维码QRCode图片
            ImageIO.write(bufImg, imgType, imgFile);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 生成二维码(QRCode)图片
     * @param content 存储内容
     * @param output 输出流
     * @param imgType 图片类型
     * @param size 二维码尺寸
     * @param imgPath logo文件
     */
    public void encoderQRCode(String content, OutputStream output, String imgType, int size,File ccbFile) {
        try {
            BufferedImage bufImg = this.qRCodeCommon(content, imgType, size, ccbFile);
            // 生成二维码QRCode图片
            ImageIO.write(bufImg, imgType, output);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
     * 生成二维码(QRCode)图片的公共方法
     * @param content 存储内容
     * @param imgType 图片类型
     * @param size 二维码尺寸
     * @param imgPath logo文件
     * @return
     */
    private BufferedImage qRCodeCommon(String content, String imgType, int size,File ccbFile) {
        BufferedImage bufImg = null;
        try {
            Qrcode qrcodeHandler = new Qrcode();
            // 设置二维码排错率，可选L(7%)、M(15%)、Q(25%)、H(30%)，排错率越高可存储的信息越少，但对二维码清晰度的要求越小
            qrcodeHandler.setQrcodeErrorCorrect('H');
            qrcodeHandler.setQrcodeEncodeMode('B');
            // 设置设置二维码尺寸，取值范围1-40，值越大尺寸越大，可存储的信息越大
            qrcodeHandler.setQrcodeVersion(size);
            // 获得内容的字节数组，设置编码格式
            byte[] contentBytes = content.getBytes("utf-8");
            // 图片尺寸
            int imgSize = 67 + 12 * (size - 1);
            bufImg = new BufferedImage(imgSize, imgSize, BufferedImage.TYPE_INT_RGB);
            Graphics2D gs = bufImg.createGraphics();
            // 设置背景颜色
            gs.setBackground(Color.WHITE);
            gs.clearRect(0, 0, imgSize, imgSize);

            // 设定图像颜色> BLACK
            gs.setColor(Color.BLACK);
            // 设置偏移量，不设置可能导致解析出错
            int pixoff = 2;
            // 输出内容> 二维码
            if (contentBytes.length > 0 && contentBytes.length < 800) {
                boolean[][] codeOut = qrcodeHandler.calQrcode(contentBytes);
                for (int i = 0; i < codeOut.length; i++) {
                    for (int j = 0; j < codeOut.length; j++) {
                        if (codeOut[j][i]) {
                            gs.fillRect(j * 3 + pixoff, i * 3 + pixoff, 3, 3);
                        }
                    }
                }
            } else {
                throw new Exception("QRCode content bytes length = " + contentBytes.length + " not in [0, 800].");
            }
            if(ccbFile!=null){
                Image img = ImageIO.read(ccbFile);//实例化一个Image对象。
                img =  img.getScaledInstance(4 * (size - 1), 4 * (size - 1), 0);//
                gs.drawImage(img, (67 + 12 * (size - 1))/2-2*(size-1), (67 + 12 * (size - 1))/2-2*(size-1), null);
            }
            gs.dispose();
            bufImg.flush();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bufImg;
    }
    
    /**
     * 解析二维码（QRCode）
     * @param imgPath 图片路径
     * @return
     */
    public String decoderQRCode(String imgPath) {
        // QRCode 二维码图片的文件
        File imageFile = new File(imgPath);
        BufferedImage bufImg = null;
        String content = null;
        try {
            bufImg = ImageIO.read(imageFile);
            QRCodeDecoder decoder = new QRCodeDecoder();
            content = new String(decoder.decode(new TwoDimensionCodeImage(bufImg)), "utf-8"); 
        } catch (IOException e) {
            e.printStackTrace();
        } catch (DecodingFailedException dfe) {
            dfe.printStackTrace();
        }
        return content;
    }
    
    /**
     * 解析二维码（QRCode）
     * @param input 输入流
     * @return
     */
    public String decoderQRCode(InputStream input) {
        BufferedImage bufImg = null;
        String content = null;
        try {
            bufImg = ImageIO.read(input);
            QRCodeDecoder decoder = new QRCodeDecoder();
            content = new String(decoder.decode(new TwoDimensionCodeImage(bufImg)), "utf-8"); 
        } catch (IOException e) {
            e.printStackTrace();
        } catch (DecodingFailedException dfe) {
            dfe.printStackTrace();
        }
        return content;
    }
    
    /**
     * 图像缩放
     * @param srcPath
     * @param targetPath
     * @param scale
     */
    public void zoom(String srcPath, String targetPath, float scale)
    {  
           try
           {  
               BufferedImage src = ImageIO.read(new File(srcPath));  // 读入源图像   
               int width = src.getWidth();        // 源图宽  
               int height = src.getHeight();        // 源图高  
                                
               //  获取一个宽、长是原来scale的图像实例  
               Image image = src.getScaledInstance((int)(width * scale), (int)(height * scale), Image.SCALE_DEFAULT); 
              
               //缩放图像
               BufferedImage tag = new BufferedImage((int)(width * scale), (int)(height * scale), BufferedImage.TYPE_INT_RGB);    
               Graphics2D g = tag.createGraphics();  
              
               g.drawImage(image, 0, 0, null); // 绘制缩小后的图  
               g.dispose();  
                
               OutputStream out = new FileOutputStream(targetPath);  
               ImageIO.write(tag, "GIF", out);// 输出
               out.close();  
           }
           catch (IOException e)
           {  
               e.printStackTrace();  
           }
    }
    
    
    public static void main(String[] args) throws FileNotFoundException {
        String imgPath = "D:/qrcode.png";
        String encoderContent = "http://192.168.1.120:9999/epg/appinfo/qrcode.png";
        TwoDimensionCode handler = new TwoDimensionCode();

        File imgFile = new File("d:/qrcode2.png");
        // 生成二维码QRCode图片
        FileOutputStream out = new FileOutputStream(imgFile);
        handler.encoderQRCode(encoderContent, out, "png", 7,new File("D:/logo.png"));
    }
}