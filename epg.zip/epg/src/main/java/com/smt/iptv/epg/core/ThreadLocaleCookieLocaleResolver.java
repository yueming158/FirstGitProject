package com.smt.iptv.epg.core;

import java.util.Locale;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.i18n.CookieLocaleResolver;
import org.springframework.web.util.WebUtils;

public class ThreadLocaleCookieLocaleResolver extends CookieLocaleResolver{
    @Override
    public Locale resolveLocale(HttpServletRequest request) {
        // Check request for pre-parsed or preset locale.
        Locale locale = (Locale) request.getAttribute(LOCALE_REQUEST_ATTRIBUTE_NAME);
        if (locale != null) {
            LocaleContextHolder.setLocale(locale);
            return locale;
        }
        // Retrieve and parse cookie value.
        Cookie cookie = WebUtils.getCookie(request, getCookieName());
        if (cookie != null) {
            locale = StringUtils.parseLocaleString(cookie.getValue());
//            if (logger.isDebugEnabled()) {
//                logger.debug("Parsed cookie value [" + cookie.getValue() + "] into locale '" + locale + "'");
//            }
            if (locale != null) {
                request.setAttribute(LOCALE_REQUEST_ATTRIBUTE_NAME, locale);
                LocaleContextHolder.setLocale(locale);
                return locale;
            }
        }
        locale= determineDefaultLocale(request);
        LocaleContextHolder.setLocale(locale);
        return locale;
    }

}
