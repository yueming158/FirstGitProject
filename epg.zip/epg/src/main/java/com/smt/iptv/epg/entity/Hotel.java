package com.smt.iptv.epg.entity;

import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.smt.iptv.epg.core.IdEntity;

public class Hotel extends IdEntity {
    public Hotel() {
    }

    public Hotel(Long id) {
        this.id = id;
    }
	private String hotelname;
	private String hotellogo;
	private String hotelimage;
	//客户属性
	private Long checkinid;
	private String customername;
	@JsonIgnore
	private String englishname;
    private String sex;
    private Date checkintime;
    private Date checkouttime;
    private String roomname;// 只是为了欢迎词界面
    @JsonIgnore
	private String roomno;
	private String welcome;


    public String getHotelname() {
        return hotelname;
    }

    public void setHotelname(String hotelname) {
        this.hotelname = hotelname;
    }

    public String getHotellogo() {
        return hotellogo;
    }

    public void setHotellogo(String hotellogo) {
        this.hotellogo = hotellogo;
    }

    public String getHotelimage() {
        return hotelimage;
    }

    public void setHotelimage(String hotelimage) {
        this.hotelimage = hotelimage;
    }

    public String getCustomername() {
        return customername;
    }

    public void setCustomername(String customername) {
        this.customername = customername;
    }

    public String getEnglishname() {
        return englishname;
    }

    public void setEnglishname(String englishname) {
        this.englishname = englishname;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public Date getCheckintime() {
        return checkintime;
    }

    public void setCheckintime(Date checkintime) {
        this.checkintime = checkintime;
    }

    public Date getCheckouttime() {
        return checkouttime;
    }

    public void setCheckouttime(Date checkouttime) {
        this.checkouttime = checkouttime;
    }


    public String getRoomname() {
        return roomname;
    }

    public void setRoomname(String roomname) {
        this.roomname = roomname;
    }

    public String getRoomno() {
        return roomno;
    }

    public void setRoomno(String roomno) {
        this.roomno = roomno;
    }

    public String getWelcome() {
        return welcome;
    }

    public void setWelcome(String welcome) {
        this.welcome = welcome;
    }

    public Long getCheckinid() {
        return checkinid;
    }

    public void setCheckinid(Long checkinid) {
        this.checkinid = checkinid;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}