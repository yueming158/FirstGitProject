package com.smt.iptv.epg.core;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.SocketException;

import org.apache.commons.io.IOUtils;
import org.apache.commons.net.ftp.FTPClient;

import com.smt.iptv.epg.entity.Program;
import com.smt.iptv.epg.service.program.ProgramService;

public class AsyncFtpClient implements Runnable {
    ProgramService programService;
    Program program;
    String sourcefile;

    public AsyncFtpClient(Program program,String sourcefile,ProgramService programService) {
        this.programService = programService;
        this.program = program;
        this.sourcefile = sourcefile;
    }

    @Override
    public void run() {
        FTPClient ftp = new FTPClient();
        try {
            String username= sourcefile.split("@")[0].split(":")[1].substring(2);
            String pwd= sourcefile.split("@")[0].split(":")[2];
            String ip= sourcefile.split("@")[1].split("/")[0];
            String home= sourcefile.split("@")[1].substring(ip.length(),sourcefile.split("@")[1].lastIndexOf("/"));
            String fileName= sourcefile.split("@")[1].substring(sourcefile.split("@")[1].lastIndexOf("/")+1);
            ftp.connect(ip);
            // 如果采用默认端口，可以使用ftp.connect(url)的方式直接连接FTP服务器
            ftp.login(username, pwd);// 登录
            ftp.changeWorkingDirectory(home);
            OutputStream out = new FileOutputStream(SystemConstant.getURLValue("cdn_httpserver_local_path")+fileName);
            ftp.retrieveFile(fileName, out);
            IOUtils.closeQuietly(out);
            //文件下载完成后插入数据
            programService.addTodb(program, sourcefile);
        } catch (SocketException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}