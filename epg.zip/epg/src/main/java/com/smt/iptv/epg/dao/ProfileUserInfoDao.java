package com.smt.iptv.epg.dao;

import com.smt.iptv.epg.entity.ProfileUserInfo;

@MyBatisRepository
public interface ProfileUserInfoDao {
	ProfileUserInfo getUserinfo(ProfileUserInfo profileinfo);
}
