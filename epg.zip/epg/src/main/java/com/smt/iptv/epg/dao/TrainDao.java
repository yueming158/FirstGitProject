package com.smt.iptv.epg.dao;

import java.util.List;

import com.smt.iptv.epg.entity.Traincode;
import com.smt.iptv.epg.entity.Trainschedule;

@MyBatisRepository
public interface TrainDao  {
    List<Traincode>  listbytype(String type);
    List<Traincode>  listall();
    List<Traincode>  listexclude(String type);
	List<Trainschedule>  schedule(String traincode);
}
