package com.smt.iptv.epg.entity;

import java.util.List;

import com.smt.iptv.epg.core.IdEntity;

public class Musiccategorytype extends IdEntity{
    public Musiccategorytype() {
    }

    public Musiccategorytype(Long id) {
        this.id = id;
    }
    private String name;
    private String code;
    private List<Musiccategory> lists;
    
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getCode() {
        return code;
    }
    public void setCode(String code) {
        this.code = code;
    }
    public List<Musiccategory> getLists() {
        return lists;
    }
    public void setLists(List<Musiccategory> lists) {
        this.lists = lists;
    }

    

}
