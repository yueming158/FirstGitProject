package com.smt.iptv.epg.entity;

public class PushServerAddress {

    public PushServerAddress() {
        super();
    }
    public PushServerAddress(String ip, Integer port) {
        super();
        this.ip = ip;
        this.port = port;
    }
    private String ip;
    private Integer port;
    public String getIp() {
        return ip;
    }
    public void setIp(String ip) {
        this.ip = ip;
    }
    public Integer getPort() {
        return port;
    }
    public void setPort(Integer port) {
        this.port = port;
    }

}