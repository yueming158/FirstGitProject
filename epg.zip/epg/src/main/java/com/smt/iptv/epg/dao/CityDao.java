package com.smt.iptv.epg.dao;

import java.util.List;

import com.smt.iptv.epg.entity.City;

@I18nMyBatisRepository
public interface CityDao {
	List<City> findAll();
	City getByWeathercode(String weathercode);
}
