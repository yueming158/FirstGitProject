package com.smt.iptv.epg.dao;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.smt.iptv.epg.entity.Weather;
@MyBatisRepository
public interface WeatherDao{
	
    Weather findByCitycodeAndWeatherdate(@Param("citycode")String citycode,@Param("date") Date date);
    
    List<Weather> findByCitycodeAndWeatherdateBetween(@Param("citycode") String citycode,@Param("startDate") Date startDate,@Param("endDate") Date endDate);
}
