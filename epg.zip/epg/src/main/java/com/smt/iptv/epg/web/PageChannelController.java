package com.smt.iptv.epg.web;

import java.util.List;

import javax.servlet.ServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.smt.iptv.epg.dao.ChannelDao;
import com.smt.iptv.epg.entity.Channel;

/**
 * @author xjw
 */
@Controller
@RequestMapping(value = "/channel")
public class PageChannelController {

    @Autowired
    private ChannelDao channelDao;
    
	@RequestMapping(value = "/list")
	public String list(
			Model model, String groupId,ServletRequest request) {
	    List<Channel> channels = channelDao.getAllChannel(groupId);
	    model.addAttribute("channels", channels);
	    if(channels!=null){
	        model.addAttribute("channelsize", channels.size());
	    }
		return "channel/live_channel";
	}
	
	   @RequestMapping(value = "/play")
	    public String play(Integer channelnumber,String groupId,
	            Model model, ServletRequest request) {
	        List<Channel> channelList = channelDao.getAllChannel(groupId);
	        String channelArrStr="";
	        StringBuffer sb = new StringBuffer();
	        for(Channel c:channelList)
	        {
	            sb.append("[").append(c.getChannelnumber())
	            .append(",'")
	            .append(c.getChannelname())
	            .append("',")
	            .append(c.getTimeshift())
	            .append("],");
	        }
	        if(sb.length()>1)
	        {
	            channelArrStr="["+sb.substring(0,sb.length()-1)+"]";
	        }
	        else
	        {
	            channelArrStr="[]";
	        } 
	        model.addAttribute("channelArrStr", channelArrStr);
	        return "channel/channel_play";
	    }
}
