package com.smt.iptv.epg.entity;

import java.util.Date;

import com.smt.iptv.epg.core.IdEntity;

public class Hoteloperation extends IdEntity{
    private String iptvuser;
    private String operation;
    private Date time;
    private Date creationtime;
    public String getIptvuser() {
        return iptvuser;
    }
    public void setIptvuser(String iptvuser) {
        this.iptvuser = iptvuser;
    }
    public String getOperation() {
        return operation;
    }
    public void setOperation(String operation) {
        this.operation = operation;
    }
    public Date getTime() {
        return time;
    }
    public void setTime(Date time) {
        this.time = time;
    }
    public Date getCreationtime() {
        return creationtime;
    }
    public void setCreationtime(Date creationtime) {
        this.creationtime = creationtime;
    }
    
    
}
