/**
 * Copyright (c) 2005-2010 springside.org.cn
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * 
 * $Id: Page.java 1183 2010-08-28 08:05:49Z calvinxiu $
 */
package com.smt.iptv.epg.core;

import java.util.ArrayList;
import java.util.List;

import org.springframework.util.StringUtils;

/**
 *主要用于不显示总记录数的分页模型
 *查询时需要 查询需要的记录数多一条 如每页10条记录 则查询11条，如果查询结果11条则说明有下一页
 *如果查询出0条记录，则返回数据库最后pageSize条记录
 * @param <T> SimplePage中记录的类型.
 * @author xjw
 */
public class SimplePage<T> {

	//-- 分页参数 --//
	protected int pageNo = 1;
	protected int pageSize = 10;
	//-- 返回结果 --//
	protected List<T> result = new ArrayList<T>();
	protected T param ;

	//-- 构造函数 --//
	public SimplePage() {
	}

	public SimplePage(int pageSize) {
		this.pageSize = pageSize;
	}

	//-- 分页参数访问函数 --//
	/**
	 * 获得当前页的页号,序号从1开始,默认为1.
	 */
	public int getPageNo() {
		return pageNo;
	}

	/**
	 * 设置当前页的页号,序号从1开始,低于1时自动调整为1.
	 */
	public void setPageNo(final int pageNo) {
		this.pageNo = pageNo;
		if (pageNo < 1) {
			this.pageNo = 1;
		}
	}


	/**
	 * 获得每页的记录数量, 默认为10.
	 */
	public int getPageSize() {
		return pageSize;
	}

	/**
	 * 设置每页的记录数量.
	 */
	public void setPageSize(final int pageSize) {
		this.pageSize = pageSize;
	}

	/**
	 * 根据pageNo和pageSize计算当前页第一条记录在总结果集中的位置,序号从0开始.
	 */
	public int getFirst() {
		return ((pageNo - 1) * pageSize);
	}

	//-- 访问查询结果函数 --//
	/**
	 * 获得页内的记录列表.
	 */
	public List<T> getResult() {
		return result;
	}

	/**
	 * 设置页内的记录列表.
	 */
	public void setResult(final List<T> result) {
		this.result = result;
	}



	/**
	 * 是否还有下一页.
	 */
	public boolean isHasNext() {
		return (result.size()>pageSize);
	}

	/**
	 * 取得下页的页号, 序号从1开始.
	 * 当前页为尾页时仍返回尾页序号.
	 */
	public int getNextPage() {
		if (isHasNext()) {
			return pageNo + 1;
		} else {
			return pageNo;
		}
	}

	/**
	 * 是否还有上一页.
	 */
	public boolean isHasPre() {
		return (pageNo - 1 >= 1);
	}

	/**
	 * 取得上页的页号, 序号从1开始.
	 * 当前页为首页时返回首页序号.
	 */
	public int getPrePage() {
		if (isHasPre()) {
			return pageNo - 1;
		} else {
			return pageNo;
		}
	}

	public T getParam() {
		return param;
	}

	public void setParam(T param) {
		this.param = param;
	}

}
