package com.smt.iptv.epg.json;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smt.iptv.epg.core.SystemConstant;
import com.smt.iptv.epg.dao.CityDao;
import com.smt.iptv.epg.entity.City;

/**
 * 城市信息相关接口 主要为了获取城市地区信息 方便天气和航班功能使用。
 * 
 * @author mills
 */
@Controller
@RequestMapping(value = "/json/city")
public class CityController {

    @Autowired()
    private CityDao cityDao;
    /**
     * 获取城市列表 无需参数/json/city/list
     * @return 返回所有城市
     */
    @RequestMapping(value = "/list", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<City> list() {
        return cityDao.findAll();
    }  
    /**
     * 获取深圳和上海2个城市的 航班城市编码。深圳SZX 上海SHA /json/city/airdef
     * @return
     */
    @RequestMapping(value = "/airdef", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<City> airdef() {
        List<City> list = new LinkedList<City>();
        City c = new City();
        c.setCityname("深圳");
        c.setCityaircode("SZX");
        City c2 = new City();
        c2.setCityname("上海");
        c2.setCityaircode("SHA");
        list.add(c);
        list.add(c2);
        return list;
    } 
    @RequestMapping(value = "/local", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public City local() {
        String citycode=SystemConstant.getValue("local_city");
        citycode=citycode==null?"1903":citycode;
        return cityDao.getByWeathercode(citycode);
    } 
}
