package com.smt.iptv.epg.entity;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class ErrorCode  {
    
    public ErrorCode(){

    }
    public ErrorCode(String code,String message){
        this.code=code;
        this.message=message;
    }
    
	private String code;

    private String message;

    
    public String getCode() {
        return code;
    }


    public void setCode(String code) {
        this.code = code;
    }


    public String getMessage() {
        return message;
    }


    public void setMessage(String message) {
        this.message = message;
    }


    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}