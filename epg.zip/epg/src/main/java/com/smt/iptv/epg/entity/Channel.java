package com.smt.iptv.epg.entity;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.smt.iptv.epg.core.IdEntity;
import com.smt.iptv.epg.core.SystemConstant;

public class Channel extends IdEntity {

    public Channel() {
    }

    public Channel(Long id) {
        this.id = id;
    }
    //channel表
    private String channelname;
    private String cpobjectcode;
    private Integer channelnumber;
    @JsonIgnore
    private String callsign;
    private String timeshift;
    private Integer timeshiftduration;
    @JsonIgnore
    private String timeshifturl;
    @JsonIgnore
    private String status;
    private String hdtv;
    private String casttype;//1组播2单播
    @JsonIgnore
    private String channeltype;//1直播 2虚拟 5其它 
    private String recordstarttime;
    private String recordendtime;
    @JsonIgnore
    private String physicalchannelid;
    private String description;
    //physicalchannel表
    //private String physicacpobjectcode;
    @JsonIgnore
    private String bitratedef;
    @JsonIgnore
    private String ip;
    @JsonIgnore
    private String port;
    @JsonIgnore
    private String sourceip;
    @JsonIgnore
    private String sourceport;
    @JsonIgnore
    private String encoderip;
    @JsonIgnore
    private String encoderport;
    @JsonIgnore
    private String drmrecvip;
    @JsonIgnore
    private String drmrecvport;
    private String frequency;
    private String pmtpid;
    private String channelurl;
    //private String physicatimeshifturl;
    @JsonIgnore
    private String unicasturl;
    
    //customizedchannelno表 有些字段需要用
    private String channelgroup;
    private String servicegroup;
    
    
    //TwoSchedule
    private String nowplay;
    private String nextplay;
    private long categoryid;
    
    //是否为vip频道 1表示vip 非1表示非vip
    private String vip;
    
    
    public String getVip() {
		return vip;
	}

	public void setVip(String vip) {
		this.vip = vip;
	}


	public String getServicegroup() {
        return channelgroup;
    }

    public void setServicegroup(String servicegroup) {
        this.servicegroup =this.channelgroup = servicegroup;
    }

    public String getChannelname() {
        return channelname;
    }

    public void setChannelname(String channelname) {
        this.channelname = channelname;
    }

    public String getCpobjectcode() {
        return cpobjectcode;
    }

    public void setCpobjectcode(String cpobjectcode) {
        this.cpobjectcode = cpobjectcode;
    }

    public Integer getChannelnumber() {
        return channelnumber;
    }

    public void setChannelnumber(Integer channelnumber) {
        this.channelnumber = channelnumber;
    }

    public String getCallsign() {
        return callsign;
    }
    public String getCallsignurl() {
        return SystemConstant.getURLValue("image_server_httpprefix")+callsign;
    }
    public void setCallsign(String callsign) {
        this.callsign = callsign;
    }

    public String getTimeshift() {
        return timeshift;
    }

    public void setTimeshift(String timeshift) {
        this.timeshift = timeshift;
    }

    public Integer getTimeshiftduration() {
        return timeshiftduration;
    }

    public void setTimeshiftduration(Integer timeshiftduration) {
        this.timeshiftduration = timeshiftduration;
    }

    public String getTimeshifturl() {
        return timeshifturl;
    }

    public void setTimeshifturl(String timeshifturl) {
        this.timeshifturl = timeshifturl;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getHdtv() {
        return hdtv;
    }

    public void setHdtv(String hdtv) {
        this.hdtv = hdtv;
    }

    public String getCasttype() {
        return casttype;
    }

    public void setCasttype(String casttype) {
        this.casttype = casttype;
    }

    public String getRecordstarttime() {
        return recordstarttime;
    }

    public void setRecordstarttime(String recordstarttime) {
        this.recordstarttime = recordstarttime;
    }

    public String getRecordendtime() {
        return recordendtime;
    }

    public void setRecordendtime(String recordendtime) {
        this.recordendtime = recordendtime;
    }

    public String getPhysicalchannelid() {
        return physicalchannelid;
    }

    public void setPhysicalchannelid(String physicalchannelid) {
        this.physicalchannelid = physicalchannelid;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getBitratedef() {
        return bitratedef;
    }

    public void setBitratedef(String bitratedef) {
        this.bitratedef = bitratedef;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public String getSourceip() {
        return sourceip;
    }

    public void setSourceip(String sourceip) {
        this.sourceip = sourceip;
    }

    public String getSourceport() {
        return sourceport;
    }

    public void setSourceport(String sourceport) {
        this.sourceport = sourceport;
    }

    public String getEncoderip() {
        return encoderip;
    }

    public void setEncoderip(String encoderip) {
        this.encoderip = encoderip;
    }

    public String getEncoderport() {
        return encoderport;
    }

    public void setEncoderport(String encoderport) {
        this.encoderport = encoderport;
    }

    public String getDrmrecvip() {
        return drmrecvip;
    }

    public void setDrmrecvip(String drmrecvip) {
        this.drmrecvip = drmrecvip;
    }

    public String getDrmrecvport() {
        return drmrecvport;
    }

    public void setDrmrecvport(String drmrecvport) {
        this.drmrecvport = drmrecvport;
    }

    public String getFrequency() {
        return frequency;
    }

    public void setFrequency(String frequency) {
        this.frequency = frequency;
    }

    public String getPmtpid() {
        return pmtpid;
    }

    public void setPmtpid(String pmtpid) {
        this.pmtpid = pmtpid;
    }

    public String getChannelurl() {
        return channelurl;
    }

    public void setChannelurl(String channelurl) {
        this.channelurl = channelurl;
    }

    public String getUnicasturl() {
        return unicasturl;
    }

    public void setUnicasturl(String unicasturl) {
        this.unicasturl = unicasturl;
    }

    public String getChannelgroup() {
        return channelgroup;
    }

    public void setChannelgroup(String channelgroup) {
        this.channelgroup = channelgroup;
    }

    public String getNowplay() {
        return nowplay;
    }

    public void setNowplay(String nowplay) {
        this.nowplay = nowplay;
    }

    public String getNextplay() {
        return nextplay;
    }

    public void setNextplay(String nextplay) {
        this.nextplay = nextplay;
    }

    public long getCategoryid() {
        return categoryid;
    }

    public void setCategoryid(long categoryid) {
        this.categoryid = categoryid;
    }
    
    public String getChanneltype() {
        return channeltype;
    }

    public void setChanneltype(String channeltype) {
        this.channeltype = channeltype;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
}