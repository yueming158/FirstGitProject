package com.smt.iptv.epg.json;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smt.iptv.epg.core.I18nResource;
import com.smt.iptv.epg.core.SystemConstant;
import com.smt.iptv.epg.core.SystemResource;
import com.smt.iptv.epg.dao.WeatherDao;
import com.smt.iptv.epg.entity.Weather;

/**
 * 天气相关接口
 * 
 * @author mills
 */
@Controller
@RequestMapping(value = "/json/weather")
public class WeatherController {

    @Autowired
    private WeatherDao weatherDao;
    /**
     * 得到指定城市当天天气/json/weather/current/{citycode}
     * @param citycode 城市编码
     * @return Weather当天天气
     */
    @RequestMapping(value = "/current/{citycode}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Weather get(@PathVariable("citycode") String citycode) {
        Weather weather = weatherDao.findByCitycodeAndWeatherdate(citycode, new Date());
        //weather.setCityname(I18nResource.getString(weather.getCitycode())); 已经在getset方法里实现了
        return weather;
    }
    /**
     * 得到指定城市一段时间内天气 从当天开始
     * @param citycode 城市编码
     * @param days 得到天气预报的天数。例如3 着得到3天内部的天气
     * @return List<Weather> 天气列表
     */
    @RequestMapping(value = "/current/{citycode}/{days}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<Weather> getMore(@PathVariable("citycode") String citycode, @PathVariable("days") int days) {
        List<Weather> weathers = weatherDao.findByCitycodeAndWeatherdateBetween(citycode,new Date(), addDay(new Date(),days-1));
//        已经在getset方法里实现了
//        for(Weather w:weathers){
//            w.setCityname(I18nResource.getString(w.getCitycode()));
//        }
        return weathers;
    }
    private Date addDay(Date date, int n) {
        Calendar cd = Calendar.getInstance();
        cd.setTime(date);
        cd.add(Calendar.DATE, n);// 增加n天
        return cd.getTime();
    }
}
