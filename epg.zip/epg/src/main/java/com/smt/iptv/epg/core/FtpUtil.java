package com.smt.iptv.epg.core;

import com.smt.iptv.epg.entity.Program;
import com.smt.iptv.epg.service.program.ProgramService;


public class FtpUtil {

    // 异步下载文件方法
    // ftp://xjw:123456@60.194.136.206/home/xjw/wrere.mp4
    public static void asyncDownFile(Program program,String sourcefile,ProgramService programService) {
        new Thread(new AsyncFtpClient(program,sourcefile,programService)).start();
    }
}

