package com.smt.iptv.epg.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.smt.iptv.epg.entity.Timezone;
@MyBatisRepository
public interface TimezoneDao{
    List<Timezone> findByViewflag(@Param("viewflag") String viewflag);
     
}
