package com.smt.iptv.epg.service.mail;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSenderImpl;

/**
 * 不使用spring初始化，方便静态调用
 */
public class SimpleMailUtil {
	private static Logger logger = LoggerFactory.getLogger(SimpleMailUtil.class);
	private static JavaMailSenderImpl mailSender=null;
	static{
        AbstractApplicationContext  context =new  ClassPathXmlApplicationContext("applicationContext-email.xml");  
        mailSender = (JavaMailSenderImpl)context.getBean("mailSender"); 
	}
    private static void init(){
        AbstractApplicationContext  context =new  ClassPathXmlApplicationContext("applicationContext-email.xml");  
        mailSender = (JavaMailSenderImpl)context.getBean("mailSender"); 
    }
	/**
	 * 发送纯文本的用户修改通知邮件.有回调处理函数
	 */
    public static void sendNotificationMail( final String [] sendTo,final String subject,final String content,final MailSendCallback callback) {

        new Thread(new Runnable() {
            
            @Override
            public void run() {
                if(mailSender==null){
                    init();
                }
                SimpleMailMessage msg = new SimpleMailMessage();
                msg.setFrom(mailSender.getUsername());
                msg.setTo(sendTo);//"xujw@szhhzt.com"
                msg.setSubject(subject);//"智能互动视讯系统报警信息"

                // 将用户名与当期日期格式化到邮件内容的字符串模板
                //String content = String.format(textTemplate, userName, new Date());
                msg.setText(content);
                try {
                    mailSender.send(msg);
                    if (logger.isInfoEnabled()) {
                        logger.info("纯文本邮件已发送至{}", StringUtils.join(msg.getTo(), ","));
                    }
                } catch (Exception e) {
                    logger.error("发送邮件失败："+e.getMessage().substring(e.getMessage().indexOf(":")+1, e.getMessage().length()-1));
                    if(callback!=null){
                        callback.call();
                    }
                }
            }
        }).start();

    }
    /**
     * 发送纯文本的用户修改通知邮件. 无回调处理函数
     */
    public static void sendNotificationMail( final String [] sendTo,final String subject,final String content) {
        sendNotificationMail(sendTo,subject,content,null);

    }
    /**
     * 发送纯文本的用户修改通知邮件. 无回调处理函数
     */
    public static void sendNotificationMail( final String sendTo,final String subject,final String content,final MailSendCallback callback) {
        sendNotificationMail(new String []{sendTo},subject,content,callback);

    }
    /**
     * 发送纯文本的用户修改通知邮件. 无回调处理函数
     */
    public static void sendNotificationMail( final String sendTo,final String subject,final String content) {
        sendNotificationMail(new String []{sendTo},subject,content,null);

    }
}
