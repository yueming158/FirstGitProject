package com.smt.iptv.epg.json;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Lists;
import com.smt.iptv.epg.dao.GoodsDao;
import com.smt.iptv.epg.dao.GoodsorderDao;
import com.smt.iptv.epg.entity.Goods;
import com.smt.iptv.epg.entity.Goodscart;
import com.smt.iptv.epg.entity.Goodsorder;
import com.smt.iptv.epg.entity.Page;

/**
 * 订餐相关接口
 * 
 * @author rich
 */
@Controller
@RequestMapping(value = "/json/goods")
public class GoodsController {

    @Autowired
    private GoodsDao goodsDao;
    @Autowired
    private GoodsorderDao goodsorderDao;
    /**
     * 首页推荐
     * 
     * @return
     */
    @RequestMapping(value = "/featured", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    List<Goods> getFeatured() {
        return goodsDao.getFeatured();
    }

    /**
     * 菜单分页查询
     * 
     * @param categoryId
     *            来自分类接口
     * @param page
     * @return
     */
    @RequestMapping(value = "/list", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Page<Goods> getGoodslistPage(Long categoryId, Page<Goods> page) {
        List<Goods> list = goodsDao.getGoodslistPage(categoryId, page);
        page.setResult(list);
        return page;
    }

    /**
     * 单个菜品详情
     * 
     * @param id
     * @return
     */
    @RequestMapping(value = "goodsdetail", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    Goods getGoodsById(Long id) {
        return goodsDao.getGoodsById(id);
    }

    /**
     * 相关菜品详情
     * 
     * @param id
     * @return
     */
    @RequestMapping(value = "/recommend", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    List<Goods> getRecommend(String goodsstr) {
        if (goodsstr != null && goodsstr.matches("(\\d+,)*\\d+")) {
            return goodsDao.getRecommend(goodsstr);
        } else {
            return Lists.newArrayList();
        }
    }

    // 提交订单
    @RequestMapping(value = "/addorder", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    boolean addorder(String username, String tel,@RequestParam(required=false,defaultValue="0")Long goodsId,@RequestParam(required=false,defaultValue="0")Integer number) {
        SimpleDateFormat sdf = new SimpleDateFormat(username+"yyMMddHHmmss");
        if(goodsId!=0&&number!=0){
            //直接订购
            
            Goods d =goodsDao.getGoodsById(goodsId);
            if(d==null){
                return false;
            }
            d.setNumber(number);
            Goodsorder order = new Goodsorder();
            order.setUsername(username);
            //order.setRoomname(roomname);在sql中实现了
            order.setOrdercode(sdf.format(new Date()));
            order.setTel(tel);
            order.setTotalprice(d.getPrice()*number);
            order.setStatus("1");
            order.setTotalnumber(number);
            goodsorderDao.addorder(order); // 新增订单
            goodsorderDao.addOrderGoodsMap(order.getId(), Lists.newArrayList(d)); // 写入订单内容
            goodsDao.clearCart(username);//清空购物车
        }
        //购物车订购
        List<Goodscart> cart =goodsDao.getCart(username);
        if(cart!=null&&!cart.isEmpty()){
            Integer totalprice = 0;
            Integer totalnumber =0;
            List<Goods> goodsList = Lists.newArrayList();
            for (Goodscart c : cart) {
                if(c.getGoods()!=null&&c.getGoods().getPrice()!=null&&c.getGoods().getNumber()!=null){
                    goodsList.add(c.getGoods());
                    totalprice+=c.getGoods().getPrice()*c.getGoods().getNumber();
                    totalnumber+=c.getGoods().getNumber();
                }
            }
            Goodsorder order = new Goodsorder();
            order.setUsername(username);
            //order.setRoomname(roomname);在sql中实现了
            order.setOrdercode(sdf.format(new Date()));
            order.setTel(tel);
            order.setTotalprice(totalprice);
            order.setStatus("1");
            order.setTotalnumber(totalnumber);
            goodsorderDao.addorder(order); // 新增订单
            goodsorderDao.addOrderGoodsMap(order.getId(), goodsList); // 写入订单内容
            goodsDao.clearCart(username);//清空购物车
        }
        return true;
    }

    /**
     * 我的订单列表
     * 
     * @param username
     * @return
     */
    @RequestMapping(value = "/myorders", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    List<Goodsorder> getMyOrders(String username) {
        return goodsorderDao.getMyOrders(username);
    }

    /**
     * 单条订单详情
     * 
     * @param goodsstr
     * @return
     */
    @RequestMapping(value = "/orderdetail", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    List<Goods> orderdetail(Long orderid) {
        return goodsorderDao.getGoodsListByOrderid(orderid);
    }

    /**
     * 添加到购物车
     * 
     * @param username
     * @param goodsId
     * @param number
     * @return
     */
    @RequestMapping(value = "/addtocart", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    boolean addGoodsToCart(String username, Long goodsId, Integer number,@RequestParam(required=false,value="merge") String merge) {
        if (number == null||goodsDao.getGoodsById(goodsId)==null){
            return false;
        }
        if(!"no".equals(merge)){
            //同商品合并显示 只新增数量
            Goodscart goodscart = goodsDao.getGoodsFromCartByGoodsId(username, goodsId);
            if (goodscart == null) {
                return goodsDao.addToCart(username,goodsId,number) == 1 ? true : false;
            } else {
                Goods goods = goodscart.getGoods();
                Integer newnum =goods.getNumber() == null?number:goods.getNumber() + number;
                return goodsDao.modifyNumber(goodscart.getId(),newnum) == 1 ? true : false;
            }
        }else{
            //同商品分开显示 不显示数量 每次只能添加一道菜
            if(number!=1){
                return false;
            }
            return goodsDao.addToCart(username,goodsId,number) == 1 ? true : false;
        }
    }

    /**
     * 查看购物车商品列表
     * 
     * @param username
     * @return
     */
    @RequestMapping(value = "/getcart", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    List<Goodscart> getGoodsListFormCart(String username) {
        return goodsDao.getCart(username);
    }

    /**
     * 查看购物车总数
     * 
     * @param username
     * @return
     */
    @RequestMapping(value = "/getcarttotal", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    Integer getCartTotal(String username) {
        return goodsDao.getCartTotal(username);
    }

    /**
     * 修改购物车
     * 
     * @param goodscart
     * @return
     */
    @RequestMapping(value = "/modifynumber", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    boolean modifyNumber(Long goodscartId, Integer number) {
        return goodsDao.modifyNumber(goodscartId,number) == 1 ? true : false;
    }

    /**
     * 购物车批量删除商品
     * 
     * @param goodscart
     * @return
     */
    @RequestMapping(value = "/delete", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    boolean deleteFormCart(String goodscartids) {
        if (StringUtils.isNotEmpty(goodscartids) && goodscartids.matches("(\\d+,)*\\d+")) {
            return goodsDao.deleteFormCart(goodscartids) >0 ? true : false;
        } else {
            return false;
        }
    }

    /**
     * 清空购物车
     * 
     * @param username
     * @return
     */
    @RequestMapping(value = "/clearcart", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    boolean clearCart(String username) {
        return goodsDao.clearCart(username) >0 ? true : false;
    }
}
