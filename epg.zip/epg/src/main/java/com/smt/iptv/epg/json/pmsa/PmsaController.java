package com.smt.iptv.epg.json.pmsa;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springside.modules.mapper.JaxbMapper;

import com.google.common.collect.Lists;
import com.smt.iptv.epg.core.HttpJDKUtil;
import com.smt.iptv.epg.core.Result;
import com.smt.iptv.epg.core.SoapClientUtil;
import com.smt.iptv.epg.core.SystemConstant;
import com.smt.iptv.epg.dao.BillDao;
import com.smt.iptv.epg.dao.HotelDao;
import com.smt.iptv.epg.dao.ProgramDao;
import com.smt.iptv.epg.entity.Program;
import com.smt.iptv.epg.entity.pmsa.Fee;
import com.smt.iptv.epg.entity.pmsa.FeeContainer;
import com.smt.iptv.epg.entity.pmsa.FeeDetail;
import com.smt.iptv.epg.entity.pmsa.PostingRequest;

/**
 * 酒店相关接口
 * 
 * @author mills
 */
@Controller
@RequestMapping(value = "/json/pmsa")
public class PmsaController {
    Logger logger =LoggerFactory.getLogger(PmsaController.class);
    @Autowired
    private ProgramDao programDao;
    @Autowired
    private BillDao billDao;
    @Autowired
    private HotelDao hotelDao;

    public static String guestinfo(String roomno){
        //String loginxml = HttpJDKUtil.executeHttpGet(SystemConstant.getURLValue("xr_pms_server")+"XRHotel_Service.asmx/GuestInfo?Name=&Pwd=&Roomno="+roomno, "utf-8");
        String loginxml = SoapClientUtil.GuestInfo("","",roomno); 
        //loginxml = HttpJDKUtil.executeHttpGet("http://222.161.243.182:5031/XRHotel_Service.asmx/GuestInfo?Name=&Pwd=&Roomno="+roomno, "utf-8");
        if(loginxml==null||loginxml.indexOf("&lt;name&gt;")==-1||loginxml.indexOf("&lt;/name&gt;")==-1){
            return null;
        }else{
            String name =loginxml.substring(loginxml.indexOf("&lt;name&gt;")+12, loginxml.indexOf("&lt;/name&gt;"));
            return name;
        }
    }
    
    /**
     * 账单查询
     */
    @RequestMapping(value = "/billquery", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<Fee> query(String  roomno) {
        //String billxml = HttpJDKUtil.executeHttpGet(SystemConstant.getURLValue("xr_pms_server")+"XRHotel_Service.asmx/QueryBill?Roomno="+roomno, "utf-8");
        String billxml = SoapClientUtil.QueryBill(roomno); 
        if(billxml==null){
            return Lists.newArrayList();
        }
        billxml = billxml.replaceAll("&lt;", "<").replaceAll("&gt;", ">").replace("xmlns=\"http://tempuri.org/\"", "").replaceAll("杂项", "VOD");
        logger.info(billxml);
        FeeContainer bc = JaxbMapper.fromXml(billxml, FeeContainer.class);
        return bc.getItems();
    }
    /**
     * 抛账
     * @param roomno
     * @param price
     * @param quantity
     * @param remark
     * @param programid
     * @return
     * @throws UnsupportedEncodingException
     */
    @RequestMapping(value = "/posting", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Result posting(String roomno,Integer price, Integer quantity,String remark,Long programid,HttpServletRequest request) throws UnsupportedEncodingException {
        List<Long> customerids = billDao.getCustomerid(roomno);
//        if(customerids==null||customerids.size()==0){
//            return new Result(false,"客人尚未入住");
//        }
            //1房态同步 按西软的实时来不按自己的来
        String guestname= PmsaController.guestinfo(roomno);
        if(guestname==null){
            return new Result(false,"无法获取客房入住信息");//return new Result(false,"客人尚未入住");
        }else{
            //如果客人名字有变化同步客房信息
            if(!guestname.equals(billDao.getGuestname(roomno))){
                //1.2入住(包含数据不同步的退房逻辑)
                String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+request.getContextPath();
                String url =basePath.replace("epg", "portal")+"/json/room/pmsacheckin";
                Calendar c = Calendar.getInstance();
                c.add(Calendar.DAY_OF_MONTH, 1);
                String param ="roomNo="+roomno+"&name="+URLEncoder.encode(guestname, "UTF-8")
                        +"&beginTime="+new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date())
                        +"&endTime="+new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(c.getTime())
                        +"&identityCard=&sex=1&age=0";
                HttpJDKUtil.executeHttpPost(url, param);
            }
        }

        //开始抛账准备工作
        PostingRequest posttingrequest=new PostingRequest();
        FeeDetail feeDetail = new FeeDetail();
        feeDetail.setFeecode("02");//VOD
        feeDetail.setPccode(SystemConstant.getValue("xr_pccode"));//每个酒店不一样 配置
        feeDetail.setRoomno(roomno);
        feeDetail.setAmount(price.toString());
        feeDetail.setQuantity(quantity.toString());
        feeDetail.setRemark(remark);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        feeDetail.setSdate(sdf.format(new Date()));
        posttingrequest.setFeeDetail(feeDetail);
        String requestxml =JaxbMapper.toXml(posttingrequest);
        //开始抛账准备工作end
        //判断是否已经购买过
        if(billDao.isOrder(roomno, programid, LocaleContextHolder.getLocale().getLanguage())!=0){
            //本地已经购买
            return new Result(true,"已经购买");
        }else{
            List<Fee> feelist = query(roomno);
            for(Fee f:feelist){
                if(remark.equals(f.getFeename())){//这个判断不严谨  
                    //2有可能重复抛账 必须调用billqery 因为抛账返回可能不正确。 
                    //3如有不一致且必须更新本地购买记录
                    for(Long customerid:customerids){
                        //programid和语言才能确定唯一片源   为了记录是哪位客人点播
                        billDao.record(feeDetail,customerid,programid,LocaleContextHolder.getLocale().getLanguage());
                    }
                    return new Result(true,"已经购买");
                }
            }
        }
        //开始抛账
        //logger.info(requestxml);
        //String postingresult = HttpJDKUtil.executeHttpGet(SystemConstant.getURLValue("xr_pms_server")+"XRHotel_Service.asmx/Posting?Fun=01&Strxml="+URLEncoder.encode(requestxml, "utf-8") , "utf-8");
        String postingresult = SoapClientUtil.Posting("01", URLEncoder.encode(requestxml, "utf-8"));
        //logger.info(postingresult);
        if(postingresult==null){
            //4billquery才能决定是否真异常
            Boolean isSuccess=false;;
            List<Fee> feelist = query( roomno);
            for(Fee f:feelist){
                if(remark.equals(f.getFeename())){//这个判断不严谨  
                    isSuccess=true;
                    break;
                }
            }
            if(!isSuccess){
                return new Result(false,"PMS服务异常，请联系管理员");
            }
        }
        
        if(postingresult.indexOf("&lt;error&gt;")!=-1){
            return new Result(false,postingresult.substring(postingresult.indexOf("&lt;error&gt;")+13, postingresult.indexOf("&lt;/error&gt;")));
        }else if(postingresult.indexOf("&lt;success&gt;")!=-1){
            for(Long customerid:customerids){
                //programid和语言才能确定唯一片源   为了记录是哪位客人点播
                billDao.record(feeDetail,customerid,programid,LocaleContextHolder.getLocale().getLanguage());
            }
            return new Result(true,postingresult.substring(postingresult.indexOf("&lt;success&gt;")+15, postingresult.indexOf("&lt;/success&gt;")));
        }
        return new Result(false,"服务异常，请联系管理员");
    }
    /**
     * 是否订购过 SQL里已经限制了是当前客人的点播记录
     */
    @RequestMapping(value = "/isorder", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Boolean query(String roomno,Long programid) {
        Program p = programDao.getProgram(programid);
        if(p!=null){
            if(p.getPrice()==null||p.getPrice()<=0){
                return true;
            }
            if(billDao.isOrder(roomno, programid, LocaleContextHolder.getLocale().getLanguage())!=0){
                return true;
            }
        }
        return false;
    }
    /**
     * 入住接口 还未处理逻辑
     * @throws UnsupportedEncodingException 
     */
    @RequestMapping(value="/checkin" , produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Boolean checkin(String roomNo,String name, String identityCard,String beginTime,String endTime,String sex,String age,@RequestParam(required=false)String birthday,HttpServletRequest request) throws UnsupportedEncodingException {
        //为泰能PMS做的特殊处理  CharacterEncodingFilter
        String data =(String)request.getAttribute("data");
        //roomNo=0102&name=电视台-郭X第三方的~!@#$%^&*()({}|/aaaa&identityCard=420154199002021234&sex=1&age=24&beginTime=2014-08-08 13:13:13&&endTime=2014-08-18 13:13:13
        if(StringUtils.isNotEmpty(data)){
            data =data.substring(0, data.indexOf(0));
            roomNo=data.substring(data.indexOf("roomNo=")+7,data.indexOf("&name="));
            name=data.substring(data.indexOf("&name=")+6,data.indexOf("&identityCard="));
            identityCard=data.substring(data.indexOf("&identityCard=")+14,data.indexOf("&sex="));
            sex=data.substring(data.indexOf("&sex=")+5,data.indexOf("&beginTime="));
            //age=data.substring(data.indexOf("&age=")+5,data.indexOf("&beginTime="));
            beginTime=data.substring(data.indexOf("&beginTime=")+11,data.indexOf("&endTime="));
            endTime=data.substring(data.indexOf("&endTime=")+9);
        }
        //为泰能PMS做的特殊处理END  CharacterEncodingFilter
        logger.error("ckin:roomNo="+roomNo+"&name="+name+"&identityCard="+identityCard+"&beginTime="+beginTime+"&endTime="+endTime+"&sex="+sex+"&age="+age+""+"&birthday="+birthday+"");
        if(StringUtils.isEmpty(roomNo)||StringUtils.isEmpty(name)){
            ///||StringUtils.isEmpty(identityCard)||!age.matches("\\d+")||(!"0".equals(sex)&&!"1".equals(sex))
            return false;
        }
        if(StringUtils.isNotBlank(identityCard)&&identityCard.length()==18){
            String sexStr =identityCard.substring(16,17);
            if(sexStr.matches("\\d")){
                Integer sexnum=Integer.parseInt(sexStr)%2;
                sex = sexnum.toString();
            }
        }
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
        try {
            sdf.parse(beginTime);
            sdf.parse(endTime);
            if(StringUtils.isNotEmpty(birthday)){
                Date d = sdf2.parse(birthday);
                Calendar c =Calendar.getInstance();
                c.setTimeInMillis(System.currentTimeMillis()-d.getTime()) ;
                age=((new Date()).getYear()-d.getYear())+"";
            }
        } catch (Exception e) {
            return false;
        }
        //1并检查房间状态总入住数与入住人的区别 如有不 一样更新 可以不做
        //3调用portal入住接口执行其它入住逻辑
        //CheckinGuest  guest= new CheckinGuest( roomNo,  name,  identityCard,  beginTime,  endTime,  sex,  age);
        if(name.length()>1&&name.endsWith("_")){
            name=name.substring(0, name.length()-1);
        }
        String param = "roomNo="+roomNo+"&name="+URLEncoder.encode(name, "UTF-8")+"&identityCard="+identityCard+"&beginTime="+beginTime+"&endTime="+endTime+"&sex="+sex+"&age="+age;
        String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+request.getContextPath();
        String url =basePath.replace("epg", "portal")+"/json/room/pmsacheckin";
        String result = HttpJDKUtil.executeHttpPost(url, param);
        if(result!=null&&result.indexOf("true")!=-1){
            return true;
        }else{
            return false;
        }
    }
    /**
     * 退房接口 还未处理逻辑
     * @param roomNo
     * @param ckoutTime
     * @return
     */
    @RequestMapping(value="/checkout" , produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Boolean posting(String roomNo,String ckoutTime,HttpServletRequest request) {
        logger.error("ckout:roomNo="+roomNo+"&ckoutTime="+ckoutTime);
        if(StringUtils.isEmpty(roomNo)){
            return false;
        }
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            sdf.parse(ckoutTime);
        } catch (ParseException e) {
            return false;
        }
        //1并检查房间状态总入住数与入住人的区别 如有不 一样更新 可以不做
        //3调用portal退房接口执行其它入住逻辑
        String param ="roomNo="+roomNo+"&ckoutTime="+ckoutTime;
        String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+request.getContextPath();
        String url =basePath.replace("epg", "portal")+"/json/room/pmsacheckout";
        String result = HttpJDKUtil.executeHttpPost(url, param);
        if(result!=null&&result.indexOf("true")!=-1){
            return true;
        }else{
            return false;
        }
    }
    /**
     * 退房接口 还未处理逻辑
     * @param roomNo
     * @param ckoutTime
     * @return
     */
    @RequestMapping(value="/vodfree" , produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Boolean vodfree(String roomNo,String status,HttpServletRequest request) {
        if(StringUtils.isNotBlank(roomNo)&&("on".equals(status)||"off".equals(status))){
            Long num =hotelDao.updateVodfree(roomNo, status);
            if(num>0){
                return true;
            }
        }
        return false;  
    }
}
