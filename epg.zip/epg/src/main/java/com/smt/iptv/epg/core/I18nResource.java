package com.smt.iptv.epg.core;

import java.util.Locale;
import java.util.ResourceBundle;

import org.springframework.context.i18n.LocaleContextHolder;

public class I18nResource {
  
    
    private static ResourceBundle resb = ResourceBundle.getBundle("message"); 
    

    public static String  getString(String key){
        if(LocaleContextHolder.getLocale()==null){
            return resb.getString(key);
        }else{
            return ResourceBundle.getBundle("message", LocaleContextHolder.getLocale()).getString(key);
        }
    }
    public static Integer  getInteger(String key){
        return Integer.valueOf(resb.getString(key));
    }
    public static String  getString(String key,String locale,String country){
            return ResourceBundle.getBundle("message", new Locale(locale, country)).getString(key);
    }
}
