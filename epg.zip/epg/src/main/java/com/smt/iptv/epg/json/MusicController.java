package com.smt.iptv.epg.json;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smt.iptv.epg.dao.MusicDao;
import com.smt.iptv.epg.entity.Game;
import com.smt.iptv.epg.entity.Music;
import com.smt.iptv.epg.entity.Musiccategory;
import com.smt.iptv.epg.entity.Musiccategorytype;
import com.smt.iptv.epg.entity.Page;

/**
 * 
 * @author mills
 */
@Controller
@RequestMapping(value = "/json/music")
public class MusicController {

    @Autowired()
    private MusicDao musicDao;


    @RequestMapping(value = "/categorytypelist", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<Musiccategorytype> getCategorytypeList(){
        return musicDao.getCategorytypeList();
    }
    @RequestMapping(value = "/indexcategorylist", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<Musiccategory> getMusiccategoryList(){
        return musicDao.getMusiccategoryList(14L);
    }
    @RequestMapping(value = "/musiclist", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<Music> getMusicList(Long musiccategoryId){
        return musicDao.getMusicList(musiccategoryId);
    }
    @RequestMapping(value = "/music", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Music getMusic(Long musicId){
        return musicDao.getMusic(musicId);
    }
}
