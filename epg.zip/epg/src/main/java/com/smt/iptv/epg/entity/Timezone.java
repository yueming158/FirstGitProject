package com.smt.iptv.epg.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.smt.iptv.epg.core.IdEntity;

public class Timezone extends IdEntity {
    
    public Timezone() {
    }

    public Timezone(Long id) {
        this.id = id;
    }
    
    private String cityname;
    private String englishname;
    private String timezone;
    @JsonIgnore
    private String viewflag;

    public String getCityname() {
        return cityname;
    }

    public void setCityname(String cityname) {
        this.cityname = cityname;
    }

    public String getEnglishname() {
        return englishname;
    }

    public void setEnglishname(String englishname) {
        this.englishname = englishname;
    }

    public String getTimezone() {
        return timezone;
    }

    public void setTimezone(String timezone) {
        this.timezone = timezone;
    }

    public String getViewflag() {
        return viewflag;
    }

    public void setViewflag(String viewflag) {
        this.viewflag = viewflag;
    }

}