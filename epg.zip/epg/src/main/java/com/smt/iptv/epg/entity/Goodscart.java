package com.smt.iptv.epg.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.smt.iptv.epg.core.IdEntity;

public class Goodscart extends IdEntity {

    private String username;
    @JsonProperty(value="dish")
    private Goods goods;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
    
    public Goods getGoods() {
        return goods;
    }

    public void setGoods(Goods goods) {
        this.goods = goods;
    }

}