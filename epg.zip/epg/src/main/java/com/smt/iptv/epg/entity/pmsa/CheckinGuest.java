package com.smt.iptv.epg.entity.pmsa;



public class CheckinGuest {

    public CheckinGuest() {
        super();
    }
    public CheckinGuest(String roomNo, String name, String identityCard, String beginTime, String endTime, String sex, String age) {
        super();
        this.roomNo = roomNo;
        this.name = name;
        this.identityCard = identityCard;
        this.beginTime = beginTime;
        this.endTime = endTime;
        this.sex = sex;
        this.age = age;
    }
    private String roomNo;
    private String name;
    private String identityCard;
    private String beginTime;
    private String endTime;
    private String sex;
    private String age;
    public String getRoomNo() {
        return roomNo;
    }
    public void setRoomNo(String roomNo) {
        this.roomNo = roomNo;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getIdentityCard() {
        return identityCard;
    }
    public void setIdentityCard(String identityCard) {
        this.identityCard = identityCard;
    }
    public String getBeginTime() {
        return beginTime;
    }
    public void setBeginTime(String beginTime) {
        this.beginTime = beginTime;
    }
    public String getEndTime() {
        return endTime;
    }
    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }
    public String getSex() {
        return sex;
    }
    public void setSex(String sex) {
        this.sex = sex;
    }
    public String getAge() {
        return age;
    }
    public void setAge(String age) {
        this.age = age;
    }
    @Override
    public String toString() {
        return "CheckinGuest [roomNo=" + roomNo + ", name=" + name + ", identityCard=" + identityCard + ", beginTime=" + beginTime + ", endTime=" + endTime
                + ", sex=" + sex + ", age=" + age + "]";
    }
	
}