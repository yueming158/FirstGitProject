package com.smt.iptv.epg.dao;

import java.util.List;

import com.smt.iptv.epg.entity.Menu;


@I18nMyBatisRepository
public interface MenuDao {
    List<Menu> getMainMenu();
    List<Menu> getSecondMenu(Long parentid);
}
