package com.smt.iptv.epg.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.smt.iptv.epg.entity.Infocontent;
@I18nMyBatisRepository
public interface InfocontentDao{ 
    List<Infocontent> getInfoContentList(@Param("menucode")String menucode,@Param("groupId")Integer groupId);
}