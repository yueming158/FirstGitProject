package com.smt.iptv.epg.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.smt.iptv.epg.entity.Dish;
import com.smt.iptv.epg.entity.Dishcart;
import com.smt.iptv.epg.entity.Dishorder;
import com.smt.iptv.epg.entity.Page;

@MyBatisRepository
public interface DishorderDao {
    List<Dishorder>  getMyOrders(@Param("username")String username); //order表 
    List<Dish> getDishListByOrderid(@Param("orderid")Long orderid); //ordermap表 
    Long addorder(Dishorder dishorder); //order表 
    void addOrderDishMap(@Param("orderid")Long orderid,@Param("dishs")List<Dish> dishs); //ordermap表 
}
