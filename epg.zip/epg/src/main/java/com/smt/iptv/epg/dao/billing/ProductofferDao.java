package com.smt.iptv.epg.dao.billing;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.smt.iptv.epg.dao.MyBatisRepository;
import com.smt.iptv.epg.entity.billing.Productoffer;

@MyBatisRepository
public interface ProductofferDao {
	List<Productoffer> getProgramProductofferList(
			@Param("productoffertype") String productoffertype,
			@Param("resourceid") String resourceid);
	
	List<Productoffer> getChannelProductofferList(
			@Param("productoffertype") String productoffertype,
			@Param("resourceid") String resourceid);
	
	Productoffer getProductoffer(@Param("id") String id);
}
