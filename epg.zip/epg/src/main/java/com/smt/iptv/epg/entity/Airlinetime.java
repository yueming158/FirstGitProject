package com.smt.iptv.epg.entity;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.epg.core.IdEntity;

public class Airlinetime extends IdEntity {
    private String company;
    private String airlinecode;
    private String startdrome;
    private String arrivedrome;
    private String starttime;
    private String arrivetime;
    private String mode;
    private String airlinestop;
    private String airlinecitycode;

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getAirlinecode() {
        return airlinecode;
    }

    public void setAirlinecode(String airlinecode) {
        this.airlinecode = airlinecode;
    }

    public String getStartdrome() {
        return startdrome;
    }

    public void setStartdrome(String startdrome) {
        this.startdrome = startdrome;
    }

    public String getArrivedrome() {
        return arrivedrome;
    }

    public void setArrivedrome(String arrivedrome) {
        this.arrivedrome = arrivedrome;
    }

    public String getStarttime() {
        return starttime;
    }

    public void setStarttime(String starttime) {
        this.starttime = starttime;
    }

    public String getArrivetime() {
        return arrivetime;
    }

    public void setArrivetime(String arrivetime) {
        this.arrivetime = arrivetime;
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public String getAirlinestop() {
        return airlinestop;
    }

    public void setAirlinestop(String airlinestop) {
        this.airlinestop = airlinestop;
    }

    public String getAirlinecitycode() {
        return airlinecitycode;
    }

    public void setAirlinecitycode(String airlinecitycode) {
        this.airlinecitycode = airlinecitycode;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}