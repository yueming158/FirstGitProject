package com.smt.iptv.epg.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.smt.iptv.epg.entity.Game;
import com.smt.iptv.epg.entity.Page;

@I18nMyBatisRepository
public interface GameDao {
	List<Game> getGamelistPage(@Param("apptype") String apptype,@Param("page") Page<Game> page);
}
