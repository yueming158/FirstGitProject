package com.smt.iptv.epg.json.license;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import com.smt.iptv.epg.core.Result;
import com.smt.iptv.epg.core.SystemConstant;

/**
 * License管理的Controller, 使用Restful风格的Urls:
 * 
 * @author xjw
 */
@Controller
@RequestMapping(value = "/json/auth")
public class AuthenticationController {
    //license鉴权 如果设备曾经激活 则返回license字符串  如果设备未激活 服务器记录该设备新增再返回license字符串
    @RequestMapping(value = "first")
    @ResponseBody
    public Result first(String licensecode, String hardwareinfo, String systeminfo, String appinfo) {
        //192.168.1.247:9999/license/json/auth/first?licensecode=a8255ba7-7bbe-499c-8aef-bc41639eb56d&hardwareinfo=aa&systeminfo=vv&appinfo=bb
        RestTemplate template = new RestTemplate();  
        Result result =template.getForObject(SystemConstant.getURLValue("license_server")+"json/auth/first?licensecode="+licensecode+"&hardwareinfo="+hardwareinfo+"&systeminfo="+systeminfo+"&appinfo="+appinfo, Result.class);
        return result;
    }
    //不带客户授权码来进行激活，每次都带上好了，感觉不需要这个接口
    @RequestMapping(value = "again")
    @ResponseBody
    public Result again(String hardwareinfo,String systeminfo, String appinfo) {
        RestTemplate template = new RestTemplate();  
        Result result =template.getForObject(SystemConstant.getURLValue("license_server")+"/json/auth/again?hardwareinfo="+hardwareinfo+"&systeminfo="+systeminfo+"&appinfo="+appinfo, Result.class,hardwareinfo,systeminfo,appinfo);
        return result;
    }

}
