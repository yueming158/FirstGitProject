package com.smt.iptv.epg.json;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smt.iptv.epg.dao.TimezoneDao;
import com.smt.iptv.epg.entity.Timezone;

/**
 * 世界时钟功能时区相关的接口
 * 
 * @author mills
 */
@Controller
@RequestMapping(value = "/json/timezone")
public class TimezoneController {

    @Autowired
    private TimezoneDao timezoneDao;
    private static String VIEWFLAG_TRUE="1";
    
    /**
     *  获取在界面上显示哪几个城市的时区 时间时钟功能。/json/timezone/viewlist
     * @return List<Timezone> 返回显示的城市时区列表
     */
    @RequestMapping(value = "/viewlist", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<Timezone> viewlist() {
        return timezoneDao.findByViewflag(VIEWFLAG_TRUE);
    }
}
