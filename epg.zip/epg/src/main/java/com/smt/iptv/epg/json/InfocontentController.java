package com.smt.iptv.epg.json;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smt.iptv.epg.dao.InfocontentDao;
import com.smt.iptv.epg.entity.Infocontent;

/**
 * 酒店相关接口
 * 
 * @author mills
 */
@Controller
@RequestMapping(value = "/json/infocontent")
public class InfocontentController {

	@Autowired
	private InfocontentDao infocontentDao;

	@RequestMapping(value="/{menucode}" ,method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<Infocontent> getInfoContentList(@PathVariable("menucode")String menucode,@RequestParam(required=false,defaultValue="1")Integer groupId) {
	    return infocontentDao.getInfoContentList(menucode,groupId);
	}
}
