package com.smt.iptv.epg.json;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smt.iptv.epg.dao.AirlinetimeDao;
import com.smt.iptv.epg.entity.Airlinetime;
import com.smt.iptv.epg.entity.Page;

/**
 * 航班相关接口
 * 
 * @author mills
 */
@Controller
@RequestMapping(value = "/json/airlinetime")
public class AirlinetimeController {

    @Autowired()
    private AirlinetimeDao airlinetimeDao;
    /**
     * 获取分页的航班信息 /json/airlinetime/{airlinecitycode}/{daynum}/{pageNo}/{pageSize}
     * @param airlinecitycode 城市编号
     * @param daynum 时间 当天是0 昨天是-1 明天是1 以此类推
     * @param pageNo 分页对象 当前页
     * @param pageSize 分页对象 每页记录数
     * @return Page<Airlinetime> 返回分页对象 ， 其中数据列为Airlinetime对象
     */
    @RequestMapping(value = "/{airlinecitycode}/{daynum}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Page<Airlinetime> findByAirlinecitycodeAndDate(@PathVariable("airlinecitycode") String airlinecitycode,
            @PathVariable("daynum") Integer daynum,Page<Airlinetime> page) {
        Calendar cd = Calendar.getInstance();
        cd.add(Calendar.DATE, daynum);
        int weeknumber =cd.get(Calendar.DAY_OF_WEEK)-1;
        List<Airlinetime> list = airlinetimeDao.getairlinetimelistPage(airlinecitycode,weeknumber,page);
        page.setResult(list);
        return page;
    }
    /**
     *  默认使用获取深圳到上海当天的航班信息  /json/airlinetime/{pageNo}/{pageSize}
     * @param pageNo 分页对象 当前页
     * @param pageSize 分页对象 每页记录数
     * @return Page<Airlinetime> 返回分页对象 ， 其中数据列为Airlinetime对象
     */
    @RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Page<Airlinetime> findByDefAirline(Integer pageNo,Integer pageSize) {
    	Page<Airlinetime> page = new Page<Airlinetime>(pageNo, pageSize);
    	 int weeknumber =Calendar.getInstance().get(Calendar.DAY_OF_WEEK)-1;
        List<Airlinetime> list = airlinetimeDao.getairlinetimelistPage("SZXSHA",weeknumber,page);
        page.setResult(list);
        return page;
    }
}
