package com.smt.iptv.epg.entity;

import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.epg.core.IdEntity;

public class Hotelcustomer extends IdEntity {
    public Hotelcustomer() {
    }

    public Hotelcustomer(Long id) {
        this.id = id;
    }
    private Long hotelroomid;
    private String customername;
    private String identitycard;
    private String sex;
    private String status;
    private Date checkintime;
    private Date checkouttime;

    public Long getHotelroomid() {
        return hotelroomid;
    }

    public void setHotelroomid(Long hotelroomid) {
        this.hotelroomid = hotelroomid;
    }

    public String getCustomername() {
        return customername;
    }

    public void setCustomername(String customername) {
        this.customername = customername;
    }

    public String getIdentitycard() {
        return identitycard;
    }

    public void setIdentitycard(String identitycard) {
        this.identitycard = identitycard;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public Date getCheckintime() {
        return checkintime;
    }

    public void setCheckintime(Date checkintime) {
        this.checkintime = checkintime;
    }

    public Date getCheckouttime() {
        return checkouttime;
    }

    public void setCheckouttime(Date checkouttime) {
        this.checkouttime = checkouttime;
    }

    
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }


    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}