package com.smt.iptv.epg.entity.billing;



import java.beans.Transient;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class Attr {

    @JsonIgnore
    private String usetype;//用途
    private String type;// 属性数据类型
    private String name; // 属性名
    private String attrkey; // 属性key
    private String value;
    @JsonIgnore
    private String enumstr; // 枚举定义

    public String getUsetype() {
        return usetype;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAttrkey() {
        return attrkey;
    }

    public void setAttrkey(String attrkey) {
        this.attrkey = attrkey;
    }

    @Transient
    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public void setUsetype(String usetype) {
        this.usetype = usetype;
    }

    public String getEnumstr() {
        return enumstr;
    }

    public void setEnumstr(String enumstr) {
        this.enumstr = enumstr;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
}