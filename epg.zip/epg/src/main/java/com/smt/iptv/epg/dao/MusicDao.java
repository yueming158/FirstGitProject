package com.smt.iptv.epg.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.smt.iptv.epg.entity.Dish;
import com.smt.iptv.epg.entity.Dishcart;
import com.smt.iptv.epg.entity.Dishorder;
import com.smt.iptv.epg.entity.Music;
import com.smt.iptv.epg.entity.Musiccategory;
import com.smt.iptv.epg.entity.Musiccategorytype;
import com.smt.iptv.epg.entity.Page;

@I18nMyBatisRepository
public interface MusicDao {
    //音乐欣赏
    List<Musiccategorytype> getCategorytypeList();
    //首页
    List<Musiccategory> getMusiccategoryList(@Param("typeid")Long typeid);
    //共用
    List<Music> getMusicList(@Param("musiccategoryId")Long musiccategoryId);
    Music getMusic(@Param("musicId")Long musicId);
}
