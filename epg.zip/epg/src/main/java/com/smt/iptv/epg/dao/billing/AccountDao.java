package com.smt.iptv.epg.dao.billing;

import org.apache.ibatis.annotations.Param;

import com.smt.iptv.epg.dao.MyBatisRepository;
import com.smt.iptv.epg.entity.billing.Account;

@MyBatisRepository
public interface AccountDao {
	public Integer getAccountBalance(@Param("iptvusername") String iptvusername);
	public Account getAccount(@Param("iptvusername") String iptvusername);
	public int updateAccountBalance(@Param("id") Long id,@Param("balance") int balance);
}
