package com.smt.iptv.epg.json;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smt.iptv.epg.core.SystemConstant;
import com.smt.iptv.epg.dao.CategoryDao;
import com.smt.iptv.epg.dao.MenuDao;
import com.smt.iptv.epg.entity.Category;
import com.smt.iptv.epg.entity.Menu;

/**
 * 分类请求接口
 * 
 * @author mills
 */
@Controller
@RequestMapping(value = "/json/category")
public class CategoryController {

    @Autowired
    private CategoryDao categoryDao;
    @Autowired
    private MenuDao menuDao;
    /**
     * 获取每个类型的分类列表 未分二级多级查询需新接口/json/category/{type}
     * @param type category类型   30代表频道，10代表电影，11代表连续剧，17 音乐，19 综艺，40游戏
     * @return List<Category> 分类列表
     */
    @RequestMapping(value = "/vod/type", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<Category> list() {
        return categoryDao.getVodType();
    }
    
    
    /**
     * 获取每个类型的分类列表 一级分类接口/json/category/{type}
     * @param type category类型   30代表频道，10代表电影，11代表连续剧，17 音乐，19 综艺，40游戏 50订餐 51是特产 可以合并
     * @return List<Category> 分类列表
     */
    @RequestMapping(value = "/{type}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<Category> listpageByCategory(@PathVariable("type") String type,@RequestParam(required=false) String menucode) {
        List<Category> list = categoryDao.getCategoryList(type,menucode);
        if("10".equals(type)&&StringUtils.isEmpty(menucode)){
            if(StringUtils.isNotBlank(SystemConstant.getValue("shortcut_vod_menucode"))){
                return categoryDao.getCategoryList(type,SystemConstant.getValue("shortcut_vod_menucode"));
            }else{
                List<Menu> menus =menuDao.getMainMenu();
                for(Menu menu:menus){
                    if("lvb_x_vod_a".equals(menu.getTemplatecode())){
                        return categoryDao.getCategoryList(type,menu.getCode());
                    }
                }
            }
        }
        return list;
    }
    
    /**
     * 获取每个类型的分类列表 二级分类接口/json/category/{type}
     * @param type category类型   30代表频道，10代表电影，11代表连续剧，17 音乐，19 综艺，40游戏
     * @return List<Category> 分类列表
     */
    @RequestMapping(value = "second/{categoryId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<Category> getSecondListByCategoryId(@PathVariable Long categoryId) {
        List<Category> list = categoryDao.getSecondListByCategoryId(categoryId);
        return list;
    }
}
