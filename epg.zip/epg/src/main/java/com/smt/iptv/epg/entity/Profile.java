package com.smt.iptv.epg.entity;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.smt.iptv.epg.core.IdEntity;
import com.smt.iptv.epg.core.SystemConstant;
import com.smt.iptv.epg.core.SystemResource;

public class Profile extends IdEntity {
    
    public Profile() {
    }

    public Profile(Long id) {
        this.id = id;
    }
    
    private String iptvusername;
    private String channelgroup;
    private String status;
    @JsonIgnore
    private String macaddress;
    private String ipaddress;
    @JsonIgnore
    private String stbversion;
    private Integer epggroupid;
    //接口额外属性
    private String code="200";
    private String isencrypted;
    private String roomname;
    private String roomno;
    private String hotspot ="off";
    private Integer level = 0;
    private String vodfree ="on";
    private String onlylive ="off";
    private String wifiname; //wifi密码
    private String interacpassword; //wifi密码
    
    @JsonIgnore
    private String iptvpassword;
    @JsonIgnore
    private String distributeip;
    @JsonIgnore
    private String token;
    public String getWifiname() {
        if("on".equals(SystemConstant.getValue("wifi_name_same"))){
            return SystemConstant.getValue("wifi_name");
        }else{
            return SystemConstant.getValue("wifi_name")+roomno;
        }
    }

    public String getInteracpassword() {
        if("on".equals(SystemConstant.getValue("wifi_password_same"))){
            if(SystemConstant.getValue("wifi_password")!=null){
                if(SystemConstant.getValue("wifi_password").length()>=8){
                    return SystemConstant.getValue("wifi_password");
                }else{
                    return SystemConstant.getValue("wifi_password")+roomno;
                }
            }else{
                return "12345678";
            }
        }else{
            if(StringUtils.isNotBlank(SystemConstant.getValue("wifi_password"))){
                return interacpassword==null?SystemConstant.getValue("wifi_password"):interacpassword;
            }else{
                return interacpassword==null?"00000000":interacpassword;
            }
        }
    }

    public void setInteracpassword(String interacpassword) {
        this.interacpassword = interacpassword;
    }
    
    public void setWifiname(String wifiname) {
        this.wifiname = wifiname;
    }
    
    public String getIptvusername() {
        return iptvusername;
    }

    public void setIptvusername(String iptvusername) {
        this.iptvusername = iptvusername;
    }

    public String getIptvpassword() {
        return iptvpassword;
    }

    public void setIptvpassword(String iptvpassword) {
        this.iptvpassword = iptvpassword;
    }

    public String getChannelgroup() {
        return channelgroup;
    }

    public void setChannelgroup(String channelgroup) {
        this.channelgroup = channelgroup;
    }

    public String getMacaddress() {
        return macaddress;
    }

    public void setMacaddress(String macaddress) {
        this.macaddress = macaddress;
    }

    public String getIpaddress() {
        return ipaddress;
    }

    public void setIpaddress(String ipaddress) {
        this.ipaddress = ipaddress;
    }

    public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getIsencrypted() {
        isencrypted = SystemConstant.getValue("epg_isencrypted");
        return isencrypted ;
    }

    public void setIsencrypted(String isencrypted) {
        this.isencrypted = isencrypted;
    }

    public String getRoomname() {
        return roomname;
    }

    public void setRoomname(String roomname) {
        this.roomname = roomname;
    }

    public String getRoomno() {
        return roomno;
    }

    public void setRoomno(String roomno) {
        this.roomno = roomno;
    }

    public String getHotspot() {
        return hotspot;
    }

    public void setHotspot(String hotspot) {
        this.hotspot = hotspot;
    }

    public String getVodfree() {
    		return vodfree;
    }

    public void setVodfree(String vodfree) {
        this.vodfree = vodfree;
    }


    public String getOnlylive() {
        return onlylive;
    }

    public String getStbversion() {
        return stbversion;
    }

    public void setStbversion(String stbversion) {
        this.stbversion = stbversion;
    }

    public void setOnlylive(String onlylive) {
        this.onlylive = onlylive;
    }

    public Integer getLevel() {
        return level;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }

    public Integer getEpggroupid() {
        return epggroupid==null?1:epggroupid;
    }

    public void setEpggroupid(Integer epggroupid) {
        this.epggroupid = epggroupid;
    }

    public String getDistributeip() {
        return distributeip;
    }

    public void setDistributeip(String distributeip) {
        this.distributeip = distributeip;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
    
}