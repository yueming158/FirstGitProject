package com.smt.iptv.epg.entity;

import com.smt.iptv.epg.core.IdEntity;
import com.smt.iptv.epg.core.SystemConstant;

public class Music extends IdEntity{
    public Music() {
    }

    public Music(Long id) {
        this.id = id;
    }
    private String name;
    private String singer;
    private String lyricist;
    private String composer;
    private String playurl;
    private String logourl;
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getSinger() {
        return singer;
    }
    public void setSinger(String singer) {
        this.singer = singer;
    }
    public String getLyricist() {
        return lyricist;
    }
    public void setLyricist(String lyricist) {
        this.lyricist = lyricist;
    }
    public String getComposer() {
        return composer;
    }
    public void setComposer(String composer) {
        this.composer = composer;
    }
    public String getLogourl() {
        return logourl;
    }
    public void setLogourl(String logourl) {
        this.logourl = logourl;
    }
    public String getPlayurl() {
        return SystemConstant.getURLValue("image_server_httpprefix")+ playurl;
    }
    public void setPlayurl(String playurl) {
        this.playurl = playurl;
    }

}
