package com.smt.iptv.epg.dao.billing;

import org.apache.ibatis.annotations.Param;

import com.smt.iptv.epg.dao.MyBatisRepository;

@MyBatisRepository
public interface AuthenticataccountDao {
	public Boolean accessSingleProgram(
			@Param("iptvusername") String iptvusername,
			@Param("resourceid") String resourceid);

	public boolean accessAllProgram(@Param("iptvusername") String iptvusername);
	
	public Boolean accessSingleChannel(
			@Param("iptvusername") String iptvusername,
			@Param("resourceid") String resourceid);

	public boolean accessAllChannel(@Param("iptvusername") String iptvusername);
}
