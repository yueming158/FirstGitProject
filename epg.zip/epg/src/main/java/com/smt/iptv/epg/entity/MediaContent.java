package com.smt.iptv.epg.entity;

import java.beans.Transient;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.smt.iptv.epg.core.CryptCore;
import com.smt.iptv.epg.core.IdEntity;
import com.smt.iptv.epg.core.SystemConstant;

public class MediaContent extends IdEntity {
    
    public MediaContent() {
    }

    public MediaContent(Long id) {
        this.id = id;
    }
    @JsonIgnore
    private Long programid;
    private String viewname;
    private Integer sequence;
    @JsonIgnore
    private String cpobjectcode;
    private Integer duration;
    @JsonIgnore
    private String urltype;
    @JsonIgnore
    private String otherplayurl;
    @JsonIgnore
    private String sourcefilename;
    private String playurl;
    @Transient
    public String getPlayurl() {
        return playurl;
    }
    
    public void setPlayurl(String playurl) {
        this.playurl = playurl;
    }

    public Long getProgramid() {
        return programid;
    }

    public void setProgramid(Long programid) {
        this.programid = programid;
    }

    public String getViewname() {
        return viewname;
    }

    public void setViewname(String viewname) {
        this.viewname = viewname;
    }

    public Integer getSequence() {
        return sequence;
    }

    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

    public String getCpobjectcode() {
        return cpobjectcode;
    }

    public void setCpobjectcode(String cpobjectcode) {
        this.cpobjectcode = cpobjectcode;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public String getUrltype() {
        return urltype;
    }

    public void setUrltype(String urltype) {
        this.urltype = urltype;
    }

    public String getOtherplayurl() {
        return otherplayurl;
    }

    public void setOtherplayurl(String otherplayurl) {
        this.otherplayurl = otherplayurl;
    }
    
    public String getSourcefilename() {
        return sourcefilename;
    }

    public void setSourcefilename(String sourcefilename) {
        this.sourcefilename = sourcefilename;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}