package com.smt.iptv.epg.json.aotuaddress;


public class Stbcfg{

    private String iptvusername;//账号
    private String password; //密码
    
    private String ipaddr;  //ip
    private String mask;    //掩码
    private String gateway; //网关
    private String dns;     //dns
    //private String token;
    
    //返回结果
    private Boolean result=true; //执行是否成功
    private String desc=""; //情况说明
    public String getIptvusername() {
        return iptvusername;
    }
    public void setIptvusername(String iptvusername) {
        this.iptvusername = iptvusername;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public String getIpaddr() {
        return ipaddr;
    }
    public void setIpaddr(String ipaddr) {
        this.ipaddr = ipaddr;
    }
    public String getMask() {
        return mask;
    }
    public void setMask(String mask) {
        this.mask = mask;
    }
    public String getGateway() {
        return gateway;
    }
    public void setGateway(String gateway) {
        this.gateway = gateway;
    }
    public String getDns() {
        return dns;
    }
    public void setDns(String dns) {
        this.dns = dns;
    }
//    public String getToken() {
//        return token;
//    }
//    public void setToken(String token) {
//        this.token = token;
//    }
    public Boolean getResult() {
        return result;
    }
    public void setResult(Boolean result) {
        this.result = result;
    }
    public String getDesc() {
        return desc;
    }
    public void setDesc(String desc) {
        this.desc = desc;
    }

    
    
}