package com.smt.iptv.epg.dao;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.smt.iptv.epg.entity.Airlinetime;
import com.smt.iptv.epg.entity.Page;

@MyBatisRepository
public interface AirlinetimeDao {
    List<Airlinetime> getairlinetimelistPage(@Param("airlinecitycode") String airlinecitycode, @Param("weeknumber")Integer weeknumber,
            @Param("page") Page<Airlinetime> page);
}