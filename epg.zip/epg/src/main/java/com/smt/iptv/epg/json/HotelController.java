package com.smt.iptv.epg.json;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Lists;
import com.smt.iptv.epg.core.I18nResource;
import com.smt.iptv.epg.core.SystemConstant;
import com.smt.iptv.epg.dao.EpgDao;
import com.smt.iptv.epg.dao.HotelDao;
import com.smt.iptv.epg.dao.ProfileDao;
import com.smt.iptv.epg.entity.Epgvariable;
import com.smt.iptv.epg.entity.Hotel;
import com.smt.iptv.epg.entity.Menu;

/**
 * 酒店相关接口
 * 
 * @author mills
 */
@Controller
@RequestMapping(value = "/json/hotel")
public class HotelController {
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	@Autowired
	private HotelDao hotelDao;
	@Autowired
	private EpgDao epgDao;
    @Autowired
    private ProfileDao profileDao;
    /**
     *  获取酒店背景图片和logo图片  /json/hotel
     * @return Hotel 背景图和logo
     */
	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public Hotel list(String iptvusername,@RequestParam(required=false,defaultValue="1")Integer groupId) {
	    
	    
		Hotel hotel = hotelDao.getHotelRoomInfo(iptvusername);
		if(hotel==null){
		     return null;
		}
		
		
		
		String hotelname =epgDao.getByName("AB_hotel_name",groupId);
		String logo =epgDao.getByName("AB_welcome_logo",groupId);
		String bg =epgDao.getByName("AB_welcome_bg",groupId);
		if(StringUtils.isEmpty(hotelname)){
		    hotelname=epgDao.getByName("hotel_name",groupId);
		}
		if(StringUtils.isEmpty(logo)){
		    logo=epgDao.getByName("hotel_logo",groupId);
        }
		if(StringUtils.isEmpty(bg)){
		    bg=epgDao.getByName("hotel_welcome_bg",groupId);
        }
		hotel.setHotelname(hotelname);
		hotel.setHotellogo(logo);
		hotel.setHotelimage(bg);
		if(StringUtils.isEmpty(hotel.getWelcome())){
		    String defaultWelcome=epgDao.getByName("default_welcome",groupId);
		    if(StringUtils.isNotEmpty(defaultWelcome)){
		        hotel.setWelcome(defaultWelcome);
		    }else{
		        hotel.setWelcome(I18nResource.getString("welcome_prefix")+hotel.getHotelname()+I18nResource.getString("welcome_suffix"));
		    }
		}
		if(StringUtils.isEmpty(hotel.getRoomname())){
		    hotel.setRoomname(I18nResource.getString("no_allocate_room"));
		}
		if(new Locale("en").getLanguage().equals(LocaleContextHolder.getLocale().getLanguage())){
		    hotel.setCustomername(hotel.getEnglishname());
		    if(StringUtils.isEmpty(hotel.getCustomername())){
                hotel.setCustomername("Guest");
            }
		}else{
		    if(StringUtils.isEmpty(hotel.getCustomername())){
	            hotel.setCustomername("客人");
	        }
		}
		//并州饭店start
		String name =hotel.getCustomername();
        if(name.lastIndexOf("-")!=-1){
            name = hotel.getCustomername().substring(hotel.getCustomername().lastIndexOf("-")+1);
        }
        name =name.replaceAll("\\*| ", "");
        hotel.setCustomername(name);
        //并州饭店 end
		hotel.setHotellogo(SystemConstant.getURLValue("image_server_httpprefix")+hotel.getHotellogo());
		hotel.setHotelimage(SystemConstant.getURLValue("image_server_httpprefix")+hotel.getHotelimage());
		return hotel; 
	}
    
    /**
     * 变量查询
     */
    @RequestMapping(value="/variable" , method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<Epgvariable> variable(Long groupId) {
        return epgDao.listByEpggroup(groupId);
    }

}
