package com.smt.iptv.epg.entity;

import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.smt.iptv.epg.core.IdEntity;

public class Schedule extends IdEntity {

	public Schedule() {
	}

	public Schedule(Long id) {
		this.id = id;
	}

    private long channelid ;
    private String schedulename;
    @JsonIgnore
    private String cpobjectcode;
    private Date scheduledate;
    private Date starttime;
    private Date endtime;
    @JsonIgnore
    private String hotflag;
    @JsonIgnore
    private String deleteflag;
    @JsonIgnore
    private Date createdate;
    private String description;
    @JsonIgnore
    private long duration;
    private String tvodurl;
    private String playstatus;
    
    public long getDuration() {
        return duration;
    }

    public void setDuration(long duration) {
        this.duration = duration;
    }

    public long getChannelid() {
        return channelid;
    }

    public void setChannelid(long channelid) {
        this.channelid = channelid;
    }

    public String getSchedulename() {
        return schedulename;
    }

    public void setSchedulename(String schedulename) {
        this.schedulename = schedulename;
    }

    public String getCpobjectcode() {
        return cpobjectcode;
    }

    public void setCpobjectcode(String cpobjectcode) {
        this.cpobjectcode = cpobjectcode;
    }

    public Date getScheduledate() {
        return scheduledate;
    }

    public void setScheduledate(Date scheduledate) {
        this.scheduledate = scheduledate;
    }

    public Date getStarttime() {
        return starttime;
    }

    public void setStarttime(Date starttime) {
        this.starttime = starttime;
    }

    public Date getEndtime() {
        return endtime;
    }

    public void setEndtime(Date endtime) {
        this.endtime = endtime;
    }

    public String getHotflag() {
        return hotflag;
    }

    public void setHotflag(String hotflag) {
        this.hotflag = hotflag;
    }

    public String getDeleteflag() {
        return deleteflag;
    }

    public void setDeleteflag(String deleteflag) {
        this.deleteflag = deleteflag;
    }

    public Date getCreatedate() {
        return createdate;
    }

    public void setCreatedate(Date createdate) {
        this.createdate = createdate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTvodurl() {
        return tvodurl;
    }

    public void setTvodurl(String tvodurl) {
        this.tvodurl = tvodurl;
    }
    
    public String getPlaystatus() {
        return playstatus;
    }

    public void setPlaystatus(String playstatus) {
        this.playstatus = playstatus;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}