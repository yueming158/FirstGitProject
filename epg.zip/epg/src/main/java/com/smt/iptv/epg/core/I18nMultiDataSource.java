package com.smt.iptv.epg.core;

import org.springframework.context.i18n.LocaleContextHolder;  
import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;  
   
public class I18nMultiDataSource extends AbstractRoutingDataSource{  
    @Override  
    protected Object determineCurrentLookupKey() {  
        String language = LocaleContextHolder.getLocale().getLanguage();  
        //System.out.println("Language obtained: "+ language);  
        return language;  
    }
}