package com.smt.iptv.epg.entity.billing;

import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.epg.core.IdEntity;

public class Accountrecord extends IdEntity{
	public Accountrecord() {
	}
	
	public Accountrecord(Long id) {
		this.id = id;
	}
	
	private Long accountid;
	private String type;
	private int balance;
	private Long orderusageid;
	private String description;
	private Date recorddate;
	
	public Date getRecorddate() {
		return recorddate;
	}

	public void setRecorddate(Date recorddate) {
		this.recorddate = recorddate;
	}

	public Long getAccountid() {
		return accountid;
	}

	public void setAccountid(Long accountid) {
		this.accountid = accountid;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

	public Long getOrderusageid() {
		return orderusageid;
	}

	public void setOrderusageid(Long orderusageid) {
		this.orderusageid = orderusageid;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
