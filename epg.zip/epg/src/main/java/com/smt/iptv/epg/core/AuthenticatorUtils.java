package com.smt.iptv.epg.core;
import java.security.GeneralSecurityException;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.lang3.StringUtils;

/**
 * 认证器工具
 * 
 
 */
public class AuthenticatorUtils {

    /** 算法 */
    private static final String ALGORITHM = "TripleDES";
    /** 转换方式 */
    private static final String TRANSFORMATION = "TripleDES/ECB/PKCS5Padding";
    /** 密钥长度 */
    private static final int KEY_LENGTH = 24;
    /** 密钥填充字符 */
    private static final char KEY_PAD_CHAR = '0';

    /**
     * 加密认证字符
     * 
     * @param key
     *            密钥
     * @param source
     *            明文
     * @return 密文
     */
    public static String encrypt(String key, String source) {
        byte[] sourceBytes = source.getBytes();
        byte[] data = doFinal(Cipher.ENCRYPT_MODE, key, sourceBytes);
        return Hex.encodeHexString(data).toUpperCase();
    }

    /**
     * 解密认证字符
     * 
     * @param key
     *            密钥
     * @param source
     *            密文
     * @return 明文
     */
    public static String decrypt(String key, String source) {
        byte[] sourceBytes;
        try {
            sourceBytes = Hex.decodeHex(source.toCharArray());
        } catch (DecoderException e) {
            throw new RuntimeException(e);
        }
        byte[] data = doFinal(Cipher.DECRYPT_MODE, key, sourceBytes);
        return new String(data);
    }

    /**
     * 加密或解密
     * 
     * @param mode
     *            模式，加密或解密
     * @param key
     *            密钥
     * @param sourceBytes
     *            原文
     * @return 明文或密文
     */
    private static byte[] doFinal(int mode, String key, byte[] sourceBytes) {
        byte[] keyBytes = adjustSecretKey(key).getBytes();
        SecretKey secretKey = new SecretKeySpec(keyBytes, ALGORITHM);
        try {
            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(mode, secretKey);
            return cipher.doFinal(sourceBytes);
        } catch (GeneralSecurityException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * 调整密钥
     * 
     * @param key
     *            密钥
     * @return 新密钥
     */
    private static String adjustSecretKey(String key) {
        return StringUtils.rightPad(key, KEY_LENGTH, KEY_PAD_CHAR);
    }

    public static void main(String[] args) throws Exception {
        String key = "123456";
        String source ="1234$89F02BD15B2A5E0B84750F43$testxxt01$$$AC:4A:FE:39:F9:DF$$"; //"BEF758DBACB16C2F133410A3";
        
        String encryptedData = encrypt(key, source);
        System.out.println("密文：" + encryptedData);
        System.out.println("密文长度：" + encryptedData.length());

        String decryptedData = decrypt(key, encryptedData);
        System.out.println("明文：" + decryptedData);
        System.out.println("明文长度：" + decryptedData.length());
    }

}
