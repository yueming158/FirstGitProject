package com.smt.iptv.epg.task;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.smt.iptv.epg.core.SystemResource;

@Component
public class SpringTasker {

    private static Logger logger = LoggerFactory.getLogger(SpringTasker.class);

//    // 同步主节点的FTP文件
//    public void executeFileSync() {
//        // 如果同步开关未打开则不同步
//        if (!"on".equals(SystemResource.getString("needfilesync"))) {
//            return;
//        }
//        File timefile = new File(SystemResource.getString("uploadfile") + "synctimestamp.log");
//        long oldtime = 0L;
//        if (!timefile.exists()) {
//            try {
//                File uploadfile = new File(SystemResource.getString("uploadfile"));
//                if (!uploadfile.exists()) {
//                    uploadfile.mkdirs();
//                }
//                timefile.createNewFile();
//            } catch (IOException e) {
//            }
//        }else{
//            try {
//                BufferedReader fr = new BufferedReader(new FileReader(timefile));
//                String line = fr.readLine();
//                if (line == null || line.isEmpty()) {
//                    line = "0";
//                }
//                oldtime = Long.parseLong(line);
//                fr.close();
//            } catch (Exception e) {
//            }
//        }
//        String masterftpip = SystemResource.getString("masterftpip");
//        Integer masterftpport = SystemResource.getInteger("masterftpport");
//        String masterftpuser = SystemResource.getString("masterftpuser");
//        String masterftppwd = SystemResource.getString("masterftppwd");
//        String masterftpremotepath = SystemResource.getString("masterftpremotepath");
//        String uploadfile = SystemResource.getString("uploadfile");
//        String masterftpcharset = SystemResource.getString("masterftpcharset");
//        long lastmodifytime = FtpFileSyncUtil.downOverTimeFile(oldtime, masterftpip, masterftpport, masterftpuser, masterftppwd, masterftpremotepath,
//                uploadfile, masterftpcharset);
//        FileOutputStream out = null;
//        try {
//            out = new FileOutputStream(timefile);
//            out.write((lastmodifytime + "").getBytes());// 因为文件修改时间只到分
//                                                        // 不到秒，所以-60000
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//        } catch (IOException e) {
//            e.printStackTrace();
//        } finally {
//            IOUtils.closeQuietly(out);
//        }
//    }
}
