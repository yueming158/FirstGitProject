package com.smt.iptv.epg.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.smt.iptv.epg.entity.Dish;
import com.smt.iptv.epg.entity.Dishcart;
import com.smt.iptv.epg.entity.Dishorder;
import com.smt.iptv.epg.entity.Page;

@I18nMyBatisRepository
public interface DishDao {
    //浏览 数据是多份 支持i18n
    Dish getDishById(@Param("dishid")Long dishid);
    List<Dish> getDishlistPage(@Param("categoryId")Long categoryId,@Param("page")Page<Dish> page);
    List<Dish> getFeatured();
    List<Dish> getRecommend(@Param("dishstr")String dishstr);
    
    //购物车
    List<Dishcart> getCart(@Param("username")String username);
    Integer getCartTotal(@Param("username")String username);

    Dishcart getDishFromCartByDishId(@Param("username")String username,@Param("dishId")Long dishId);//?
    Integer addToCart(@Param("username")String username,@Param("dishid")Long dishid,@Param("number")Integer number);
    Integer modifyNumber(@Param("dishcartId")Long dishcartId, @Param("number")Integer number);
    
    Integer deleteFormCart(@Param("dishcartids")String dishcartids);
    int clearCart(@Param("username")String username);
}
