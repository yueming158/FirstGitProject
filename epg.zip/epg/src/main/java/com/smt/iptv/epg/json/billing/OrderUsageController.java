package com.smt.iptv.epg.json.billing;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;


import com.smt.iptv.epg.entity.billing.Orderresultcode;

import com.smt.iptv.epg.service.billing.OrderusageService;

@Controller
@RequestMapping(value = "/json/orderusage")
public class OrderUsageController {
	@Autowired
	private OrderusageService orderUsageService;
	
	@RequestMapping(value = "/addorder", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public Orderresultcode addOrder(
			@RequestParam(required = true) String productofferid,
			@RequestParam(required = true) String iptvusername) {
		Orderresultcode orderResut = null;
		try {
			orderResut = orderUsageService.addOrder(productofferid, iptvusername);
		} catch (Exception e) {
			e.printStackTrace();
			return new Orderresultcode("10005", "订购失败处理错误");
		}
		return orderResut;
	}
	
	
	
}

