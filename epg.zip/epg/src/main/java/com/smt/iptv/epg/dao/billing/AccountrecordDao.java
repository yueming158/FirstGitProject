package com.smt.iptv.epg.dao.billing;

import com.smt.iptv.epg.dao.MyBatisRepository;
import com.smt.iptv.epg.entity.billing.Accountrecord;

@MyBatisRepository
public interface AccountrecordDao {
	public int saveAccountrecord(Accountrecord accountrecord);
}
