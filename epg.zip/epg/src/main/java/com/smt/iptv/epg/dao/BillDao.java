package com.smt.iptv.epg.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.smt.iptv.epg.entity.pmsa.FeeDetail;

@MyBatisRepository
public interface BillDao {
    Long isOrder(@Param("roomno") String roomno, @Param("programid") Long programid,@Param("language") String language);
    List<Long> getCustomerid(@Param("roomno") String roomno);
    String getGuestname(@Param("roomno") String roomno);
    Long record(@Param("feeDetail") FeeDetail feeDetail,@Param("hotelcustomerid") Long hotelcustomerid,@Param("programid") Long programid,@Param("language") String language);
    //Boolean cleanRecord(@Param("roomno") String roomno);
}
