package com.smt.iptv.epg.json;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smt.iptv.epg.core.CryptCore;
import com.smt.iptv.epg.core.SystemConstant;
import com.smt.iptv.epg.dao.ChannelDao;
import com.smt.iptv.epg.entity.Channel;
import com.smt.iptv.epg.entity.Page;

/**
 * 频道直播相关接口
 * 
 * @author mills
 */
@Controller
@RequestMapping(value = "/json/channel")
public class ChannelController {
    private Integer LOAD_BALANCING_NUMBER = 0;// 这里有多线程问题 先暂时忽略 不会致命 可以接受
    @Autowired
    private ChannelDao channelDao;

    /**
     * 根据用户分组 获取频道数据/json/channel/{channelgroup}
     * 
     * @param channelgroup
     *            用户组编码 从登录接口获取
     * @return 分页对象。 数据为频道列表
     */
    @RequestMapping(value = "/all/{channelgroup}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<Channel> list(@PathVariable("channelgroup") String channelgroup) {
        if (channelgroup.endsWith("_zh") || channelgroup.endsWith("_en")) {
            channelgroup = channelgroup.substring(0, channelgroup.length() - 2) + LocaleContextHolder.getLocale().getLanguage();
        }
        List<Channel> list = channelDao.getAllChannel(channelgroup);
        String serverprefix = getServerPrefix();
        for (Channel c : list) {
            if ("2".equals(c.getCasttype())) {//单播
                String unicasturl = c.getUnicasturl() != null ? c.getUnicasturl().split(",")[0] : "";
                if("1".equals(c.getChanneltype())){//必须是直播频道 虚拟频道和网络频道等不负载均衡
                    if ("on".equals(SystemConstant.getValue("load_balancing")) && StringUtils.isNotEmpty(serverprefix)
                            && unicasturl.length() > serverprefix.length()) {
                        unicasturl = serverprefix + unicasturl.substring(unicasturl.lastIndexOf("/")+1);
                    }
                }
                c.setChannelurl(CryptCore.encryptToDES(unicasturl));
                c.setUnicasturl(CryptCore.encryptToDES(unicasturl));
            } else { //如果是组播地址不负载均衡
                c.setUnicasturl("not used");
                c.setChannelurl(CryptCore.encryptToDES(c.getChannelurl() != null ? c.getChannelurl().split(",")[0] : ""));
            }
            c.setTimeshifturl(CryptCore.encryptToDES(c.getTimeshifturl() != null ? c.getTimeshifturl().split(",")[0] : ""));
        }
        return list;
    }

    /**
     * 根据用户分组和分页对象和频道类型 获取频道分页数据/json/channel/{channelgroup}
     * 
     * @param channelgroup
     *            用户组ID 从登录接口获取
     * @return 分页对象。 数据为频道列表
     */
    @RequestMapping(value = "/tvodlist/{channelgroup}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<Channel> tvodlist(@PathVariable("channelgroup") String channelgroup) {
        if (channelgroup.endsWith("_zh") || channelgroup.endsWith("_en")) {
            channelgroup = channelgroup.substring(0, channelgroup.length() - 2) + LocaleContextHolder.getLocale().getLanguage();
        }
        String serverprefix = getServerPrefix();
        List<Channel> list = channelDao.getTvodChannel(channelgroup);
        for (Channel c : list) {
            if ("2".equals(c.getCasttype())) {
                String unicasturl = c.getUnicasturl() != null ? c.getUnicasturl().split(",")[0] : "";
                if("1".equals(c.getChanneltype())){
                    if ("on".equals(SystemConstant.getValue("load_balancing")) && StringUtils.isNotEmpty(serverprefix)
                            && unicasturl.length() > serverprefix.length()) {
                        unicasturl = serverprefix + unicasturl.substring(unicasturl.lastIndexOf("/")+1);
                    }
                }
                c.setChannelurl(CryptCore.encryptToDES(unicasturl));
                c.setUnicasturl(CryptCore.encryptToDES(unicasturl));
            } else {
                c.setUnicasturl("not used");
                c.setChannelurl(CryptCore.encryptToDES(c.getChannelurl() != null ? c.getChannelurl().split(",")[0] : ""));
            }
            c.setTimeshifturl(CryptCore.encryptToDES(c.getTimeshifturl() != null ? c.getTimeshifturl().split(",")[0] : ""));
        }
        return list;
    }
    /**
     * 获取负载均衡地址 如其中一地址为空则不路由
     * 
     * @return
     */
    private String getServerPrefix() {
        List<String> addressList = SystemConstant.getLiveServerList();
        synchronized(LOAD_BALANCING_NUMBER){
            if (addressList.size() == 0) {
                return "";
            } else if (LOAD_BALANCING_NUMBER < addressList.size()) {
                String url = addressList.get(LOAD_BALANCING_NUMBER);
                LOAD_BALANCING_NUMBER++;
                return url;
            } else {
                LOAD_BALANCING_NUMBER = 1;
                return addressList.get(0);
            }
        }
    }
}
