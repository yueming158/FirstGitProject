package com.smt.iptv.epg.json;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smt.iptv.epg.core.Result;
import com.smt.iptv.epg.core.SystemConstant;
import com.smt.iptv.epg.dao.EpgDao;

/**
 * 酒店相关接口
 * 
 * @author mills
 */
@Controller
@RequestMapping(value = "/json/config")
public class ConfigController {
    @Autowired
    private EpgDao epgDao;
    /**
     * 系统配置查询
     */
    @RequestMapping(value="/system/{name}" , method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Result systemconfig(@PathVariable("name")String name) {
        //盒子的真实license地址固定指向本地 由本地再去访问真正的license服务器，中间过滤一下
        if("license_server".equals(name)){
            return new Result(true, SystemConstant.getValue("epg_server_address"));
        }
        String str =SystemConstant.getValue(name);
        
        if(StringUtils.isNotEmpty(str)){
            return new Result(true, str);
        }else{
            return new Result(false, "配置项为空");
        }
    }
    /**
     * 终端配置查询
     */
    @RequestMapping(value="/stb/{name}" , method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Result epgvariable(@PathVariable("name")String name,@RequestParam(required=false,defaultValue="1")Integer groupId) {
        String str =epgDao.getByName(name,groupId);
        if(StringUtils.isNotEmpty(str)){
            return new Result(true, str);
        }else{
            return new Result(false, "配置项为空");
        }
    }
}
