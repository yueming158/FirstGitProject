package com.smt.iptv.epg.core;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.smt.iptv.epg.dao.GlobalconfigDao;
import com.smt.iptv.epg.entity.Globalconfig;

public class ConfigServlet extends HttpServlet {
    Logger logger = LoggerFactory.getLogger(ConfigServlet.class);
    private static final long serialVersionUID = 6518116926795353891L;

    public ConfigServlet() {
        super();
    }

    public void destroy() {
        super.destroy();
        // Put your code here
    }

    public void init() throws ServletException {
        load();
   /*     if (StringUtils.isEmpty(SystemConstant.getValue("license"))
                || !getMACAddress().equalsIgnoreCase(CryptCore.decryptByDES(SystemConstant.getValue("license"))) || System.currentTimeMillis() > 2412433386809L) {
            logger.error("getMACAddress()=" + getMACAddress());
            logger.error("license=" + SystemConstant.getValue("license"));
            logger.error("no license so exit!");
            System.exit(0);
        }*/
        new Thread(new Runnable() {  
            @Override
            public void run() {
                while(true){
                    SystemConstant.checkServer();
                    try {
                        Thread.sleep(30000);
                    } catch (InterruptedException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }
        }).start();
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) {
        load();
        PrintWriter out;
        try {
            out = response.getWriter();
            out.print("{success:true}");
            out.flush();
            out.close();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) {
        doPost(request, response);
    }

    private void load() {

        WebApplicationContext webApplicationContext = WebApplicationContextUtils.getRequiredWebApplicationContext(getServletContext());
        GlobalconfigDao dao = (GlobalconfigDao) webApplicationContext.getBean("globalconfigDao");
        List<Globalconfig> list = (List<Globalconfig>) dao.findAll();
        for (Globalconfig g : list) {
            SystemConstant.put(g.getName(), g.getValue());
        }
    }

    // // 获取MAC地址的方法
    // private static String getMACAddress() {
    // // 获得网络接口对象（即网卡），并得到mac地址，mac地址存在于一个byte数组中。
    // byte[] mac;
    // try {
    // mac =
    // NetworkInterface.getByInetAddress(InetAddress.getLocalHost()).getHardwareAddress();
    // StringBuffer sb = new StringBuffer();
    //
    // for (int i = 0; i < mac.length; i++) {
    // if (i != 0) {
    // sb.append(":");
    // }
    // // mac[i] & 0xFF 是为了把byte转化为正整数
    // String s = Integer.toHexString(mac[i] & 0xFF);
    // sb.append(s.length() == 1 ? 0 + s : s);
    // }
    //
    // // 把字符串所有小写字母改为大写成为正规的mac地址并返回
    // return sb.toString().toUpperCase();
    // } catch (SocketException e) {
    // // TODO Auto-generated catch block
    // e.printStackTrace();
    // }
    // return "00:00:00:00:00:00";
    // }

    /**
     * 获取当前操作系统名称. return 操作系统名称 例如:windows xp,linux 等.
     */
    public static String getOSName() {
        return System.getProperty("os.name").toLowerCase();
    }

    /**
     * 获取unix网卡的mac地址. 非windows的系统默认调用本方法获取. 如果有特殊系统请继续扩充新的取mac地址方法.
     * 
     * @return mac地址
     */
    public static String getUnixMACAddress(String cmdStr) {
        String mac = "";
        BufferedReader bufferedReader = null;
        Process process = null;
        try {
            // linux下的命令，一般取eth0作为本地主网卡
            process = Runtime.getRuntime().exec(cmdStr);
            // 显示信息中包含有mac地址信息
            bufferedReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line = null;
            int index = -1;
            while ((line = bufferedReader.readLine()) != null) {
                // 寻找标示字符串[hwaddr]
                index = line.toLowerCase().indexOf("hwaddr");
                if (index >= 0) {// 找到了
                    // 取出mac地址并去除2边空格
                    mac = line.substring(index + "hwaddr".length() + 1).trim();
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (bufferedReader != null) {
                    bufferedReader.close();
                }
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            bufferedReader = null;
            process = null;
        }
        return mac;
    }

    /**
     * 获取widnows网卡的mac地址.
     * 
     * @return mac地址
     */
    public static String getWindowsMACAddress() {
        String mac = null;
        BufferedReader bufferedReader = null;
        Process process = null;
        try {
            // windows下的命令，显示信息中包含有mac地址信息
            process = Runtime.getRuntime().exec("ipconfig /all");
            bufferedReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line = null;
            int index = -1;
            while ((line = bufferedReader.readLine()) != null) {
                //System.out.println(line);
                // 寻找标示字符串[physical
                index = line.toLowerCase().indexOf("physical address");

                if (index >= 0) {// 找到了
                    index = line.indexOf(":");// 寻找":"的位置
                    if (index >= 0) {
                        //System.out.println(mac);
                        // 取出mac地址并去除2边空格
                        mac = line.substring(index + 1).trim();
                    }
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (bufferedReader != null) {
                    bufferedReader.close();
                }
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            bufferedReader = null;
            process = null;
        }

        return mac;
    }

    /**
     * windows 7 专用 获取MAC地址
     * 
     * @return
     * @throws Exception
     */
    public static String getMACAddressByWin7() throws Exception {

        // 获取本地IP对象
        InetAddress ia = InetAddress.getLocalHost();
        // 获得网络接口对象（即网卡），并得到mac地址，mac地址存在于一个byte数组中。
        byte[] mac = NetworkInterface.getByInetAddress(ia).getHardwareAddress();

        // 下面代码是把mac地址拼装成String
        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < mac.length; i++) {
            if (i != 0) {
                sb.append("-");
            }
            // mac[i] & 0xFF 是为了把byte转化为正整数
            String s = Integer.toHexString(mac[i] & 0xFF);
            sb.append(s.length() == 1 ? 0 + s : s);
        }

        // 把字符串所有小写字母改为大写成为正规的mac地址并返回
        return sb.toString().toUpperCase();
    }

    /**
     * 测试用的main方法.
     * @throws Exception
     */
    public static String getMACAddress() {
        String os = getOSName();
        if (os.equals("windows 7")) {
            try {
                return getMACAddressByWin7();
            } catch (Exception e) {
                return "";
            }
        } else if (os.startsWith("windows")) {
            return getWindowsMACAddress();
        } else {
            return getUnixMACAddress("ifconfig eth0")+getUnixMACAddress("ifconfig em1");
        }
    }

    public static void main(String[] arguments) throws Exception {
        System.out.println("MAC ......... " + getMACAddress());
        System.out.println(1411544354105L + (1000 * 60 * 60 * 24 * 60));

    }
}
