package com.smt.iptv.epg.entity.pmsa;

public class FeeDetail {
    private String feecode;// 是 01:电话 02:VOD 03:宽带 04:BOS迷你吧
                           // 99:其他（参数Fun非01时，即调用入账进行”付款”操作，这里必须填99）
    private String pccode;// 是 PMS费用码
    private String accnt="";// 否 PMS账号
    private String araccnt="";// 否 PMS AR账号（暂时不用）
    private String roomno;// 否 房号（feecode=01时填分机号）（账号为空时必填，且同住客取账号最大的入账）
    private String guid="";// 否 厂商流水号
    private String amount;// 是 消费单价
    private String quantity;// 是 消费份数
    private String remark;// 是 电话填被叫号、VOD填点播名称等，用于PMS查看
    private String sdate;// 是 账务发生时间（yyyy-MM-dd hh:mm:ss）
    private String ref1="";// 否 功能扩展节点，详见其他说明（枚举说明M03）
    private String ref2="";// 否 功能扩展节点，详见其他说明（枚举说明M04）
    private String ref3="";// 否 功能扩展节点，详见其他说明（枚举说明M05）
    public String getFeecode() {
        return feecode;
    }
    public void setFeecode(String feecode) {
        this.feecode = feecode;
    }
    public String getPccode() {
        return pccode;
    }
    public void setPccode(String pccode) {
        this.pccode = pccode;
    }
    public String getAccnt() {
        return accnt;
    }
    public void setAccnt(String accnt) {
        this.accnt = accnt;
    }
    public String getAraccnt() {
        return araccnt;
    }
    public void setAraccnt(String araccnt) {
        this.araccnt = araccnt;
    }
    public String getRoomno() {
        return roomno;
    }
    public void setRoomno(String roomno) {
        this.roomno = roomno;
    }
    public String getGuid() {
        return guid;
    }
    public void setGuid(String guid) {
        this.guid = guid;
    }
    public String getAmount() {
        return amount;
    }
    public void setAmount(String amount) {
        this.amount = amount;
    }
    public String getQuantity() {
        return quantity;
    }
    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }
    public String getRemark() {
        return remark;
    }
    public void setRemark(String remark) {
        this.remark = remark;
    }
    public String getSdate() {
        return sdate;
    }
    public void setSdate(String sdate) {
        this.sdate = sdate;
    }
    public String getRef1() {
        return ref1;
    }
    public void setRef1(String ref1) {
        this.ref1 = ref1;
    }
    public String getRef2() {
        return ref2;
    }
    public void setRef2(String ref2) {
        this.ref2 = ref2;
    }
    public String getRef3() {
        return ref3;
    }
    public void setRef3(String ref3) {
        this.ref3 = ref3;
    }
    @Override
    public String toString() {
        return "FeeDetail [feecode=" + feecode + ", pccode=" + pccode + ", accnt=" + accnt + ", araccnt=" + araccnt + ", roomno=" + roomno + ", guid=" + guid
                + ", amount=" + amount + ", quantity=" + quantity + ", remark=" + remark + ", sdate=" + sdate + ", ref1=" + ref1 + ", ref2=" + ref2 + ", ref3="
                + ref3 + "]";
    }
    
    

}
