package com.smt.iptv.epg.entity;

import com.smt.iptv.epg.core.IdEntity;

public class ProfileUserInfo extends IdEntity {
    
    public ProfileUserInfo() {
    }

    public ProfileUserInfo(Long id) {
        this.id = id;
    }
    
   
    private String iptvusername;

    public String getIptvusername() {
        return iptvusername;
    }

    public void setIptvusername(String iptvusername) {
        this.iptvusername = iptvusername;
    }
}