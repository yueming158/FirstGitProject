package com.smt.iptv.epg.entity;

import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.smt.iptv.epg.core.CryptCore;
import com.smt.iptv.epg.core.IdEntity;
import com.smt.iptv.epg.core.SystemConstant;

public class Infocontent extends IdEntity {

    public Infocontent() {
    }

    public Infocontent(Long id) {
        this.id = id;
    }

    private String text1;
    private String text2;
    private String text3;
    private String text4;
    private String text5;
    private String areatext;
    @JsonIgnore
    private String smallimageurl;
    @JsonIgnore
    private String largeimageurl;
    private String videourl;// 视频地址

    public String getText1() {
        return text1;
    }

    public void setText1(String text1) {
        this.text1 = text1;
    }

    public String getText2() {
        return text2;
    }

    public void setText2(String text2) {
        this.text2 = text2;
    }

    public String getText3() {
        return text3;
    }

    public void setText3(String text3) {
        this.text3 = text3;
    }

    public String getText4() {
        return text4;
    }

    public void setText4(String text4) {
        this.text4 = text4;
    }

    public String getText5() {
        return text5;
    }

    public void setText5(String text5) {
        this.text5 = text5;
    }

    public String getAreatext() {
        return areatext;
    }

    public void setAreatext(String areatext) {
        this.areatext = areatext;
    }

    public String getSmallimageurl() {
        return smallimageurl;
    }

    public void setSmallimageurl(String smallimageurl) {
        this.smallimageurl = smallimageurl;
    }

    public String getLargeimageurl() {
        return largeimageurl;
    }

    public void setLargeimageurl(String largeimageurl) {
        this.largeimageurl = largeimageurl;
    }

    public String getVideourl() {
        return videourl;
    }

    public void setVideourl(String videourl) {
        this.videourl = videourl;
    }

    public String getSmallimage() {
        String prefix=SystemConstant.getURLValue("image_server_httpprefix");
        if (this.smallimageurl != null && this.smallimageurl.contains(",")) {
            String urls="";
            for(String url:this.smallimageurl.split(",")){
                urls+=prefix+url+",";
            }
            return urls.substring(0, urls.length()-1);
        } else {
            return prefix + this.smallimageurl;
        }
    }

    public String getLargeimage() {
        String prefix=SystemConstant.getURLValue("image_server_httpprefix");
        if (this.largeimageurl != null && this.largeimageurl.contains(",")) {
            String urls="";
            for(String url:this.largeimageurl.split(",")){
                urls+=prefix+url+",";
            }
            return urls.substring(0, urls.length()-1);
        } else {
            return prefix + this.largeimageurl;
        }
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

}