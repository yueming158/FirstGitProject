package com.smt.iptv.epg.entity;

import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.epg.core.IdEntity;

public class Bulletin extends IdEntity {
    
    public Bulletin() {
    }

    public Bulletin(Long id) {
        this.id = id;
    }
    private String important;
	private Date releasetime;
	private Integer loopnumber;
    private String loopintervaltime;
	private String content;
    private String readstatus;
	private String type;

    public String getImportant() {
        return important;
    }

    public void setImportant(String important) {
        this.important = important;
    }

    public Date getReleasetime() {
        return releasetime;
    }

    public void setReleasetime(Date releasetime) {
        this.releasetime = releasetime;
    }

    public Integer getLoopnumber() {
        return loopnumber;
    }

    public void setLoopnumber(Integer loopnumber) {
        this.loopnumber = loopnumber;
    }

    public String getLoopintervaltime() {
        return loopintervaltime;
    }

    public void setLoopintervaltime(String loopintervaltime) {
        this.loopintervaltime = loopintervaltime;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getReadstatus() {
        return readstatus;
    }

    public void setReadstatus(String readstatus) {
        this.readstatus = readstatus;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	} 
}