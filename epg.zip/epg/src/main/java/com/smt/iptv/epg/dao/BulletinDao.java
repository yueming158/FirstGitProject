package com.smt.iptv.epg.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.smt.iptv.epg.entity.Bulletin;
import com.smt.iptv.epg.entity.Page;

@MyBatisRepository
public interface BulletinDao {
    List<Bulletin> getBulletinlistPage(@Param("iptvusername") String iptvusername, @Param("page") Page<Bulletin> page);
    List<Bulletin> getUnreadBulletinlistPage(@Param("iptvusername") String iptvusername, @Param("page") Page<Bulletin> page);
    Integer getUnreadTotal(@Param("iptvusername") String iptvusername);
    void readBulletin(@Param("iptvusername") String iptvusername,@Param("bulletinid")Long bulletinid);
}
