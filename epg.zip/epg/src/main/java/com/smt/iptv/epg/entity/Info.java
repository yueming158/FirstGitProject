package com.smt.iptv.epg.entity;

import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.smt.iptv.epg.core.CryptCore;
import com.smt.iptv.epg.core.IdEntity;
import com.smt.iptv.epg.core.SystemConstant;

public class Info extends IdEntity {
    
    public Info() {
    }

    public Info(Long id) {
        this.id = id;
    }
    
	private String infoname;
	private String infotype;
	private String infotext;
	private String contenturl;//视频地址
	private Date infodate;
	@JsonIgnore
    private String infoimg;
    public String getInfoname() {
        return infoname;
    }

    public void setInfoname(String infoname) {
        this.infoname = infoname;
    }

    public String getInfotype() {
        return infotype;
    }

    public void setInfotype(String infotype) {
        this.infotype = infotype;
    }

    public String getInfotext() {
        return infotext;
    }

    public void setInfotext(String infotext) {
        this.infotext = infotext;
    }


    public String getContenturl() {
        return CryptCore.encryptToDES(contenturl);//加密播放url
    }

    public void setContenturl(String contenturl) {
        this.contenturl = contenturl;
    }

    public Date getInfodate() {
        return infodate;
    }

    public void setInfodate(Date infodate) {
        this.infodate = infodate;
    }

    public String getInfoimg() {
        return infoimg;
    }

    public void setInfoimg(String infoimg) {
        this.infoimg = infoimg;
    }

    public String getImageurl() {
        return SystemConstant.getURLValue("image_server_httpprefix")+this.infoimg;
    }
    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}