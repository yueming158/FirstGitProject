package com.smt.iptv.epg.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.smt.iptv.epg.core.SystemConstant;

public class Epgvariable{

    private String name;
    private String value;
    @JsonIgnore
    private String type;
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getValue() {
        if("I".equals(type)||"F".equals(type)){
            return SystemConstant.getURLValue("image_server_httpprefix")+value;
        }
        return value;
    }
    
    public String getType() {
        return type;
    }
    
    public void setType(String type) {
        this.type = type;
    }
    
    public void setValue(String value) {
        this.value = value;
    }

}