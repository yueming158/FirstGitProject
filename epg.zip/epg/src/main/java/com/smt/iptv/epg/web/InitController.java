package com.smt.iptv.epg.web;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smt.iptv.epg.core.SystemConstant;
import com.smt.iptv.epg.dao.AppInfoDao;
import com.smt.iptv.epg.dao.ChannelDao;
import com.smt.iptv.epg.dao.ProfileDao;
import com.smt.iptv.epg.entity.AppInfo;
import com.smt.iptv.epg.entity.Channel;
import com.smt.iptv.epg.service.qrcode.TwoDimensionCode;

/**
 * @author xjw
 */
@Controller
@RequestMapping(value = "/init")
public class InitController {

    @Autowired
    private ChannelDao channelDao;
    
    @Autowired
    private ProfileDao profileDao;
    
    @Autowired
    private AppInfoDao appInfoDao;
    @RequestMapping(value = "")
    public String login(
            Model model, String userId,String authenticator ,ServletRequest request) {
        return "init/login";
    }
    
	@RequestMapping(value = "init")
	public String list(
			Model model, String userId,String authenticator ,ServletRequest request) {
	    String groupId = profileDao.getChannelgroup(userId);
	    if(groupId==null){
	        groupId="test1";
	    }
	    List<Channel> channels = channelDao.getAllChannel(groupId);
	    model.addAttribute("channels", channels);
	    if(channels!=null){
	        model.addAttribute("channelsize", channels.size());
	    }
	    model.addAttribute("userGroupNMB", groupId);
		return "init/init";
	}
    @RequestMapping(value = "download")
    public String download(Model model) {
        AppInfo android = appInfoDao.getAppInfo("2");
        AppInfo ios = appInfoDao.getAppInfo("4");
        if(android!=null)
        model.addAttribute("android", SystemConstant.getURLValue("image_server_httpprefix")+android.getDownloadurl());
        if(ios!=null)
        model.addAttribute("ios", SystemConstant.getURLValue("image_server_httpprefix")+ios.getDownloadurl());
        return "init/download";
    }
	
    @RequestMapping(value = "qrcode.png")
    @ResponseBody
    public void qrcode(ServletResponse response){
        String qrcodeurl =SystemConstant.getURLValue("epg_server_address")+"init/download";//定死的IOSandroid区分跳转页面
        TwoDimensionCode handler = new TwoDimensionCode();
        // 生成二维码QRCode图片
        OutputStream out;
        try {
            response.setContentType(MediaType.IMAGE_PNG_VALUE);
            out = response.getOutputStream();
            handler.encoderQRCode(qrcodeurl, out, "png", 7,null);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @RequestMapping(value = "qrcode/{name}.png")
    @ResponseBody
    public void qrcode(@PathVariable("name")String name,ServletResponse response){
        String qrcodeurl =SystemConstant.getURLValue("epg_server_address")+"init/download";//定死的IOSandroid区分跳转页面
        TwoDimensionCode handler = new TwoDimensionCode();
        // 生成二维码QRCode图片
        OutputStream out;
        try {
            response.setContentType(MediaType.IMAGE_PNG_VALUE);
            out = response.getOutputStream();
            handler.encoderQRCode(qrcodeurl, out, "png", 7,null);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @RequestMapping(value = "iosqrcode/{name}.png")
    @ResponseBody
    public void iosqrcode(@PathVariable("name")String name,ServletResponse response){
        String qrcodeurl =SystemConstant.getURLValue("epg_server_address")+"init/download";//定死的IOSandroid区分跳转页面
        TwoDimensionCode handler = new TwoDimensionCode();
        // 生成二维码QRCode图片
        OutputStream out;
        try {
            response.setContentType(MediaType.IMAGE_PNG_VALUE);
            out = response.getOutputStream();
            handler.encoderQRCode(qrcodeurl, out, "png", 7,null);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
