package com.smt.iptv.epg.json;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smt.iptv.epg.dao.TrainDao;
import com.smt.iptv.epg.entity.Traincode;
import com.smt.iptv.epg.entity.Trainschedule;

/**
 * 酒店相关接口
 * 
 * @author mills
 */
@Controller
@RequestMapping(value = "/json/train")
public class TrainController {
	@Autowired
	private TrainDao trainDao;
	
	
	
    @RequestMapping(value="/listall" ,method = RequestMethod.GET,  produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<Traincode> listall(String cityname) {
        return trainDao.listall(); 
    }

    @RequestMapping(value="/listbytype" ,method = RequestMethod.GET,  produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<Traincode> listbytype(String type,String cityname) {
        return trainDao.listbytype(type); 
    }
  
    @RequestMapping(value="/listexclude" ,method = RequestMethod.GET,  produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<Traincode> listexclude(String type,String cityname) {
        return trainDao.listexclude(type); 
    }

    @RequestMapping(value="/schedule" , method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<Trainschedule> schedule(String traincode) {
        return trainDao.schedule(traincode); 
    }
    

}
