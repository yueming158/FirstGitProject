package com.smt.iptv.epg.service.program;

import java.text.DecimalFormat;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.epg.core.FtpUtil;
import com.smt.iptv.epg.core.SystemConstant;
import com.smt.iptv.epg.dao.ProgramDao;
import com.smt.iptv.epg.entity.MediaContent;
import com.smt.iptv.epg.entity.Program;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class ProgramService  {

    @Autowired
    private ProgramDao programDao;
    
    @Transactional(readOnly = false)
    public void add(Program program,String sourcefile) {
        try {

            FtpUtil.asyncDownFile(program,sourcefile,this);
//            programDao.addprogram(program);
//            MediaContent mediaContent =new MediaContent();
//            mediaContent.setProgramid(program.getId());
//            mediaContent.setDuration(program.getDuration());
//            mediaContent.setSourcefilename((home+"/"+fileName).substring(1));
//            programDao.addMediacontent(mediaContent);
//            DecimalFormat dcmFmt = new DecimalFormat("progam0000000000");
//            String code =dcmFmt.format(program.getId());
//            program.setCpobjectcode(code);
//            programDao.updateProgramCode(program);
//            DecimalFormat dcmFmt2 = new DecimalFormat("MOV0000000000@CRI");
//            String code2 =dcmFmt2.format(mediaContent.getId());
//            mediaContent.setCpobjectcode(code2);
//            programDao.updateMediacontentCode(mediaContent);
            
        }catch (Exception e) {
            e.printStackTrace();
           throw new RuntimeException("添加失败");
        }
    }
    @Transactional(readOnly = false)
    public void addTodb(Program program,String sourcefile) {
        try {
            String ip= sourcefile.split("@")[1].split("/")[0];
            String home= sourcefile.split("@")[1].substring(ip.length(),sourcefile.split("@")[1].lastIndexOf("/"));
            String fileName= sourcefile.split("@")[1].substring(sourcefile.split("@")[1].lastIndexOf("/")+1);
            programDao.addprogram(program);
            MediaContent mediaContent =new MediaContent();
            mediaContent.setProgramid(program.getId());
            mediaContent.setDuration(program.getDuration());
            mediaContent.setSourcefilename((home+"/"+fileName).substring(1));
            programDao.addMediacontent(mediaContent);
            DecimalFormat dcmFmt = new DecimalFormat("progam0000000000");
            String code =dcmFmt.format(program.getId());
            program.setCpobjectcode(code);
            programDao.updateProgramCode(program);
            DecimalFormat dcmFmt2 = new DecimalFormat("MOV0000000000@CRI");
            String code2 =dcmFmt2.format(mediaContent.getId());
            mediaContent.setCpobjectcode(code2);
            programDao.updateMediacontentCode(mediaContent);
            
        }catch (Exception e) {
            e.printStackTrace();
           throw new RuntimeException("添加失败");
        }
    }
}

