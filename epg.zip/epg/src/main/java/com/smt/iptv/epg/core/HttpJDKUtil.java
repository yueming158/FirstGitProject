package com.smt.iptv.epg.core;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HttpJDKUtil {
    private static Logger logger = LoggerFactory.getLogger(HttpJDKUtil.class);
    public static String executeHttpGet(String urlString,String charsetName) {
        String result = null;
        URL url = null;
        HttpURLConnection connection = null;
        InputStreamReader in = null;
        try {
            url = new URL(urlString);
            connection = (HttpURLConnection) url.openConnection();
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(5000);
            in = new InputStreamReader(connection.getInputStream(),charsetName);
            BufferedReader bufferedReader = new BufferedReader(in);
            StringBuffer strBuffer = new StringBuffer();
            String line = null;
            while ((line = bufferedReader.readLine()) != null) {
                strBuffer.append(line);
            }
            result = strBuffer.toString();
        } catch (Exception e) {
            logger.error("url:"+urlString+"请求失败，原因："+e.getMessage());
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

        }
        return result;
    }
	/**
	 * 
	 * @param urlString
	 * @param paramString "token=alexzhou"
	 * @return
	 */
	public static String executeHttpPost(String urlString,String paramString) {
		String result = null;
		URL url = null;
		HttpURLConnection connection = null;
		InputStreamReader in = null;
		try {
			url = new URL(urlString);
			connection = (HttpURLConnection) url.openConnection();
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(5000);
			connection.setDoInput(true);
			connection.setDoOutput(true);
			connection.setRequestMethod("POST");
			connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			connection.setRequestProperty("Charset", "utf-8");
			DataOutputStream dop = new DataOutputStream(
					connection.getOutputStream());
			dop.writeBytes(paramString);
			dop.flush();
			dop.close();

			in = new InputStreamReader(connection.getInputStream());
			BufferedReader bufferedReader = new BufferedReader(in);
			StringBuffer strBuffer = new StringBuffer();
			String line = null;
			while ((line = bufferedReader.readLine()) != null) {
				strBuffer.append(line);
			}
			result = strBuffer.toString();
		} catch (Exception e) {
		    logger.error("url:"+urlString+"请求失败，原因："+e.getMessage());
		} finally {
			if (connection != null) {
				connection.disconnect();
			}
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

		}
		return result;
	}
	
	public static String executeSoapGet(String urlString,String charsetName) {
        String result = null;
        URL url = null;
        HttpURLConnection connection = null;
        InputStreamReader in = null;
        try {
            url = new URL(urlString);
            connection = (HttpURLConnection) url.openConnection();
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(5000);
            in = new InputStreamReader(connection.getInputStream(),charsetName);
            BufferedReader bufferedReader = new BufferedReader(in);
            StringBuffer strBuffer = new StringBuffer();
            String line = null;
            while ((line = bufferedReader.readLine()) != null) {
                strBuffer.append(line);
            }
            result = strBuffer.toString();
        } catch (Exception e) {
            logger.error("url:"+urlString+"请求失败，原因："+e.getMessage());
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

        }
        return result;
    }
	public static void main(String[] args) {
	        String urlString="http://192.168.1.160:9999/epg/json/pmsa/checkin";
	        String paramString= new String("roomNo=9219&name=李怡昱燚&identityCard=G000056754&sex=0&beginTime=2014-12-16 14:44:00&endTime=2014-12-24 11:02:00 ");
	        String result = null;
	        URL url = null;
	        HttpURLConnection connection = null;
	        InputStreamReader in = null;
	        try {
	            url = new URL(urlString);
	            connection = (HttpURLConnection) url.openConnection();
	            connection.setConnectTimeout(5000);
	            connection.setReadTimeout(5000);
	            connection.setDoInput(true);
	            connection.setDoOutput(true);
	            connection.setRequestMethod("POST");
	            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");//multipart/form-data   text/html 
	            connection.setRequestProperty("Charset", "gb2312");
	            DataOutputStream dop = new DataOutputStream(
	                    connection.getOutputStream());
	            //dop.writeBytes(paramString);
	            dop.write(paramString.getBytes("GB18030"));
	            dop.flush();
	            dop.close();

	            in = new InputStreamReader(connection.getInputStream());
	            BufferedReader bufferedReader = new BufferedReader(in);
	            StringBuffer strBuffer = new StringBuffer();
	            String line = null;
	            while ((line = bufferedReader.readLine()) != null) {
	                strBuffer.append(line);
	            }
	            result = strBuffer.toString();
	        } catch (Exception e) {
	            logger.error("url:"+urlString+"请求失败，原因："+e.getMessage());
	        } finally {
	            if (connection != null) {
	                connection.disconnect();
	            }
	            if (in != null) {
	                try {
	                    in.close();
	                } catch (IOException e) {
	                    e.printStackTrace();
	                }
	            }

	        }
    }
	
}
