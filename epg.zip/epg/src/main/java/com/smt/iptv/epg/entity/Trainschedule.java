package com.smt.iptv.epg.entity;

import com.smt.iptv.epg.core.IdEntity;


public class Trainschedule extends IdEntity {

    public Trainschedule() {
    }

    public Trainschedule(Long id) {
        this.id = id;
    }
    
    private String traincode;
    private Integer sequence;
    private String station;
    private String arrivetime;
    private String leavetime;
    private String staytime;
    
    public String getTraincode() {
        return traincode;
    }
    public void setTraincode(String traincode) {
        this.traincode = traincode;
    }
    public Integer getSequence() {
        return sequence;
    }
    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }
    public String getStation() {
        return station;
    }
    public void setStation(String station) {
        this.station = station;
    }
    public String getArrivetime() {
        return arrivetime;
    }
    public void setArrivetime(String arrivetime) {
        this.arrivetime = arrivetime;
    }
    public String getLeavetime() {
        return leavetime;
    }
    public void setLeavetime(String leavetime) {
        this.leavetime = leavetime;
    }
    public String getStaytime() {
        return staytime;
    }
    public void setStaytime(String staytime) {
        this.staytime = staytime;
    }

}