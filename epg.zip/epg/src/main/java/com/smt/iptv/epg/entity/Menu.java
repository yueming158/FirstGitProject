package com.smt.iptv.epg.entity;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.smt.iptv.epg.core.IdEntity;
import com.smt.iptv.epg.core.SystemConstant;

public class Menu extends IdEntity {
    
    public Menu() {
        super();
    }
    
	private String name;
	private String code;
	private Integer sequence;
	private String templatecode;
	private String zhtitle;
	private String entitle;
	@JsonIgnore
	private String menubg;
	@JsonIgnore
	private String menulogo;
	private String enable;
	private Integer childnum;
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Integer getSequence() {
        return sequence;
    }

    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

    public String getTemplatecode() {
        return templatecode;
    }

    public void setTemplatecode(String templatecode) {
        this.templatecode = templatecode;
    }

    public String getZhtitle() {
        return zhtitle;
    }

    public void setZhtitle(String zhtitle) {
        this.zhtitle = zhtitle;
    }

    public String getEntitle() {
        return entitle;
    }

    public void setEntitle(String entitle) {
        this.entitle = entitle;
    }

    public String getMenubg() {
        return menubg;
    }

    public void setMenubg(String menubg) {
        this.menubg = menubg;
    }
    
    public String getMenubgurl() {
        return SystemConstant.getURLValue("image_server_httpprefix")+ this.menubg;
    }
    
    public String getMenulogo() {
        return menulogo;
    }

    public void setMenulogo(String menulogo) {
        this.menulogo = menulogo;
    }
    
    public String getMenulogourl() {
        return SystemConstant.getURLValue("image_server_httpprefix")+ this.menulogo;
    }
    
    public String getEnable() {
        return enable;
    }

    public void setEnable(String enable) {
        this.enable = enable;
    }

    public Integer getChildnum() {
        return childnum;
    }

    public void setChildnum(Integer childnum) {
        this.childnum = childnum;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}