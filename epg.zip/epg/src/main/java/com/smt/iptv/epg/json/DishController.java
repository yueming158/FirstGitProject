package com.smt.iptv.epg.json;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Lists;
import com.smt.iptv.epg.dao.DishDao;
import com.smt.iptv.epg.dao.DishorderDao;
import com.smt.iptv.epg.entity.Dish;
import com.smt.iptv.epg.entity.Dishcart;
import com.smt.iptv.epg.entity.Dishorder;
import com.smt.iptv.epg.entity.Page;

/**
 * 订餐相关接口
 * 
 * @author rich
 */
@Controller
@RequestMapping(value = "/json/dish")
public class DishController {

    @Autowired
    private DishDao dishDao;
    @Autowired
    private DishorderDao dishorderDao;
    /**
     * 首页推荐
     * 
     * @return
     */
    @RequestMapping(value = "/featured", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    List<Dish> getFeatured() {
        return dishDao.getFeatured();
    }

    /**
     * 菜单分页查询
     * 
     * @param categoryId
     *            来自分类接口
     * @param page
     * @return
     */
    @RequestMapping(value = "/list", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Page<Dish> getDishlistPage(Long categoryId, Page<Dish> page) {
        List<Dish> list = dishDao.getDishlistPage(categoryId, page);
        page.setResult(list);
        return page;
    }

    /**
     * 单个菜品详情
     * 
     * @param id
     * @return
     */
    @RequestMapping(value = "dishdetail", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    Dish getDishById(Long id) {
        return dishDao.getDishById(id);
    }

    /**
     * 相关菜品详情
     * 
     * @param id
     * @return
     */
    @RequestMapping(value = "/recommend", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    List<Dish> getRecommend(String dishstr) {
        if (dishstr != null && dishstr.matches("(\\d+,)*\\d+")) {
            return dishDao.getRecommend(dishstr);
        } else {
            return Lists.newArrayList();
        }
    }

    // 提交订单
    @RequestMapping(value = "/addorder", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    boolean addorder(String username, String tel,@RequestParam(required=false,defaultValue="0")Long dishId,@RequestParam(required=false,defaultValue="0")Integer number) {
        SimpleDateFormat sdf = new SimpleDateFormat(username+"yyMMddHHmmss");
        if(dishId!=0&&number!=0){
            //直接订购
            
            Dish d =dishDao.getDishById(dishId);
            if(d==null){
                return false;
            }
            d.setNumber(number);
            Dishorder order = new Dishorder();
            order.setUsername(username);
            //order.setRoomname(roomname);在sql中实现了
            order.setOrdercode(sdf.format(new Date()));
            order.setTel(tel);
            order.setTotalprice(d.getPrice()*number);
            order.setStatus("1");
            order.setTotalnumber(number);
            dishorderDao.addorder(order); // 新增订单
            dishorderDao.addOrderDishMap(order.getId(), Lists.newArrayList(d)); // 写入订单内容
            dishDao.clearCart(username);//清空购物车
        }
        //购物车订购
        List<Dishcart> cart =dishDao.getCart(username);
        if(cart!=null&&!cart.isEmpty()){
            Integer totalprice = 0;
            Integer totalnumber =0;
            List<Dish> dishList = Lists.newArrayList();
            for (Dishcart c : cart) {
                if(c.getDish()!=null&&c.getDish().getPrice()!=null&&c.getDish().getNumber()!=null){
                    dishList.add(c.getDish());
                    totalprice+=c.getDish().getPrice()*c.getDish().getNumber();
                    totalnumber+=c.getDish().getNumber();
                }
            }
            Dishorder order = new Dishorder();
            order.setUsername(username);
            //order.setRoomname(roomname);在sql中实现了
            order.setOrdercode(sdf.format(new Date()));
            order.setTel(tel);
            order.setTotalprice(totalprice);
            order.setStatus("1");
            order.setTotalnumber(totalnumber);
            dishorderDao.addorder(order); // 新增订单
            dishorderDao.addOrderDishMap(order.getId(), dishList); // 写入订单内容
            dishDao.clearCart(username);//清空购物车
        }
        return true;
    }

    /**
     * 我的订单列表
     * 
     * @param username
     * @return
     */
    @RequestMapping(value = "/myorders", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    List<Dishorder> getMyOrders(String username) {
        return dishorderDao.getMyOrders(username);
    }

    /**
     * 单条订单详情
     * 
     * @param dishstr
     * @return
     */
    @RequestMapping(value = "/orderdetail", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    List<Dish> orderdetail(Long orderid) {
        return dishorderDao.getDishListByOrderid(orderid);
    }

    /**
     * 添加到购物车
     * 
     * @param username
     * @param dishId
     * @param number
     * @return
     */
    @RequestMapping(value = "/addtocart", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    boolean addDishToCart(String username, Long dishId, Integer number,@RequestParam(required=false,value="merge") String merge) {
        if (number == null||dishDao.getDishById(dishId)==null){
            return false;
        }
        if(!"no".equals(merge)){
            //同菜品合并显示 只新增数量
            Dishcart dishcart = dishDao.getDishFromCartByDishId(username, dishId);
            if (dishcart == null) {
                return dishDao.addToCart(username,dishId,number) == 1 ? true : false;
            } else {
                Dish dish = dishcart.getDish();
                Integer newnum =dish.getNumber() == null?number:dish.getNumber() + number;
                return dishDao.modifyNumber(dishcart.getId(),newnum) == 1 ? true : false;
            }
        }else{
            //同菜品分开显示 不显示数量 每次只能添加一道菜
            if(number!=1){
                return false;
            }
            return dishDao.addToCart(username,dishId,number) == 1 ? true : false;
        }
    }

    /**
     * 查看购物车商品列表
     * 
     * @param username
     * @return
     */
    @RequestMapping(value = "/getcart", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    List<Dishcart> getDishListFormCart(String username) {
        return dishDao.getCart(username);
    }

    /**
     * 查看购物车总数
     * 
     * @param username
     * @return
     */
    @RequestMapping(value = "/getcarttotal", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    Integer getCartTotal(String username) {
        return dishDao.getCartTotal(username);
    }

    /**
     * 修改购物车
     * 
     * @param dishcart
     * @return
     */
    @RequestMapping(value = "/modifynumber", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    boolean modifyNumber(Long dishcartId, Integer number) {
        return dishDao.modifyNumber(dishcartId,number) == 1 ? true : false;
    }

    /**
     * 购物车批量删除商品
     * 
     * @param dishcart
     * @return
     */
    @RequestMapping(value = "/delete", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    boolean deleteFormCart(String dishcartids) {
        if (StringUtils.isNotEmpty(dishcartids) && dishcartids.matches("(\\d+,)*\\d+")) {
            return dishDao.deleteFormCart(dishcartids) >0 ? true : false;
        } else {
            return false;
        }
    }

    /**
     * 清空购物车
     * 
     * @param username
     * @return
     */
    @RequestMapping(value = "/clearcart", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    boolean clearCart(String username) {
        return dishDao.clearCart(username) >0 ? true : false;
    }
}
