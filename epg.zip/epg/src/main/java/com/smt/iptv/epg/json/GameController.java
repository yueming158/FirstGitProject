package com.smt.iptv.epg.json;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smt.iptv.epg.dao.GameDao;
import com.smt.iptv.epg.entity.Game;
import com.smt.iptv.epg.entity.Page;

/**
 * 游戏相关接口
 * 
 * @author mills
 */
@Controller
@RequestMapping(value = "/json/app")
public class GameController {

    @Autowired()
    private GameDao gameDao;

    /**
     * 安装游戏分类获取游戏分页列表 /json/app/{apptype}
     */
    @RequestMapping(value = "/{apptype}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Page<Game> listpageByGame(@PathVariable("apptype")String apptype,Page<Game> page) {   	
    	List<Game> list =  gameDao.getGamelistPage(apptype ,page);
    	page.setResult(list);
        return page;
    }
}
