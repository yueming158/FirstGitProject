package com.smt.iptv.epg.json;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Lists;
import com.smt.iptv.epg.core.CryptCore;
import com.smt.iptv.epg.core.SystemConstant;
import com.smt.iptv.epg.dao.CategoryDao;
import com.smt.iptv.epg.dao.ProgramDao;
import com.smt.iptv.epg.entity.Category;
import com.smt.iptv.epg.entity.Channel;
import com.smt.iptv.epg.entity.MediaContent;
import com.smt.iptv.epg.entity.Page;
import com.smt.iptv.epg.entity.Program;

/**
 * 点播相关接口
 * 
 * @author mills
 */
@Controller
@RequestMapping(value = "/json/program")
public class ProgramController {
    private Integer LOAD_BALANCING_NUMBER = 0;// 这里有多线程问题 先暂时忽略 不会致命 可以接受
    @Autowired
    private ProgramDao programDao;
    @Autowired
    private CategoryDao categoryDao;
    /**
     * 根据点播内容类型  分类类型 获取点播列表 /json/program/{programType}/{categoryId}/{pageNo}/{pageSize}
     * @param programType 10 电影 11连续剧  17 音乐 19综艺
     * @param categoryId 分类类型ID
     * @param pageNo 分页对象 当前页
     * @param pageSize 分页对象 每页记录数
     * @return Page<Program> 点播内容的分页对象
     */
    @RequestMapping(value = "/{programType}/{categoryId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Page<Program> listpageByProgram(
            @PathVariable("programType")String programType,@RequestParam(required=false)Integer level,
            @PathVariable("categoryId")Long categoryId,Page<Program> page) {
        //Long pictypeid=1L;
        //Long pictypeid2=2L;
        List<Long> ids = programDao.getPicTypeList(programType);
        Long pictypeid=ids.size()>0?ids.get(0):0L;
        Long pictypeid2=ids.size()>1?ids.get(1):0L;
        List<Program> list =programDao.getProgramlistPage(pictypeid,pictypeid2,categoryId,level,page);
        page.setResult(list);
        return page;
    }
    /**
     *  查看电影详情或者连续剧详情 或者音乐点播详情或者综艺点播详情 /json/program/id/{programid}
     * @param programid 点播节目的ID
     * @return List<MediaContent> 返回详情列表  连续剧的每集列表 或者其他点播内容
     */
    @RequestMapping(value = "/{programid}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<MediaContent> getMediacontentList(
            @PathVariable("programid")Long programid) { 
        List<MediaContent> list =programDao.getMediaContentList(programid);
        String serverprefix = getServerPrefix();
        if(list!=null)
        for (MediaContent m : list) {
            String urltype= m.getUrltype();
            if(urltype!=null&&urltype.equals("u")){
                m.setPlayurl(CryptCore.encryptToDES(m.getOtherplayurl()));
            }else if(urltype!=null&&urltype.startsWith("f")){
                if(!"off".equals(SystemConstant.getValue("load_balancing_vod"))){
                    m.setPlayurl(CryptCore.encryptToDES(serverprefix+m.getSourcefilename()));
                }else{
                    m.setPlayurl(CryptCore.encryptToDES(SystemConstant.getURLValue("CDN_httpserver_address_"+urltype)+m.getSourcefilename()));
                }
            }else{
                //转码点播不支持负载均衡
                m.setPlayurl(CryptCore.encryptToDES(SystemConstant.getURLValue("CDN_server_address")+m.getCpobjectcode()));
            }
        }
    	return list;
    }
    /**
     * 根据点播内容类型  分类类型 获取点播列表 /json/program/{programType}/{categoryId}/{pageNo}/{pageSize}
     * @param programType 10 电影 11连续剧  17 音乐 19综艺
     * @param categoryId 分类类型ID
     * @param pageNo 分页对象 当前页
     * @param pageSize 分页对象 每页记录数
     * @return Page<Program> 点播内容的分页对象
     */
    @RequestMapping(value = "/{categoryId}/recommend", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<Program> recommend(
            @PathVariable("categoryId")Long categoryId,@RequestParam(required=false)Integer level) {
        Category category = categoryDao.findOne(categoryId);
        if(category!=null){
            List<Long> ids = programDao.getPicTypeList(category.getCategorytype());
            Long pictypeid=ids.size()>0?ids.get(0):0L;
            Long pictypeid2=ids.size()>1?ids.get(1):0L;
            List<Program> list =programDao.getProgramlistPage(pictypeid,pictypeid2,categoryId,level,new Page<Program>(1,6));
            return list;
        }
        return Lists.newArrayList();
    }
    
    /**
     * 根据点播内容类型  分类类型 获取点播列表 /json/program/{programType}/{categoryId}/{pageNo}/{pageSize}
     * @param programType 10 电影 11连续剧  17 音乐 19综艺
     * @param categoryId 分类类型ID
     * @param pageNo 分页对象 当前页
     * @param pageSize 分页对象 每页记录数
     * @return Page<Program> 点播内容的分页对象
     */
    @RequestMapping(value = "/search", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Page<Program> search(String searchname,Page<Program> page,@RequestParam(required=false)Integer level) {
         //String programType,
//        List<Long> ids = programDao.getPicTypeList(programType);
//        Long pictypeid=ids.size()>0?ids.get(0):0L;
//        Long pictypeid2=ids.size()>1?ids.get(1):0L;
        if(StringUtils.isBlank(searchname)){
            searchname="''";
        }else{
            searchname="'"+searchname+"%'";
        }
        List<Program> list =programDao.searchProgramlistPage(searchname,level,page);
        page.setResult(list);
        return page;
    }
    /**
     * 根据ID查看历史记录 分页由页面控制
     * @param level
     * @param ids
     * @return
     */
    @RequestMapping(value = "/history", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Page<Program> history(@RequestParam(required=false)Integer level,String ids,Page<Program> page) {
        if(!ids.matches("\\d+(,\\d+)*")){
            return page;
        }
        List<Long> pids = programDao.getPicTypeList("10");
        Long pictypeid=pids.size()>0?pids.get(0):0L;
        Long pictypeid2=pids.size()>1?pids.get(1):0L;
        List<Program> list =programDao.getProgramListByIds(pictypeid, pictypeid2, ids, level);
        
        List<Program> orderlist =Lists.newArrayList();
        for(String id:ids.split(",")){
            label1:
            for(Program p:list){
                if(p.getId().toString().equals(id)){
                    orderlist.add(p);
                    break label1;
                }
            }
        }
        page.setResult(orderlist);
        return page;
    }
    /**
     * 获取负载均衡地址 如其中一地址为空则不路由
     * 
     * @return
     */
    private String getServerPrefix() {
        List<String> addressList = SystemConstant.getVodServerList();
        synchronized(LOAD_BALANCING_NUMBER){
            if (addressList.size() == 0) {
                return "";
            } else if (LOAD_BALANCING_NUMBER < addressList.size()) {
                String url = addressList.get(LOAD_BALANCING_NUMBER);
                LOAD_BALANCING_NUMBER++;
                return url;
            } else {
                LOAD_BALANCING_NUMBER = 1;
                return addressList.get(0);
            }
        }
    }
}
