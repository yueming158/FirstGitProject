package com.smt.iptv.epg.json;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smt.iptv.epg.core.SystemConstant;
import com.smt.iptv.epg.dao.BulletinDao;
import com.smt.iptv.epg.entity.Bulletin;
import com.smt.iptv.epg.entity.Page;
import com.smt.iptv.epg.entity.PushServerAddress;

/**
 * 酒店公告的接口
 * 
 * @author mills
 */
@Controller
@RequestMapping(value = "/json/bulletin")
public class BulletinController {

    @Autowired
    private BulletinDao bulletinDao;
    /**
     * 获取全部消息列表
     */
    @RequestMapping(value = "/all", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Page<Bulletin> list(String iptvusername,Page<Bulletin> page) {
        List<Bulletin> list = bulletinDao.getBulletinlistPage(iptvusername, page);
        page.setResult(list);
        return page;
    }
    /**
     * 获取未读消息列表
     */
    @RequestMapping(value = "/unread", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Page<Bulletin> unreadlist(String iptvusername,Page<Bulletin> page) {
        List<Bulletin> list = bulletinDao.getUnreadBulletinlistPage(iptvusername, page);
        page.setResult(list);
        return page;
    }
    /**
     * 获取未读消息列表
     */
    @RequestMapping(value = "/unreadtotal", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Integer unreadtotal(String iptvusername) {
        return bulletinDao.getUnreadTotal(iptvusername);
    }
    /**
     * 标记消息已经读取
     */
    @RequestMapping(value = "/markread", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Boolean unreadlist(String iptvusername,Long bulletinid) {
        bulletinDao.readBulletin(iptvusername, bulletinid);
        return true;
    }
    
    /**
     * 
     */
    @RequestMapping(value = "/serveraddress", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public PushServerAddress serveraddress(HttpServletRequest requst) {
        String ip =SystemConstant.getValue("push_server_ip")!=null?SystemConstant.getValue("push_server_ip"):requst.getServerName();
        String port =SystemConstant.getValue("push_server_port")!=null&&SystemConstant.getValue("push_server_port").matches("\\d+")?SystemConstant.getValue("push_server_port"):"10000";
        return new PushServerAddress(ip,Integer.parseInt(port));
    }
}
