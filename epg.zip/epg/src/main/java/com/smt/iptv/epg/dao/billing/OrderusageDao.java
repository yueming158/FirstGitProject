package com.smt.iptv.epg.dao.billing;


import java.util.Date;

import org.apache.ibatis.annotations.Param;

import com.smt.iptv.epg.dao.MyBatisRepository;
import com.smt.iptv.epg.entity.billing.Orderusage;

@MyBatisRepository
public interface OrderusageDao {
	public void saveOrderusage(Orderusage orderUsage);

	public Date getLastOrderusage(@Param("accountid") Long accountId, @Param("productofferid")Long productofferid);
	
}
