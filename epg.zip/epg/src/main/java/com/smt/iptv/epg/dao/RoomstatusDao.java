package com.smt.iptv.epg.dao;

import com.smt.iptv.epg.entity.Roomstatus;

@I18nMyBatisRepository
public interface RoomstatusDao {
    Roomstatus getRoomstatusByAccount(String account);
}
