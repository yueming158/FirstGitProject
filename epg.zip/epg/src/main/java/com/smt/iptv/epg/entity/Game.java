package com.smt.iptv.epg.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.smt.iptv.epg.core.IdEntity;
import com.smt.iptv.epg.core.SystemConstant;

public class Game extends IdEntity {

    private String gamename;
    private Integer gamesize;
    private Integer downnum;
    @JsonIgnore
    private String downurl;
    @JsonIgnore
    private String imgurl;
    private String entrance;
    private String gamepackage;
    private String description;
    public String getGamename() {
        return gamename;
    }
    public void setGamename(String gamename) {
        this.gamename = gamename;
    }
    public Integer getGamesize() {
        return gamesize;
    }
    public void setGamesize(Integer gamesize) {
        this.gamesize = gamesize;
    }
    public Integer getDownnum() {
        return downnum;
    }
    public void setDownnum(Integer downnum) {
        this.downnum = downnum;
    }
    public String getDownurl() {
        return downurl;
    }
    public void setDownurl(String downurl) {
        this.downurl = downurl;
    }
    public String getEntrance() {
        return entrance;
    }
    public void setEntrance(String entrance) {
        this.entrance = entrance;
    }
    public String getGamepackage() {
        return gamepackage;
    }
    public void setGamepackage(String gamepackage) {
        this.gamepackage = gamepackage;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public String getImgurl() {
        return imgurl;
    }
    public void setImgurl(String imgurl) {
        this.imgurl = imgurl;
    }
    public String getImageurl() {
        return SystemConstant.getURLValue("image_server_httpprefix")+this.imgurl;
    }
    public String getDownloadurl() {
        return SystemConstant.getURLValue("image_server_httpprefix")+this.downurl;
    }
    
}