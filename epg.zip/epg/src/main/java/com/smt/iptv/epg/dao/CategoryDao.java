package com.smt.iptv.epg.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.smt.iptv.epg.entity.Category;

@I18nMyBatisRepository
public interface CategoryDao {
     List<Category> getVodType();
	 List<Category> getCategoryList(@Param("type")String type, @Param("menucode")String menucode);
     List<Category> getSecondListByCategoryId(Long categoryId);
     Category findOne(Long categoryId);
}
