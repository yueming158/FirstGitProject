package com.smt.iptv.epg.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.smt.iptv.epg.core.IdEntity;


public class AppInfo extends IdEntity {
    @JsonIgnore
    private String appupdateinfoname;
    private String versioncode;
	private String version;
	private String needupdate;
	private String downloadurl;
	private String forceupdate;
	@JsonIgnore
	private String description;
	@JsonIgnore
	private String apptype;
	@JsonIgnore
	private String accnts;
	
    public String getVersioncode() {
        return versioncode;
    }
    public void setVersioncode(String versioncode) {
        this.versioncode = versioncode;
    }
    public String getVersion() {
        return version;
    }
    public void setVersion(String version) {
        this.version = version;
    }
    public String getNeedupdate() {
        return needupdate;
    }
    public void setNeedupdate(String needupdate) {
        this.needupdate = needupdate;
    }
    public String getDownloadurl() {
        return downloadurl;
    }
    public void setDownloadurl(String downloadurl) {
        this.downloadurl = downloadurl;
    }
    public String getForceupdate() {
        return forceupdate;
    }
    public void setForceupdate(String forceupdate) {
        this.forceupdate = forceupdate;
    }
    public String getAppupdateinfoname() {
        return appupdateinfoname;
    }
    public void setAppupdateinfoname(String appupdateinfoname) {
        this.appupdateinfoname = appupdateinfoname;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public String getApptype() {
        return apptype;
    }
    public void setApptype(String apptype) {
        this.apptype = apptype;
    }
    public String getAccnts() {
        return accnts;
    }
    public void setAccnts(String accnts) {
        this.accnts = accnts;
    }

}
