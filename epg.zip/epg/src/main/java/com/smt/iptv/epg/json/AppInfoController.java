package com.smt.iptv.epg.json;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smt.iptv.epg.core.SystemConstant;
import com.smt.iptv.epg.dao.AppInfoDao;
import com.smt.iptv.epg.entity.AppInfo;

/**
 * APP更新接口
 * 
 * @author mills
 */
@Controller
@RequestMapping(value = "/json/appinfo")
public class AppInfoController {

    @Autowired()
    private AppInfoDao appInfoDao;
    
    /**
     * 获取是服务器的最新APP版本 /json/appinfo/{apptype}
     * @param apptype 1：IPTV 2：OTT 可以扩展
     * @return 最新版本信息
     */
    @RequestMapping(value = "/{apptype}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public AppInfo getAppInfo(@PathVariable("apptype") String apptype,@RequestParam(required=false)Integer iptvusername) {
        if(iptvusername!=null){
            AppInfo special = appInfoDao.getAppInfoForSpecialAccnts(apptype);
            if(special!=null&&StringUtils.isNotBlank(special.getAccnts())){//有灰度升级的apk
                String [] accnts =special.getAccnts().split(",");
                for(String accnt:accnts ){
                    if(accnt.indexOf("-")==-1){
                        //逗号分隔的 单个账号直接判断等不等
                        if(accnt.equals(iptvusername.toString())){
                            if(StringUtils.isEmpty(special.getDownloadurl())||!special.getDownloadurl().endsWith(".apk")){
                                AppInfo appInfo = new AppInfo();
                                appInfo.setForceupdate("0");
                                appInfo.setNeedupdate("0");
                                appInfo.setVersion("1.0");
                                appInfo.setVersioncode("1");
                                return appInfo;
                            }
                            special.setDownloadurl(SystemConstant.getURLValue("image_server_httpprefix")+special.getDownloadurl());
                            return special;
                        }
                    }else{
                       //逗号分隔的 多个账号判断是否在账号区间内
                        try{
                            int start=Integer.parseInt(accnt.split("-")[0]);
                            int end=Integer.parseInt(accnt.split("-")[1]);
                            if(iptvusername>=start&&iptvusername<=end){
                                if(StringUtils.isEmpty(special.getDownloadurl())||!special.getDownloadurl().endsWith(".apk")){
                                    AppInfo appInfo = new AppInfo();
                                    appInfo.setForceupdate("0");
                                    appInfo.setNeedupdate("0");
                                    appInfo.setVersion("1.0");
                                    appInfo.setVersioncode("1");
                                    return appInfo;
                                }
                                special.setDownloadurl(SystemConstant.getURLValue("image_server_httpprefix")+special.getDownloadurl());
                                return special;
                            }
                        }catch (Exception e) {
                           continue;
                        }
                    }
                }
            }
        }
        AppInfo appInfo = appInfoDao.getAppInfo(apptype);
        if(appInfo==null||StringUtils.isEmpty(appInfo.getDownloadurl())||!appInfo.getDownloadurl().endsWith(".apk")){
            appInfo = new AppInfo();
            appInfo.setForceupdate("0");
            appInfo.setNeedupdate("0");
            appInfo.setVersion("1.0");
            appInfo.setVersioncode("1");
            return appInfo;
        }else{
            appInfo.setDownloadurl(SystemConstant.getURLValue("image_server_httpprefix")+appInfo.getDownloadurl());
            return appInfo;
        }
    }
}
