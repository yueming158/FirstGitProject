package com.smt.iptv.epg.entity.billing;

import java.util.ArrayList;
import java.util.List;


import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springside.modules.mapper.JsonMapper;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.JavaType;
import com.smt.iptv.epg.core.IdEntity;

public class Productoffer extends IdEntity {
	public Productoffer(){
	}
	public Productoffer(Long id){
		this.id = id;
	}
	
	private String productoffertype;
	private String offername;
	private String strategytype;
	//价格单位为分
	private int price;
	private int cycleduration;
	private String description;
	@JsonIgnore
	private String attrs;	

	private static JsonMapper mapper = new JsonMapper();
    private static JavaType attrsType =mapper.createCollectionType(ArrayList.class, Attr.class);
    public List<Attr> getAttrList() {

        if (StringUtils.isNotEmpty(attrs)) {
            return mapper.fromJson(attrs, attrsType);
        } else {
            return null;
        }
    }
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getAttrs() {
		return attrs;
	}
	public void setAttrs(String attrs) {
		this.attrs = attrs;
	}
	public String getProductoffertype() {
		return productoffertype;
	}
	public void setProductoffertype(String productoffertype) {
		this.productoffertype = productoffertype;
	}
	public String getOffername() {
		return offername;
	}
	public void setOffername(String offername) {
		this.offername = offername;
	}
	public String getStrategytype() {
		return strategytype;
	}
	public void setStrategytype(String strategytype) {
		this.strategytype = strategytype;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getCycleduration() {
		return cycleduration;
	}
	public void setCycleduration(int cycleduration) {
		this.cycleduration = cycleduration;
	}
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
	
}
