package com.smt.iptv.epg.entity.pmsa;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)  
@XmlType(propOrder = { "hall", "flr","roomtype" ,"roomno","roomstate","isEA","isED"})  
public class Room {
    private String hall;// 楼号
    private String flr;// 楼层
    private String roomtype;// 房型代码
    private String roomno;// 房号
    private String roomstate;// 房间状态，详见其他说明(枚举说明M01)
    private String isEA;// 是否本日将到(1.是 2.否)
    private String isED;// 是否本日将离(1.是 2.否)
    public String getHall() {
        return hall;
    }
    public void setHall(String hall) {
        this.hall = hall;
    }
    public String getFlr() {
        return flr;
    }
    public void setFlr(String flr) {
        this.flr = flr;
    }
    public String getRoomtype() {
        return roomtype;
    }
    public void setRoomtype(String roomtype) {
        this.roomtype = roomtype;
    }
    public String getRoomno() {
        return roomno;
    }
    public void setRoomno(String roomno) {
        this.roomno = roomno;
    }
    public String getRoomstate() {
        return roomstate;
    }
    public void setRoomstate(String roomstate) {
        this.roomstate = roomstate;
    }
    public String getIsEA() {
        return isEA;
    }
    public void setIsEA(String isEA) {
        this.isEA = isEA;
    }
    public String getIsED() {
        return isED;
    }
    public void setIsED(String isED) {
        this.isED = isED;
    }
    @Override
    public String toString() {
        return "Room [hall=" + hall + ", flr=" + flr + ", roomtype=" + roomtype + ", roomno=" + roomno + ", roomstate=" + roomstate + ", isEA=" + isEA
                + ", isED=" + isED + "]";
    }

}
