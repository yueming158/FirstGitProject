/**
 * Copyright (c) 2005-2010 springside.org.cn
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * 
 * $Id: Page.java 1183 2010-08-28 08:05:49Z calvinxiu $
 */
package com.smt.iptv.epg.entity;

import java.util.ArrayList;
import java.util.List;


public class Page<T> {
    protected int pageNo = 1;
    protected int pageSize = -1;
    protected long totalCount = -1;
    protected List<T> result = new ArrayList<T>();
    
    // -- 构造函数 --//
    public Page() {
    }
    
    public Page(int pageNo,int pageSize) {
        this.setPageNo(pageNo);
        this.pageSize = pageSize;
    }
    
    public int getPageNo() {
        return pageNo;
    }
    
    public void setPageNo(int pageNo) {
        this.pageNo = pageNo>=1?pageNo:1;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public List<T> getResult() {
        return result;
    }

    public void setResult(final List<T> result) {
        this.result = result;
    }

    public long getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(final long totalCount) {
        this.totalCount = totalCount;
    }

    //根据pageNo和pageSize计算当前页第一条记录在总结果集中的位置,序号从0开始.
    public int getFirst() {
        return ((pageNo - 1) * pageSize);
    }
    
    //根据pageSize与totalCount计算总页数, 默认值为-1.
    public long getTotalPages() {
        if (totalCount < 0) {
            return -1;
        }
        long count = totalCount / pageSize;
        if (totalCount % pageSize > 0) {
            count++;
        }
        return count;
    }

    //是否还有下一页.
    public boolean isHasNext() {
        	return(pageNo + 1 <= getTotalPages());
    }
}
