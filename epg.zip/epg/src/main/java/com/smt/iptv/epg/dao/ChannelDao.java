package com.smt.iptv.epg.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.smt.iptv.epg.entity.Channel;
import com.smt.iptv.epg.entity.Page;


@MyBatisRepository
public interface ChannelDao {
    
	List<Channel> getChannellistPage(@Param("groupId")String groupId, @Param("categoryId")Long categoryId,@Param("page")Page<Channel> page);
	
	List<Channel> getAllChannel(String groupId);
	
	List<Channel> getTvodChannel(String groupId);
	
	Channel getChannel(Long channelid);
	
	List<Channel> getChannelListTwoSchedule(@Param("groupId")String groupId,@Param("categoryId")Long categoryId);
}
