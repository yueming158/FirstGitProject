package com.smt.iptv.epg.entity;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.smt.iptv.epg.core.IdEntity;
import com.smt.iptv.epg.core.SystemConstant;

public class Program extends IdEntity {
    
    public Program() {
    }

    public Program(Long id) {
        this.id = id;
    }

    private String programname;
    private String searchname;
    private String year;
    private String starrating;
    private String areaname;
    private String programtype;
    private String genrenames;
    private String actornames;
    private String writernames;
    private String description;
    private Integer price;
    @JsonIgnore
    private String pictureurl;
    @JsonIgnore
    private String pictureurl2;
    
    
    
    
    
    @JsonIgnore
    private String cpobjectcode;
    @JsonIgnore
    private Integer duration;

    @JsonIgnore
    private String urltype;
    @JsonIgnore
    private String otherplayurl;
    
    //是否为vip付费点播视频,1表示vip 非1表示非vip
    private String vip;
    
	public String getVip() {
		return vip;
	}

	public void setVip(String vip) {
		this.vip = vip;
	}

	public String getProgramname() {
        return programname;
    }
    @JsonIgnore
    public String getPlayurl() {
        return  SystemConstant.getURLValue("CDN_server_address")+this.cpobjectcode;
    }

    public String getImageurl() {
        return SystemConstant.getURLValue("image_server_httpprefix")+this.pictureurl;
    }
    
    public String getImageurlbig() {
        return SystemConstant.getURLValue("image_server_httpprefix")+this.pictureurl2;
    }
    
    public void setProgramname(String programname) {
        this.programname = programname;
    }

    public String getSearchname() {
        return searchname;
    }

    public void setSearchname(String searchname) {
        this.searchname = searchname;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getStarrating() {
        return starrating;
    }

    public void setStarrating(String starrating) {
        this.starrating = starrating;
    }

    public String getAreaname() {
        return areaname;
    }

    public void setAreaname(String areaname) {
        this.areaname = areaname;
    }

    public String getProgramtype() {
        return programtype;
    }

    public void setProgramtype(String programtype) {
        this.programtype = programtype;
    }

    public String getGenrenames() {
        return genrenames;
    }

    public void setGenrenames(String genrenames) {
        this.genrenames = genrenames;
    }

    public String getActornames() {
        return actornames;
    }

    public void setActornames(String actornames) {
        this.actornames = actornames;
    }

    public String getWriternames() {
        return writernames;
    }

    public void setWriternames(String writernames) {
        this.writernames = writernames;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCpobjectcode() {
        return cpobjectcode;
    }

    public void setCpobjectcode(String cpobjectcode) {
        this.cpobjectcode = cpobjectcode;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }
    
    public String getPictureurl() {
        return pictureurl;
    }

    public void setPictureurl(String pictureurl) {
        this.pictureurl = pictureurl;
    }

    public String getPictureurl2() {
        return pictureurl2;
    }

    public void setPictureurl2(String pictureurl2) {
        this.pictureurl2 = pictureurl2;
    }

    public String getUrltype() {
        return urltype;
    }

    public void setUrltype(String urltype) {
        this.urltype = urltype;
    }

    public String getOtherplayurl() {
        return otherplayurl;
    }

    public void setOtherplayurl(String otherplayurl) {
        this.otherplayurl = otherplayurl;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}