package com.smt.iptv.epg.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.smt.iptv.epg.entity.Hotelcall;
import com.smt.iptv.epg.entity.Hotelcustomer;

@MyBatisRepository
public interface HotelcallDao  {
    
	List<Hotelcall> getHotelcall(@Param("reqtype")String reqtype,@Param("iptvusername")String iptvusername);
	
	List<Hotelcall> getCheckinoutcall(@Param("iptvusername")String iptvusername);
	
	Hotelcustomer getHotelcustomer(String iptvusername);
    int cancel(@Param("iptvusername")String iptvusername,@Param("type")String type);
    int cancelroom(@Param("iptvusername")String iptvusername);
    
	int insertHotercall(Hotelcall hotelcall);
	
	int cancelBeforeResponse(Long id);
}