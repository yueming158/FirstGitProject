package com.smt.iptv.epg.entity.billing;

import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.epg.core.IdEntity;

public class Account extends IdEntity {

	public Account() {
		
	}
	public Account(Long id) {
		this.id = id;
	}
	
	private Long userid;
	private Long usergroupid;
	private String accountname;
	//状态 0 为无效 ,1为有效
	private String status;
	private Date creationdate;
	private String description;
	private int balance;
	
	public Long getUserid() {
		return userid;
	}
	public void setUserid(Long userid) {
		this.userid = userid;
	}
	public Long getUsergroupid() {
		return usergroupid;
	}
	public void setUsergroupidLong(Long usergroupid) {
		this.usergroupid = usergroupid;
	}
	public String getAccountname() {
		return accountname;
	}
	public void setAccountname(String accountname) {
		this.accountname = accountname;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getCreationdate() {
		return creationdate;
	}
	public void setCreationdate(Date creationdate) {
		this.creationdate = creationdate;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public void setUsergroupid(Long usergroupid) {
		this.usergroupid = usergroupid;
	}
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
	
}
