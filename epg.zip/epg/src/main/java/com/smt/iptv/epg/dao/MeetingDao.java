package com.smt.iptv.epg.dao;

import java.util.List;

import com.smt.iptv.epg.entity.Meeting;

@I18nMyBatisRepository
public interface MeetingDao {
	List<Meeting> findAllByToday();
}
