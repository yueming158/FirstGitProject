package com.smt.iptv.epg.entity;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.smt.iptv.epg.core.IdEntity;

public class Dishorder extends IdEntity {

    private String roomname;
    private String username;
    private String ordercode;
    private Integer totalprice;
    private Integer totalnumber;
    private String status;
    private String creationtime;
    @JsonIgnore
    private String verifypeople;
    @JsonIgnore
    private String verifytime;
    @JsonIgnore
    private String deliverpeople;
    @JsonIgnore
    private String delivertime;
    private String completetime;
    private String tel;
    
    public String getRoomname() {
        return roomname;
    }

    public void setRoomname(String roomname) {
        this.roomname = roomname;
    }

    public String getOrdercode() {
        return ordercode;
    }

    public void setOrdercode(String ordercode) {
        this.ordercode = ordercode;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Integer getTotalprice() {
        return totalprice;
    }

    public void setTotalprice(Integer totalprice) {
        this.totalprice = totalprice;
    }

    public Integer getTotalnumber() {
        return totalnumber;
    }

    public void setTotalnumber(Integer totalnumber) {
        this.totalnumber = totalnumber;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCreationtime() {
        return creationtime.replace(".0", "");
    }

    public void setCreationtime(String creationtime) {
        this.creationtime = creationtime;
    }

    public String getVerifypeople() {
        return verifypeople;
    }

    public void setVerifypeople(String verifypeople) {
        this.verifypeople = verifypeople;
    }

    public String getVerifytime() {
        return verifytime;
    }

    public void setVerifytime(String verifytime) {
        this.verifytime = verifytime;
    }

    public String getDeliverpeople() {
        return deliverpeople;
    }

    public void setDeliverpeople(String deliverpeople) {
        this.deliverpeople = deliverpeople;
    }

    public String getDelivertime() {
        return delivertime;
    }

    public void setDelivertime(String delivertime) {
        this.delivertime = delivertime;
    }

    public String getCompletetime() {
        return completetime;
    }

    public void setCompletetime(String completetime) {
        this.completetime = completetime;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
}