package com.smt.iptv.epg.task;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.SocketException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPReply;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.smt.iptv.epg.core.SystemConstant;



public class FtpFileSyncUtil {

    private static Logger logger = LoggerFactory.getLogger(FtpFileSyncUtil.class);
    /**
     * Description: 从FTP服务器下载指定时间戳之后的全部文件存放到本地目录
     * @param time 时间戳
     * @param url FTP服务器hostname
     * @param port FTP服务器端口
     * @param username FTP登录账号
     * @param password FTP登录密码
     * @param remotePath FTP服务器上的相对路径
     * @param localPath 下载后保存到本地的路径
     * @return
     */
    public static long downOverTimeFile(long time, String url, int port, String username, String password, String remotePath, String localPath,
            String charsetName) {
        long lastmodifytime = time;
        FTPClient ftp = new FTPClient();
        try {
            int reply;
            logger.info("time"+time+" url:"+url+" port:"+port+" username:"+username+" password"+password+" :charsetName"+charsetName+" remotePath"+remotePath);
            ftp.connect(url, port);// 如果采用默认端口，可以使用ftp.connect(url)的方式直接连接FTP服务器
            ftp.login(username, password);// 登录
            ftp.setControlEncoding(charsetName);
            for(String s:ftp.listNames()){
                logger.info(s);
            }
            reply = ftp.getReplyCode();
            if (!FTPReply.isPositiveCompletion(reply)) {
                logger.info("FTPReply.isPositiveCompletion(reply) 为否 直接退出");
                ftp.disconnect();
                return lastmodifytime;
            }
            ftp.changeWorkingDirectory(remotePath);// 转移到FTP服务器目录
            lastmodifytime = downListFiles(ftp, time, localPath, charsetName);
            ftp.logout();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (ftp.isConnected()) {
                try {
                    ftp.disconnect();
                } catch (IOException ioe) {
                }
            }
        }
        return lastmodifytime;
    }
    /**
     * 递归拷贝所有文件的方法
     * @param ftp
     * @param time
     * @param localPath
     * @param charsetName
     * @throws IOException
     */
    private static long downListFiles(FTPClient ftp, long time, String localPath, String charsetName) throws IOException {
        FTPFile[] fs = ftp.listFiles();
        long maxtime=0;
        for (FTPFile ff : fs) {
            long newtime =0l;
            if (ff.isFile()) {
                newtime =ff.getTimestamp().getTime().getTime();
               // System.out.println(ff.getName() +"lastmodifytime:" + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(ff.getTimestamp().getTime())+" time:"+new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date(time))+ ":");
                if (newtime > time) {// if(ff.getName().equals(fileName)){
                    
                    File localFile = new File(localPath + "/" + ff.getName());
                    OutputStream out = new FileOutputStream(localFile);
                    ftp.retrieveFile(new String(ff.getName().getBytes(charsetName), "iso8859-1"), out);//需要开个线程来做
                    out.close();
                }
            } else if (ff.isDirectory() && !ff.getName().equals(".") && !ff.getName().equals("..")) {
                ftp.cwd(new String(ff.getName().getBytes(charsetName), "iso8859-1"));
                File d = new File(localPath + "/" + ff.getName());
                if (!d.exists()) {
                    d.mkdirs();
                }
                newtime = downListFiles(ftp, time, localPath + "/" + ff.getName(), charsetName);
                
            }
            if(newtime>maxtime){
                maxtime=newtime;
            }
        }
        ftp.cdup();
        return maxtime;
    }
    //异步下载文件方法
    
    //ftp://xjw:123456@60.194.136.206/home/xjw/wrere.mp4
    public static void downFile(String ftpurl){
        String username= ftpurl.split("@")[0].split(":")[1].substring(2);
        String pwd= ftpurl.split("@")[0].split(":")[2];
        String ip= ftpurl.split("@")[1].split("/")[0];
        String home= ftpurl.split("@")[1].substring(ip.length());
        String name= ftpurl.split("@")[1].substring(ip.length());
        FTPClient ftp = new FTPClient();
        try {
            ftp.connect(ip);

            // 如果采用默认端口，可以使用ftp.connect(url)的方式直接连接FTP服务器
            ftp.login(username, pwd);// 登录
            ftp.changeWorkingDirectory(home);
            
            File localFile = new File(SystemConstant.getURLValue("fileupload")+"content/"+name);
            OutputStream out = new FileOutputStream(localFile);
            ftp.retrieveFile("xx.ts", out);
            IOUtils.closeQuietly(out);
        } catch (SocketException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
       // FileUtils

            

    }
}