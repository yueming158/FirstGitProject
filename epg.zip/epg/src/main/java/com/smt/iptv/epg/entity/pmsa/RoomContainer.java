package com.smt.iptv.epg.entity.pmsa;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
@XmlAccessorType(XmlAccessType.FIELD)  
@XmlRootElement(name="string")
public class RoomContainer{
    
    private String time;
    @XmlElementWrapper(name="interface")
    @XmlElement(name = "items",type=Room.class)
    private List<Room> items;
    
    public List<Room> getItems() {
        return items;
    }
    public void setItems(List<Room> items) {
        this.items = items;
    }

    public String getTime() {
        return time;
    }
    public void setTime(String time) {
        this.time = time;
    }
    @Override
    public String toString() {
        return "Intetface [items=" + items + "]";
    }   
    
    
}