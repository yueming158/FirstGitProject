package com.smt.iptv.epg.service.billing;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.epg.dao.billing.AccountDao;
import com.smt.iptv.epg.dao.billing.AccountrecordDao;
import com.smt.iptv.epg.dao.billing.OrderusageDao;
import com.smt.iptv.epg.dao.billing.ProductofferDao;
import com.smt.iptv.epg.entity.billing.Account;
import com.smt.iptv.epg.entity.billing.Accountrecord;
import com.smt.iptv.epg.entity.billing.Orderresultcode;
import com.smt.iptv.epg.entity.billing.Orderusage;
import com.smt.iptv.epg.entity.billing.Productoffer;

@Component
@Transactional(readOnly=true)   
public class OrderusageService {
	private static final long TIME_UNTIS = 3600*1000*24;
	@Autowired
	private AccountDao accountDao;
	@Autowired
	private ProductofferDao productOfferDao;
	@Autowired
	private OrderusageDao orderusageDao;
	@Autowired
	private AccountrecordDao accountRecordDao;
	@Transactional(rollbackFor=Exception.class)
	public Orderresultcode addOrder(String productofferid,String iptvusername) {
		//判断账户余额是否充足等前提条件
		Account account = accountDao.getAccount(iptvusername);
		Productoffer productOffer = productOfferDao.getProductoffer(productofferid);
		//无此商品
		if(null==productOffer){
			return new Orderresultcode("10002", "订购失败商品信息错误");
		}
		//无此账号
		if(null==account){
			return new Orderresultcode("10003", "订购失败无账号信息");
		}
		int balance = account.getBalance();
		//余额是否充足
		if(balance<productOffer.getPrice()){
			return new Orderresultcode("10004", "订购失败余额不足");
		}
		//订购商品(记录订购信息表,余额扣除,记录账户操作日志)
		try {
			int rows = accountDao.updateAccountBalance(account.getId(), balance-productOffer.getPrice());
			if(rows <= 0) {
				throw new RuntimeException();
			}
			Orderusage orderUsage = constructOrderUsage(productOffer,account.getId());
			orderusageDao.saveOrderusage(orderUsage);
			if(orderUsage.getId() <= 0){
				throw new RuntimeException();
			}
			Accountrecord accountRecord = new Accountrecord();
			accountRecord.setBalance(productOffer.getPrice());
			accountRecord.setOrderusageid(orderUsage.getId());
			accountRecord.setType("1");
			accountRecord.setAccountid(account.getId());
			accountRecord.setRecorddate(orderUsage.getCreationtime());
			rows = accountRecordDao.saveAccountrecord(accountRecord);
			if(rows <= 0){
				throw new RuntimeException();
			}
		} catch (Exception e) {
			throw new RuntimeException();
		}
		//返回订购结果状态
		return new Orderresultcode("10001", "订购成功");
	}

	private Orderusage constructOrderUsage(Productoffer productOffer,Long accountId){
		Orderusage orderUsage = new Orderusage();
		orderUsage.setAccountid(accountId);
		orderUsage.setCreationtime(new Date());
		orderUsage.setListprice(productOffer.getPrice());
		orderUsage.setOrderstarttime(orderUsage.getCreationtime());
		// 如果订购的是周期性产品需要进行处理
		//如果是周期性的商品且重复购买需要累加时间 两类情况 一类 已过期 一类为过期 
		//
		if(productOffer.getStrategytype().equals("1")){
			Date lastEndDate = orderusageDao.getLastOrderusage(accountId, productOffer.getId());	
			if(null !=lastEndDate && orderUsage.getOrderstarttime().compareTo(lastEndDate)<0) {
				orderUsage.setOrderstarttime(lastEndDate);
			}
		}
		orderUsage.setOrderendtime(new Date(orderUsage.getOrderstarttime().getTime()+productOffer.getCycleduration()*TIME_UNTIS));
		orderUsage.setPaystatus("2");
		orderUsage.setProductofferid(productOffer.getId());
		orderUsage.setProductoffername(productOffer.getOffername());
		return orderUsage;
	}
}
