package com.smt.iptv.epg.json.aotuaddress;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smt.iptv.epg.core.Result;
import com.smt.iptv.epg.core.SystemConstant;
import com.smt.iptv.epg.dao.ProfileDao;
import com.smt.iptv.epg.entity.Profile;

/**
 * 酒店相关接口
 * 
 * @author mills
 */
@Controller
@RequestMapping(value = "/json/stbinit")
public class StbinitController {
    @Autowired
    private ProfileDao profileDao;
    /**
     * 获取服务器地址
     */
    @RequestMapping(value="/epgaddress" , method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Result systemconfig() {
        String str =SystemConstant.getValue("epg_server_address");
        if(StringUtils.isNotEmpty(str)&&str.startsWith("http://")&&str.endsWith("/epg")){
            return new Result(true, str.substring(7, str.length()-4));
        }else{
            return new Result(false, "后台epg_server_address配置有误");
        }
    }
    /**
     * 获取机顶盒信息
     */
    @RequestMapping(value="/cfg" , method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Stbcfg cfg(String mac) {
        Stbcfg stbcfg = new Stbcfg();
        Profile p= profileDao.getProfileByMac(mac.toUpperCase());
        if(p==null){
            stbcfg.setResult(false);
            stbcfg.setDesc("服务器未配置该设备");
            return stbcfg;
        }
//        //未记录token
//        if(StringUtils.isEmpty(p.getToken())){
//            if(StringUtils.isEmpty(token)){
//                stbcfg.setToken(String.valueOf(System.currentTimeMillis()));
//                p.setToken(stbcfg.getToken());
//                profileDao.updateToken(p);
//            }else{
//                stbcfg.setToken(token);
//                p.setToken(token);
//                profileDao.updateToken(p);
//            }
//        }else{
//            if(!p.getToken().equals(token)){
//                stbcfg.setResult(false);
//                stbcfg.setDesc("TOKEN错误,机顶盒MAC冲突");
//                return stbcfg;
//            }else{
//                stbcfg.setToken(p.getToken());
//            }
//        }
        stbcfg.setIptvusername(p.getIptvusername());
        stbcfg.setPassword(p.getIptvpassword());
        stbcfg.setIpaddr(p.getDistributeip());
        stbcfg.setMask(SystemConstant.getValue("stbinit_mask"));
        stbcfg.setGateway(SystemConstant.getValue("stbinit_gateway"));
        stbcfg.setDns(SystemConstant.getValue("stbinit_dns"));
        return stbcfg;
    }
}
