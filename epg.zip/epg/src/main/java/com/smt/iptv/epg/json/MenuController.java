package com.smt.iptv.epg.json;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smt.iptv.epg.dao.MenuDao;
import com.smt.iptv.epg.entity.Menu;
import com.smt.iptv.epg.entity.Music;
import com.smt.iptv.epg.entity.Musiccategory;
import com.smt.iptv.epg.entity.Musiccategorytype;

/**
 * 
 * @author mills
 */
@Controller
@RequestMapping(value = "/json/menu")
public class MenuController {

    @Autowired()
    private MenuDao menuDao;

    @RequestMapping(value = "", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<Menu> getMainMenu(){
        return menuDao.getMainMenu();
    }
    @RequestMapping(value = "/{parentid}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<Menu> getSecondMenu(@PathVariable("parentid")Long parentid){
        return menuDao.getSecondMenu(parentid);
    }

}
