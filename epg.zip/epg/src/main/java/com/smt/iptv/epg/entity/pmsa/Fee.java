package com.smt.iptv.epg.entity.pmsa;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)  
@XmlType(propOrder = { "feetype", "typeTitle","feename" ,"fee","feedate"})  
public class Fee {

    private String feetype="2";//消费编码
	private String typeTitle="VOD";//消费类型名称
	private String feename="变形金刚";//消费名称
	private String fee="123";//价格
	private String feedate="dd";//生成时间

    public String getFeetype() {
        return feetype;
    }

    public void setFeetype(String feetype) {
        this.feetype = feetype;
    }

    public String getTypeTitle() {
        return typeTitle;
    }

    public void setTypeTitle(String typeTitle) {
        this.typeTitle = typeTitle;
    }

    public String getFeename() {
        return feename;
    }

    public void setFeename(String feename) {
        this.feename = feename;
    }

    public String getFee() {
        return fee;
    }

    public void setFee(String fee) {
        this.fee = fee;
    }

    public String getFeedate() {
        return feedate;
    }

    public void setFeedate(String feedate) {
        this.feedate = feedate;
    }

    @Override
    public String toString() {
        return "Fee [feetype=" + feetype + ", typeTitle=" + typeTitle + ", feename=" + feename + ", fee=" + fee + ", feedate=" + feedate + "]";
    }
    
}