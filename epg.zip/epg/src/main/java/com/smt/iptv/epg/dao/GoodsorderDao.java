package com.smt.iptv.epg.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.smt.iptv.epg.entity.Goods;
import com.smt.iptv.epg.entity.Goodscart;
import com.smt.iptv.epg.entity.Goodsorder;
import com.smt.iptv.epg.entity.Page;

@MyBatisRepository
public interface GoodsorderDao {

    //订单
    List<Goodsorder>  getMyOrders(@Param("username")String username);
    List<Goods> getGoodsListByOrderid(@Param("orderid")Long orderid);
    Long addorder(Goodsorder goodsorder);
    void addOrderGoodsMap(@Param("orderid")Long orderid,@Param("goodss")List<Goods> goodss); 
}
