package com.smt.iptv.epg.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.smt.iptv.epg.entity.MediaContent;
import com.smt.iptv.epg.entity.Page;
import com.smt.iptv.epg.entity.Program;

@I18nMyBatisRepository
public interface ProgramDao {
    
    List<Program> getProgramlistPage(@Param("pictypeid")Long pictypeid,@Param("pictypeid2")Long pictypeid2,
    		@Param("categoryId")Long categoryId,@Param("level")Integer level,@Param("page")Page<Program> page);
    
    List<Program> getProgramListByIds(@Param("pictypeid")Long pictypeid,@Param("pictypeid2")Long pictypeid2,
            @Param("ids")String ids,@Param("level")Integer level);
    
    List<Program> searchProgramlistPage(@Param("searchname")String searchname,@Param("level")Integer level,@Param("page")Page<Program> page);
    
    List<MediaContent> getMediaContentList(long programid);
   
    List<Long> getPicTypeList(String programType);
    
    
    //测试在epg新增节目才用到的
    Program getProgram(Long programId);
    Program getProgramMediaContent(Long contentId);
    MediaContent getMediaContentById(Long contentId);
//    
    Long addprogram(Program program);
    void addMediacontent( MediaContent mediacontent );
   
    void updateProgramCode(Program program);
    void updateMediacontentCode(MediaContent mediacontent);
}
