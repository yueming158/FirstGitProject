package com.smt.iptv.epg.json.billing;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smt.iptv.epg.core.Result;
import com.smt.iptv.epg.dao.billing.AuthenticataccountDao;
/**
 * 鉴权接口
 * @author pengyueyang
 *
 */
@Controller
@RequestMapping("/json/authenticataccount")
public class AuthenticatAccountController {
	 @Autowired
	 private AuthenticataccountDao authenticatAccountDao;
	 @RequestMapping(value = "/program",method = {RequestMethod.GET},produces = MediaType.APPLICATION_JSON_VALUE)
	 @ResponseBody
	 public Result authenticatAccountProgram(@RequestParam(required=true)String resouceid,@RequestParam(required=true)String iptvusername){
		 //鉴权
		 //是否订购了所有点播
		 if(authenticatAccountDao.accessAllProgram(iptvusername)) {
			return new Result(true, ""); 
		 }
		 //是否订购了点播包
		/* if(authenticatAccountDao.accessGroupProgram(iptvusername,resouceid)) {
			 return true;
		 }*/
		 //是否订购了单个点播
		 return new Result(authenticatAccountDao.accessSingleProgram(iptvusername, resouceid),"");
	 }
	 
	 @RequestMapping(value = "/channel",method = {RequestMethod.GET},produces = MediaType.APPLICATION_JSON_VALUE)
	 @ResponseBody
	 public Result authenticatAccountChannel(@RequestParam(required=true)String resouceid,@RequestParam(required=true)String iptvusername){
		 //鉴权
		 //是否订购了所有直播
		 if(authenticatAccountDao.accessAllChannel(iptvusername)) {
			return new Result(true, ""); 
		 }
		 //是否订购了直播包
		/* if(authenticatAccountDao.accessGroupChannel(iptvusername,resouceid)) {
			 return true;
		 }*/
		 //是否订购了单个直播
		 return  new Result(authenticatAccountDao.accessSingleChannel(iptvusername, resouceid),"");
	 }
}
