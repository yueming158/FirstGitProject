package com.smt.iptv.epg.service.mail;

public interface MailSendCallback {
    void call();
}
