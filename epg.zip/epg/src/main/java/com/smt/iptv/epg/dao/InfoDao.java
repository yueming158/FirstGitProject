package com.smt.iptv.epg.dao;

import java.util.List;

import com.smt.iptv.epg.entity.Info;
import com.smt.iptv.epg.entity.Page;
@I18nMyBatisRepository
public interface InfoDao{ 
    List<Info> getInfoListByUseType(String useType);
}