package com.smt.iptv.epg.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.smt.iptv.epg.dao.CategoryDao;
import com.smt.iptv.epg.dao.ProgramDao;
import com.smt.iptv.epg.entity.Category;
import com.smt.iptv.epg.entity.MediaContent;
import com.smt.iptv.epg.entity.Page;
import com.smt.iptv.epg.entity.Program;

/**
 * @author xjw
 */
@Controller
@RequestMapping(value = "/program")
public class PageProgramController {

    private static final String MOVIE_TYPE = "10";
    @Autowired
    private CategoryDao categoryDao;
    @Autowired
    private ProgramDao programDao;

    @RequestMapping(value = "/list")
    public String list(Model model) {
        List<Category> categorys = categoryDao.getCategoryList(MOVIE_TYPE,null);
        if (categorys.size() > 9) {
            categorys = categorys.subList(0, 9);
        }
        model.addAttribute("categoryAllList", categorys);
        return "program/vod_more";
    }

    @RequestMapping(value = "/programlist")
    public String programlist(Model model, Long categoryId, Page<Program> page) {
        page.setPageSize(10);
        List<Program> programList = programDao.getProgramlistPage(1L,2L, categoryId,null, page);
        model.addAttribute("page", page);
        model.addAttribute("programList", programList);
        return "program/program_more_list";
    }

    @RequestMapping(value = "/detail")
    public String detail(Model model, Long programId) {

        Program program = programDao.getProgram(programId);
        if (program.getDescription() != null & program.getDescription().length() > 150) {
            program.setDescription(program.getDescription().substring(0, 150) + "...");
        }
        List<MediaContent> mediaContents = programDao.getMediaContentList(programId);
        model.addAttribute("program", program);
        model.addAttribute("mediaContents", mediaContents);
        return "program/vod_detail";
    }

    @RequestMapping(value = "/vodplay")
    public String vodplay(Model model, Long mediacontentId) {

        Program program = programDao.getProgramMediaContent(mediacontentId);
        MediaContent mediaContent = programDao.getMediaContentById(mediacontentId);
        model.addAttribute("program", program);
        model.addAttribute("mediaContent", mediaContent);
        return "program/vod_play";
    }

}
