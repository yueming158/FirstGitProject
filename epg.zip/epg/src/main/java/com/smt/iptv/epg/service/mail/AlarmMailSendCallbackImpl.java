package com.smt.iptv.epg.service.mail;

import com.smt.iptv.epg.core.SystemConstant;

public class AlarmMailSendCallbackImpl implements MailSendCallback {
    private String key;
    private Integer retryTime;
    public AlarmMailSendCallbackImpl(String key,Integer retryTime) {
        this.key = key;
        this.retryTime=retryTime;
    }

    @Override
    public void call() {
        new Thread(new Runnable() {
            
            @Override
            public void run() {
                try {
                    Thread.sleep(retryTime);// 一小时后取消邮件发送标志再重试
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                SystemConstant.cancelSendFlag(key);
            }
        }).start();

    }

}
