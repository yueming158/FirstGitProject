package com.smt.iptv.epg.dao;

import org.apache.ibatis.annotations.Param;

import com.smt.iptv.epg.entity.Hotel;

@MyBatisRepository
public interface HotelDao  {
	Hotel getHotel(Long id);
	Hotel getHotelRoomInfo(@Param("iptvusername")String iptvusername);
	Long updateVodfree(@Param("roomNo")String roomNo ,@Param("status")String status);
}
