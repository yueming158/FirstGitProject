package com.smt.iptv.epg.entity;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.epg.core.IdEntity;

public class CustomizedChannelNO extends IdEntity {

	public CustomizedChannelNO() {
	}

	public CustomizedChannelNO(Long id) {
		this.id = id;
	}

	private String channelgroup;
	private String channelid;
	private int channelnumber;

	public String getChannelid() {
		return channelid;
	}

	public void setChannelid(String channelid) {
		this.channelid = channelid;
	}

	public String getChannelgroup() {
		return channelgroup;
	}

	public void setChannelgroup(String channelgroup) {
		this.channelgroup = channelgroup;
	}

	public int getChannelnumber() {
		return channelnumber;
	}

	public void setChannelnumber(int channelnumber) {
		this.channelnumber = channelnumber;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}