package com.smt.iptv.epg.json;

import java.text.SimpleDateFormat;
import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smt.iptv.epg.dao.HotelDao;
import com.smt.iptv.epg.dao.HotelcallDao;
import com.smt.iptv.epg.entity.Hotel;
import com.smt.iptv.epg.entity.Hotelcall;
import com.smt.iptv.epg.entity.Hotelcustomer;

/**
 * 酒店相关接口
 * 
 * @author mills
 */
@Controller
@RequestMapping(value = "/json/hotelcall")
public class HotelcallController {
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    @Autowired
    private HotelcallDao hotelcallDao;
    @Autowired()
    private HotelDao hotelDao;

    /**
     * @param iptvusername
     * @return
     */
    @RequestMapping(value = "/customerinfo/{iptvusername}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Hotelcustomer getCustomerInfo(@PathVariable("iptvusername") String iptvusername) {
        return hotelcallDao.getHotelcustomer(iptvusername);
    }

    @RequestMapping(value = "/list/{type}/{iptvusername}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<Hotelcall> list(@PathVariable("type") String type, @PathVariable("iptvusername") String iptvusername) {
        if ("12".equals(type)) {
            return hotelcallDao.getCheckinoutcall(iptvusername);
        } else {
            return hotelcallDao.getHotelcall(type, iptvusername);
        }
    }

    @RequestMapping(value = "/delete/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Boolean list(@PathVariable("id") Long id) {

        // 必须响应之前才能cancel
        int num = hotelcallDao.cancelBeforeResponse(id);
        if (num > 0) {
            return true;
        } else {
            return false;
        }
    }

    @RequestMapping(value = "/save/{type}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Boolean save(Hotelcall hotelcall, @PathVariable("type") String type) {
        // roomname作为冗余数据传入此处 可能会造成数据不准确 ，
        // 需要在修改房间和盒子关系以及房间名称的时候更新此处 因为房间可能被删除等
        // 所以这是历史关联数据 以历史为准 不改
        Hotel hotel = hotelDao.getHotelRoomInfo(hotelcall.getIptvusername());
        hotelcall.setRoomname(hotel.getRoomname());
        hotelcall.setReqtype(type);
        //连续多次次请求呼叫时之前未响应的请求状态变为取消
        if ("1".equals(type) || "2".equals(type)) {// //type: 1退房 2续房
            hotelcallDao.cancelroom(hotelcall.getIptvusername());
        } else { // 3叫醒服务 4打扫房间 5洗衣服务
            hotelcallDao.cancel(hotelcall.getIptvusername(), type);
        }

        int num = hotelcallDao.insertHotercall(hotelcall);
        if (num > 0) {
            return true;
        } else {
            return false;
        }
    }
}
