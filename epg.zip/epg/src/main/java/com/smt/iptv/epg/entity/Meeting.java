package com.smt.iptv.epg.entity;

import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.smt.iptv.epg.core.IdEntity;

public class Meeting extends IdEntity {
    public Meeting() {
    }

    public Meeting(Long id) {
        this.id = id;
    }
    private String meetingname;
    private String meetingaddress;
    @JsonIgnore
    private Date meetingtime;
    @JsonIgnore
    private String meetingstatus;

    public String getBegintime() {
        return DateFormatUtils.format(meetingtime, "MM-dd HH:mm");
    }

    public String getStatus() {
        return System.currentTimeMillis()>meetingtime.getTime()?"已进行":"未进行";
    }
    public String getMeetingname() {
        return meetingname;
    }

    public void setMeetingname(String meetingname) {
        this.meetingname = meetingname;
    }

    public String getMeetingaddress() {
        return meetingaddress;
    }

    public void setMeetingaddress(String meetingaddress) {
        this.meetingaddress = meetingaddress;
    }

    public Date getMeetingtime() {
        return meetingtime;
    }

    public void setMeetingtime(Date meetingtime) {
        this.meetingtime = meetingtime;
    }

    public String getMeetingstatus() {
        return meetingstatus;
    }

    public void setMeetingstatus(String meetingstatus) {
        this.meetingstatus = meetingstatus;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}