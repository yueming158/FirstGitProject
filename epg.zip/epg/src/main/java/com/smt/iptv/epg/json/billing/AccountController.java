package com.smt.iptv.epg.json.billing;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smt.iptv.epg.core.Result;
import com.smt.iptv.epg.dao.billing.AccountDao;
@Controller
@RequestMapping("/json/account")
public class AccountController {
	@Autowired
	private AccountDao accountDao;
	
	@RequestMapping(value = "/balance", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public Result getAccountBalance(@RequestParam(required = true) String iptvusername) {
		//账户余额单位为分
		Integer balance = accountDao.getAccountBalance(iptvusername);
		if(null == balance){
			balance = 0;
		}
		return new Result(true,balance.toString());
	}
}
