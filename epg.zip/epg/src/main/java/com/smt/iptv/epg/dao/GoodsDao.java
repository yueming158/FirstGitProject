package com.smt.iptv.epg.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.smt.iptv.epg.entity.Goods;
import com.smt.iptv.epg.entity.Goodscart;
import com.smt.iptv.epg.entity.Goodsorder;
import com.smt.iptv.epg.entity.Page;

@I18nMyBatisRepository
public interface GoodsDao {
    //浏览
    Goods getGoodsById(@Param("goodsid")Long goodsid);
    List<Goods> getGoodslistPage(@Param("categoryId")Long categoryId,@Param("page")Page<Goods> page);
    List<Goods> getFeatured();
    List<Goods> getRecommend(@Param("goodsstr")String goodsstr);
    //购物车
    List<Goodscart> getCart(@Param("username")String username);
    Integer getCartTotal(@Param("username")String username);

    Goodscart getGoodsFromCartByGoodsId(@Param("username")String username,@Param("goodsId")Long goodsId);//?
    Integer addToCart(@Param("username")String username,@Param("goodsid")Long goodsid,@Param("number")Integer number);
    Integer modifyNumber(@Param("goodscartId")Long goodscartId, @Param("number")Integer number);
    
    Integer deleteFormCart(@Param("goodscartids")String goodscartids);
    int clearCart(@Param("username")String username);
}
