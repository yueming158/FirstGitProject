package com.smt.iptv.epg.json;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smt.iptv.epg.dao.InfoDao;
import com.smt.iptv.epg.entity.Info;
import com.smt.iptv.epg.entity.Page;

/**
 * 酒店相关接口
 * 
 * @author mills
 */
@Controller
@RequestMapping(value = "/json/info")
public class InfoController {

	@Autowired
	private InfoDao infoDao;
	/**
	 * 城市简介
	 */
	@RequestMapping(value="/cityintro" ,method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<Info> cityintro() {
	    return infoDao.getInfoListByUseType("1");
	}
    /**
     * 城市风光
     */
    @RequestMapping(value="/cityscenery" ,method = RequestMethod.GET,  produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<Info> cityscenery() {
        return infoDao.getInfoListByUseType("2");
    }
    /**
     * 酒店介绍
     */
    @RequestMapping(value="/hotel" ,method = RequestMethod.GET,  produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<Info> hotelinfo() {
        return infoDao.getInfoListByUseType("3");
    }
    /**
     * 酒店介绍
     */
    @RequestMapping(value="/hotelroom" ,method = RequestMethod.GET,  produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<Info> hotelroom() {
        return infoDao.getInfoListByUseType("4");
    }
    /**
     * 酒店介绍
     */
    @RequestMapping(value="/hotelbrother" ,method = RequestMethod.GET,  produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<Info> hotelbrother() {
        return infoDao.getInfoListByUseType("5");
    }
}
