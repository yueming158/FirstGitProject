package com.smt.iptv.epg.json;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smt.iptv.epg.dao.RoomstatusDao;
import com.smt.iptv.epg.entity.Roomstatus;

/**
 * 城市信息相关接口 主要为了获取城市地区信息 方便天气和航班功能使用。
 * 
 * @author mills
 */
@Controller
@RequestMapping(value = "/json/roomstatus")
public class RoomstatusController {

    @Autowired
    private RoomstatusDao roomstatusDao;

    @RequestMapping(value = "", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Roomstatus roomstatus(@RequestParam(required = true) String account) {
        Roomstatus roomstatus = roomstatusDao.getRoomstatusByAccount(account);
        return roomstatus!=null?roomstatus:new Roomstatus();
    }
}
