package com.smt.iptv.epg.entity.billing;

import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.epg.core.IdEntity;
/**
 * 订购记录
 * @author pengyueyang
 *
 */
public class Orderusage extends IdEntity {
	public Orderusage(){	
	}
	public Orderusage(Long id){
		this.id = id;
	}
	
	private Long accountid;
	private Long productofferid;
	//支付状态 1.待支付,2.已支付,3.	已取消
	private String paystatus;
	private String productoffername;
	//产品列表价格单位为分
	private int listprice;
	private Date orderstarttime;
	private Date orderendtime;
	private Date ordercancletime;
	private Date creationtime;
	
	public Long getAccountid() {
		return accountid;
	}
	public void setAccountid(Long accountid) {
		this.accountid = accountid;
	}
	public Long getProductofferid() {
		return productofferid;
	}
	public void setProductofferid(Long productofferid) {
		this.productofferid = productofferid;
	}
	public String getPaystatus() {
		return paystatus;
	}
	public void setPaystatus(String paystatus) {
		this.paystatus = paystatus;
	}
	public String getProductoffername() {
		return productoffername;
	}
	public void setProductoffername(String productoffername) {
		this.productoffername = productoffername;
	}
	public int getListprice() {
		return listprice;
	}
	public void setListprice(int listprice) {
		this.listprice = listprice;
	}
	public Date getOrderstarttime() {
		return orderstarttime;
	}
	public void setOrderstarttime(Date orderstarttime) {
		this.orderstarttime = orderstarttime;
	}
	public Date getOrderendtime() {
		return orderendtime;
	}
	public void setOrderendtime(Date orderendtime) {
		this.orderendtime = orderendtime;
	}
	public Date getOrdercancletime() {
		return ordercancletime;
	}
	public void setOrdercancletime(Date ordercancletime) {
		this.ordercancletime = ordercancletime;
	}
	public Date getCreationtime() {
		return creationtime;
	}
	public void setCreationtime(Date creationtime) {
		this.creationtime = creationtime;
	}
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
