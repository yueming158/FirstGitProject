package com.smt.iptv.epg.json.billing;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smt.iptv.epg.dao.billing.ProductofferDao;
import com.smt.iptv.epg.entity.billing.Productoffer;

/**
 * 计费系统商品信息接口
 * @author pengyueyang
 *
 */

@Controller
@RequestMapping(value = "/json/productoffer")
public class ProductOfferController {
	@Autowired
	private ProductofferDao productOfferDao;
	
    @RequestMapping(value = "/program/list", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<Productoffer> programList(@RequestParam(required=true)String productoffertype,@RequestParam(required=true)String resourceid) {
    	 return productOfferDao.getProgramProductofferList(productoffertype,resourceid);
    }
    
    @RequestMapping(value = "/channel/list", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<Productoffer> channelList(@RequestParam(required=true)String productoffertype,@RequestParam(required=true)String resourceid) {
    	 return productOfferDao.getChannelProductofferList(productoffertype,resourceid);
    } 
}
