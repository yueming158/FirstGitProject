package com.smt.iptv.epg.entity;


import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springside.modules.mapper.JsonMapper;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.smt.iptv.epg.core.I18nResource;
import com.smt.iptv.epg.core.IdEntity;

public class Rate extends IdEntity {
    public Rate() {
    }

    public Rate(Long id) {
        this.id = id;
    }
    
    private String selfsymbol;
    private String selfname;
    private String symbol;
    private String name;
    private String mbuyprice;
    private String fbuyprice;
    private String sellprice;
    private String baseprice;
    @JsonFormat(pattern="MM-dd")
    private Date date;
    

    public String getSelfsymbol() {
        return selfsymbol;
    }


    public void setSelfsymbol(String selfsymbol) {
        this.selfsymbol = selfsymbol;
    }


    public String getSelfname() {
        return  I18nResource.getString(selfsymbol);
    }


    public void setSelfname(String selfname) {
        this.selfname = selfname;
    }


    public String getSymbol() {
        return symbol;
    }


    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }


    public String getName() {
        if(StringUtils.isEmpty(symbol)){
            return name;
        }else{
            return I18nResource.getString(symbol);
        }
    }


    public void setName(String name) {
        this.name = name;
    }


    public String getMbuyprice() {
        return mbuyprice;
    }


    public void setMbuyprice(String mbuyprice) {
        this.mbuyprice = mbuyprice;
    }


    public String getFbuyprice() {
        return fbuyprice;
    }


    public void setFbuyprice(String fbuyprice) {
        this.fbuyprice = fbuyprice;
    }


    public String getSellprice() {
        return sellprice;
    }


    public void setSellprice(String sellprice) {
        this.sellprice = sellprice;
    }


    public String getBaseprice() {
        return baseprice;
    }


    public void setBaseprice(String baseprice) {
        this.baseprice = baseprice;
    }


    public Date getDate() {
        return date;
    }


    public void setDate(Date date) {
        this.date = date;
    }
    
}