package com.smt.iptv.epg.entity;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.epg.core.IdEntity;

public class Globalconfig extends IdEntity {
    
    public Globalconfig() {
    }

    public Globalconfig(Long id) {
        this.id = id;
    }
    
	private String name;
	private String value;
	private String description;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }


    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}