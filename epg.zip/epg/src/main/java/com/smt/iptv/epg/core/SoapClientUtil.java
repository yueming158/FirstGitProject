package com.smt.iptv.epg.core;

import org.apache.cxf.endpoint.Client;
import org.apache.cxf.jaxws.endpoint.dynamic.JaxWsDynamicClientFactory;
import org.slf4j.Logger;
import org.springside.modules.mapper.JaxbMapper;

import com.smt.iptv.epg.entity.pmsa.FeeContainer;

public class SoapClientUtil {
    private static Logger logger = org.slf4j.LoggerFactory.getLogger(SoapClientUtil.class);
    public static void main(String str[]) throws Exception {  
        Long time = System.currentTimeMillis();
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();  
        Client client = dcf.createClient("http://115.238.104.156:5031/XRHotel_WS?wsdl"); 
        System.out.println(System.currentTimeMillis()-time);       
        Object[] response = client.invoke("QueryBill", "0201");  
        System.out.println(System.currentTimeMillis()-time);
        client.destroy();
        System.out.println(System.currentTimeMillis()-time);
        System.out.println("Response is " + response[0]);  
        String billxml =(String)response[0];
        billxml = billxml.replaceAll("&lt;", "<").replaceAll("&gt;", ">").replace("xmlns=\"http://tempuri.org/\"", "").replaceAll("杂项", "VOD");
        logger.info("<string>"+billxml+"</string>");
//        <interface time="2014-12-16 16:04:12">
//        <items>
//        <feetype>00</feetype>
//        <typeTitle>房费</typeTitle>
//        <feename>房费</feename>
//        <fee>500</fee>
//        <feedate>2014/9/26 15:40:56</feedate>
//        </items>
//        </interface>
        FeeContainer bc = JaxbMapper.fromXml("<string>"+billxml+"</string>", FeeContainer.class);
        System.out.println(bc);
    }  
    public static String GuestInfo(String name,String pwd, String roomno){  
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();  
        Client client = dcf.createClient(SystemConstant.getValue("xr_pms_server"));  

        Object[] response;
        try {
            response = client.invoke("GuestInfo", "","",roomno);
            return "<string>"+response[0]+"</string>";  
        } catch (Exception e) {
            logger.error("GuestInfo:roomno="+roomno+" Exception:"+e.getMessage());
            return "";
        }  
  
    }  
    public static String QueryBill(String roomno){  
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();  
        Client client = dcf.createClient(SystemConstant.getValue("xr_pms_server"));  

        Object[] response;
        try {
            response = client.invoke("QueryBill", roomno);
            return "<string>"+response[0]+"</string>";  
        } catch (Exception e) {
            logger.error("QueryBill:roomno="+roomno+" Exception:"+e.getMessage());
            return "";
        }
    }
    public static String Posting(String fun,String xml){  
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();  
        Client client = dcf.createClient(SystemConstant.getValue("xr_pms_server"));  
        Object[] response;
        try {
            response = client.invoke("Posting",fun ,xml);
            return "<string>"+response[0]+"</string>";  
        } catch (Exception e) {
            logger.error("Posting:xml="+xml+" Exception:"+e.getMessage());
            return "";
        }  
  
    }
    
} 
