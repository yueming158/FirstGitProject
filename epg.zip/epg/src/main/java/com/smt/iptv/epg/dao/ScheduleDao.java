package com.smt.iptv.epg.dao;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.smt.iptv.epg.entity.Page;
import com.smt.iptv.epg.entity.Schedule;

@MyBatisRepository
public interface ScheduleDao {
    
    List<Schedule> getSchedulelistPage(@Param("channelid") Long channelid, @Param("page") Page<Schedule> page);
    List<Schedule> getOldSchedulelistPage(@Param("channelid") Long channelid, @Param("page") Page<Schedule> page);
    
    List<Schedule> getTvodSchedulelistPage(@Param("channelid") Long channelid, @Param("day") Date day,@Param("tvodtime") Date tvodtime, @Param("page") Page<Schedule> page);
    Schedule getFirstSchedule(@Param("channelid") Long channelid, @Param("day") Date day);
}
