package com.smt.iptv.epg.entity;

import java.sql.Date;
import java.util.Calendar;

import org.apache.commons.lang3.StringUtils;
import org.springframework.context.i18n.LocaleContextHolder;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.smt.iptv.epg.core.CnToSpell;
import com.smt.iptv.epg.core.I18nResource;
import com.smt.iptv.epg.core.IdEntity;
import com.smt.iptv.epg.core.SystemConstant;

public class Weather extends IdEntity {
    public Weather() {
    }

    public Weather(Long id) {
        this.id = id;
    }

    private String weather;
    private String temp;
    private String wd;
    private String ws;
    private String cityname;
    private String citycode;
    @JsonIgnore
    private String logourl;
    private String currenttemp;
    private Date weatherdate;

    public String getLogoImageUrl() {
        return SystemConstant.getURLValue("epg_server_address") + this.logourl;
    }

    public String getWeather() {
        return I18nResource.getString(logourl);
    }

    public void setWeather(String weather) {
        this.weather = weather;
    }

    public String getTemp() {
        return temp;
    }

    public void setTemp(String temp) {
        this.temp = temp;
    }

    public String getWd() {
        return wd;
    }

    public void setWd(String wd) {
        this.wd = wd;
    }

    public String getWs() {
        return ws;
    }

    public void setWs(String ws) {
        this.ws = ws;
    }

    public String getCityname() {
        if (!"zh".equals(LocaleContextHolder.getLocale().getLanguage())) {
            try {
                String name = I18nResource.getString(citycode);
                return name;
            } catch (Exception e) {
                if(StringUtils.isNotEmpty(cityname)){
                    String englishname = CnToSpell.getFullSpell2(cityname);
                    englishname = Character.toUpperCase(englishname.charAt(0)) + englishname.substring(1);
                    return englishname;
                }
            }
        }
        return cityname;
    }

    public void setCityname(String cityname) {
        this.cityname = cityname;
    }

    public String getCitycode() {
        return citycode;
    }

    public void setCitycode(String citycode) {
        this.citycode = citycode;
    }

    public String getLogourl() {
        return logourl;
    }

    public void setLogourl(String logourl) {
        this.logourl = logourl;
    }

    public Date getWeatherdate() {
        return weatherdate;
    }

    public void setWeatherdate(Date weatherdate) {
        this.weatherdate = weatherdate;
    }

    public String getCurrenttemp() {
        if (temp != null && temp.split("~").length == 2) {
            try {
                String lowStr = temp.split("~")[0];
                String highStr = temp.split("~")[1];
                int low = Integer.parseInt(lowStr.substring(0, lowStr.length() - 1));
                int high = Integer.parseInt(highStr.substring(0, highStr.length() - 1));
                Calendar cal = Calendar.getInstance();
                int now = cal.get(Calendar.HOUR_OF_DAY) - 4;
                if (now < 0) {
                    now = 0 - now;
                } else if (now > 12) {
                    now = 24 - now;
                }
                int temp = (((high - low) * now) / 12);
                return low + temp + "℃";
            } catch (Exception e) {
            }
        }
        return currenttemp;
    }

    public void setCurrenttemp(String currenttemp) {
        this.currenttemp = currenttemp;
    }

}