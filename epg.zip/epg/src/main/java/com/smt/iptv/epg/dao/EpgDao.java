package com.smt.iptv.epg.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.smt.iptv.epg.entity.Epgvariable;
import com.smt.iptv.epg.entity.Info;
import com.smt.iptv.epg.entity.Page;
@I18nMyBatisRepository
public interface EpgDao{ 
    List<Epgvariable> listByEpggroup(Long id);
    String getByName(@Param("name")String name,@Param("groupId")Integer groupId);
}