package com.smt.iptv.epg.json;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smt.iptv.epg.dao.MeetingDao;
import com.smt.iptv.epg.entity.Meeting;

/**
 * 酒店相关接口
 * 
 * @author mills
 */
@Controller
@RequestMapping(value = "/json/meeting")
public class MeetingController {


    @Autowired
    private MeetingDao meetingDao;
    /**
     * 变量查询
     */
    @RequestMapping(value="/todaylist" , method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<Meeting> todaylist() {
        return meetingDao.findAllByToday();
    }

}
