package com.smt.iptv.epg.entity.pmsa;

public class Customer {
    private String accnt;
    private String name;
    public String getAccnt() {
        return accnt;
    }
    public void setAccnt(String accnt) {
        this.accnt = accnt;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    
}
