package com.smt.iptv.epg.dao;

import org.apache.ibatis.annotations.Param;

import com.smt.iptv.epg.entity.AppInfo;

@MyBatisRepository
public interface AppInfoDao{
	AppInfo getAppInfo(@Param("apptype")String apptype);
	AppInfo getAppInfoForSpecialAccnts(@Param("apptype")String apptype);
	
}
