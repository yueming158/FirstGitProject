package com.smt.iptv.epg.entity;

public class NameVariable {
    public NameVariable() {
    }
    private String name;
    private String vale;
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getVale() {
        return vale;
    }
    public void setVale(String vale) {
        this.vale = vale;
    }
}
