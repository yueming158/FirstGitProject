package com.smt.iptv.epg.dao;

import java.util.List;

import com.smt.iptv.epg.entity.Hoteloperation;

@MyBatisRepository
public interface HoteloperationDao {
	//打扫 大于当前时间的 已经受理的一条  未受理的一条
    
    List<Hoteloperation> getHoteloperation();
    //叫醒大于当前时间的 已经受理的一条  未受理的一条
	
	//退房续房 房间到期时间 已经受理的操作一条 未受理的操作一条
    
}
