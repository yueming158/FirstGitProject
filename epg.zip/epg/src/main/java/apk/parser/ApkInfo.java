// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 
// Source File Name:   ApkInfo.java

package apk.parser;


public class ApkInfo
{

    private String packageName;
    private String versionName;
    private String versionCode;
    private String mainName;

    public ApkInfo()
    {
    }

    public ApkInfo(String packageName, String versionName, String versionCode)
    {
        this.packageName = packageName;
        this.versionName = versionName;
        this.versionCode = versionCode;
    }

    public String getPackageName()
    {
        return packageName;
    }

    public void setPackageName(String packageName)
    {
        this.packageName = packageName;
    }

    public String getVersionName()
    {
        return versionName;
    }

    public void setVersionName(String versionName)
    {
        this.versionName = versionName;
    }

    public String getVersionCode()
    {
        return versionCode;
    }

    public void setVersionCode(String versionCode)
    {
        this.versionCode = versionCode;
    }

    public String getMainName() {
        return mainName;
    }

    public void setMainName(String mainName) {
        this.mainName = mainName;
    }

    @Override
    public String toString() {
        return "ApkInfo [packageName=" + packageName + ", versionName=" + versionName + ", versionCode=" + versionCode + ", mainName=" + mainName + "]";
    }



}
