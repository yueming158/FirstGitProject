// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 
// Source File Name:   GetApkInfo.java

package apk.parser;

import java.io.ByteArrayInputStream;
import java.io.File;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

public class GetApkInfo
{

    public static ApkInfo getApkInfoByFilePath(File apkFile)
    {
        ApkInfo apkInfo = null;
        try
        {
            SAXParserFactory parserFactory = SAXParserFactory.newInstance();
            parserFactory.setValidating(false);
            parserFactory.setNamespaceAware(false);
            MyXmlResolve myXmlResolve = new MyXmlResolve();
            String strContent = AXMLPrinter.getManifestXMLFromAPK(apkFile);//.parse(stream);
            byte by[] = strContent.getBytes("utf-8");
            ByteArrayInputStream bais = new ByteArrayInputStream(by);
            SAXParser parser = parserFactory.newSAXParser();
            parser.parse(bais, myXmlResolve);
            bais.close();
            parser = null;
            apkInfo = myXmlResolve.getApkInfo();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return apkInfo;
    }
    public static void main(String[] args) {
        System.out.println(getApkInfoByFilePath(new File("d:\\aa.xml")));
    }

}
