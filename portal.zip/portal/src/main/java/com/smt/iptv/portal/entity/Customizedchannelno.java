package com.smt.iptv.portal.entity;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.portal.core.IdEntity;
@Entity
@Table(name = "customizedchannelno")
public class Customizedchannelno extends IdEntity {
    
    public Customizedchannelno() {
    }

    public Customizedchannelno(Long id) {
        this.id = id;
    }
    
	private String channelgroup;
	private Channel channel;
	private String channelnumber;
	private String view;
    
    @ManyToOne
    @JoinColumn(name = "channelid")
    public Channel getChannel() {
        return channel;
    }

    public void setChannel(Channel channel) {
        this.channel = channel;
    }

    public String getChannelgroup() {
        return channelgroup;
    }

    public void setChannelgroup(String channelgroup) {
        this.channelgroup = channelgroup;
    }

    public String getChannelnumber() {
        return channelnumber;
    }

    public void setChannelnumber(String channelnumber) {
        this.channelnumber = channelnumber;
    }
   

    public String getView() {
        return view;
    }

    public void setView(String view) {
        this.view = view;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
}