package com.smt.iptv.portal.web.program;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.smt.iptv.portal.core.CnToSpell;
import com.smt.iptv.portal.entity.Schedule;
import com.smt.iptv.portal.service.cmp.ScheduleService;
import com.smt.iptv.portal.service.excel.ExcelDataArray;
import com.smt.iptv.portal.service.excel.POIExcelUtilProcess;

/**
 * Schedule管理的Controller, 使用Restful风格的Urls:
 * 
 * List page     : GET /schedule/
 * Create page   : GET /schedule/create
 * Create action : POST /schedule/create
 * Update page   : GET /schedule/update/{id}
 * Update action : POST /schedule/update
 * Delete action : GET /schedule/delete/{id}
 * 
 * @author xjw
 */
@Controller
@RequestMapping(value = "/schedule")
public class ScheduleController {

	private static final int PAGE_SIZE = 50;

	private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
	static {
		sortTypes.put("starttime", "时间");
		sortTypes.put("schedulename", "名称");
	}

	@Autowired
	private ScheduleService scheduleService;

	@RequestMapping(value = "/list")
	public String list(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
			@RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
		Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");

		Page<Schedule> schedules = scheduleService.getPage( searchParams, pageNumber, PAGE_SIZE, sortType);

		model.addAttribute("schedules", schedules);
		model.addAttribute("sortType", sortType);
		model.addAttribute("sortTypes", sortTypes);
		// 将搜索条件编码成字符串，用于排序，分页的URL
		model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
		return "schedule/scheduleList";
	}

	@RequestMapping(value = "create", method = RequestMethod.GET)
	public String createForm(Model model) {
		model.addAttribute("schedule", new Schedule());
		model.addAttribute("action", "create");
		return "schedule/scheduleForm";
	}

	@RequestMapping(value = "create", method = RequestMethod.POST)
	public String create(@Valid Schedule newSchedule, RedirectAttributes redirectAttributes) {
	    newSchedule.setSearchname(CnToSpell.getSimpleSpell(newSchedule.getSchedulename()));
		scheduleService.save(newSchedule);
		redirectAttributes.addFlashAttribute("message", "新增成功");
		return "redirect:/schedule/list";
	}

	@RequestMapping(value = "update/{id}", method = RequestMethod.GET)
	public String updateForm(@PathVariable("id") Long id, Model model) {
		model.addAttribute("schedule", scheduleService.findOne(id));
		model.addAttribute("action", "update");
		return "schedule/scheduleForm";
	}

	@RequestMapping(value = "update", method = RequestMethod.POST)
	public String update(@Valid @ModelAttribute("preloadSchedule") Schedule schedule, RedirectAttributes redirectAttributes) {
	    schedule.setSearchname(CnToSpell.getSimpleSpell(schedule.getSchedulename()));
		scheduleService.save(schedule);
		redirectAttributes.addFlashAttribute("message", "保存成功");
		return "redirect:/schedule/list";
	}

	@RequestMapping(value = "delete/{id}")
	public String delete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
		scheduleService.delete(id);
		redirectAttributes.addFlashAttribute("message", "删除成功");
		return "redirect:/schedule/list";
	}

	/**
	 * 使用@ModelAttribute, 实现Struts2 Preparable二次部分绑定的效果,先根据form的id从数据库查出Schedule对象,再把Form提交的内容绑定到该对象上。
	 * 因为仅update()方法的form中有id属性，因此本方法在该方法中执行.
	 */
	@ModelAttribute("preloadSchedule")
	public Schedule getSchedule(@RequestParam(value = "id", required = false) Long id) {
		if (id != null) {
			return scheduleService.findOne(id);
		}
		return null;
	}
	
    @RequestMapping(value = "bychannel/{channelid}", method = RequestMethod.GET)
    public String bychannel(@PathVariable("channelid") Long channelid,@RequestParam(defaultValue = "0")Integer daynumber, @RequestParam(defaultValue = "") String scheduledate,
            Model model) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date day;
        try {
            day = sdf.parse(scheduledate);
        } catch (ParseException e) {
            day = new Date();
            day.setHours(0);
            day.setMinutes(0);
            day.setSeconds(0);
        }
        day = new Date(day.getTime()+(86400000*daynumber));
        List<Schedule> schedules = scheduleService.getScheduleList(channelid, day);
        model.addAttribute("channelid", channelid);
        model.addAttribute("schedules", schedules);
        model.addAttribute("scheduledate", sdf.format(day));
        return "schedule/scheduleByChnList";
    }
    @RequestMapping(value = "bychannelcreate/{channelid}", method = RequestMethod.GET)
    public String bychannelcreate(@PathVariable("channelid") Long channelid,
            Model model) {
        model.addAttribute("channelid", channelid);
        model.addAttribute("schedule", new Schedule());
        model.addAttribute("action", "bychannelsave");
        return "schedule/scheduleByChnCreate";
    }
    @RequestMapping(value = "bychannelupdate/{channelid}/{id}", method = RequestMethod.GET)
    public String bychannelupdate(@PathVariable("channelid") Long channelid,
            @PathVariable("id") Long id,Model model) {
        model.addAttribute("channelid", channelid);
        model.addAttribute("schedule", scheduleService.findOne(id));
        model.addAttribute("action", "bychannelsave");
        return "schedule/scheduleByChnCreate";
    }
    @RequestMapping(value = "bychannelsave/{channelid}", method = RequestMethod.POST)
    public String bychannelSave(@Valid Schedule newSchedule,@PathVariable("channelid") Long channelid, RedirectAttributes redirectAttributes){
        newSchedule.setScheduledate(newSchedule.getStarttime());
        scheduleService.save(newSchedule);
        redirectAttributes.addFlashAttribute("message", "保存成功");
        return "redirect:/schedule/bychannel/"+channelid;
    }

    @RequestMapping(value = "import", method = RequestMethod.POST)
    public String importByChannel(Long channelid,
            Model model, MultipartFile file, RedirectAttributes redirectAttributes) {
        ExcelDataArray   excelDataArray = null;
        if (file != null && file.getOriginalFilename() != null
                && file.getOriginalFilename().length() > 4) {
            try {  
                final int startRow = 0; //Excel数据开始的行数  
                excelDataArray = POIExcelUtilProcess  
                        .importExcelFileToDataArray(file.getInputStream(), startRow);  
            } catch (IOException e) {  
                e.printStackTrace();  
            }  
        }
        try{
            scheduleService.importdata(channelid, excelDataArray);
            redirectAttributes.addFlashAttribute("message", "保存成功");
        }catch(Exception e){
            redirectAttributes.addFlashAttribute("message", "导入失败:"+e.getMessage());
        }
        return "redirect:/schedule/bychannel/"+channelid;
    }
    
    @RequestMapping(value = "deletes")
    public String delete(Long [] scheduleids,Long channelid, RedirectAttributes redirectAttributes) {
        if(scheduleids!=null&&scheduleids.length>0){
            List<Schedule> list = Lists.newArrayList();
            for(Long id:scheduleids){
                list.add(new Schedule(id));
            }
            if(!list.isEmpty()){
                scheduleService.delete(list);
                redirectAttributes.addFlashAttribute("message", "删除成功");
            }else{
                redirectAttributes.addFlashAttribute("message", "没有删除对象");
            }
        }
        return "redirect:/schedule/bychannel/"+channelid;
    }
    
}
