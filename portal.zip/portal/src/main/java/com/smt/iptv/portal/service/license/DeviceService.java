package com.smt.iptv.portal.service.license;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.entity.license.Device;
import com.smt.iptv.portal.repository.license.DeviceDao;
import com.smt.iptv.portal.service.cmp.BaseService;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class DeviceService extends BaseService<DeviceDao, Device> {
    public long count(){
        return dao.count();
    }
    public Device findByHardwareinfo(String hardwareinfo){
        return dao.findByHardwareinfo(hardwareinfo);
    }
}
