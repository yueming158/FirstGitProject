package com.smt.iptv.portal.repository.aaa;

import com.smt.iptv.portal.entity.aaa.Usergroup;
import com.smt.iptv.portal.repository.BaseDao;

public interface UsergroupDao extends BaseDao<Usergroup> {

}
