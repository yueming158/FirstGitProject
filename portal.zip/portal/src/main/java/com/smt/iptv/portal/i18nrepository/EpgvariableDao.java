package com.smt.iptv.portal.i18nrepository;

import java.util.List;

import com.smt.iptv.portal.i18nentity.Epgvariable;
import com.smt.iptv.portal.repository.BaseDao;

public interface EpgvariableDao extends BaseDao<Epgvariable> {
    Epgvariable getByEpggroupidAndName(Long epggroupid,String name);
    List<Epgvariable> getByEpggroupid(Long epggroupid);
}
