package com.smt.iptv.portal.model;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.smt.iptv.portal.core.IdEntity;

public class MediaContent extends IdEntity {
    
    public MediaContent() {
    }

    public MediaContent(Long id) {
        this.id = id;
    }
    
    private String viewname;
    private int sequence;
    @JsonIgnore
    private String cpobjectcode;
    private int duration;

    public String getPlayurl() {
        return  SystemConstant.getURLValue("CDN_server_address")+this.cpobjectcode;
    }

    public String getViewname() {
        return viewname;
    }

    public void setViewname(String viewname) {
        this.viewname = viewname;
    }

    public int getSequence() {
        return sequence;
    }

    public void setSequence(int sequence) {
        this.sequence = sequence;
    }

    public String getCpobjectcode() {
        return cpobjectcode;
    }

    public void setCpobjectcode(String cpobjectcode) {
        this.cpobjectcode = cpobjectcode;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}