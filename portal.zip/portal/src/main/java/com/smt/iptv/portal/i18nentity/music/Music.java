package com.smt.iptv.portal.i18nentity.music;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import com.smt.iptv.portal.core.IdEntity;
import com.smt.iptv.portal.i18nentity.Category;

@Entity
@Table(name = "music")
public class Music extends IdEntity{
    public Music() {
    }

    public Music(Long id) {
        this.id = id;
    }
    private String name;
    private String singer;
    private String lyricist;
    private String composer;
    private String playurl;
    private String logourl;
    private String lrcurl;
    
    private List<Musiccategorymap> categorylist;
    
    @ManyToMany
    @JoinTable(
            name="musiccategorymap",
            joinColumns=@JoinColumn(name="musicid", referencedColumnName="id"),//控制端列
            inverseJoinColumns=@JoinColumn(name="musiccategoryid", referencedColumnName="id")//被控制端列
            )
    public List<Musiccategorymap> getCategorylist() {
        return categorylist;
    }

    public void setCategorylist(List<Musiccategorymap> categorylist) {
        this.categorylist = categorylist;
    }
    
    
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getSinger() {
        return singer;
    }
    public void setSinger(String singer) {
        this.singer = singer;
    }
    public String getLyricist() {
        return lyricist;
    }
    public void setLyricist(String lyricist) {
        this.lyricist = lyricist;
    }
    public String getComposer() {
        return composer;
    }
    public void setComposer(String composer) {
        this.composer = composer;
    }
    public String getLogourl() {
        return logourl;
    }
    public void setLogourl(String logourl) {
        this.logourl = logourl;
    }
    public String getPlayurl() {
        return playurl;
    }
    public void setPlayurl(String playurl) {
        this.playurl = playurl;
    }

    public String getLrcurl() {
        return lrcurl;
    }

    public void setLrcurl(String lrcurl) {
        this.lrcurl = lrcurl;
    }
    
}
