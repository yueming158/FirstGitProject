package com.smt.iptv.portal.web.music;

import java.io.File;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Maps;
import com.smt.iptv.portal.core.FileUploadUtil;
import com.smt.iptv.portal.i18nentity.music.Music;
import com.smt.iptv.portal.i18nentity.program.Picturetype;
import com.smt.iptv.portal.service.cmp.PicturetypeService;
import com.smt.iptv.portal.service.music.MusicService;

/**
 * @author rich
 */
@Controller
@RequestMapping(value = "/music")
public class MusicController {

    private static final int PAGE_SIZE = 50;

    private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
    static {
        sortTypes.put("auto", "自动");
        sortTypes.put("name", "名称");
    }

    @Autowired
    private MusicService musicService;
    @Autowired
    private PicturetypeService  picturetypeService;
    @RequestMapping(value = "/list")
    public String list(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");

        Page<Music> musics = musicService.getPage(searchParams, pageNumber, PAGE_SIZE, sortType);

        model.addAttribute("musics", musics);
        model.addAttribute("sortType", sortType);
        model.addAttribute("sortTypes", sortTypes);
        // 将搜索条件编码成字符串，用于排序，分页的URL
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
        return "music/musicList";
    }

    @RequestMapping(value = "create", method = RequestMethod.GET)
    public String createForm(Model model) {
        model.addAttribute("music", new Music());
        model.addAttribute("action", "create");
        int  width =0;
        int  height =0;
        String size="0";
        List<Picturetype>  ptypelist =picturetypeService.getByPicturetypecode("101");
        if(ptypelist !=null&&ptypelist.size()==1){
            width = ptypelist.get(0).getMaxwidth(); // 得到源图宽
            height = ptypelist.get(0).getMaxheight(); // 得到源图长
            size = ptypelist.get(0).getFilemaxsize(); // 得到源图大小
        }
        model.addAttribute("width", width);
        model.addAttribute("height", height);
        model.addAttribute("size", size);
        return "music/musicForm";
    }

    @RequestMapping(value = "create", method = RequestMethod.POST)
    public String create(@Valid Music music,int width ,int height, RedirectAttributes redirectAttributes,MultipartFile imgfile, MultipartFile musicfile,MultipartFile lrcfile) {
        String relativePath = "music/";
        if (!musicfile.isEmpty()&&!imgfile.isEmpty()) {
            File descimgfile = FileUploadUtil.saveFile(imgfile, relativePath, true,width,height);
            music.setLogourl(relativePath + descimgfile.getName());
        }
        if (!musicfile.isEmpty()) {
            File descfile = FileUploadUtil.saveFile(musicfile, relativePath, true,0,0);
            music.setPlayurl(relativePath + descfile.getName());
        }
        if (!lrcfile.isEmpty()) {
            File descfile = FileUploadUtil.saveFile(lrcfile, relativePath, true,0,0);
            music.setLrcurl(relativePath + descfile.getName());
        }
        musicService.save(music);
        redirectAttributes.addFlashAttribute("message", "保存成功");
        return "redirect:/music/list";
    }

    @RequestMapping(value = "update/{id}", method = RequestMethod.GET)
    public String updateForm(@PathVariable("id") Long id, Model model) {
        model.addAttribute("music", musicService.findOne(id));
        model.addAttribute("action", "update");
        int  width =0;
        int  height =0;
        String size="0";
        List<Picturetype>  ptypelist =picturetypeService.getByPicturetypecode("101");
        if(ptypelist !=null&&ptypelist.size()==1){
            width = ptypelist.get(0).getMaxwidth(); // 得到源图宽
            height = ptypelist.get(0).getMaxheight(); // 得到源图长
            size = ptypelist.get(0).getFilemaxsize(); // 得到源图大小
        }
        model.addAttribute("width", width);
        model.addAttribute("height", height);
        model.addAttribute("size", size);
        return "music/musicForm";
    }

    @RequestMapping(value = "update", method = RequestMethod.POST)
    public String update(@Valid @ModelAttribute("preloadMusic") Music music,int width ,int height, RedirectAttributes redirectAttributes,
            MultipartFile imgfile, MultipartFile musicfile,MultipartFile lrcfile) {
        String relativePath = "music/";
        if (!musicfile.isEmpty()) {
            File descfile = FileUploadUtil.saveFile(musicfile, relativePath, true,0,0);
            FileUploadUtil.delete(music.getPlayurl());
            music.setPlayurl(relativePath + descfile.getName());
        }
        if (!imgfile.isEmpty()) {
            File descimgfile = FileUploadUtil.saveFile(imgfile, relativePath, true,width,height);
            FileUploadUtil.delete(music.getLogourl());
            music.setLogourl(relativePath + descimgfile.getName());
        }
        if (!lrcfile.isEmpty()) {
            File descfile = FileUploadUtil.saveFile(lrcfile, relativePath, true,0,0);
            FileUploadUtil.delete(music.getLrcurl());
            music.setLrcurl(relativePath + descfile.getName());
        }
        musicService.save(music);
        redirectAttributes.addFlashAttribute("message", "保存成功");
        return "redirect:/music/list";
    }

    @RequestMapping(value = "delete/{id}")
    public String delete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
        musicService.delete(id);
        redirectAttributes.addFlashAttribute("message", "删除成功");
        return "redirect:/music/list";
    }

    /**
     * 使用@ModelAttribute, 实现Struts2 Preparable二次部分绑定的效果
     */
    @ModelAttribute("preloadMusic")
    public Music getMusic(@RequestParam(value = "id", required = false) Long id) {
        if (id != null) {
            return musicService.findOne(id);
        }
        return null;
    }
}