package com.smt.iptv.portal.web.music;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.smt.iptv.portal.core.SystemEnum;
import com.smt.iptv.portal.i18nentity.music.Music;
import com.smt.iptv.portal.i18nentity.music.Musiccategory;
import com.smt.iptv.portal.i18nentity.music.Musiccategorymap;
import com.smt.iptv.portal.service.cmp.GlobalenumService;
import com.smt.iptv.portal.service.music.MusiccategoryService;
import com.smt.iptv.portal.service.music.MusiccategorymapService;

/**
 * Musiccategory管理的Controller, 使用Restful风格的Urls:
 * 
 * List page : GET /musiccategory/ Create page : GET /musiccategory/create
 * Create action : POST /musiccategory/create Update page : GET
 * /musiccategory/update/{id} Update action : POST /musiccategory/update Delete
 * action : GET /musiccategory/delete/{id}
 * 
 * @author xjw
 */
@Controller
@RequestMapping(value = "/musiccategory")
public class MusiccategoryController {

    private static final int PAGE_SIZE = 50;

    private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
    static {
        sortTypes.put("sequence", "自动");
    }

    @Autowired
    private MusiccategoryService musiccategoryService;
    @Autowired
    private MusiccategorymapService musiccategorymapService;
    @Autowired
    private GlobalenumService globalenumService;
    
    @RequestMapping(value = "/list")
    public String list(@RequestParam(value = "sortType", defaultValue = "sequence") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");

        Page<Musiccategory> musiccategorys = musiccategoryService.getPage(searchParams, pageNumber, PAGE_SIZE, sortType);
        model.addAttribute("categorytype", globalenumService.getByType(SystemEnum.MUSICCATEGORY));
        model.addAttribute("musiccategorys", musiccategorys);
        model.addAttribute("sortType", sortType);
        model.addAttribute("sortTypes", sortTypes);
        model.addAttribute("typeid", searchParams.get("EQ_typeid"));
        // 将搜索条件编码成字符串，用于排序，分页的URL
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
        return "music/musiccategoryList";
    }
    @RequestMapping(value = "/ajaxlist")
    public String ajaxlist(@RequestParam(value = "sortType", defaultValue = "sequence") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");

        Page<Musiccategory> musiccategorys = musiccategoryService.getPage(searchParams, pageNumber, PAGE_SIZE, sortType);
        model.addAttribute("categorytype", globalenumService.getByType(SystemEnum.MUSICCATEGORY));
        model.addAttribute("musiccategorys", musiccategorys);
        model.addAttribute("sortType", sortType);
        model.addAttribute("sortTypes", sortTypes);
        // 将搜索条件编码成字符串，用于排序，分页的URL
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
        return "music/musiccategoryajaxList";
    }
    @RequestMapping(value = "create", method = RequestMethod.GET)
    public String createForm(Model model, Musiccategory musiccategory, Long typeid) {
        model.addAttribute("categorytype", globalenumService.getByType(SystemEnum.MUSICCATEGORY));
        model.addAttribute("musiccategory", musiccategory);
        model.addAttribute("typeid", typeid);
        model.addAttribute("action", "create");
        return "music/musiccategoryForm";
    }

    @RequestMapping(value = "create", method = RequestMethod.POST)
    public String create(Musiccategory musiccategory,String tabindex, RedirectAttributes redirectAttributes) {
        musiccategoryService.save(musiccategory);
        redirectAttributes.addFlashAttribute("message", "新增成功");
        redirectAttributes.addFlashAttribute("tabindex", tabindex);
        return "redirect:/musiccategory/list";
    }

    @RequestMapping(value = "update/{id}", method = RequestMethod.GET)
    public String updateForm(@PathVariable("id") Long id, Model model, Long typeid) {
        model.addAttribute("categorytype", globalenumService.getByType(SystemEnum.MUSICCATEGORY));
        model.addAttribute("musiccategory", musiccategoryService.findOne(id));
        model.addAttribute("typeid", typeid);
        model.addAttribute("action", "update");
        return "music/musiccategoryForm";
    }

    @RequestMapping(value = "update", method = RequestMethod.POST)
    public String update(@ModelAttribute("preloadMusiccategory") Musiccategory musiccategory,String tabindex, RedirectAttributes redirectAttributes) {
        musiccategoryService.save(musiccategory);
        redirectAttributes.addFlashAttribute("message", "保存成功");
        redirectAttributes.addFlashAttribute("tabindex", tabindex);
        return "redirect:/musiccategory/list";
    }

    @RequestMapping(value = "delete/{id}")
    public String delete(@PathVariable("id") Long id,String tabindex, RedirectAttributes redirectAttributes) {
        int num = musiccategoryService.deleteCheckRel(id);// 删除
                                                          // 单独的记录，如果有关联记录则删除不成功
        if (num > 0) {
            redirectAttributes.addFlashAttribute("message", "删除成功");
        } else {
            redirectAttributes.addFlashAttribute("message", "该导航包含下级导航或内容，无法删除");
        }
        redirectAttributes.addFlashAttribute("tabindex", tabindex);
        return "redirect:/musiccategory/list";
    }

    /**
     * 使用@ModelAttribute, 实现二次部分绑定
     */
    @ModelAttribute("preloadMusiccategory")
    public Musiccategory getMusiccategory(@RequestParam(value = "id", required = false) Long id) {
        if (id != null) {
            return musiccategoryService.findOne(id);
        }
        return null;
    }


    /**
     * 显示当前关联
     * 
     * @param categorytype
     * @return
     */
    @RequestMapping(value = "/contentlist")
    public String contentlist(Long musiccategoryid, @RequestParam(value = "sortType", defaultValue = "sequence") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");
        if(!searchParams.containsKey("EQ_musiccategory.id")&&musiccategoryid!=null){
            searchParams.put("EQ_musiccategory.id", musiccategoryid + "");
        }
        Page<Musiccategorymap> maps = musiccategorymapService.getPage(searchParams, pageNumber, PAGE_SIZE, sortType);
        model.addAttribute("maps", maps);
        model.addAttribute("musiccategoryid", musiccategoryid + "");
        model.addAttribute("sortType", sortType);
        model.addAttribute("sortTypes", sortTypes);
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_")+"&musiccategoryid="+musiccategoryid);// 将搜索条件编码成字符串，用于排序，分页的URL

        return "music/mapList";
    }
    //单删
    @RequestMapping(value = "/deletecontent")
    public String deletecontent(Long musiccategoryid,Long id, RedirectAttributes redirectAttributes) {
        musiccategorymapService.delete(id);
        return "redirect:/musiccategory/contentlist?musiccategoryid="+ musiccategoryid;
    }
    //批删
    @RequestMapping(value = "/deletecontents")
    public String deletecontents(Long musiccategoryid,Long [] ids, RedirectAttributes redirectAttributes) {
        musiccategorymapService.deleteAll(ids);
        return "redirect:/musiccategory/contentlist?musiccategoryid="+ musiccategoryid;
    }
    @RequestMapping(value = "/select")
    public String select(Long musiccategoryid, @RequestParam(value = "sortType", defaultValue = "auto") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");
        Page<Music> exceptcontents = musiccategorymapService.getMusicExceptCategory(musiccategoryid, pageNumber, PAGE_SIZE, sortType);
        model.addAttribute("exceptcontents", exceptcontents);
        model.addAttribute("musiccategoryid", musiccategoryid + "");
        
        model.addAttribute("sortType", sortType);
        model.addAttribute("sortTypes", sortTypes);
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_")+"&musiccategoryid="+musiccategoryid);
        return "music/mapSelect";
    }

    @RequestMapping(value = "/selectadd")
    public String selectadd(Long musiccategoryid,
            @RequestParam(value = "contentids", defaultValue = "") String contentids, RedirectAttributes redirectAttributes) {

        String[] idsArr = contentids.split(",");

        List<Musiccategorymap> list = new ArrayList<Musiccategorymap>();
        int i=1;
        for (String s : idsArr) {
            if (s.matches("\\d+")) {
                Musiccategorymap map = new Musiccategorymap();
                map.setMusiccategory(new Musiccategory(musiccategoryid));
                map.setMusic(new Music(Long.parseLong(s)));
                map.setSequence(i++);
                list.add(map);
            }
        }
        if(!list.isEmpty()){
            musiccategorymapService.updateAllSequence(list.size(),musiccategoryid);
            musiccategorymapService.save(list);
        }
        redirectAttributes.addFlashAttribute("message", "关联成功");
        return "redirect:/musiccategory/contentlist?musiccategoryid="+ musiccategoryid;
    }

    @RequestMapping(value = "/checkboxlist")
    public String checkboxlist(Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");

        Page<Musiccategory> musiccategorys = musiccategoryService.getPage(searchParams, 1, PAGE_SIZE, "auto");

        model.addAttribute("musiccategorys", musiccategorys);
        model.addAttribute("sortType", "auto");
        model.addAttribute("sortTypes", sortTypes);
        // 将搜索条件编码成字符串，用于排序，分页的URL
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
        return "program/musiccategorys";
    }
    
    /**
     * 排序
     */
    @RequestMapping(value = "/sortlist" ,method = RequestMethod.GET)
    public String sortlist(Long musiccategoryid, @RequestParam(value = "sortType", defaultValue = "sequence") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");
        if(!searchParams.containsKey("EQ_musiccategory.id")&&musiccategoryid!=null){
            searchParams.put("EQ_musiccategory.id", musiccategoryid + "");
        }
        Page<Musiccategorymap> maps = musiccategorymapService.getPage(searchParams, pageNumber, 1000, sortType);
        Page<Musiccategorymap> maps2 = musiccategorymapService.getPage(searchParams, pageNumber+1, 1000, sortType);
        model.addAttribute("maps", maps);
        model.addAttribute("maps2", maps2);
        model.addAttribute("musiccategoryid", musiccategoryid + "");

        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_")+"&musiccategoryid="+musiccategoryid);// 将搜索条件编码成字符串，用于排序，分页的URL

        return "music/sortList";
    }
    
    /**
     * 排序
     * @throws UnsupportedEncodingException 
     */
    @RequestMapping(value = "/sortlist" ,method = RequestMethod.POST)
    @ResponseBody
    public byte[] sortlistsave(Long [] ids,Integer [] sequences) throws UnsupportedEncodingException {
        List<Musiccategorymap> list =Lists.newArrayList();
        for(int i=0;i<ids.length;i++){
            Musiccategorymap mc =musiccategorymapService.findOne(ids[i]);
            mc.setSequence(sequences[i]);
            list.add(mc);
        }
        musiccategorymapService.save(list);
        return "保存成功".getBytes("utf-8");
    }
}
