package com.smt.iptv.portal.web.pmsa;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.ParseException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smt.iptv.portal.core.Result;
import com.smt.iptv.portal.entity.hotel.Hotelcustomer;
import com.smt.iptv.portal.entity.hotel.Hotelroom;
import com.smt.iptv.portal.service.hotel.HotelcustomerService;
import com.smt.iptv.portal.service.hotel.HotelroomService;

/**
 * @author rich
 */
@Controller
@RequestMapping(value = "/json/room/")
public class CheckinoutController {


    @Autowired
    private HotelcustomerService hotelcustomerService;
    @Autowired
    private HotelroomService hotelroomService;

    @RequestMapping(value = "pmsacheckin")
    @ResponseBody
    public Result pmsacheckin(String roomNo,String name, String identityCard,
            String beginTime,String endTime,String sex,String age,HttpServletRequest request) throws ParseException, UnsupportedEncodingException {
        //name = URLDecoder.decode(name,"utf-8");
        if(roomNo==null||name==null){
            return new Result(false, "");
        }
        synchronized (this) {   
            List<Hotelcustomer> list =hotelcustomerService.getByRoomnoNotEpmpty(roomNo);
            if(list!=null&&list.size()>0){
                for(Hotelcustomer hc:list){
                    if("1".equals(hc.getStatus())){
                           //重复的入住消息
                        if(name.equals(hc.getCustomername())||name.equals(hc.getEnglishname())){
                                return new Result();
                        }else{
                            hotelcustomerService.checkout(hc);
                        }
                    }
                }
            }
            List<Hotelroom> rooms = hotelroomService.getByRoomno(roomNo);
            if(rooms!=null&&rooms.size()>0){
                for(Hotelroom room:rooms){
                    Hotelcustomer newHotelcustomer=new Hotelcustomer();
                    Long hotelroomid=room.getId();
                    newHotelcustomer.setCheckintime(DateUtils.parseDate(beginTime, "yyyy-MM-dd HH:mm:ss"));;
                    newHotelcustomer.setCheckouttime(DateUtils.parseDate(endTime, "yyyy-MM-dd HH:mm:ss"));
                    newHotelcustomer.setCustomername(name);
                    newHotelcustomer.setEnglishname(name);
                    newHotelcustomer.setHotelroom(new Hotelroom(hotelroomid));
                    newHotelcustomer.setIdentitycard(identityCard);
                    newHotelcustomer.setSex(sex);
                    newHotelcustomer.setStatus("1");
                    hotelcustomerService.checkin(newHotelcustomer);
                }
            }
        }
        return new Result();
    }
    
    @RequestMapping(value = "pmsacheckout")
    @ResponseBody
    public Result pmsacheckout(String roomNo,String ckoutTime) {
        List<Hotelcustomer> list =hotelcustomerService.getByRoomnoNotEpmpty(roomNo);
        if(list!=null&&list.size()>0){
            for(Hotelcustomer hc:list){
                 hotelcustomerService.checkout(hc);
            }
        }
        return new Result();
    }
    
}
