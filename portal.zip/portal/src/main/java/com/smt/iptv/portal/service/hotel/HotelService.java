package com.smt.iptv.portal.service.hotel;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.entity.hotel.Hotel;
import com.smt.iptv.portal.repository.hotel.HotelDao;
import com.smt.iptv.portal.service.cmp.BaseService;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class HotelService extends BaseService<HotelDao, Hotel> {

}
