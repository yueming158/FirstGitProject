package com.smt.iptv.portal.entity;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.portal.core.IdEntity;
@Entity
@Table(name = "virtualcontentinfo")
public class Virtualcontentinfo extends IdEntity {
    
    public Virtualcontentinfo() {
    }

    public Virtualcontentinfo(Long id) {
        this.id = id;
    }
    
    private String viewname;
    private int channId;
    private String channCode;
    private int contId;
    private String contCode;
    private int duration;
    private int seq;
    public String getViewname() {
        return viewname;
    }

    public void setViewname(String viewname) {
        this.viewname = viewname;
    }

    public int getChannId() {
        return channId;
    }

    public void setChannId(int channId) {
        this.channId = channId;
    }

    public String getChannCode() {
        return channCode;
    }

    public void setChannCode(String channCode) {
        this.channCode = channCode;
    }

    public int getContId() {
        return contId;
    }

    public void setContId(int contId) {
        this.contId = contId;
    }

    public String getContCode() {
        return contCode;
    }

    public void setContCode(String contCode) {
        this.contCode = contCode;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public int getSeq() {
        return seq;
    }

    public void setSeq(int seq) {
        this.seq = seq;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}