package com.smt.iptv.portal.entity;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.portal.core.IdEntity;
@Entity
@Table(name = "slavearea")
public class Slavearea extends IdEntity {
    
    public Slavearea() {
    }

    public Slavearea(Long id) {
        this.id = id;
    }
    
	private String name;

	private Boolean selected;
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
    @Transient
    public Boolean getSelected() {
        return selected;
    }

    public void setSelected(Boolean selected) {
        this.selected = selected;
    }
    
}