package com.smt.iptv.portal.model;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.smt.iptv.portal.core.IdEntity;

public class Channel extends IdEntity {

    public Channel() {
    }

    public Channel(Long id) {
        this.id = id;
    }
    //channel表
    private String channelname;
    private String cpobjectcode;
    private int channelnumber;
    private String callsign;
    private String timeshift;
    private int timeshiftduration;
    private String timeshifturl;
    @JsonIgnore
    private String status;
    private String hdtv;
    private String casttype;
    private String recordstarttime;
    private String recordendtime;
    @JsonIgnore
    private String physicalchannelid;
    private String description;
    //physicalchannel表
    //private String physicacpobjectcode;
    @JsonIgnore
    private String bitratedef;
    @JsonIgnore
    private String ip;
    @JsonIgnore
    private String port;
    @JsonIgnore
    private String sourceip;
    @JsonIgnore
    private String sourceport;
    @JsonIgnore
    private String encoderip;
    @JsonIgnore
    private String encoderport;
    @JsonIgnore
    private String drmrecvip;
    @JsonIgnore
    private String drmrecvport;
    @JsonIgnore
    private String frequency;
    @JsonIgnore
    private String pmtpid;
    private String channelurl;
    //private String physicatimeshifturl;
    private String unicasturl;
    
    //customizedchannelno表
    private String servicegroup;

    public String getChannelname() {
        return channelname;
    }

    public void setChannelname(String channelname) {
        this.channelname = channelname;
    }

    public String getCpobjectcode() {
        return cpobjectcode;
    }

    public void setCpobjectcode(String cpobjectcode) {
        this.cpobjectcode = cpobjectcode;
    }

    public int getChannelnumber() {
        return channelnumber;
    }

    public void setChannelnumber(int channelnumber) {
        this.channelnumber = channelnumber;
    }

    public String getCallsign() {
        return callsign;
    }

    public void setCallsign(String callsign) {
        this.callsign = callsign;
    }

    public String getTimeshift() {
        return timeshift;
    }

    public void setTimeshift(String timeshift) {
        this.timeshift = timeshift;
    }

    public int getTimeshiftduration() {
        return timeshiftduration;
    }

    public void setTimeshiftduration(int timeshiftduration) {
        this.timeshiftduration = timeshiftduration;
    }

    public String getTimeshifturl() {
        return timeshifturl;
    }

    public void setTimeshifturl(String timeshifturl) {
        this.timeshifturl = timeshifturl;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getHdtv() {
        return hdtv;
    }

    public void setHdtv(String hdtv) {
        this.hdtv = hdtv;
    }

    public String getCasttype() {
        return casttype;
    }

    public void setCasttype(String casttype) {
        this.casttype = casttype;
    }

    public String getRecordstarttime() {
        return recordstarttime;
    }

    public void setRecordstarttime(String recordstarttime) {
        this.recordstarttime = recordstarttime;
    }

    public String getRecordendtime() {
        return recordendtime;
    }

    public void setRecordendtime(String recordendtime) {
        this.recordendtime = recordendtime;
    }

    public String getPhysicalchannelid() {
        return physicalchannelid;
    }

    public void setPhysicalchannelid(String physicalchannelid) {
        this.physicalchannelid = physicalchannelid;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getBitratedef() {
        return bitratedef;
    }

    public void setBitratedef(String bitratedef) {
        this.bitratedef = bitratedef;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public String getSourceip() {
        return sourceip;
    }

    public void setSourceip(String sourceip) {
        this.sourceip = sourceip;
    }

    public String getSourceport() {
        return sourceport;
    }

    public void setSourceport(String sourceport) {
        this.sourceport = sourceport;
    }

    public String getEncoderip() {
        return encoderip;
    }

    public void setEncoderip(String encoderip) {
        this.encoderip = encoderip;
    }

    public String getEncoderport() {
        return encoderport;
    }

    public void setEncoderport(String encoderport) {
        this.encoderport = encoderport;
    }

    public String getDrmrecvip() {
        return drmrecvip;
    }

    public void setDrmrecvip(String drmrecvip) {
        this.drmrecvip = drmrecvip;
    }

    public String getDrmrecvport() {
        return drmrecvport;
    }

    public void setDrmrecvport(String drmrecvport) {
        this.drmrecvport = drmrecvport;
    }

    public String getFrequency() {
        return frequency;
    }

    public void setFrequency(String frequency) {
        this.frequency = frequency;
    }

    public String getPmtpid() {
        return pmtpid;
    }

    public void setPmtpid(String pmtpid) {
        this.pmtpid = pmtpid;
    }

    public String getChannelurl() {
        return channelurl;
    }

    public void setChannelurl(String channelurl) {
        this.channelurl = channelurl;
    }

    public String getUnicasturl() {
        return unicasturl;
    }

    public void setUnicasturl(String unicasturl) {
        this.unicasturl = unicasturl;
    }

    public String getServicegroup() {
        return servicegroup;
    }

    public void setServicegroup(String servicegroup) {
        this.servicegroup = servicegroup;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
}