package com.smt.iptv.portal.service.goods;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;
import com.smt.iptv.portal.i18nentity.goods.Goods;
import com.smt.iptv.portal.i18nrepository.goods.GoodsDao;
import com.smt.iptv.portal.service.cmp.BaseService;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class GoodsService extends BaseService<GoodsDao, Goods> {
    
    public List<Goods> getRecommends(Long id){
        Goods d = dao.findOne(id);
        if(d!=null&& StringUtils.isNotEmpty(d.getRecommend())){
            List<Long> idList =Lists.newArrayList();
            String [] idArr =d.getRecommend().split(",");
            for(String idStr:idArr){
                if(idStr.matches("\\d+")){
                    idList.add(Long.parseLong(idStr));
                }
            }
            if(idList.size()>0){
                return (List<Goods>)dao.findAll(idList);
            }
        }
        return null;//dao.findAll();
    }
    @Transactional(readOnly = false)
    public void deleteGoodsAndCartAndFeatured(Long goodsId){
        dao.deleteFeatured(goodsId);
        dao.deleteCartWithGoodsId(goodsId);
        dao.delete(goodsId);
    }
}
