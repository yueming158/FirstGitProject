package com.smt.iptv.portal.repository.aaa;

import com.smt.iptv.portal.entity.aaa.Account;
import com.smt.iptv.portal.repository.BaseDao;

public interface AccountDao extends BaseDao<Account> {

}
