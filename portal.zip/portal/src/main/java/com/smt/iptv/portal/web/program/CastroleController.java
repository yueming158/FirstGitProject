package com.smt.iptv.portal.web.program;

import java.util.Map;

import javax.servlet.ServletRequest;
import javax.validation.Valid;

import org.apache.shiro.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Maps;
import com.smt.iptv.portal.i18nentity.program.Castrole;
import com.smt.iptv.portal.service.account.ShiroDbRealm.ShiroUser;
import com.smt.iptv.portal.service.cmp.CastroleService;

/**
 * Castrole管理的Controller, 使用Restful风格的Urls:
 * 
 * List page     : GET /castrole/
 * Create page   : GET /castrole/create
 * Create action : POST /castrole/create
 * Update page   : GET /castrole/update/{id}
 * Update action : POST /castrole/update
 * Delete action : GET /castrole/delete/{id}
 * 
 * @author xjw
 */
@Controller
@RequestMapping(value = "/castrole")
public class CastroleController {

	private static final int PAGE_SIZE = 50;

	private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
	static {
		sortTypes.put("auto", "自动");
		sortTypes.put("castrolename", "名称");
	}

	@Autowired
	private CastroleService castroleService;

	@RequestMapping(value = "/list")
	public String list(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
			@RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
		Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");

		Page<Castrole> castroles = castroleService.getPage( searchParams, pageNumber, PAGE_SIZE, sortType);

		model.addAttribute("castroles", castroles);
		model.addAttribute("sortType", sortType);
		model.addAttribute("sortTypes", sortTypes);
		// 将搜索条件编码成字符串，用于排序，分页的URL
		model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
		return "castrole/castroleList";
	}

	@RequestMapping(value = "create", method = RequestMethod.GET)
	public String createForm(Model model) {
		model.addAttribute("castrole", new Castrole());
		model.addAttribute("action", "create");
		return "castrole/castroleForm";
	}

	@RequestMapping(value = "create", method = RequestMethod.POST)
	public String create(@Valid Castrole newCastrole, RedirectAttributes redirectAttributes) {
		castroleService.create(newCastrole,"cpobjectcode","CASTROLE0000000000");
		redirectAttributes.addFlashAttribute("message", "新增成功");
		return "redirect:/castrole/list";
	}

	@RequestMapping(value = "update/{id}", method = RequestMethod.GET)
	public String updateForm(@PathVariable("id") Long id, Model model) {
		model.addAttribute("castrole", castroleService.findOne(id));
		model.addAttribute("action", "update");
		return "castrole/castroleForm";
	}

	@RequestMapping(value = "update", method = RequestMethod.POST)
	public String update(@Valid @ModelAttribute("preloadCastrole") Castrole castrole, RedirectAttributes redirectAttributes) {
		castroleService.save(castrole);
		redirectAttributes.addFlashAttribute("message", "保存成功");
		return "redirect:/castrole/list";
	}

	@RequestMapping(value = "delete/{id}")
	public String delete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
		castroleService.delete(id);
		redirectAttributes.addFlashAttribute("message", "删除成功");
		return "redirect:/castrole/list";
	}

	/**
	 * 使用@ModelAttribute, 实现Struts2 Preparable二次部分绑定的效果,先根据form的id从数据库查出Castrole对象,再把Form提交的内容绑定到该对象上。
	 * 因为仅update()方法的form中有id属性，因此本方法在该方法中执行.
	 */
	@ModelAttribute("preloadCastrole")
	public Castrole getCastrole(@RequestParam(value = "id", required = false) Long id) {
		if (id != null) {
			return castroleService.findOne(id);
		}
		return null;
	}

	/**
	 * 取出Shiro中的当前用户Id.
	 */
	private Long getCurrentUserId() {
		ShiroUser user = (ShiroUser) SecurityUtils.getSubject().getPrincipal();
		return user.id;
	}
}
