package com.smt.iptv.portal.repository;

import com.smt.iptv.portal.entity.Meeting;

public interface MeetingDao extends BaseDao<Meeting> {

}
