package com.smt.iptv.portal.service.cfg;

import java.io.File;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;

import apk.parser.GetApkInfo;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.smt.iptv.portal.entity.Appupdateinfo;
import com.smt.iptv.portal.i18nentity.Epgvariable;
import com.smt.iptv.portal.i18nentity.info.Infotemplate;
import com.smt.iptv.portal.model.SystemConstant;
import com.smt.iptv.portal.service.cmp.AppupdateinfoService;
import com.smt.iptv.portal.service.hotel.EpgvariableService;
import com.smt.iptv.portal.service.info.InfotemplateService;

//Spring Bean的标识.
@Component
public class ConfigService {
    @Autowired
    private AppupdateinfoService appupdateinfoService;
    @Autowired
    private InfotemplateService infotemplateService;
    @Autowired
    private EpgvariableService epgvariableService;
    //限制apk版本兼容性不在这里做
    public List<Properties> initConfig(){
        //1获取当前生效apk
        Appupdateinfo appupdateinfo =appupdateinfoService.getAppupdateinfoForInitConfig();
        if(appupdateinfo!=null){
            File apkFile = new File(SystemConstant.getURLValue("fileupload")+appupdateinfo.getDownloadurl());
            //3同步模板数据
            Properties apktemplates = GetApkInfo.getTemplateConfig(apkFile);
            if(apktemplates.size()>0){
                List<String> names=Lists.newArrayList();
                List<Infotemplate> list = infotemplateService.getAll();
                for(Infotemplate template:list){
                    String code =template.getCode();
                    if(apktemplates.getProperty(code)==null){
                        template.setEnabled("0");
                    }else{
                        template.setEnabled("1");
                        names.add(code);
                    }
                }
                infotemplateService.save(list);
                for(String name:names){
                    apktemplates.remove(name);
                }
            }
            //4同步配置数据 兼容epggourp
            Properties stbconfig = GetApkInfo.getStbconfig(apkFile);
            stbconfig.put("default_welcome","欢迎词" );
            if(stbconfig.size()>0){
                List<String> names=Lists.newArrayList();
                List<Epgvariable> list = epgvariableService.getAll();
                for(Epgvariable epgvariable:list){
                    String name =epgvariable.getName();
                    if(stbconfig.getProperty(name)==null){
                        epgvariable.setEnabled("0");
                    }else{
                        epgvariable.setEnabled("1");
                        names.add(name);
                    }
                }
                epgvariableService.save(list);
                for(String name:names){
                    stbconfig.remove(name);
                }
            }
            return Lists.newArrayList(apktemplates,stbconfig);
        }
        return Lists.newArrayList();
    }
}
