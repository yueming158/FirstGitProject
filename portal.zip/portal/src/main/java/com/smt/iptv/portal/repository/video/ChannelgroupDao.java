package com.smt.iptv.portal.repository.video;

import org.springframework.data.jpa.repository.Query;

import com.smt.iptv.portal.entity.Channelgroup;
import com.smt.iptv.portal.repository.BaseDao;

public interface ChannelgroupDao extends BaseDao<Channelgroup> {
    @Query("select s.id from Channelgroup s  where s.id=?1 and not exists(select 1 from Iptvprofile i where i.channelgroup.id=?1)")
    public Long getSingleChannelgroupId(Long id);
    public Channelgroup getBychannelgroupcode(String channelgroupcode);
}
