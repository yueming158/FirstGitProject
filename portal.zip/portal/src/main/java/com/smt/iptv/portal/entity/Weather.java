package com.smt.iptv.portal.entity;



import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.smt.iptv.portal.core.IdEntity;
import com.smt.iptv.portal.model.SystemConstant;

@Entity
@Table(name = "weather")
public class Weather extends IdEntity {
    private String weather;
    private String temp;
    private String wd;
    private String ws;
    private String cityname;
    private String citycode;
    @JsonIgnore
    private String logourl;
    private Date weatherdate;
    private String currenttemp;
    
    @Transient
    public String getLogoImageUrl(){
        return SystemConstant.getURLValue("image_server_httpprefix")+this.logourl;
    }
	public Weather() {
	}

	public Weather(Long id) {
		this.id = id;
	}

	
    public String getWeather() {
        return weather;
    }

    public void setWeather(String weather) {
        this.weather = weather;
    }

    public String getTemp() {
        return temp;
    }

    public void setTemp(String temp) {
        this.temp = temp;
    }

    public String getWd() {
        return wd;
    }

    public void setWd(String wd) {
        this.wd = wd;
    }

    public String getWs() {
        return ws;
    }

    public void setWs(String ws) {
        this.ws = ws;
    }

    public String getCityname() {
        return cityname;
    }

    public void setCityname(String cityname) {
        this.cityname = cityname;
    }

    public String getCitycode() {
        return citycode;
    }

    public void setCitycode(String citycode) {
        this.citycode = citycode;
    }

    public String getLogourl() {
        return logourl;
    }

    public void setLogourl(String logourl) {
        this.logourl = logourl;
    }

    public Date getWeatherdate() {
        return weatherdate;
    }

    public void setWeatherdate(Date weatherdate) {
        this.weatherdate = weatherdate;
    }
    
    public String getCurrenttemp() {
        return currenttemp;
    }
    public void setCurrenttemp(String currenttemp) {
        this.currenttemp = currenttemp;
    }
    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}