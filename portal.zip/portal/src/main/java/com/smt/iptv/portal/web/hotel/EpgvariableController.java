package com.smt.iptv.portal.web.hotel;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Maps;
import com.smt.iptv.portal.core.FileUploadUtil;
import com.smt.iptv.portal.i18nentity.Epggroup;
import com.smt.iptv.portal.i18nentity.Epgvariable;
import com.smt.iptv.portal.service.cmp.EpggroupService;
import com.smt.iptv.portal.service.hotel.EpgvariableService;

/**
 * 
 * @author rich
 */
@Controller
@RequestMapping(value = "/epgvariable")
public class EpgvariableController {

	private static final int PAGE_SIZE = 50;

	private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
	static {
		sortTypes.put("auto", "自动");
		sortTypes.put("name", "名称");
	}

	@Autowired
	private EpgvariableService epgvariableService;
    @Autowired
    private EpggroupService epggroupService;
	@RequestMapping(value = "/list")
	public String list(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
			@RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
	    List<Epggroup> epggroups =epggroupService.getAll();
	    model.addAttribute("epggroups",epggroups );//group
		Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");
		if(!searchParams.containsKey("EQ_epggroupid")){
		    searchParams.put("EQ_epggroupid",epggroups!=null?epggroups.get(0).getId().toString():"1");
		}
        if(!searchParams.containsKey("EQ_enabled")){
            searchParams.put("EQ_enabled","1");
        }
		Page<Epgvariable> epgvariables = epgvariableService.getPage( searchParams, pageNumber, PAGE_SIZE, sortType);
		model.addAttribute("epgvariables", epgvariables);
		model.addAttribute("sortType", sortType);
		model.addAttribute("sortTypes", sortTypes);
		// 将搜索条件编码成字符串，用于排序，分页的URL
		model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
		return "hotel/epgvariableList";
	}


	@RequestMapping(value = "update/{id}", method = RequestMethod.GET)
	public String updateForm(@PathVariable("id") Long id, Model model,@RequestParam(required=false)Long epggroupid) {
	    if(id==0L){
	        Epgvariable epgvariable =new Epgvariable();
	        epgvariable.setEpggroupid(epggroupid==null?1L:epggroupid);
	        model.addAttribute("epgvariable", epgvariable);
	    }else{
	        model.addAttribute("epgvariable", epgvariableService.findOne(id));
	    }
		model.addAttribute("action", "update");
		return "hotel/epgvariableForm";
	}
	
    @RequestMapping(value = "update", method = RequestMethod.POST)
    public String update(@Valid @ModelAttribute("preloadEpgvariable") Epgvariable epgvariable, RedirectAttributes redirectAttributes,
            @RequestParam("file") MultipartFile multipartFile,
            HttpServletRequest request) throws FileNotFoundException, IOException {
        String relativePath ="hotel/";
        if("I".equals(epgvariable.getType())&&!multipartFile.isEmpty()){
            File file = FileUploadUtil.saveFile(multipartFile, relativePath,true,0,0);
            if(file!=null&&file.isFile()){   
                //检查图片大小限制
                BufferedImage sourceImg =ImageIO.read(new FileInputStream(file)); 
                if(sourceImg==null){
                    file.delete();
                    redirectAttributes.addFlashAttribute("message", "文件类型不正确");
                    return "redirect:/epgvariable/list";
                }else if(sourceImg.getWidth()!=epgvariable.getWidth()||sourceImg.getHeight()!=epgvariable.getHeight()){
                    redirectAttributes.addFlashAttribute("message", "保存失败，图片大小不匹配");
                    file.delete();
                    return "redirect:/epgvariable/list";
                }else{
                    FileUploadUtil.delete(epgvariable.getValue());
                    epgvariable.setValue(relativePath+file.getName());
                }
            }
        }else if("F".equals(epgvariable.getType())&&!multipartFile.isEmpty()){
            File file = FileUploadUtil.saveFile(multipartFile, relativePath,true,0,0);
            if(file!=null&&file.isFile()){
                FileUploadUtil.delete(epgvariable.getValue());
                epgvariable.setValue(relativePath+file.getName());
            }
        }
        epgvariableService.save(epgvariable);
        redirectAttributes.addFlashAttribute("message", "保存成功");
        return "redirect:/epgvariable/list?search_EQ_epggroupid="+epgvariable.getEpggroupid();
    }

	/**
	 * 使用@ModelAttribute, 实现Struts2 Preparable二次部分绑定的效果,先根据form的id从数据库查出Epgvariable对象,再把Form提交的内容绑定到该对象上。
	 * 因为仅update()方法的form中有id属性，因此本方法在该方法中执行.
	 */
	@ModelAttribute("preloadEpgvariable")
	public Epgvariable getEpgvariable(@RequestParam(value = "id", required = false) Long id) {
		if (id != null) {
			return epgvariableService.findOne(id);
		}
		return new Epgvariable();
	}

	

}
