package com.smt.iptv.portal.web.program;

import java.io.File;
import java.util.Map;

import javax.servlet.ServletRequest;
import javax.validation.Valid;

import org.apache.shiro.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Maps;
import com.smt.iptv.portal.core.FileUploadUtil;
import com.smt.iptv.portal.core.SystemEnum;
import com.smt.iptv.portal.i18nentity.Info;
import com.smt.iptv.portal.service.account.ShiroDbRealm.ShiroUser;
import com.smt.iptv.portal.service.cmp.GlobalenumService;
import com.smt.iptv.portal.service.cmp.InfoService;

/**
 * Info管理的Controller, 使用Restful风格的Urls:
 * 
 * List page     : GET /info/
 * Create page   : GET /info/create
 * Create action : POST /info/create
 * Update page   : GET /info/update/{id}
 * Update action : POST /info/update
 * Delete action : GET /info/delete/{id}
 * 
 * @author xjw
 */
@Controller
@RequestMapping(value = "/info")
public class InfoController {

	private static final int PAGE_SIZE = 50;

	private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
	static {
		sortTypes.put("auto", "自动");
		sortTypes.put("infoname", "名称");
	}

	@Autowired
	private InfoService infoService;
	@Autowired
	private GlobalenumService globalenumService;
	@RequestMapping(value = "/list")
	public String list(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
			@RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
		Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");

		Page<Info> infos = infoService.getPage( searchParams, pageNumber, PAGE_SIZE, sortType);
		model.addAttribute("infos", infos);
		model.addAttribute("infotypes", globalenumService.getByType(SystemEnum.INFOTYPE));
		model.addAttribute("sortType", sortType);
		model.addAttribute("sortTypes", sortTypes);
		// 将搜索条件编码成字符串，用于排序，分页的URL
		model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
		return "info/infoList";
	}

	@RequestMapping(value = "create", method = RequestMethod.GET)
	public String createForm(Model model) {
		model.addAttribute("info", new Info());
		model.addAttribute("action", "create");
		model.addAttribute("infotypes", globalenumService.getByType(SystemEnum.INFOTYPE));
		return "info/infoForm";
	}

	@RequestMapping(value = "create", method = RequestMethod.POST)
	public String create(@Valid Info newInfo,MultipartFile file, RedirectAttributes redirectAttributes) {
	    if(!file.isEmpty()){
    	    String relativePath ="info/";
            File descfile = FileUploadUtil.saveFile(file, relativePath,true,0,0);
            newInfo.setInfoimg(relativePath+ descfile.getName());
	    }
        infoService.save(newInfo);
        redirectAttributes.addFlashAttribute("message", "新增成功");
		return "redirect:/info/list";
	}

	@RequestMapping(value = "update/{id}", method = RequestMethod.GET)
	public String updateForm(@PathVariable("id") Long id, Model model) {
		model.addAttribute("info", infoService.findOne(id));
		model.addAttribute("action", "update");
		model.addAttribute("infotypes", globalenumService.getByType(SystemEnum.INFOTYPE));
		return "info/infoForm";
	}

	@RequestMapping(value = "update", method = RequestMethod.POST)
	public String update(@Valid @ModelAttribute("preloadInfo") Info info,MultipartFile file, RedirectAttributes redirectAttributes) {
	    String relativePath ="info/";
	    if(!file.isEmpty()){
    	    File descfile = FileUploadUtil.saveFile(file, relativePath,true,0,0);
    	    FileUploadUtil.delete(info.getInfoimg());
    	    info.setInfoimg(relativePath+ descfile.getName());
	    }
		infoService.save(info);
		redirectAttributes.addFlashAttribute("message", "保存成功");
		return "redirect:/info/list";
	}

	@RequestMapping(value = "delete/{id}")
	public String delete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
		infoService.delete(id);
		redirectAttributes.addFlashAttribute("message", "删除成功");
		return "redirect:/info/list";
	}

	/**
	 * 使用@ModelAttribute, 实现Struts2 Preparable二次部分绑定的效果,先根据form的id从数据库查出Info对象,再把Form提交的内容绑定到该对象上。
	 * 因为仅update()方法的form中有id属性，因此本方法在该方法中执行.
	 */
	@ModelAttribute("preloadInfo")
	public Info getInfo(@RequestParam(value = "id", required = false) Long id) {
		if (id != null) {
			return infoService.findOne(id);
		}
		return null;
	}

	/**
	 * 取出Shiro中的当前用户Id.
	 */
	private Long getCurrentUserId() {
		ShiroUser user = (ShiroUser) SecurityUtils.getSubject().getPrincipal();
		return user.id;
	}
}
