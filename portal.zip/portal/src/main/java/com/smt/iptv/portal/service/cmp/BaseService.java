package com.smt.iptv.portal.service.cmp;

import java.text.DecimalFormat;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.transaction.annotation.Transactional;
import org.springside.modules.utils.Collections3;

import com.google.common.collect.Lists;
import com.smt.iptv.portal.core.IdEntity;
import com.smt.iptv.portal.core.SearchFilter;
import com.smt.iptv.portal.core.ServiceException;
import com.smt.iptv.portal.repository.BaseDao;

//Spring Bean的标识.
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class BaseService<T extends BaseDao<E>, E extends IdEntity>{

	protected T dao;
	
    @Autowired
    public void setDao(T dao) {
        this.dao = dao;
    }
	
	public E findOne(Long id) {
         return (E) dao.findOne(id);
	}
	/**
	 * 
	 * @param entity 要新增的new状态对象 无ID
	 * @param Field   新增时需要默认添加编码的字段名
	 * @param dcmFmtStr    默认编码的DecimalFormat格式，根据ID得到编码值。
	 */
    @Transactional(readOnly = false)
    public void create(E entity,String propertyName,String dcmFmtStr) {
        dao.save(entity);
        int index=dcmFmtStr.indexOf("0");
        dcmFmtStr =dcmFmtStr.substring(0, index)+LocaleContextHolder.getLocale().getLanguage()+dcmFmtStr.substring(index);
        DecimalFormat dcmFmt = new DecimalFormat(dcmFmtStr);
        String code =dcmFmt.format(entity.getId());
        String methodEnd = propertyName.substring(0,1).toUpperCase() + propertyName.substring(1);
            try {
                entity.getClass().getMethod("set"+methodEnd, String.class).invoke(entity, code);
            } catch (Exception e) {
                throw new ServiceException(e);
            } 
        dao.save(entity);
    }
	@Transactional(readOnly = false)
	public E save(E entity) {
	    return dao.save(entity);
	}
    @Transactional(readOnly = false)
    public void save(Iterable<E> entities) {
        dao.save(entities);
    }
	@Transactional(readOnly = false)
	public void delete(Long id) {
	    dao.delete(id);
	}
    @Transactional(readOnly = false)
    public void delete(E entity) {
        dao.delete(entity);
    }
    @Transactional(readOnly = false)
    public void delete(Iterable<? extends E> entities) {
        dao.delete(entities);
    }
    public List<E> getAll() {
        return (List<E>) dao.findAll();
    }

	public Page<E> getPage(Map<String, Object> searchParams, int pageNumber, int pageSize,
			String sortType) {
		PageRequest pageRequest = buildPageRequest(pageNumber, pageSize, sortType);
		Specification<E> spec = (Specification<E>) buildSpecification(searchParams);
		return dao.findAll(spec, pageRequest);
	}

    public Page<E> getPageDesc(Map<String, Object> searchParams, int pageNumber, int pageSize,
            String sortType) {
        PageRequest pageRequest = buildPageRequestDesc(pageNumber, pageSize, sortType);
        Specification<E> spec = (Specification<E>) buildSpecification(searchParams);
        return dao.findAll(spec, pageRequest);
    }
    /**
     * 创建分页请求.
     */
    protected PageRequest buildPageRequestDesc(int pageNumber, int pageSize, String sortType) {
        Sort sort = null;
        if ("auto".equals(sortType)) {
            sort = new Sort(Direction.ASC, "id");
        } else {
            sort = new Sort(Direction.DESC, sortType);
        }
        return new PageRequest(pageNumber - 1, pageSize, sort);
    }
	/**
	 * 创建分页请求.
	 */
	protected PageRequest buildPageRequest(int pageNumber, int pageSize, String sortType) {
		Sort sort = null;
		if ("auto".equals(sortType)) {
			sort = new Sort(Direction.DESC, "id");
		} else {
			sort = new Sort(Direction.ASC, sortType);
		}
		return new PageRequest(pageNumber - 1, pageSize, sort);
	}

	/**
	 * 创建动态查询条件组合.
	 */
	protected Specification<E> buildSpecification( Map<String, Object> searchParams) {
		Map<String, SearchFilter> filters = SearchFilter.parse(searchParams);
		Specification<E> spec = bySearchFilter(filters.values());
		return spec;
	}

    private static <T> Specification<T> bySearchFilter(final Collection<SearchFilter> filters) {
        return new Specification<T>() {
            @Override
            public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
                if (Collections3.isNotEmpty(filters)) {

                    List<Predicate> predicates = Lists.newArrayList();
                    for (SearchFilter filter : filters) {
                        // nested path translate, 如Task的名为"user.name"的filedName, 转换为Task.user.name属性
                        String[] names = StringUtils.split(filter.fieldName, ".");
                        Path expression = root.get(names[0]);
                        for (int i = 1; i < names.length; i++) {
                            expression = expression.get(names[i]);
                        }

                        // logic operator
                        switch (filter.operator) {
                        case EQ:
                            predicates.add(builder.equal(expression, filter.value));
                            break;
                        case NOTEQ:
                            predicates.add(builder.notEqual(expression, filter.value));
                            break;
                        case LIKE:
                            predicates.add(builder.like(expression, "%" + filter.value + "%"));
                            break;
                        case GT:
                            predicates.add(builder.greaterThan(expression, (Comparable) filter.value));
                            break;
                        case LT:
                            predicates.add(builder.lessThan(expression, (Comparable) filter.value));
                            break;
                        case GTE:
                            predicates.add(builder.greaterThanOrEqualTo(expression, (Comparable) filter.value));
                            break;
                        case LTE:
                            predicates.add(builder.lessThanOrEqualTo(expression, (Comparable) filter.value));
                            break;
                        }
                    }

                    // 将所有条件用 and 联合起来
                    if (predicates.size() > 0) {
                        return builder.and(predicates.toArray(new Predicate[predicates.size()]));
                    }
                }

                return builder.conjunction();
            }
        };
    }
}
