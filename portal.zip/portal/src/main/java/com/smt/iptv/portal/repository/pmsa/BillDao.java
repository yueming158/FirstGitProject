package com.smt.iptv.portal.repository.pmsa;

import com.smt.iptv.portal.entity.pmsa.Bill;
import com.smt.iptv.portal.repository.BaseDao;

public interface BillDao extends BaseDao<Bill> {
}
