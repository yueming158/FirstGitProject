package com.smt.iptv.portal.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springside.modules.mapper.JsonMapper;

import com.fasterxml.jackson.databind.JavaType;
import com.smt.iptv.portal.core.IdEntity;
import com.smt.iptv.portal.entity.aaa.Account;
import com.smt.iptv.portal.entity.aaa.Attr;

@Entity
@Table(name = "iptvprofile")
public class Iptvprofile extends IdEntity {

    public Iptvprofile() {
    }

    public Iptvprofile(Long id) {
        this.id = id;
    }

    private Channelgroup channelgroup;
    private String iptvusername;
    private String iptvpassword;
    private String interacpassword;
    private String status;
    private String macaddress;
    private String ipaddress;
    private String hotspot;
    private Integer level;
    private String stbversion;
    private Long epggroupid;
    private String loginstatus;// O 在线 N不在线
    // private String username;
    // private String useridentity;
    // private String usertel;
    // private String useraddress;
    // private String description;
    private String distributeip;
    private String token;
    private Account account;
    private String attrs;

    private static JsonMapper mapper = new JsonMapper();
    private static JavaType attrsType =mapper.createCollectionType(ArrayList.class, Attr.class);
    @Transient
    public List<Attr> getAttrList() {

        if (StringUtils.isNotEmpty(attrs)) {
            return mapper.fromJson(attrs, attrsType);
        } else {
            return null;
        }
    }
    public void setAttrList(List<Attr> attrsList) {
        this.attrs = mapper.toJson(attrsList);
    }
    @ManyToOne(cascade=CascadeType.ALL)
    @JoinColumn(name = "accountid")
    public Account getAccount() {
        return account;
    }

    public void setAccount(Account account) {
        this.account = account;
    }

    @ManyToOne
    @JoinColumn(name = "channelgroupid")
    public Channelgroup getChannelgroup() {
        return channelgroup;
    }

    public void setChannelgroup(Channelgroup channelgroup) {
        this.channelgroup = channelgroup;
    }

    public String getIptvusername() {
        return iptvusername;
    }

    public void setIptvusername(String iptvusername) {
        this.iptvusername = iptvusername;
    }

    public String getIptvpassword() {
        return iptvpassword;
    }

    public void setIptvpassword(String iptvpassword) {
        this.iptvpassword = iptvpassword;
    }

    public String getInteracpassword() {
        return interacpassword;
    }

    public void setInteracpassword(String interacpassword) {
        this.interacpassword = interacpassword;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMacaddress() {
        return macaddress;
    }

    public void setMacaddress(String macaddress) {
        this.macaddress = macaddress;
    }

    public String getIpaddress() {
        return ipaddress;
    }

    public void setIpaddress(String ipaddress) {
        this.ipaddress = ipaddress;
    }

    public String getHotspot() {
        return hotspot;
    }

    public void setHotspot(String hotspot) {
        this.hotspot = hotspot;
    }

    // public String getUsername() {
    // return username;
    // }
    //
    // public void setUsername(String username) {
    // this.username = username;
    // }
    //
    // public String getUseridentity() {
    // return useridentity;
    // }
    //
    // public void setUseridentity(String useridentity) {
    // this.useridentity = useridentity;
    // }
    //
    // public String getUsertel() {
    // return usertel;
    // }
    //
    // public void setUsertel(String usertel) {
    // this.usertel = usertel;
    // }
    //
    // public String getUseraddress() {
    // return useraddress;
    // }
    //
    // public void setUseraddress(String useraddress) {
    // this.useraddress = useraddress;
    // }
    //
    // public String getDescription() {
    // return description;
    // }
    //
    // public void setDescription(String description) {
    // this.description = description;
    // }

    public Integer getLevel() {
        return level;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }

    public String getStbversion() {
        return stbversion;
    }

    public void setStbversion(String stbversion) {
        this.stbversion = stbversion;
    }

    public Long getEpggroupid() {
        return epggroupid;
    }

    public void setEpggroupid(Long epggroupid) {
        this.epggroupid = epggroupid;
    }

    @Transient
    public String getLoginstatus() {
        return loginstatus;
    }

    public void setLoginstatus(String loginstatus) {
        this.loginstatus = loginstatus;
    }

    public String getDistributeip() {
        return distributeip;
    }

    public void setDistributeip(String distributeip) {
        this.distributeip = distributeip;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getAttrs() {
        return attrs;
    }

    public void setAttrs(String attrs) {
        this.attrs = attrs;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
}