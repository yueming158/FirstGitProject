package com.smt.iptv.portal.service.cmp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;
import com.smt.iptv.portal.entity.Channelgroup;
import com.smt.iptv.portal.entity.Iptvprofile;
import com.smt.iptv.portal.repository.IptvprofileDao;
import com.smt.iptv.portal.repository.hotel.HotelroomDao;
import com.smt.iptv.portal.service.excel.ExcelDataArray;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class IptvprofileService extends BaseService<IptvprofileDao, Iptvprofile> {
    @Autowired
    private HotelroomDao hotelroomDao;
    @Transactional(readOnly = false)
    public void changeStatus(Long id, String status) {
        dao.changeStatus(id, status);
        if("0".equals(status)){//0代表解绑
            dao.clearmac(id);
        }
    }

    public Iptvprofile getByiptvusername(String iptvusername) {
        return dao.getByiptvusername(iptvusername);
    }

    public Iptvprofile getBymacaddress(String macaddress) {
        return dao.getBymacaddress(macaddress);
    }
    
    @Transactional(readOnly = false)
    public  void importdata(Long channelgroupid,ExcelDataArray excelDataArray){
        List<Iptvprofile> profiles =Lists.newArrayList();
        Integer nameInt = dao.getMaxIptvusername().intValue();
        if(excelDataArray!=null){
            for(String [] row: excelDataArray.getDataArray()){
                //this.create(new Schedule(channelid, row), "cpobjectcode", "SCH0000000000");
                if(row==null||(row.length!=1)){
                    throw new RuntimeException("excel导入数据格式不正确");
                }
                Iptvprofile p=new Iptvprofile();
                p.setChannelgroup(new Channelgroup(channelgroupid));
                p.setMacaddress(row[0]);
                p.setIptvpassword("111111");
                p.setStatus("0");
                p.setIptvusername(String.valueOf(nameInt++));
                profiles.add(p);
            }
        }
        try{
            dao.save(profiles);
        }catch (Exception e) {
            if(e.getMessage().startsWith("Duplicate entry")){
                throw new RuntimeException(e.getMessage().split("'")[1]+"此地址已经授权绑定");
            }
        }
    }
    @Override
    @Transactional(readOnly = false)
    public void delete(Long id) {
        dao.delete(id);
        hotelroomDao.deleteByIptvprofileId(id);
    }
    public Integer getMaxIptvusername(){
        return dao.getMaxIptvusername().intValue();
    }
    
    
    public List<String> getProfileIdByGroup(Long epggroupid){
    	return dao.getProfileIdByGroup(epggroupid);
    }
}
