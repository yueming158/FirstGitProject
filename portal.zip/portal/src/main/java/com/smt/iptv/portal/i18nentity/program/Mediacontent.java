package com.smt.iptv.portal.i18nentity.program;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.portal.core.IdEntity;
@Entity
@Table(name = "mediacontent")
public class Mediacontent extends IdEntity {
    
    public Mediacontent() {
    }

    public Mediacontent(Long id) {
        this.id = id;
    }
    
	private String mediacontentname;
	private String cpobjectcode;
	private String mediatype;
	private Integer duration;
	
	private String status;
	private String videotype;
	private String audiotype;  
    private String streamtype;
    
    private String sourcefilename;
    private String destfilename;
    private String offcbr;
    private String segmentcount;
    private String deleteflag = "1";
    private String filesize;
    private String propagationpriority;
    private Date createtime;
    
    private Program program;
    private String sequence;
    
    private String urltype;
    private String otherplayurl;

    @ManyToOne
    @JoinColumn(name="programid")
    public Program getProgram() {
        return program;
    }

    public void setProgram(Program program) {
        this.program = program;
    }
    
    public String getMediacontentname() {
        return mediacontentname;
    }

    public void setMediacontentname(String mediacontentname) {
        this.mediacontentname = mediacontentname;
    }

    public String getCpobjectcode() {
        return cpobjectcode;
    }

    public void setCpobjectcode(String cpobjectcode) {
        this.cpobjectcode = cpobjectcode;
    }

    public String getMediatype() {
        return mediatype;
    }

    public void setMediatype(String mediatype) {
        this.mediatype = mediatype;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getVideotype() {
        return videotype;
    }

    public void setVideotype(String videotype) {
        this.videotype = videotype;
    }

    public String getAudiotype() {
        return audiotype;
    }

    public void setAudiotype(String audiotype) {
        this.audiotype = audiotype;
    }

    public String getStreamtype() {
        return streamtype;
    }

    public void setStreamtype(String streamtype) {
        this.streamtype = streamtype;
    }

    public String getSourcefilename() {
        return sourcefilename;
    }

    public void setSourcefilename(String sourcefilename) {
        this.sourcefilename = sourcefilename;
    }

    public String getDestfilename() {
        return destfilename;
    }

    public void setDestfilename(String destfilename) {
        this.destfilename = destfilename;
    }

    public String getOffcbr() {
        return offcbr;
    }

    public void setOffcbr(String offcbr) {
        this.offcbr = offcbr;
    }

    public String getSegmentcount() {
        return segmentcount;
    }

    public void setSegmentcount(String segmentcount) {
        this.segmentcount = segmentcount;
    }

    public String getDeleteflag() {
        return deleteflag;
    }

    public void setDeleteflag(String deleteflag) {
        this.deleteflag = deleteflag;
    }

    public String getFilesize() {
        return filesize;
    }

    public void setFilesize(String filesize) {
        this.filesize = filesize;
    }

    public String getPropagationpriority() {
        return propagationpriority;
    }

    public void setPropagationpriority(String propagationpriority) {
        this.propagationpriority = propagationpriority;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public String getSequence() {
        return sequence;
    }

    public void setSequence(String sequence) {
        this.sequence = sequence;
    }

    public String getOtherplayurl() {
        return otherplayurl;
    }

    public void setOtherplayurl(String otherplayurl) {
        this.otherplayurl = otherplayurl;
    }

    public String getUrltype() {
        return urltype;
    }

    public void setUrltype(String urltype) {
        this.urltype = urltype;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}