package com.smt.iptv.portal.i18nrepository.dish;

import com.smt.iptv.portal.i18nentity.dish.Dishfeatured;
import com.smt.iptv.portal.repository.BaseDao;

public interface DishfeaturedDao  extends BaseDao<Dishfeatured>{
    public Dishfeatured getByDishId(Long dishId);
}
