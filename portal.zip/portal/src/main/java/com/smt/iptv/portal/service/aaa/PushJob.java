package com.smt.iptv.portal.service.aaa;


import java.util.List;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.smt.iptv.portal.entity.Bulletin;
import com.smt.iptv.portal.push.PushMessage;
import com.smt.iptv.portal.push.PushServer;
import com.smt.iptv.portal.service.cmp.BulletinService;
import com.smt.iptv.portal.service.cmp.IptvprofileService;


@Component
public class PushJob implements Job{
	@Autowired
	private BulletinService bulletinService;
	@Autowired
	private IptvprofileService iptvprofileService;
	@Override
	public void execute(JobExecutionContext context)
			throws JobExecutionException {
		Bulletin scheduleJob = (Bulletin) context.getMergedJobDataMap().get("scheduleJob");
		//push message
		
		//全体
		if("5".equals(scheduleJob.getType())){
			PushServer.sendMsgToAll(new PushMessage("msg", scheduleJob.getContent()));
		}
		//房间
		else if("6".equals(scheduleJob.getType())){
			List<Long> iptvprofileid = bulletinService.getIptvprofileidByBulletinid(scheduleJob.getId());
			if(null!=iptvprofileid && iptvprofileid.size()>0) {
				for (Long id : iptvprofileid) {
					PushServer.sendMsg(iptvprofileService.findOne(id).getIptvusername(), new PushMessage("msg", scheduleJob.getContent()));
				}
			}
		}
		//分组
		else if("9".equals(scheduleJob.getType())){
			List<String> iptvprofileid = iptvprofileService.getProfileIdByGroup(scheduleJob.getEpggroupid());		
			pushMessage(scheduleJob, iptvprofileid);
		}
		
		//System.out.println("push data"+ scheduleJob.getContent());
		
	}
	
	private void pushMessage(Bulletin scheduleJob, List<String> iptvprofileid) {
		if(null!=iptvprofileid && iptvprofileid.size()>0) {
			for (String id : iptvprofileid) {
				PushServer.sendMsg(id, new PushMessage("msg", scheduleJob.getContent()));
			}
		}
	}

}
