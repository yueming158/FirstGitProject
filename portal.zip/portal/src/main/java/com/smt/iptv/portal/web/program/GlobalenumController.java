package com.smt.iptv.portal.web.program;

import java.util.Map;

import javax.servlet.ServletRequest;
import javax.validation.Valid;

import org.apache.shiro.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Maps;
import com.smt.iptv.portal.i18nentity.Globalenum;
import com.smt.iptv.portal.service.account.ShiroDbRealm.ShiroUser;
import com.smt.iptv.portal.service.cmp.GlobalenumService;

/**
 * Globalenum管理的Controller, 使用Restful风格的Urls:
 * 
 * List page     : GET /globalenum/
 * Create page   : GET /globalenum/create
 * Create action : POST /globalenum/create
 * Update page   : GET /globalenum/update/{id}
 * Update action : POST /globalenum/update
 * Delete action : GET /globalenum/delete/{id}
 * 
 * @author xjw
 */
@Controller
@RequestMapping(value = "/globalenum")
public class GlobalenumController {

	private static final int PAGE_SIZE = 50;

	private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
	static {
		sortTypes.put("auto", "自动");
		sortTypes.put("globalenumname", "名称");
	}

	@Autowired
	private GlobalenumService globalenumService;

	@RequestMapping(value = "/list")
	public String list(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
			@RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
		Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");

		Page<Globalenum> globalenums = globalenumService.getPage( searchParams, pageNumber, PAGE_SIZE, sortType);

		model.addAttribute("globalenums", globalenums);
		model.addAttribute("sortType", sortType);
		model.addAttribute("sortTypes", sortTypes);
		// 将搜索条件编码成字符串，用于排序，分页的URL
		model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
		return "globalenum/globalenumList";
	}

	@RequestMapping(value = "create", method = RequestMethod.GET)
	public String createForm(Model model) {
		model.addAttribute("globalenum", new Globalenum());
		model.addAttribute("action", "create");
		return "globalenum/globalenumForm";
	}

	@RequestMapping(value = "create", method = RequestMethod.POST)
	public String create(@Valid Globalenum newGlobalenum, RedirectAttributes redirectAttributes) {

		globalenumService.save(newGlobalenum);
		redirectAttributes.addFlashAttribute("message", "新增成功");
		return "redirect:/globalenum/list";
	}

	@RequestMapping(value = "update/{id}", method = RequestMethod.GET)
	public String updateForm(@PathVariable("id") Long id, Model model) {
		model.addAttribute("globalenum", globalenumService.findOne(id));
		model.addAttribute("action", "update");
		return "globalenum/globalenumForm";
	}

	@RequestMapping(value = "update", method = RequestMethod.POST)
	public String update(@Valid @ModelAttribute("preloadGlobalenum") Globalenum globalenum, RedirectAttributes redirectAttributes) {
		globalenumService.save(globalenum);
		redirectAttributes.addFlashAttribute("message", "保存成功");
		return "redirect:/globalenum/list";
	}

	@RequestMapping(value = "delete/{id}")
	public String delete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
		globalenumService.delete(id);
		redirectAttributes.addFlashAttribute("message", "删除成功");
		return "redirect:/globalenum/list";
	}

	/**
	 * 使用@ModelAttribute, 实现Struts2 Preparable二次部分绑定的效果,先根据form的id从数据库查出Globalenum对象,再把Form提交的内容绑定到该对象上。
	 * 因为仅update()方法的form中有id属性，因此本方法在该方法中执行.
	 */
	@ModelAttribute("preloadGlobalenum")
	public Globalenum getGlobalenum(@RequestParam(value = "id", required = false) Long id) {
		if (id != null) {
			return globalenumService.findOne(id);
		}
		return null;
	}

	/**
	 * 取出Shiro中的当前用户Id.
	 */
	private Long getCurrentUserId() {
		ShiroUser user = (ShiroUser) SecurityUtils.getSubject().getPrincipal();
		return user.id;
	}
}
