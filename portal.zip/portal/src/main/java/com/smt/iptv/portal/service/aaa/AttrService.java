package com.smt.iptv.portal.service.aaa;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.entity.aaa.Attr;
import com.smt.iptv.portal.repository.aaa.AttrDao;
import com.smt.iptv.portal.service.cmp.BaseService;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class AttrService extends BaseService<AttrDao, Attr> {
    public List<Attr> getByUsetype(String type){
        return dao.getByUsetype(type);
    }
}
