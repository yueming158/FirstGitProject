package com.smt.iptv.portal.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.format.annotation.DateTimeFormat;

import com.smt.iptv.portal.core.IdEntity;
@Entity
@Table(name = "personmessage")
public class Personmessage extends IdEntity {
    
    public Personmessage() {
    }

    public Personmessage(Long id) {
        this.id = id;
    }
    
    private String status;//0 未发布 1 发布
    private String important;
	private String content;
	private String iptvusername;
	private String roomname;
    private Date creatdate;
    
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getImportant() {
        return important;
    }

    public void setImportant(String important) {
        this.important = important;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    
    public String getIptvusername() {
        return iptvusername;
    }

    public void setIptvusername(String iptvusername) {
        this.iptvusername = iptvusername;
    }

    
    public Date getCreatdate() {
        return creatdate;
    }

    public void setCreatdate(Date createdate) {
        this.creatdate = createdate;
    }

    public String getRoomname() {
        return roomname;
    }

    public void setRoomname(String roomname) {
        this.roomname = roomname;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}