package com.smt.iptv.portal.i18nentity.goods;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.smt.iptv.portal.core.IdEntity;
import com.smt.iptv.portal.i18nentity.Category;
@Entity
@Table(name = "categorygoods")
public class Categorygoods extends IdEntity {
    
    public Categorygoods() {
    }

    public Categorygoods(Long id) {
        this.id = id;
    }
    
	private Category category;
	private Goods goods;
	private Integer sequence;
	@ManyToOne
	@JoinColumn(name="categoryid")
    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }
    @ManyToOne
    @JoinColumn(name="goodsid")
    public Goods getGoods() {
        return goods;
    }

    public void setGoods(Goods goods) {
        this.goods = goods;
    }

    public Integer getSequence() {
        return sequence;
    }

    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

}