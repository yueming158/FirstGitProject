package com.smt.iptv.portal.repository.role;

import java.util.List;

import com.smt.iptv.portal.entity.role.Resource;
import com.smt.iptv.portal.repository.BaseDao;

public interface ResourceDao extends BaseDao<Resource> {
    List<Resource> getByEnabled(String enabled);
}