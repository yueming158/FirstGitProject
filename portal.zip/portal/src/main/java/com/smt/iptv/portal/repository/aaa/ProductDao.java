package com.smt.iptv.portal.repository.aaa;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;

import com.smt.iptv.portal.entity.aaa.Product;
import com.smt.iptv.portal.repository.BaseDao;

public interface ProductDao extends BaseDao<Product> {
    @Query("select p from Product p where p.productname like ?1 and p.resourcetype=?2 and p.id not in(?3) and p.status='1'")
	public Page<Product> getNotLinkedProduct(String productname, Integer resourcetype,List<Long> list, Pageable pageable);
    @Query("select p from Product p where p.productname like ?1 and p.id not in(?2) and p.status='1'")
	public Page<Product> getNotLinkedProduct(String productname,List<Long> list,Pageable pageable);
}
