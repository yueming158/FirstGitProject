package com.smt.iptv.portal.web.aaa;


import java.util.List;
import java.util.Map;

import javax.servlet.ServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Maps;
import com.smt.iptv.portal.core.SystemResource;
import com.smt.iptv.portal.entity.aaa.Attr;
import com.smt.iptv.portal.entity.aaa.Orderusage;
import com.smt.iptv.portal.entity.aaa.Productoffer;
import com.smt.iptv.portal.entity.hotel.Hotelroom;
import com.smt.iptv.portal.push.PushServer;
import com.smt.iptv.portal.service.aaa.AccountService;
import com.smt.iptv.portal.service.aaa.AttrService;
import com.smt.iptv.portal.service.aaa.OrderProductofferService;
import com.smt.iptv.portal.service.aaa.OrderusageService;
import com.smt.iptv.portal.service.aaa.ProductofferService;
import com.smt.iptv.portal.service.cmp.ChannelgroupService;
import com.smt.iptv.portal.service.cmp.EpggroupService;
import com.smt.iptv.portal.service.hotel.HotelroomService;

/**
 * @author xjw
 */
@Controller
@RequestMapping(value = "/orderproductoffer")
public class OrderProductofferController {

    private static final int PAGE_SIZE = 20;
    @Autowired
	private ProductofferService productofferService;
    @Autowired
    private OrderProductofferService orderProductofferService;
    @Autowired
    private OrderusageService orderUsageService;
    @Autowired
    private AccountService accountService;
    private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
    static {
        sortTypes.put("auto", "自动");
    }


    @Autowired
    private HotelroomService hotelroomService;
    @Autowired
    private ChannelgroupService channelgroupService;
    @Autowired
    private EpggroupService epggroupService;
    @Autowired
    private AttrService attrService;
    @RequestMapping(value = "/list")
    public String list(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");

        Page<Hotelroom> hotelrooms = hotelroomService.getPage(searchParams, pageNumber, PAGE_SIZE, sortType);
        if (hotelrooms != null) {
            List<String> usernames = PushServer.getLonginUsers();
            for (Hotelroom hotelroom : hotelrooms.getContent()) {
                for (String username : usernames) {
                    if (hotelroom.getIptvprofile().getIptvusername().equals(username)) {
                        hotelroom.getIptvprofile().setLoginstatus("O");
                        break;
                    }
                }
            }
        }
        model.addAttribute("hotelrooms", hotelrooms);
        model.addAttribute("epggroups", epggroupService.getAll());//group
        model.addAttribute("sortType", sortType);
        model.addAttribute("sortTypes", sortTypes);
        // 将搜索条件编码成字符串，用于排序，分页的URL
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
        model.addAttribute("hotspot", SystemResource.getString("hotspot"));
        model.addAttribute("vodfree", SystemResource.getString("vodfree"));
        model.addAttribute("onlylive", SystemResource.getString("onlylive"));
        return "orderproductoffer/orderproductofferList";
    }


    @RequestMapping(value = "update/{id}", method = RequestMethod.GET)
    public String updateForm(@PathVariable("id") Long id, Model model) {
        Hotelroom hotelroom = hotelroomService.findOne(id);
        List<Attr> oldattrs=hotelroom.getIptvprofile().getAttrList();
        List<Attr> newattrs=attrService.getByUsetype(Attr.TYPE_USER);
        if(oldattrs!=null&&newattrs!=null){
            for(Attr attr: newattrs){
                for(int i=0;i<oldattrs.size();i++){
                    Attr old =oldattrs.get(i);
                    if(attr.getAttrkey()!=null&&attr.getAttrkey().equals(old.getAttrkey())){
                        attr.setValue(old.getValue());
                        oldattrs.remove(i);
                        break;
                    }
                }
            }
        }
        hotelroom.getIptvprofile().setAttrList(newattrs);
        model.addAttribute("hotelroom", hotelroom);
        model.addAttribute("channelgroups", channelgroupService.getAll());
        model.addAttribute("epggroups", epggroupService.getAll());//group
        model.addAttribute("action", "update");
        model.addAttribute("hotspot", SystemResource.getString("hotspot"));
        model.addAttribute("vodfree", SystemResource.getString("vodfree"));
        model.addAttribute("onlylive", SystemResource.getString("onlylive"));
        return "orderproductoffer/orderproductofferForm";
    }
    
    @RequestMapping(value = "/orderForm")
    public String orderForm(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request,
            Long accountId){
    	//查询已订购的一次性服务
    	List<Long> orderedPrdouctofferIds = orderUsageService.getOrderusageByType(accountId,"2");
    	//查询
    	
    	
		Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");
		
		
		Page<Productoffer> productoffers = productofferService.getProductoffers(searchParams, pageNumber, 10, sortType,orderedPrdouctofferIds);
		
		//Page<Productoffer> productoffers = productofferService.getPageDesc( searchParams, pageNumber, 10, sortType);

		model.addAttribute("productoffers", productoffers);
		model.addAttribute("sortType", sortType);
		model.addAttribute("sortTypes", sortTypes);
		// 将搜索条件编码成字符串，用于排序，分页的URL
		model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
		model.addAttribute("accountId", accountId);
		int balance = accountService.findOne(accountId).getBalance();
		model.addAttribute("balance", balance);
		
		model.addAttribute("orderusages", orderUsageService.getOrderusageByAccountId(accountId));
    	return "orderproductoffer/productofferOrderForm";
    }
    
    
    @RequestMapping(value = "/order")
    public String order(Model model, ServletRequest request,Long accountId,int balance, RedirectAttributes redirectAttributes){
    	String result = null;
    	try {
    		result = orderProductofferService.order(accountId,balance,request.getParameterValues("productofferid"));
		} catch (Exception e) {
			result = "订购失败";
		}
    	redirectAttributes.addFlashAttribute("message", result);
		return "redirect:/orderproductoffer/orderForm?accountId="+accountId+"&search_EQ_productoffertype=1";
    }
    
    @RequestMapping(value="/moreorderusage")
    public String moreOrderusage(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request){
    	Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");
    	Long accountId = Long.valueOf((String)searchParams.get("EQ_accountid"));
    	String productoffername= (String)searchParams.get("LIKE_productoffername");
		Page<Orderusage> orderUsages = orderUsageService.getOrderusages(accountId,productoffername,pageNumber-1, 20);
		model.addAttribute("orderUsages", orderUsages);
		model.addAttribute("sortType", sortType);
		model.addAttribute("sortTypes", sortTypes);
		// 将搜索条件编码成字符串，用于排序，分页的URL
		model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
    	return "orderproductoffer/moreorderusageList";
    }
    
    @RequestMapping(value="/orderusagerecord")
    public String  orderusagerecord(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request){
    	Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");
		Page<Orderusage> orderUsages = orderUsageService.getPageDesc(searchParams, pageNumber, 20, sortType);
		model.addAttribute("orderUsages", orderUsages);
		model.addAttribute("sortType", sortType);
		model.addAttribute("sortTypes", sortTypes);
		// 将搜索条件编码成字符串，用于排序，分页的URL
		model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
    	return "orderproductoffer/orderusagerecordList";
    }
    
    
    
    @RequestMapping(value="/deleteorderusage")
    public String deleteOrderusage(Long orderusageId,Long accountId,RedirectAttributes redirectAttributes){
    	String message = null;
    	try {
			message = orderProductofferService.deleteOderusage(orderusageId,
					accountId);
		} catch (Exception e) {
			message = "退订失败！";
		}
    	redirectAttributes.addFlashAttribute("message", message);
		return "redirect:/orderproductoffer/moreorderusage?search_EQ_accountid="+accountId+"&search_EQ_paystatus=2";
    }
    
    
    @RequestMapping(value="/accountrechargeForm")
    public String accountrechargeForm(Model model,Long accountId){
    	model.addAttribute("accountId", accountId);
    	return "orderproductoffer/accountrechargeForm";
    }
    
    @RequestMapping(value="/accountrecharge")
    @ResponseBody
    public String accountrecharge(Long accountId,int balance,RedirectAttributes redirectAttributes){
    	String message = null;
    	try {
			message = orderProductofferService.accountrecharge(accountId,balance);
		} catch (Exception e) {
			message = "error";
		}
		return message;
    }
    
    @RequestMapping(value="/accountrefundForm")
    public String accountrefundForm(Model model,Long accountId){
    	model.addAttribute("account", accountService.findOne(accountId));
    	return "orderproductoffer/accountrefundForm";
    }
    
    @RequestMapping(value="/accountrefund")
    @ResponseBody
    public String accountrefund(Long accountId,int balance,RedirectAttributes redirectAttributes){
    	String message = null;
    	try {
			message = orderProductofferService.accountrefund(accountId,balance);
		} catch (Exception e) {
			message = "error";
		}
		return message;
    }
    
    
    
}
