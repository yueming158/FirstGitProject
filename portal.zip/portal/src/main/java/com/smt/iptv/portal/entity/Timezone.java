package com.smt.iptv.portal.entity;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.portal.core.IdEntity;
@Entity
@Table(name = "timezone")
public class Timezone extends IdEntity {
    
    public Timezone() {
    }

    public Timezone(Long id) {
        this.id = id;
    }
    
	private String cityname;
	private String timezone;
	private String viewflag;

    public String getCityname() {
        return cityname;
    }

    public void setCityname(String cityname) {
        this.cityname = cityname;
    }

    public String getTimezone() {
        return timezone;
    }

    public void setTimezone(String timezone) {
        this.timezone = timezone;
    }

    public String getViewflag() {
        return viewflag;
    }

    public void setViewflag(String viewflag) {
        this.viewflag = viewflag;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}