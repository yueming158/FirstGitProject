package com.smt.iptv.portal.i18nentity;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.portal.core.IdEntity;
@Entity
@Table(name = "epggroup")
public class Epggroup extends IdEntity {
    
    public Epggroup() {
    }

    public Epggroup(Long id) {
        this.id = id;
    }
    
	private String epggroupname;


    public String getEpggroupname() {
        return epggroupname;
    }

    public void setEpggroupname(String epggroupname) {
        this.epggroupname = epggroupname;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}