package com.smt.iptv.portal.repository.license;

import com.smt.iptv.portal.entity.license.License;
import com.smt.iptv.portal.repository.BaseDao;


public interface LicenseDao extends BaseDao<License>{
    License findByLicensecode(String licensecode);
}
