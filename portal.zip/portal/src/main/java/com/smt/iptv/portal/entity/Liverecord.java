package com.smt.iptv.portal.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.format.annotation.DateTimeFormat;

import com.smt.iptv.portal.core.IdEntity;
@Entity
@Table(name = "liverecord")
public class Liverecord extends IdEntity {
    
    public Liverecord() {
    }

    public Liverecord(Long id) {
        this.id = id;
    }

    private String chancode;
	private String schedulename;
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date starttime;
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date endtime;
    private String status;

    public String getChancode() {
        return chancode;
    }

    public void setChancode(String chancode) {
        this.chancode = chancode;
    }

    public String getSchedulename() {
        return schedulename;
    }

    public void setSchedulename(String schedulename) {
        this.schedulename = schedulename;
    }

    public Date getStarttime() {
        return starttime;
    }

    public void setStarttime(Date starttime) {
        this.starttime = starttime;
    }

    public Date getEndtime() {
        return endtime;
    }

    public void setEndtime(Date endtime) {
        this.endtime = endtime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}