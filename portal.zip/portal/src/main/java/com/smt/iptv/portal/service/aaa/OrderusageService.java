package com.smt.iptv.portal.service.aaa;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.entity.aaa.Orderusage;
import com.smt.iptv.portal.repository.aaa.OrderusageDao;
import com.smt.iptv.portal.service.cmp.BaseService;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class OrderusageService extends BaseService<OrderusageDao, Orderusage> {
	public Page<Orderusage> getOrderusageByAccountId(Long accountId) {
		PageRequest page = new PageRequest(0, 12,new Sort(Direction.DESC, "orderstarttime"));
		return dao.getOrderusageByAccountId(accountId,new Date(),page);
	}
	
	public Page<Orderusage> getOrderusages(Long accountId,String productoffername,int currentPage,int pageSize) {
		PageRequest page = new PageRequest(currentPage, pageSize,new Sort(Direction.DESC, "orderstarttime"));
		if(null == productoffername) {
			productoffername = "";
		}
		productoffername ="%"+productoffername+"%";
		return dao.getOrderusages(accountId,new Date(),productoffername,page);
	}
	
	public List<Long> getOrderusageByType(Long accountId, String type) {
		return dao.getOrderusageByType(accountId, type);
	}
	
	public Date getLastOrderusage(Long accountId,Long productoffeId) {
		return dao.getLastOrderusage(accountId,productoffeId);
	}

}
