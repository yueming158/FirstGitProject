package com.smt.iptv.portal.service.dish;

import java.math.BigInteger;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.entity.Dishorder;
import com.smt.iptv.portal.entity.Dishordermap;
import com.smt.iptv.portal.model.SystemConstant;
import com.smt.iptv.portal.repository.DishorderDao;
import com.smt.iptv.portal.service.cmp.BaseService;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class DishorderService extends BaseService<DishorderDao, Dishorder> {
    public List<Dishordermap> getDishListByOrder(Long orderid){
        return dao.getDishListByOrder(orderid);
    }
    
    @Transactional(readOnly = false)
    public Dishorder verify(Long id,String name) {
        Dishorder dishorder = dao.findOne(id);
        if (dishorder != null) {
            dishorder.setStatus("2");
            dishorder.setVerifytime(new Date());
            dishorder.setVerifypeople(name);
            return dao.save(dishorder);
        } else {
            return null;
        }
    }
    @Transactional(readOnly = false)
    public Dishorder complete(Long id ) {
        Dishorder dishorder = dao.findOne(id);
        if (dishorder != null) {
            dishorder.setStatus("4");
            dishorder.setCompletetime(new Date());
            return dao.save(dishorder);
        } else {
            return null;
        }
    }
    @Transactional(readOnly = false)
    public Dishorder cancel(Long id ) {
        Dishorder dishorder = dao.findOne(id);
        if (dishorder != null) {
            dishorder.setStatus("5");
            dishorder.setCompletetime(new Date());
            return dao.save(dishorder);
        } else {
            return null;
        }
    }
    public int getNewOrderCount(){
        BigInteger count =dao.getNewOrderCount();
//        if(!count.toString().equals(SystemConstant.getValue("ordercount"))){
//            SystemConstant.map.put("ordercount", count.toString());
//        }
        return count.intValue();
    }
}
