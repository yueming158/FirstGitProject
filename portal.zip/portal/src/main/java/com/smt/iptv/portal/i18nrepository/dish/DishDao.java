package com.smt.iptv.portal.i18nrepository.dish;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.smt.iptv.portal.i18nentity.dish.Dish;
import com.smt.iptv.portal.repository.BaseDao;

public interface DishDao extends BaseDao<Dish> {
    @Query(nativeQuery=true,value="delete from dishcart where dishid=?1")
    @Modifying
    void deleteCartWithDishId(Long dishId);
    
    @Query("delete from Dishfeatured where dish.id=?1")
    @Modifying
    void deleteFeatured(Long dishId);
}
