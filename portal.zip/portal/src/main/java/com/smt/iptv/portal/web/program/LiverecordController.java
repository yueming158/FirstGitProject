package com.smt.iptv.portal.web.program;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.smt.iptv.portal.core.Result;
import com.smt.iptv.portal.entity.Channel;
import com.smt.iptv.portal.entity.Liverecord;
import com.smt.iptv.portal.service.cmp.ChannelService;
import com.smt.iptv.portal.service.cmp.LiverecordService;

/**
 * @author xjw
 */
@Controller
@RequestMapping(value = "/liverecord")
public class LiverecordController {

	private static final int PAGE_SIZE = 500;

	private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
	static {
		sortTypes.put("starttime", "时间");
	}

	@Autowired
	private LiverecordService liverecordService;
    @Autowired
    private ChannelService channelService;

    @RequestMapping(value = "/list")
    public String list(@RequestParam(value = "sortType", defaultValue = "starttime") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber,Long channelid, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");
        Channel channel = channelService.findOne(channelid);
        searchParams.put("EQ_chancode", channel.getCpobjectcode()) ;
        Page<Liverecord> liverecords = liverecordService.getPage( searchParams, pageNumber, PAGE_SIZE, sortType);
        model.addAttribute("liverecords", liverecords);
        model.addAttribute("channel", channel);
        model.addAttribute("sortType", sortType);
        model.addAttribute("sortTypes", sortTypes);
        // 将搜索条件编码成字符串，用于排序，分页的URL
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_")+"&channelid="+channelid);
        return "liverecord/liverecordList";
    }
    @RequestMapping(value = "/ajaxlist")
    public String ajaxlist(@RequestParam(value = "sortType", defaultValue = "starttime") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber,Long channelid, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");
        Channel channel = channelService.findOne(channelid);
        searchParams.put("EQ_chancode", channel.getCpobjectcode()) ;
        Page<Liverecord> liverecords = liverecordService.getPage( searchParams, pageNumber, PAGE_SIZE, sortType);
        model.addAttribute("liverecords", liverecords);
        model.addAttribute("channel", channel);
        model.addAttribute("sortType", sortType);
        model.addAttribute("sortTypes", sortTypes);
        // 将搜索条件编码成字符串，用于排序，分页的URL
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_")+"&channelid="+channelid);
        return "liverecord/ajaxList";
    }

    @RequestMapping(value = "create", method = RequestMethod.POST)
    @ResponseBody
    public Result create(Liverecord liverecord,Long channelid) {
        Channel c =channelService.findOne(channelid);
        if(c!=null){
            liverecord.setStatus("1");
            liverecord.setChancode(c.getCpobjectcode());
            //不过期
            if(liverecord.getStarttime().getTime()<=System.currentTimeMillis()){
                return new Result(false,"录制开始时间必须大于现在时间");
            }
            //不逆期
            if(liverecord.getStarttime().getTime()>=liverecord.getEndtime().getTime()){
                return new Result(false,"录制结束时间必须大于录制开始时间");
            }
            //不交叉
            String chancode=liverecord.getChancode();
            Date starttime =liverecord.getStarttime();
            Date endtime =liverecord.getEndtime();
            if(liverecordService.getInnerCrossTimeRecor(chancode, starttime, endtime)>0
                    ||liverecordService.getOuterCrossTimeRecord(chancode, starttime)>0){
                return new Result(false,"录制节目编排时间不能交叉");
            }
            
        }else{
            return new Result(false,"直播频道不存在");
        }
        liverecordService.save(liverecord);
        return new Result(true,"添加成功");
    }
    
	@RequestMapping(value = "update", method = RequestMethod.POST)
	@ResponseBody
	public Result update(@ModelAttribute("preloadLiverecord") Liverecord liverecord) {
        //不过期
        if(liverecord.getStarttime().getTime()<=System.currentTimeMillis()){
            return new Result(false,"录制开始时间必须大于现在时间");
        }
        //不逆期
        if(liverecord.getStarttime().getTime()>=liverecord.getEndtime().getTime()){
            return new Result(false,"录制结束时间必须大于录制开始时间");
        }
        //不交叉
        String chancode=liverecord.getChancode();
        Date starttime =liverecord.getStarttime();
        Date endtime =liverecord.getEndtime();
        if(liverecordService.getInnerCrossTimeRecor(liverecord.getId(),chancode, starttime, endtime)>0
                ||liverecordService.getOuterCrossTimeRecord(liverecord.getId(),chancode, starttime)>0){
            return new Result(false,"录制节目编排时间不能交叉");
        }
	    //状态必须为未录制
        if(!"1".equals(liverecord.getStatus())){
            return new Result(false,"节目已经开始录制,不能再更改");
        }
		liverecordService.save(liverecord);
		return new Result(true,"添加成功");
	}
	
    @RequestMapping(value = "delete/{id}")
    @ResponseBody
    public Result delete(@PathVariable("id") Long id) {
        try{
        liverecordService.delete(id);
        }catch (Exception e) {
            return new Result(true,"删除异常");
        }
        return new Result(true,"删除成功");
    }
    
	/**
	 * 使用@ModelAttribute, 实现Struts2 Preparable二次部分绑定的效果,先根据form的id从数据库查出Liverecord对象,再把Form提交的内容绑定到该对象上。
	 * 因为仅update()方法的form中有id属性，因此本方法在该方法中执行.
	 */
	@ModelAttribute("preloadLiverecord")
	public Liverecord getLiverecord(@RequestParam(value = "id", required = false) Long id) {
		if (id != null) {
			return liverecordService.findOne(id);
		}
		return null;
	}
	

    
}
