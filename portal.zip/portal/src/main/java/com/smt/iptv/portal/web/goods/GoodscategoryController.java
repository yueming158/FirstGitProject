package com.smt.iptv.portal.web.goods;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Maps;
import com.smt.iptv.portal.i18nentity.Category;
import com.smt.iptv.portal.i18nentity.goods.Categorygoods;
import com.smt.iptv.portal.i18nentity.goods.Goods;
import com.smt.iptv.portal.service.cmp.CategoryService;
import com.smt.iptv.portal.service.goods.CategorygoodsService;
import com.smt.iptv.portal.service.info.MenuService;

/**
 * Category管理的Controller, 使用Restful风格的Urls:
 * 
 * List page : GET /category/ Create page : GET /category/create Create action :
 * POST /category/create Update page : GET /category/update/{id} Update action :
 * POST /category/update Delete action : GET /category/delete/{id}
 * 
 * @author xjw
 */
@Controller
@RequestMapping(value = "/goodscategory")
public class GoodscategoryController {

    private static final int PAGE_SIZE = 50;
    private final static String GOODS_TEMP_CODE ="lvb_x_hotel_a_11";
    private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
    static {
        sortTypes.put("sequence", "显示顺序");
    }
    
    @Autowired
    private MenuService menuService;
    @Autowired
    private CategoryService categoryService;
    @Autowired
    private CategorygoodsService categorygoodsService;


    @RequestMapping(value = "/list")
    public String list(@RequestParam(value = "sortType", defaultValue = "sequence") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");
        searchParams.put("EQ_categorytype", "51");
        Page<Category> categorys = categoryService.getPage(searchParams, pageNumber, PAGE_SIZE, sortType);
        model.addAttribute("categorys", categorys);
        model.addAttribute("menus", menuService.getByInfotemplateCode(GOODS_TEMP_CODE));
        model.addAttribute("sortType", sortType);
        model.addAttribute("sortTypes", sortTypes);
        // 将搜索条件编码成字符串，用于排序，分页的URL
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
        return "goods/categoryList";
    }

    @RequestMapping(value = "create", method = RequestMethod.GET)
    public String createForm(Model model){
        model.addAttribute("menus", menuService.getByInfotemplateCode(GOODS_TEMP_CODE));
        model.addAttribute("action", "create");
        return "goods/categoryForm";
    }

    @RequestMapping(value = "create", method = RequestMethod.POST)
    public String create(@Valid Category newCategory, RedirectAttributes redirectAttributes) {
        newCategory.setCategorytype("51");
        newCategory.setParentid(0L);
        categoryService.save(newCategory);
        categoryService.create(newCategory, "cpobjectcode", "cate0000000000");
        redirectAttributes.addFlashAttribute("message", "新增成功");
        return "redirect:/goodscategory/list";
    }

    @RequestMapping(value = "update/{id}", method = RequestMethod.GET)
    public String updateForm(@PathVariable("id") Long id, Model model,
            @RequestParam(value = "parentname",defaultValue = "根目录",required=false) String parentname) {
        model.addAttribute("menus", menuService.getByInfotemplateCode(GOODS_TEMP_CODE));
        model.addAttribute("parentname", parentname);
        model.addAttribute("category", categoryService.findOne(id));
        model.addAttribute("action", "update");
        return "goods/categoryForm";
    }

    @RequestMapping(value = "update", method = RequestMethod.POST)
    public String update(@Valid @ModelAttribute("preloadCategory") Category category,
            RedirectAttributes redirectAttributes) {
        categoryService.save(category);
        redirectAttributes.addFlashAttribute("message", "保存成功");
        return "redirect:/goodscategory/list";
    }

    @RequestMapping(value = "delete/{id}")
    public String delete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes,
            @RequestParam(value = "categorytype", defaultValue = "51",required =false) String categorytype) {
        boolean sucess = categoryService.deleteSingleCategory(id,categorytype);//删除 单独的记录，如果有关联记录则删除不成功
        if(sucess){
            redirectAttributes.addFlashAttribute("message", "删除成功");
        }else{
            redirectAttributes.addFlashAttribute("message", "该分类下包含内容，无法删除");
        }
        return "redirect:/goodscategory/list";
    }

    @ModelAttribute("preloadCategory")
    public Category getCategory(@RequestParam(value = "id", required = false) Long id) {
        if (id != null) {
            return categoryService.findOne(id);
        }
        return null;
    }
    
    //内容编辑

    @RequestMapping(value = "/contentlist")
    public String contentlist(Long categoryid,
            @RequestParam(value = "sortType", defaultValue = "auto") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");
        searchParams.put("EQ_category.id", categoryid.toString());

        Page<Categorygoods> categorycontents = categorygoodsService.getPage(searchParams, pageNumber, 20, sortType);
        model.addAttribute("categorycontents", categorycontents);
        model.addAttribute("categoryid", categoryid.toString());
        
        model.addAttribute("sortType", sortType);
        model.addAttribute("sortTypes", sortTypes);
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_")+"&categoryid="+categoryid);// 将搜索条件编码成字符串，用于排序，分页的URL
        return "goods/categorygoodsList";
    }

    @RequestMapping(value = "/select")
    public String select(Long categoryid,
            @RequestParam(value = "sortType", defaultValue = "auto") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");
        model.addAttribute("categoryid", categoryid + "");
        model.addAttribute("sortType", sortType);
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
        Map<String, String> sortTypes2 = Maps.newLinkedHashMap();
        sortTypes2.put("auto", "自动");
        Page exceptcontents = null;
        String returnUrl = "";
        
        exceptcontents = categorygoodsService.getGoodsExceptCategory(categoryid, pageNumber, 100,
                sortType);
       
        model.addAttribute("exceptcontents", exceptcontents);
        model.addAttribute("sortTypes", sortTypes);
        return "goods/categorygoodsselect";
    }

    @RequestMapping(value = "/selectadd")
    public String selectadd( Long categoryid,
            @RequestParam(value = "contentids", defaultValue = "") String contentids,
            RedirectAttributes redirectAttributes) {
        String[] idsArr = contentids.split(",");
            List<Categorygoods> list = new ArrayList<Categorygoods>();
            for (String s : idsArr) {
                if (s.matches("\\d+")) {
                    Categorygoods cg = new Categorygoods();
                    cg.setCategory(new Category(categoryid));
                    cg.setGoods(new Goods(Long.parseLong(s)));
                    list.add(cg);
                }
            }
            categorygoodsService.save(list);
        redirectAttributes.addFlashAttribute("message", "关联成功");
        return "redirect:/goodscategory/contentlist?categoryid=" + categoryid;
    }

    @RequestMapping(value = "/deletecontent")
    public String deletecontent( Long categoryid,  Long contentid,
            RedirectAttributes redirectAttributes) {
            categorygoodsService.delete(contentid);
        return "redirect:/goodscategory/contentlist?categoryid="  + categoryid;
    }
    
    @RequestMapping(value = "/deletecontents")
    public String deletecontents( Long categoryid,  Long [] ids,
            RedirectAttributes redirectAttributes) {
            categorygoodsService.deleteAll(ids);
        return "redirect:/goodscategory/contentlist?categoryid="  + categoryid;
    }
}
