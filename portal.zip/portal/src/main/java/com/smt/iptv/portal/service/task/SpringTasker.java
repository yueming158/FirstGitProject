package com.smt.iptv.portal.service.task;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springside.modules.mapper.JsonMapper;

import com.google.common.collect.Lists;
import com.smt.iptv.portal.core.HttpJDKUtil;
import com.smt.iptv.portal.entity.Channel;
import com.smt.iptv.portal.entity.Schedule;
import com.smt.iptv.portal.i18nentity.City;
import com.smt.iptv.portal.model.SystemConstant;
import com.smt.iptv.portal.service.cmp.AirlinetimeService;
import com.smt.iptv.portal.service.cmp.ChannelService;
import com.smt.iptv.portal.service.cmp.CityService;
import com.smt.iptv.portal.service.cmp.RateService;
import com.smt.iptv.portal.service.cmp.ScheduleService;
import com.smt.iptv.portal.service.hotel.WeatherService;

@Component
public class SpringTasker {

    private static Logger logger = LoggerFactory.getLogger(SpringTasker.class);

    @Autowired
    private RateService rateService;
    //@Autowired
    //private AirlinetimeService airlinetimeService;
    @Autowired
    private WeatherService weatherService;
    @Autowired
    private CityService cityService;
    @Autowired
    private ScheduleService scheduleService;
    @Autowired
    private ChannelService channelService;
    
    public void executeNetDateJob() {
        // 刷新汇率
        rateService.refreshRateData();
        // 刷新各城市天气
        List<City> list = cityService.getAll();
        for (City city : list) {
            weatherService.refreshWeatherData2(city.getCityweathercode());
        }
        // 刷新航班
         //airlinetimeService.refreshAirLinetimeData("","","");
    }

    public void executeScheduleTaskFromTvsou(){
        //删除一周前的节目单
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        c.add(Calendar.DAY_OF_MONTH, -6);
        scheduleService.deleteold(c.getTime());
        // 每周一执行一次
        List<Channel> channnels = channelService.getAll();
        // 循环 每个频道 如该频道有节目单地址
        for (Channel channel : channnels) {
            if (StringUtils.isNotEmpty(channel.getTvmaourl())&&channel.getTvmaourl().split(",").length==4) {
                // 网络抓取第二天和第6天的数据
                List<Schedule> scheduleList = getNetWorkSchedule(channel.getId(), channel.getTvmaourl());
                if (scheduleList.size() > 0) {
                    //删除第二天和第6天的数据
                    //保存新的第二天和第6天的数据
                    scheduleService.refresh(channel.getId(), scheduleList);
                }
            }
        }
    }
    
    //网络抓取8天的数据 第二天和第6天
    private List<Schedule> getNetWorkSchedule(Long channelid, String ids) {
        String [] idArr =ids.split(",");
        String tid= idArr[0];
        String pro= idArr[1];
        String tvid= idArr[2];
        String tvsouid = idArr[3];
        List<Schedule> scheduleList = Lists.newArrayList();
        SimpleDateFormat daysdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar c = Calendar.getInstance();
        //当天
        String day = daysdf.format(c.getTime());
        String weekurl = "http://m.tvsou.com/epg.asp?tid="+tid+"&pro="+pro+"&TVid="+tvid+"&Channelid="+tvsouid +"&programDT="+day;
        parseSchedule(channelid, scheduleList, day, weekurl);
        //第六天
        c.add(Calendar.DAY_OF_MONTH, 5);
        String day2 = daysdf.format(c.getTime());
        String weekurl2 = "http://m.tvsou.com/epg.asp?tid="+tid+"&pro="+pro+"&TVid="+tvid+"&Channelid="+tvsouid +"&programDT="+day2;
        parseSchedule(channelid, scheduleList, day2, weekurl2);
        return scheduleList;
    }
    //解析网页转化为schedule数据结构
    private void parseSchedule(Long channelid, List<Schedule> scheduleList,  String day, String weekurl) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-ddHH:mm");
//        weekurl="http://m.tvsou.com/epg.asp?tid=2&pro=ys&TVid=1&Channelid=1";
//        weekurl="http://m.tvsou.com/epg.asp?tid=2&pro=ys&TVid=1&ChannelID=1&programDT=2015-3-24";
        String schedule = HttpJDKUtil.executeHttpGet(weekurl, "gbk");
        if (schedule != null && schedule.indexOf("class=\"time\"") != -1) {
            schedule = schedule.substring(schedule.indexOf("class=\"time\""), schedule.lastIndexOf("</ul>"));
            String[] rows = schedule.split("</li>");
            for (String row : rows) {
                String time = StringUtils.substringBetween(row, "y'>", "<span>");
                String name ="";
                if(time==null){
                    continue;
                }
                if(row.indexOf("</a>")==-1){
                    name=StringUtils.substringBetween(row, "<span>", "</span>");
                }else{
                    String name1= StringUtils.substringBetween(row, "<span>", "<a");
                    if(StringUtils.isNotBlank(name1)){
                        name=name1;
                    }else{
                        String name2=StringUtils.substringBetween(row, "k'>", "</a>");
                        if(StringUtils.isNotBlank(name2)){
                            name=name2;
                        }
                    }
                }if(name.contains("null")){
                    System.out.println(row);
                }
                try {
                    scheduleList.add(new Schedule(channelid, sdf.parse(day + time), name));
                } catch (ParseException e) {
                    logger.error("时间格式不正确:" + day + time);
                }
            }
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        } else {
            logger.error("fail:" + weekurl);
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    public static void main(String[] args) {
        SpringTasker  s= new SpringTasker();
        s.getNetWorkSchedule(11L,"http://m.tvsou.com/epg.asp?tid=2&pro=ys&TVid=1&Channelid=1");
    }
    
    public void  executeScheduleTask(){
        //删除一周前的节目单
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        c.add(Calendar.DAY_OF_MONTH, -6);
        scheduleService.deleteold(c.getTime());
        // 每周一执行一次
        List<Channel> channnels = channelService.getAll();
        // 循环 每个频道 如该频道有节目单地址
        for (Channel channel : channnels) {
            if (StringUtils.isNotEmpty(channel.getTvmaourl())&&channel.getTvmaourl().split(",").length==4) {
                // 网络抓取第二天和第6天的数据
                List<Schedule> scheduleList = getNetWorkScheduleFromDataCenter(channel.getTvmaourl());
                if (scheduleList!=null&&scheduleList.size() > 0) {
                    //删除第二天和第6天的数据
                    for(Schedule s:scheduleList){
                        s.setChannel(channel);
                    }
                    //保存新的第二天和第6天的数据
                    scheduleService.refresh(channel.getId(), scheduleList);
                }
            }
        }
    }
    private JsonMapper mapper = new JsonMapper();
    //网络抓取8天的数据 第二天和第6天
    private List<Schedule> getNetWorkScheduleFromDataCenter( String ids) {
        List<Schedule> list = Lists.newArrayList();
        //当天
        SimpleDateFormat daysdf = new SimpleDateFormat("yyyy-MM-dd");
        String todaystr = daysdf.format(Calendar.getInstance().getTime());
        String json = HttpJDKUtil.executeHttpGet(SystemConstant.getURLValue("data_center")+"json/data/schedule"+"?ids="+ids+"&todaystr="+todaystr,  "utf-8");
        List<Schedule> list1= mapper.fromJson(json, mapper.createCollectionType(ArrayList.class, Schedule.class));
        //第6天
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_MONTH, 5);
        String sixdaystr = daysdf.format(c.getTime());
        String json6 = HttpJDKUtil.executeHttpGet(SystemConstant.getURLValue("data_center")+"json/data/schedule"+"?ids="+ids+"&todaystr="+sixdaystr,  "utf-8");
        List<Schedule> list2= mapper.fromJson(json6, mapper.createCollectionType(ArrayList.class, Schedule.class));
        list.addAll(list1);
        list.addAll(list2);
        return list;
    }
    
}
