package com.smt.iptv.portal.entity.hotel;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.portal.core.IdEntity;

@Entity
@Table(name = "hotel")
public class Hotel extends IdEntity {
	private String hotelname;
	private String hotellogo;
	private String hotelimage;

	public Hotel() {
	}

	public Hotel(Long id) {
		this.id = id;
	}

	public String getHotelname() {
        return hotelname;
    }

    public void setHotelname(String hotelname) {
        this.hotelname = hotelname;
    }

    public String getHotellogo() {
        return hotellogo;
    }

    public void setHotellogo(String hotellogo) {
        this.hotellogo = hotellogo;
    }

    public String getHotelimage() {
        return hotelimage;
    }

    public void setHotelimage(String hotelimage) {
        this.hotelimage = hotelimage;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}