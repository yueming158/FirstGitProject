package com.smt.iptv.portal.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.portal.core.IdEntity;
@Entity
@Table(name = "rate")
public class Rate extends IdEntity {
    
    public Rate() {
    }

    public Rate(Long id) {
        this.id = id;
    }
    
	private String selfsymbol;
	private String selfname;
	private String symbol;
	private String name;
	private String mbuyprice;
	private String fbuyprice;  
    private String sellprice;
    private String baseprice;
    private Date date;

    public String getSelfsymbol() {
        return selfsymbol;
    }

    public void setSelfsymbol(String selfsymbol) {
        this.selfsymbol = selfsymbol;
    }

    public String getSelfname() {
        return selfname;
    }

    public void setSelfname(String selfname) {
        this.selfname = selfname;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMbuyprice() {
        return mbuyprice;
    }

    public void setMbuyprice(String mbuyprice) {
        this.mbuyprice = mbuyprice;
    }

    public String getFbuyprice() {
        return fbuyprice;
    }

    public void setFbuyprice(String fbuyprice) {
        this.fbuyprice = fbuyprice;
    }

    public String getSellprice() {
        return sellprice;
    }

    public void setSellprice(String sellprice) {
        this.sellprice = sellprice;
    }

    public String getBaseprice() {
        return baseprice;
    }

    public void setBaseprice(String baseprice) {
        this.baseprice = baseprice;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}