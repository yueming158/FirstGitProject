package com.smt.iptv.portal.web.program;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Maps;
import com.smt.iptv.portal.core.Result;
import com.smt.iptv.portal.entity.Roomstatus;
import com.smt.iptv.portal.entity.hotel.Hotelroom;
import com.smt.iptv.portal.push.PushServer;
import com.smt.iptv.portal.service.cmp.RoomstatusService;
import com.smt.iptv.portal.service.hotel.HotelroomService;

/**
 * @author xjw
 */
@Controller
@RequestMapping(value = "/roomstatus")
public class RoomstatusController {


    private static final int PAGE_SIZE = 1000;

    private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
    static {
        sortTypes.put("auto", "自动");
        
    }
    

    @Autowired
    private RoomstatusService roomstatusService;
    @Autowired
    private HotelroomService hotelroomService;
    
    @RequestMapping(value = "/list")
    public String list(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");

        Page<Hotelroom> hotelrooms = hotelroomService.getPage(searchParams, pageNumber, PAGE_SIZE, sortType);
        
        List<Roomstatus> roomstatuss =roomstatusService.getLastRecordGroupByAccount();
        if (hotelrooms != null) {
            List<String> usernames = PushServer.getLonginUsers();
            for (Hotelroom hotelroom : hotelrooms.getContent()) {
                for (String username : usernames) {
                    if (hotelroom.getIptvprofile().getIptvusername().equals(username)) {
                        hotelroom.getIptvprofile().setLoginstatus("O");
                        break;
                    }
                }
            }
        }
        model.addAttribute("hotelrooms", hotelrooms);
        model.addAttribute("roomstatuss", roomstatuss);
        model.addAttribute("sortType", sortType);
        model.addAttribute("sortTypes", sortTypes);
        // 将搜索条件编码成字符串，用于排序，分页的URL
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
        return "roomstatus/roomstatusList";
    }
    
    @RequestMapping(value = "open")
    @ResponseBody
    public Result open(String account,Integer minutes) {
        Roomstatus roomstatus = new Roomstatus();
        roomstatus.setAccount(account);
        Calendar c =Calendar.getInstance();
        c.set(Calendar.MILLISECOND, 0);
        Date starttime= c.getTime();
        Date endtime =null;
        if(starttime.getSeconds()<=30){
            starttime.setSeconds(0);
            endtime =new Date(starttime.getTime()+minutes*60000);
        }else{
            starttime.setSeconds(0);
            endtime =new Date(starttime.getTime()+minutes*60000+60000);
        }
        roomstatus.setStarttime(starttime);
        roomstatus.setEndtime(endtime);
        if(roomstatusService.save(roomstatus)!=null){
            return new Result(true,"开放成功");
        }else{
            return new Result(false,"当前房间已开放");
        }
    }

    @RequestMapping(value = "prolong")
    @ResponseBody
    public Result prolong(Long id,Integer minutes) {
        Roomstatus roomstatus = roomstatusService.findOne(id);
        if(roomstatus!=null&&roomstatus.getEndtime()!=null){
            roomstatus.setEndtime(new Date(roomstatus.getEndtime().getTime()+minutes*60000));
            roomstatusService.save(roomstatus);
            return new Result(true,"延时成功");
        }else{
            return new Result(false,"开放记录不正确");
        }
    }
    
    @RequestMapping(value = "close")
    @ResponseBody
    public Result close(Long id) {
        Roomstatus roomstatus = roomstatusService.findOne(id);
        if(roomstatus!=null&&roomstatus.getEndtime()!=null&&roomstatus.getEndtime().getTime()>System.currentTimeMillis()){
            Calendar c =Calendar.getInstance();
            c.set(Calendar.MILLISECOND, 0);
            c.set(Calendar.SECOND, 0);
            roomstatus.setEndtime(c.getTime());
            roomstatusService.save(roomstatus);
            return new Result(true,"锁定成功");
        }else{
            return new Result(false,"房间已锁定");
        }
    }

    @RequestMapping(value = "/history")
    public String history(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");
        Page<Roomstatus> roomstatuss =roomstatusService.getPage(searchParams, pageNumber, 50, sortType);
        model.addAttribute("roomstatuss", roomstatuss);
        String roomname = hotelroomService.getRoomNameByAccount(searchParams.get("EQ_account").toString());
        model.addAttribute("roomname", roomname);
        model.addAttribute("sortType", sortType);
        model.addAttribute("sortTypes", sortTypes);
        // 将搜索条件编码成字符串，用于排序，分页的URL
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
        return "roomstatus/history";
    }
    
    @RequestMapping(value = "/timeselect")
    public String timeselect(Long id ,String account,String action,Model model){
        model.addAttribute("action", action);
        model.addAttribute("account", account);
        model.addAttribute("id", id);
        return "roomstatus/timeselect";
    }
    
	/**
	 * 使用@ModelAttribute, 实现Struts2 Preparable二次部分绑定的效果,先根据form的id从数据库查出Roomstatus对象,再把Form提交的内容绑定到该对象上。
	 * 因为仅update()方法的form中有id属性，因此本方法在该方法中执行.
	 */
	@ModelAttribute("preloadRoomstatus")
	public Roomstatus getRoomstatus(@RequestParam(value = "id", required = false) Long id) {
		if (id != null) {
			return roomstatusService.findOne(id);
		}
		return null;
	}
	

    
}
