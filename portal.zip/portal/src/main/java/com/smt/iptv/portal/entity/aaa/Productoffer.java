package com.smt.iptv.portal.entity.aaa;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springside.modules.mapper.JsonMapper;

import com.fasterxml.jackson.databind.JavaType;
import com.smt.iptv.portal.core.IdEntity;
@Entity
@Table(name = "aaa_productoffer")
public class Productoffer extends IdEntity {
    public Productoffer() {
    }

    public Productoffer(Long id) {
        this.id = id;
    }
    private String productoffertype;//商品类型
    private String offername;//商品名称
    private String strategytype;//计费类型
    private Integer price;//价格
    private Integer cycleduration;//周期 单位天
    private String description;//商品说明1
    private String attrs;//商品说明2
    private String status;//商品状态  0:待生效 1:生效2:停售3:作废
    
    private List<Product> productlist;
    
    private static JsonMapper mapper = new JsonMapper();
    private static JavaType attrsType =mapper.createCollectionType(ArrayList.class, Attr.class);
    
    
    @ManyToMany(cascade = CascadeType.REFRESH, fetch = FetchType.LAZY)
    @JoinTable(name = "aaa_productofferdetail",
    joinColumns = {@JoinColumn(name = "productofferid")},
    inverseJoinColumns = {@JoinColumn(name = "productid")})
    public List<Product> getProductlist() {
		return productlist;
	}

	public void setProductlist(List<Product> productlist) {
		this.productlist = productlist;
	}

	@Transient
    public List<Attr> getAttrList() {

        if (StringUtils.isNotEmpty(attrs)) {
            return mapper.fromJson(attrs, attrsType);
        } else {
            return null;
        }
    }
    public void setAttrList(List<Attr> attrsList) {
        this.attrs = mapper.toJson(attrsList);
    }

    public String getProductoffertype() {
        return productoffertype;
    }

    public void setProductoffertype(String productoffertype) {
        this.productoffertype = productoffertype;
    }

    public String getOffername() {
        return offername;
    }

    public void setOffername(String offername) {
        this.offername = offername;
    }

    public String getStrategytype() {
        return strategytype;
    }

    public void setStrategytype(String strategytype) {
        this.strategytype = strategytype;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public Integer getCycleduration() {
        return cycleduration;
    }

    public void setCycleduration(Integer cycleduration) {
        this.cycleduration = cycleduration;
    }


    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getAttrs() {
        return attrs;
    }

    public void setAttrs(String attrs) {
        this.attrs = attrs;
    }

    public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
}