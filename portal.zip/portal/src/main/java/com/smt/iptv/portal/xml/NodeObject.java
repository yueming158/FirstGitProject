package com.smt.iptv.portal.xml;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.google.common.collect.Lists;

/**
 * 使用JAXB2.0标注的待转换Java Bean.
 */
@XmlType(propOrder = { "elementType", "id","action","propertys"})
public class NodeObject {
    
    public NodeObject() {
        
    }
    
	public NodeObject(Long id, String elementType, String action) {
        super();
        this.id = id;
        this.elementType = elementType;
        this.action = action;
    }


    private Long id;
   
	private String elementType;
   
	private String action;
    
    private List<NodeProperty> propertys = Lists.newArrayList();
    
    @XmlAttribute(name="ID")
	public Long getId() {
        return id;
    }


    public void setId(Long id) {
        this.id = id;
    }

    @XmlAttribute(name="ElementType")
    public String getElementType() {
        return elementType;
    }


    public void setElementType(String elementType) {
        this.elementType = elementType;
    }

    @XmlAttribute(name="Action")
    public String getAction() {
        return action;
    }


    public void setAction(String action) {
        this.action = action;
    }


    @XmlElement(name = "Property")
    public List<NodeProperty> getPropertys() {
        return propertys;
    }

    public void setPropertys(List<NodeProperty> propertys) {
        this.propertys = propertys;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
