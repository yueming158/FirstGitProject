package com.smt.iptv.portal.i18nrepository.music;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.smt.iptv.portal.i18nentity.music.Musiccategory;
import com.smt.iptv.portal.repository.BaseDao;

public interface MusiccategoryDao extends BaseDao<Musiccategory> {
    @Query("delete from Musiccategory where id =?1 and not EXISTS(select 1 from Musiccategorymap m where m.musiccategory.id=?1)")
    @Modifying
    int deleteCheckRel(Long id);
}
