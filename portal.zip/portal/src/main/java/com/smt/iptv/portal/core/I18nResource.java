package com.smt.iptv.portal.core;

import java.util.ResourceBundle;

import org.springframework.context.i18n.LocaleContextHolder;

public class I18nResource {
  
    
    private static ResourceBundle resb = ResourceBundle.getBundle("message"); 
    

    public static String  getString(String key){
        if(LocaleContextHolder.getLocale()==null){
            return resb.getString(key);
        }else{
            return ResourceBundle.getBundle("message", LocaleContextHolder.getLocale()).getString(key);
        }
    }
    public static Integer  getInteger(String key){
        return Integer.valueOf(resb.getString(key));
    }
}
