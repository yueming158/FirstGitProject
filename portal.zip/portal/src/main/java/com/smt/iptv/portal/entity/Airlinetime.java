package com.smt.iptv.portal.entity;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;

import com.smt.iptv.portal.core.IdEntity;

@Entity
@Table(name = "airlinetime")
public class Airlinetime extends IdEntity {

    public Airlinetime() {
    }

    public Airlinetime(Long id) {
        this.id = id;
    }

    private String diffgrid;
    private String msdatarowOrder;

    private String company;
    private String airlinecode;
    private String startdrome;
    private String arrivedrome;
    private String starttime;
    private String arrivetime;
    private String mode;
    private String airlinestop;
    private String week;
    private String airlinecitycode;
    @Transient
    @XmlAttribute(name = "diffgrid")
    public String getDiffgrid() {
        return diffgrid;
    }

    public void setDiffgrid(String diffgrid) {
        this.diffgrid = diffgrid;
    }
    @Transient
    @XmlAttribute(name = "msdatarowOrder")
    public String getMsdatarowOrder() {
        return msdatarowOrder;
    }

    public void setMsdatarowOrder(String msdatarowOrder) {
        this.msdatarowOrder = msdatarowOrder;
    }

    @XmlElement(name = "Company")
    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    @XmlElement(name = "AirlineCode")
    public String getAirlinecode() {
        return airlinecode;
    }

    public void setAirlinecode(String airlinecode) {
        this.airlinecode = airlinecode;
    }

    @XmlElement(name = "StartDrome")
    public String getStartdrome() {
        return startdrome;
    }

    public void setStartdrome(String startdrome) {
        this.startdrome = startdrome;
    }

    @XmlElement(name = "ArriveDrome")
    public String getArrivedrome() {
        return arrivedrome;
    }

    public void setArrivedrome(String arrivedrome) {
        this.arrivedrome = arrivedrome;
    }

    @XmlElement(name = "StartTime")
    public String getStarttime() {
        return starttime;
    }

    public void setStarttime(String starttime) {
        this.starttime = starttime;
    }

    @XmlElement(name = "ArriveTime")
    public String getArrivetime() {
        return arrivetime;
    }

    public void setArrivetime(String arrivetime) {
        this.arrivetime = arrivetime;
    }

    @XmlElement(name = "Mode")
    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    @XmlElement(name = "AirlineStop")
    public String getAirlinestop() {
        return airlinestop;
    }

    public void setAirlinestop(String airlinestop) {
        this.airlinestop = airlinestop;
    }

    @XmlElement(name = "Week")
    public String getWeek() {
        return week;
    }

    public void setWeek(String week) {
        this.week = week;
    }

    @XmlTransient
    public String getAirlinecitycode() {
        return airlinecitycode;
    }

    public void setAirlinecitycode(String airlinecitycode) {
        this.airlinecitycode = airlinecitycode;
    }

}