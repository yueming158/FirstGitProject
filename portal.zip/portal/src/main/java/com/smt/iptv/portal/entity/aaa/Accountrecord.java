package com.smt.iptv.portal.entity.aaa;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.portal.core.IdEntity;

@Entity
@Table(name = "aaa_accountrecord")
public class Accountrecord extends IdEntity {
	public final static String TYPE_1 ="1"; //订购商品
	public final static String TYPE_2 ="2"; //充值
	public final static String TYPE_5 ="5"; //退订退款
	public final static String TYPE_6 ="6"; //直接退款

    public Accountrecord() {
    }

    public Accountrecord(Long id) {
        this.id = id;
    }
	
    private Long accountid;
    private String type;//流水类型 1为订购商品,2为充值,5为退订退款6为直接退款
    private Integer balance;
    private Date recorddate;
    private Long orderusageid;
    private String description;
	public Long getAccountid() {
		return accountid;
	}

	public void setAccountid(Long accountid) {
		this.accountid = accountid;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Integer getBalance() {
		return balance;
	}

	public void setBalance(Integer balance) {
		this.balance = balance;
	}

	public Date getRecorddate() {
		return recorddate;
	}

	public void setRecorddate(Date recorddate) {
		this.recorddate = recorddate;
	}

	public Long getOrderusageid() {
		return orderusageid;
	}

	public void setOrderusageid(Long orderusageid) {
		this.orderusageid = orderusageid;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	@Override
	public String toString() {
	     return ToStringBuilder.reflectionToString(this);
	}
    
    
    
    
}
