package com.smt.iptv.portal.service.hotel;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.entity.hotel.Hotelcustomer;
import com.smt.iptv.portal.entity.hotel.Hotelroom;
import com.smt.iptv.portal.repository.DishorderDao;
import com.smt.iptv.portal.repository.GoodsorderDao;
import com.smt.iptv.portal.repository.hotel.HotelcustomerDao;
import com.smt.iptv.portal.repository.hotel.HotelroomDao;
import com.smt.iptv.portal.service.cmp.BaseService;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class HotelcustomerService extends BaseService<HotelcustomerDao, Hotelcustomer> {
    @Autowired
    private HotelroomDao hotelroomDao;
    @Autowired
    private DishorderDao dishorderDao;
    @Autowired
    private GoodsorderDao goodsorderDao;
    public List<Hotelroom> getEmptyRoomList(){
        return dao.getEmptyRoomList();
    }
    
    @Transactional(readOnly = false)
    @Override
    public Hotelcustomer save(Hotelcustomer entity) {
        //如果客户入住的房间 没有住人 或者住的是自己 才能改动
        List<Hotelcustomer> hc =dao.getByHotelroomIdAndStatus(entity.getHotelroom().getId(), "1");//不靠谱 可能多个
        if(hc==null||(hc.size()==1&& hc.get(0).getId()==entity.getId())){
            return dao.save(entity);
        }
        return null;
    }
    
    @Transactional(readOnly = false)
    public Hotelcustomer checkin(Hotelcustomer entity) {
        //如果客户关联的房间住的是自己 才能改动
        List<Hotelcustomer> hc =dao.getByHotelroomIdAndStatus(entity.getHotelroom().getId(), "1");
        Hotelroom hotelroom =hotelroomDao.findOne(entity.getHotelroom().getId());
        if(hc==null||hc.size()==0){ 

            //修改wifi密码
            String interacpassword =(10000000+new Random().nextInt(90000000))+"";
            hotelroom.getIptvprofile().setInteracpassword(interacpassword);
            //隐藏私有信息推送
            dao.updateBulletinStatus(hotelroom.getIptvprofile().getId(),"1");//0 未过期 1 过期
            //隐藏酒店服务呼叫数据
            dao.updateHotelcallStatus(hotelroom.getIptvprofile().getIptvusername(),"0");
            //隐藏点餐系统订单
            dishorderDao.updateDishorderStatus(hotelroom.getIptvprofile().getIptvusername(),"0");
            goodsorderDao.updateGoodsorderStatus(hotelroom.getIptvprofile().getIptvusername(),"0");
            //清空用户的购物车 因为有2套数据  所以暂时未实现
            //dishorderDao.deleteDishcart(hotelroom.getIptvprofile().getIptvusername());
            //修改状态
            entity.setStatus("1");
            return dao.save(entity);
        }
        return null;
    }
    
    
    @Transactional(readOnly = false)
    public Hotelcustomer checkout(Hotelcustomer entity) {
        //房间多人的时候 一人退房 所有人全退
        List<Hotelcustomer> hc =dao.getByHotelroomIdAndStatus(entity.getHotelroom().getId(), "1");
        if(hc!=null&&hc.size()>=1){ 
            //修改wifi密码
            String interacpassword =(10000000+new Random().nextInt(90000000))+"";
            hc.get(0).getHotelroom().getIptvprofile().setInteracpassword(interacpassword);
            //隐藏私有信息推送
            dao.updateBulletinStatus(hc.get(0).getHotelroom().getIptvprofile().getId(),"1");//0 未过期 1 过期
            //隐藏酒店服务呼叫数据
            dao.updateHotelcallStatus(hc.get(0).getHotelroom().getIptvprofile().getIptvusername(),"0");
            //隐藏点餐系统订单
            dishorderDao.updateDishorderStatus(hc.get(0).getHotelroom().getIptvprofile().getIptvusername(),"0");
            goodsorderDao.updateGoodsorderStatus(hc.get(0).getHotelroom().getIptvprofile().getIptvusername(),"0");
            //清空用户的购物车 因为有2套数据  所以暂时未实现
            //dishorderDao.deleteDishcart(hc.get(0).getHotelroom().getIptvprofile().getIptvusername());
            //修改状态
            entity.setCheckouttime(new Date());
            entity.setStatus("2");
            for(Hotelcustomer c:hc){
                c.setCheckouttime(new Date());
                c.setStatus("2");
                dao.save(c);
            }
            return entity;
        }
        return null;
    }
    
    public List<Hotelcustomer> getByRoomno(String roomNo) {
        return dao.getByHotelroomRoomno(roomNo);
    }
    public List<Hotelcustomer> getByRoomnoNotEpmpty(String roomNo) {
        return dao.getByHotelroomRoomnoAndStatus(roomNo,"1");
    }
    public Hotelcustomer getLastGuestByRoomno(String roomNo) {
        return dao.getLastGuestByRoomno(roomNo);
    }
}
