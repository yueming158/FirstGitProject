package com.smt.iptv.portal.web.program;

import java.util.List;
import java.util.Map;

import javax.servlet.ServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Maps;
import com.smt.iptv.portal.core.Result;
import com.smt.iptv.portal.entity.hotel.Hotelroom;
import com.smt.iptv.portal.push.PushMessage;
import com.smt.iptv.portal.push.PushServer;
import com.smt.iptv.portal.service.hotel.HotelroomService;
import com.smt.iptv.portal.service.task.StbrestartJob;
import com.smt.iptv.portal.service.task.SpringTasker;

/**
 * 
 * @author xjw
 */
@Controller
@RequestMapping(value = "/task")
public class TaskController {

    private static final int PAGE_SIZE = 1000;

    private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
    static {
        sortTypes.put("auto", "自动");
    }
    
    @Autowired
    private SpringTasker springTasker;
    @Autowired
    private HotelroomService hotelroomService;
    @Autowired
    StbrestartJob stbrestartJob;
    
    @RequestMapping(value = "/list")
    public String list(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");

        Page<Hotelroom> hotelrooms = hotelroomService.getPage(searchParams, pageNumber, PAGE_SIZE, sortType);
        if (hotelrooms != null) {
            List<String> usernames = PushServer.getLonginUsers();
            for (Hotelroom hotelroom : hotelrooms.getContent()) {
                for (String username : usernames) {
                    if (hotelroom.getIptvprofile().getIptvusername().equals(username)) {
                        hotelroom.getIptvprofile().setLoginstatus("O");
                        break;
                    }
                }
            }
        }
        model.addAttribute("hotelrooms", hotelrooms);
        model.addAttribute("sortType", sortType);
        model.addAttribute("sortTypes", sortTypes);
        // 将搜索条件编码成字符串，用于排序，分页的URL
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
        return "task/roomList";
    }
    
	@RequestMapping(value = "weather", method = RequestMethod.GET)
	@ResponseBody
	public String weather() {
	    springTasker.executeNetDateJob();
	    return "sucess";
	}
	
    @RequestMapping(value = "schdule", method = RequestMethod.GET)
    @ResponseBody
    public String schdule() {
        springTasker.executeScheduleTask();
        return "sucess";
    }
    
//仅为测试使用
//    @RequestMapping(value = "reset")
//    @ResponseBody
//    public Result reset(String hour) {
//        Integer hournum=-1;
//        try{
//            hournum=Integer.parseInt(hour);
//        }catch (Exception e) {
//            return new Result(false,"时间参数不正确");
//        }
//        if(hournum>=0&&hournum<=23){
//            stbrestartJob.setCronExpression("0 0 "+hour+" * * ?"); //?cron=0 0 0 * * ?  cron%3d0+*+*+*+*+%3f
//            stbrestartJob.stop();
//            stbrestartJob.start();
//            return new Result();
//        }else{
//            return new Result(false,"时间参数不正确");
//        }
//    }
    
    @RequestMapping(value = "restartstb")
    @ResponseBody
    public Result restartstb(@RequestParam(required=false)String  names) {
        if(StringUtils.isEmpty(names)){
            PushServer.sendMsgToAll(new PushMessage("action", "restart"));
            return new Result(true,"已重启全部机顶盒");
        }else{
            String [] accounts =names.split(",");
            for(String account:accounts){
                PushServer.sendMsg(account, new PushMessage("action", "restart"));
            }
            return new Result(true,"已重启选中机顶盒");
        }
    }
    
}
