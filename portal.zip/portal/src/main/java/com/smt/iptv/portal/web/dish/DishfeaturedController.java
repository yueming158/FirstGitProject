package com.smt.iptv.portal.web.dish;

import java.util.Map;

import javax.servlet.ServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Maps;
import com.smt.iptv.portal.i18nentity.dish.Dishfeatured;
import com.smt.iptv.portal.service.dish.DishfeaturedService;
import com.smt.iptv.portal.web.vo.Message;

/**
 * @author rich
 */
@Controller
@RequestMapping(value = "/dishfeatured")
public class DishfeaturedController {

    private static final int PAGE_SIZE = 50;

    private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
    static {
        sortTypes.put("sequence", "自动");
    }

    @Autowired
    private DishfeaturedService dishfeaturedService;

    @RequestMapping(value = "/list")
    public String list(@RequestParam(value = "sortType", defaultValue = "sequence") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");
        Page<Dishfeatured> dishfeatureds = dishfeaturedService.getPage(searchParams, pageNumber, 10000, sortType);
        model.addAttribute("dishfeatureds", dishfeatureds);
        model.addAttribute("sortType", sortType);
        model.addAttribute("sortTypes", sortTypes);
        // 将搜索条件编码成字符串，用于排序，分页的URL
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
        return "dish/dishfeaturedList";
    }

    @RequestMapping(value = "add")
    @ResponseBody
    public Message create(@Valid Dishfeatured newDishfeatured, RedirectAttributes redirectAttributes) {
        //不能重复加
        if(newDishfeatured!=null
                &&newDishfeatured.getDish()!=null
                &&newDishfeatured.getDish().getId()!=null
                &&dishfeaturedService.getByDishId(newDishfeatured.getDish().getId())==null){
            newDishfeatured.setSequence(0);
            dishfeaturedService.save(newDishfeatured);
            return new Message("添加成功");
        }else{
            return new Message("不能重复添加");
        }
    }

    @RequestMapping(value = "updatesort")
    public String update( Integer [] sequences,Long [] ids, RedirectAttributes redirectAttributes) {
        if(ids!=null&&sequences!=null&&ids.length==sequences.length){
            for(int i=0;i<ids.length;i++){
                Dishfeatured dishfeatured =dishfeaturedService.findOne(ids[i]);
                dishfeatured.setSequence(sequences[i]);
                dishfeaturedService.save(dishfeatured);
            }
        }
        redirectAttributes.addFlashAttribute("message", "保存成功");
        return "redirect:/dishfeatured/list";
    }

    @RequestMapping(value = "delete/{id}")
    public String delete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
        dishfeaturedService.delete(id);
        redirectAttributes.addFlashAttribute("message", "删除成功");
        return "redirect:/dishfeatured/list";
    }

    @ModelAttribute("preloadDishfeatured")
    public Dishfeatured getDishfeatured(@RequestParam(value = "id", required = false) Long id) {
        if (id != null) {
            return dishfeaturedService.findOne(id);
        }
        return null;
    }

}
