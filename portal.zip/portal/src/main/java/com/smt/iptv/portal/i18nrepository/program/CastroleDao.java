package com.smt.iptv.portal.i18nrepository.program;

import java.util.List;

import org.springframework.data.jpa.repository.Query;

import com.smt.iptv.portal.i18nentity.program.Castrole;
import com.smt.iptv.portal.repository.BaseDao;

public interface CastroleDao extends BaseDao<Castrole> {
    //@Query("select c from Cast c,Program p where  p.id=?1") 错误。这种是2个表字段一样 而不是外键关联。
    @Query("select cr from Castrole cr,Program p where p.id=?1 and p.programtype=cr.programtype")//纯靠2个表字段一样来关联
    public List<Castrole> getCastrolesByProgramid(Long programid);
}
