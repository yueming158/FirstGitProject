package com.smt.iptv.portal.web.program;

import java.io.IOException;
import java.net.SocketException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletRequest;
import javax.validation.Valid;

import org.apache.commons.net.ftp.FTPClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.mapper.JsonMapper;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.smt.iptv.portal.core.Result;
import com.smt.iptv.portal.i18nentity.program.Mediacontent;
import com.smt.iptv.portal.i18nentity.program.Program;
import com.smt.iptv.portal.model.SystemConstant;
import com.smt.iptv.portal.service.cmp.MediacontentService;
import com.smt.iptv.portal.service.cmp.ProgramService;
import com.smt.iptv.portal.web.ftp.FtpReader;
import com.smt.iptv.portal.web.model.FileNode;

/**
 * Mediacontent管理的Controller, 使用Restful风格的Urls:
 * 
 * List page : GET /mediacontent/ Create page : GET /mediacontent/create Create
 * action : POST /mediacontent/create Update page : GET
 * /mediacontent/update/{id} Update action : POST /mediacontent/update Delete
 * action : GET /mediacontent/delete/{id}
 * 
 * @author xjw
 */
@Controller
@RequestMapping(value = "/mediacontent")
public class MediacontentController {

    private static final int PAGE_SIZE = 50;

    private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
    static {
        sortTypes.put("sequence", "顺序");
    }
    @Autowired
    private ProgramService programService;
    @Autowired
    private MediacontentService mediacontentService;

    @RequestMapping(value = "/list")
    public String list(@RequestParam(value = "sortType", defaultValue = "sequence") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");

        Page<Mediacontent> mediacontents = mediacontentService.getPage(searchParams, pageNumber, PAGE_SIZE, sortType);

        model.addAttribute("mediacontents", mediacontents);
        model.addAttribute("sortType", sortType);
        model.addAttribute("sortTypes", sortTypes);
        // 将搜索条件编码成字符串，用于排序，分页的URL
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
        return "mediacontent/mediacontentList";
    }

    @RequestMapping(value = "{programid}/list")
    public String listByProgramId(@RequestParam(value = "sortType", defaultValue = "sequence") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, @PathVariable("programid") Long programid, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");
        // LIKE_programname=浮夸
        searchParams.put("EQ_program.id", programid + "");
        Page<Mediacontent> mediacontents = mediacontentService.getPage(searchParams, pageNumber, PAGE_SIZE, sortType);
        if(mediacontents.getContent()!=null&&mediacontents.getContent().size()>0&&"0".equals(mediacontents.getContent().get(0).getSequence())){
            model.addAttribute("showname", "0");
        }else{
            model.addAttribute("showname", "1");
        }
        model.addAttribute("program", programService.findOne(programid));
        model.addAttribute("programid", programid);
        model.addAttribute("mediacontents", mediacontents);
        model.addAttribute("sortType", sortType);
        model.addAttribute("sortTypes", sortTypes);
        // 将搜索条件编码成字符串，用于排序，分页的URL
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
        return "mediacontent/mediacontentList";
    }

    @RequestMapping(value = "updatesequence", method = RequestMethod.POST)
    public String updatesequence(Long [] ids,String [] sequences,Long programid,@RequestParam(defaultValue="0")Integer showname,RedirectAttributes redirectAttributes) {
        if(ids!=null&&sequences!=null){
            List<Mediacontent> mediacontents= mediacontentService.getByIds(Arrays.asList(ids));
            if(mediacontents!=null&&mediacontents.size()==sequences.length){
                for(int i=0;i<mediacontents.size();i++){
                    mediacontents.get(i).setSequence(sequences[i]);
                }
                Collections.sort(mediacontents,new SortContent());
                for(int i=0;i<mediacontents.size();i++){
                    mediacontents.get(i).setSequence(String.valueOf(i+showname));
                }
            }
            mediacontentService.save(mediacontents);
        }
        redirectAttributes.addFlashAttribute("message", "修改成功");
        return "redirect:/mediacontent/" + programid + "/list";
    }
    private class SortContent implements Comparator<Mediacontent>{

        @Override
        public int compare(Mediacontent o1, Mediacontent o2) {
            return o1.getSequence().compareTo(o2.getSequence());
        }
    }
    
    @RequestMapping(value = "{programid}/create", method = RequestMethod.GET)
    public String createForm(@PathVariable("programid") Long programid, Model model,
            @RequestParam(value = "showname",required=false, defaultValue = "1") Integer showname,@RequestParam(value = "type", defaultValue = "m") String urltype) {
        
        Mediacontent mediacontent= new Mediacontent();
        mediacontent.setSequence((mediacontentService.getCountByProgramId(programid)+showname)+"");
        
        model.addAttribute("programid", programid);
        mediacontent.setUrltype(urltype);
        model.addAttribute("mediacontent", mediacontent);
        model.addAttribute("action", "create");
        if ("u".equals(urltype)) {
            return "mediacontent/mediacontenturlForm";
        }else if(urltype!=null&&urltype.startsWith("f")){
            return "mediacontent/mediacontentfileForm";
        }else{
            return "mediacontent/mediacontentForm";
        }
    }

    @RequestMapping(value = "{programid}/create", method = RequestMethod.POST)
    public String create(@PathVariable("programid") Long programid, @Valid Mediacontent newMediacontent, RedirectAttributes redirectAttributes) {
        Program p = programService.findOne(programid);
        newMediacontent.setProgram(p);
        mediacontentService.create(newMediacontent, "cpobjectcode", "MOV0000000000@CRI");
        redirectAttributes.addFlashAttribute("message", "新增成功");
        return "redirect:/mediacontent/" + programid + "/list";
    }

    @RequestMapping(value = "{programid}/update/{id}", method = RequestMethod.GET)
    public String updateForm(@PathVariable("programid") Long programid, @PathVariable("id") Long id, Model model,
            @RequestParam(value = "type", defaultValue = "m") String urltype) {
        model.addAttribute("programid", programid);
        model.addAttribute("mediacontent", mediacontentService.findOne(id));
        model.addAttribute("action", "update");
        if ("u".equals(urltype)) {
            return "mediacontent/mediacontenturlForm";
        }else if(urltype!=null&&urltype.startsWith("f")){
            return "mediacontent/mediacontentfileForm";
        }else{
            return "mediacontent/mediacontentForm";
        }
    }

    @RequestMapping(value = "{programid}/update", method = RequestMethod.POST)
    public String update(@PathVariable("programid") Long programid, @Valid @ModelAttribute("preloadMediacontent") Mediacontent mediacontent,
            RedirectAttributes redirectAttributes) {
        mediacontentService.save(mediacontent);
        redirectAttributes.addFlashAttribute("message", "保存成功");
        return "redirect:/mediacontent/" + programid + "/list";
    }

    @RequestMapping(value = "{programid}/delete/{id}")
    public String delete(@PathVariable("programid") Long programid, @PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
        mediacontentService.delete(id);
        redirectAttributes.addFlashAttribute("message", "删除成功");
        return "redirect:/mediacontent/" + programid + "/list";
    }

    /**
     * 使用@ModelAttribute, 实现Struts2
     * Preparable二次部分绑定的效果,先根据form的id从数据库查出Mediacontent对象,再把Form提交的内容绑定到该对象上。
     * 因为仅update()方法的form中有id属性，因此本方法在该方法中执行.
     */
    @ModelAttribute("preloadMediacontent")
    public Mediacontent getMediacontent(@RequestParam(value = "id", required = false) Long id) {
        if (id != null) {
            return mediacontentService.findOne(id);
        }
        return null;
    }
    private  static Map<String,List<FileNode>> nodesMap = Maps.newConcurrentMap();//文件夹节点缓存
    @RequestMapping(value = "/fileselect")
    public String fileselect(Model model,String urltype){
        //nodesMap.remove(urltype);
        List<FileNode> nodes = nodesMap.get(urltype);
        if(nodes==null){
            refreshfiles(urltype);
            nodes=nodesMap.get(urltype);
        }
        JsonMapper mapper = new JsonMapper();
        model.addAttribute("nodes", mapper.toJson(nodes));
        return "mediacontent/fileselect";
    }
    
    @RequestMapping(value = "/refreshfiles")
    @ResponseBody
    public  Result refreshfiles(String urltype){
        String ftpurl =SystemConstant.getValue("media_server_ftpurl_"+urltype);
        if(ftpurl==null){
            throw new RuntimeException("请在系统配置中配置media_server_ftpurl_"+urltype);
        }
        FTPClient ftp = new FTPClient();
        ftp.setConnectTimeout(3000);
        String ftpCharsetName ="utf-8";

        String username= ftpurl.split("@")[0].split(":")[1].substring(2);
        String pwd= ftpurl.split("@")[0].split(":")[2];
        String ip= ftpurl.split("@")[1].split("/")[0];
        String home= ftpurl.split("@")[1].substring(ip.length());
        List<FileNode> nodes = Lists.newArrayList();
        try {
            ftp.connect(ip, 21);
            ftp.login(username, pwd);
            ftp.cwd(home);
            ftp.getCharsetName();
            ftp.getControlEncoding();
            //ftp.setCharset(Charset.forName("gb2312"));
            ftp.setControlEncoding(ftpCharsetName);
            FtpReader.readfolder(ftp, new FileNode(), nodes,ftpCharsetName);
            ftp.cwd(home);
        } catch (SocketException e) {
            throw new RuntimeException("访问FTP服务器"+ip+"失败");
        } catch (IOException e) {
            throw new RuntimeException("访问FTP服务器"+ip+"失败");
        }
        synchronized(nodesMap){  //允许脏读
            Collections.sort(nodes);
            nodesMap.put(urltype, nodes);
        }
        return new Result();
    }
    private static Map<String,Long> lastModifyTimeMap = Maps.newConcurrentMap(); //文件夹最后刷新时间缓存
    /**
     * 使用了静态变量 lastModifyTimeMap 缓存最后修改时间
     * 可供定时器重复刷新使用 每天刷新一次？ 暂时不使用此功能 没有特别的必要
     * @param urltype
     */
    @RequestMapping(value = "/refreshfiles2")
    @ResponseBody
    public Result refreshfilesbymodifytime(String urltype){
        String ftpurl =SystemConstant.getValue("media_server_ftpurl_"+urltype);
        if(ftpurl==null){
            throw new RuntimeException("请在系统配置中配置media_server_ftpurl_"+urltype);
        }
        FTPClient ftp = new FTPClient();
        ftp.setConnectTimeout(3000);
        String ftpCharsetName ="utf-8";

        String username= ftpurl.split("@")[0].split(":")[1].substring(2);
        String pwd= ftpurl.split("@")[0].split(":")[2];
        String ip= ftpurl.split("@")[1].split("/")[0];
        String home= ftpurl.split("@")[1].substring(ip.length());
        try {
            ftp.connect(ip, 21);
            ftp.login(username, pwd);
            ftp.cwd(home);
            ftp.getCharsetName();
            ftp.getControlEncoding();
            //ftp.setCharset(Charset.forName("gb2312"));
            ftp.setControlEncoding(ftpCharsetName);
            long newtime=0L;
            Long time =lastModifyTimeMap.get(urltype);
            if(time==null){
                newtime =FtpReader.getLastModifyTime(ftp, 0L,ftpCharsetName);
                ftp.cwd(home);
            }else{
                newtime =FtpReader.compareLastModifyTime(ftp, time,ftpCharsetName);
                ftp.cwd(home);
            }
            //System.out.println( DateFormatUtils.format(newtime, "yyyy-MM-dd HH:mm:ss"));
            if(time==null||newtime>time){//如果修改时间大于以前的修改时间则刷新
                lastModifyTimeMap.put(urltype, newtime);
                List<FileNode> nodes = Lists.newArrayList();
                FtpReader.readfolder(ftp, new FileNode(), nodes,ftpCharsetName);
                synchronized(nodesMap){  //允许脏读
                    Collections.sort(nodes);
                    nodesMap.put(urltype, nodes);
                }
            }
        } catch (SocketException e) {
            throw new RuntimeException("访问FTP服务器"+ip+"失败");
        } catch (IOException e) {
            throw new RuntimeException("访问FTP服务器"+ip+"失败");
        }
        return new Result();
    }

}
