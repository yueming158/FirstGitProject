package com.smt.iptv.portal.entity.aaa;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.portal.core.IdEntity;
@Entity
@Table(name = "aaa_account")
public class Account extends IdEntity {

    public Account() {
    }

    public Account(Long id) {
        this.id = id;
    }
    private String accountname;
    private String status;
    private Date creationdate;
    private String description;
    //private String attrs;//属性集合
    private Integer  balance;//余额 单位 分

    public String getAccountname() {
        return accountname;
    }

    public void setAccountname(String accountname) {
        this.accountname = accountname;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getCreationdate() {
        return creationdate;
    }

    public void setCreationdate(Date creationdate) {
        this.creationdate = creationdate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

//    public String getAttrs() {
//        return attrs;
//    }
//
//    public void setAttrs(String attrs) {
//        this.attrs = attrs;
//    }

    public Integer getBalance() {
        return balance;
    }

    public void setBalance(Integer balance) {
        this.balance = balance;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
}