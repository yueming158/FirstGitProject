package com.smt.iptv.portal.service.send;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springside.modules.mapper.JaxbMapper;

import com.google.common.collect.Lists;
import com.smt.iptv.portal.entity.Channel;
import com.smt.iptv.portal.xml.ADI;
import com.smt.iptv.portal.xml.NodeObject;
import com.smt.iptv.portal.xml.NodeProperty;

//Spring Bean的标识.
@Component
public class ChannelLoaderService {
    public void regist(Channel e) {
        // 构造xml
        ADI adi = new ADI();
        NodeObject mediaObjs = new NodeObject(e.getId(), "Channel", "REGIST");
        adi.getObjs().add(mediaObjs);
        mediaObjs.setPropertys(buildChannelPropertyList(e));
        String xml = JaxbMapper.toXml(adi, "UTF-8");
        //socketClient.send("Channel",xml);
    }

    public void update(Channel e) {
        ADI adi = new ADI();
        NodeObject mediaObjs = new NodeObject(e.getId(), "Channel", "UPDATE");
        adi.getObjs().add(mediaObjs);
        mediaObjs.setPropertys(buildChannelPropertyList(e));
        String xml = JaxbMapper.toXml(adi, "UTF-8");
        //socketClient.send("Channel",xml);
    }

    public void delete(Channel e) {
        ADI adi = new ADI();
        NodeObject mediaObjs = new NodeObject(e.getId(), "Channel", "DELETE");
        adi.getObjs().add(mediaObjs);
        mediaObjs.getPropertys().add(new NodeProperty("CPObjectCode", e.getCpobjectcode()));
        String xml = JaxbMapper.toXml(adi, "UTF-8");
        //socketClient.send("Channel",xml);
    }

    public void delete(List<Channel> list) {
        for (Channel m : list) {
            this.delete(m);
        }
    }

    /**
     * 
     *  <Property Name="ContentProviderCode">1</Property>
        <Property Name="ChannelNumber">1</Property>
        <Property Name="DescLanguageCode">ISO8859P1</Property>
        <Property Name="LanguageCode">ISO8859P1</Property>
        <Property Name="Name">CCTV1</Property>
        <Property Name="CPObjectCode">TV00000000000000000001@CRI</Property>
        <Property Name="StorageDuration">0</Property>
        <Property Name="Odcflag">0</Property>
        <Property Name="CallSign">CCTV1</Property>
        <Property Name="TimeZone">1</Property>
        <Property Name="DMANum">0</Property>
        <Property Name="Type">1</Property>
        <Property Name="Status">0</Property>
        <Property Name="StartTime">0000</Property>
        <Property Name="EndTime">2359</Property>
        <Property Name="VideoType">0</Property>
        <Property Name="AudioType">0</Property>
        <Property Name="StreamType">1</Property>
        <Property Name="Promotion">0</Property>
        <Property Name="SubType">1</Property>
        <Property Name="HDTV">0</Property>
        <Property Name="HDCP">0</Property>
        <Property Name="Scramble">0</Property>
        <Property Name="WaterMark">0</Property>
        <Property Name="FingerPrint">0</Property>
        <Property Name="BackupPlayAheadTime">0</Property>
        <Property Name="BlockingFlag">0</Property>
        <Property Name="OffsetTime">0</Property>
        <Property Name="CXInputFormat">1</Property>
        <Property Name="CXOutputFormat">2</Property>
        <Property Name="DelayTime">0</Property>
        20150526增加TimeShift自动
     * @param e
     * @return
     */
    private List<NodeProperty> buildChannelPropertyList(Channel channel) {
        List<NodeProperty> list = Lists.newArrayList();
        list.add(new NodeProperty("ContentProviderCode", "1"));
        list.add(new NodeProperty("ChannelNumber", channel.getChannelname()));
        list.add(new NodeProperty("DescLanguageCode", "ISO8859P1"));
        list.add(new NodeProperty("LanguageCode", "ISO8859P1"));
        list.add(new NodeProperty("Name", channel.getChannelname()));
        list.add(new NodeProperty("CPObjectCode", channel.getCpobjectcode()));
        list.add(new NodeProperty("TimeShift", channel.getTimeshift()));
        list.add(new NodeProperty("StorageDuration", channel.getTimeshiftduration()));
        list.add(new NodeProperty("Odcflag", "0"));
        if(StringUtils.isNotEmpty(channel.getCallsign())){
            list.add(new NodeProperty("CallSign", channel.getCallsign()));
        }
        list.add(new NodeProperty("TimeZone", "0"));
        list.add(new NodeProperty("DMANum", "0"));
        list.add(new NodeProperty("Type", channel.getChanneltype()));
        list.add(new NodeProperty("Status", channel.getStatus()));
        if(StringUtils.isNotEmpty(channel.getRecordstarttime())){
            list.add(new NodeProperty("StartTime", channel.getRecordstarttime()));
        }
        if(StringUtils.isNotEmpty(channel.getRecordendtime())){
            list.add(new NodeProperty("EndTime", channel.getRecordendtime()));
        }
        list.add(new NodeProperty("VideoType", "0"));
        list.add(new NodeProperty("AudioType", "0"));
        list.add(new NodeProperty("StreamType", "1"));
        list.add(new NodeProperty("Promotion", "0"));
        list.add(new NodeProperty("SubType", "1"));
        list.add(new NodeProperty("HDTV", channel.getHdtv()));
        list.add(new NodeProperty("HDCP", "0"));
        list.add(new NodeProperty("Scramble", "0"));
        list.add(new NodeProperty("WaterMark", "0"));
        list.add(new NodeProperty("FingerPrint", "0"));
        list.add(new NodeProperty("BackupPlayAheadTime", "0"));
        list.add(new NodeProperty("BlockingFlag", "0"));
        list.add(new NodeProperty("OffsetTime", "0"));
        list.add(new NodeProperty("CXInputFormat", "1"));
        list.add(new NodeProperty("CXOutputFormat", "2"));
        list.add(new NodeProperty("DelayTime", "0"));
        return list;
    }

    
}
