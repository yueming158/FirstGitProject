package com.smt.iptv.portal.service.cmp;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.smt.iptv.portal.core.HttpJDKUtil;
import com.smt.iptv.portal.entity.Rate;
import com.smt.iptv.portal.entity.Ratehexun;
import com.smt.iptv.portal.model.SystemConstant;
import com.smt.iptv.portal.repository.RateDao;
import com.smt.iptv.portal.repository.RatehexunDao;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class RateService extends BaseService<RateDao, Rate> {

    @Autowired
	private RatehexunDao ratehexunDao;
    
    @Transactional(readOnly = false)
    public void refreshRateData(){
        String url =SystemConstant.getValue("HTTP_HEXUNRATE_ADDRESS");
        String jsondata = HttpJDKUtil.executeHttpGet(url,"gb2312");
        if(jsondata!=null&&jsondata.length()>100){
            List<Ratehexun> list = getListByJsonStr(jsondata);
//            if(list!=null&&!list.isEmpty()){
//                ratehexunDao.deleteAll();//删除多余的历史记录
//            }
            List<Ratehexun> oldlist = (List<Ratehexun>)ratehexunDao.findAll();
            if(list!=null){
                for(int i=0;i<list.size();i++){
                    if(oldlist!=null&&!oldlist.isEmpty()){
                        list.get(i).setId(oldlist.get(0).getId());
                        oldlist.remove(0);
                    }else{
                        break;
                    }
                }
                if(!oldlist.isEmpty()){
                    ratehexunDao.delete(oldlist);
                }
            }
            ratehexunDao.save(list);
        }
    }
    
    private List<Ratehexun> getListByJsonStr(String json){
          //截取多余部分
        int index = json.indexOf("中国银行");
        if(index!=-1){
            json="[{bank:'"+json.substring(index,json.length()-1);
        }
        //转化为标准json 统统双引号
        String json2= json.replaceAll(":'", "\":\"").replaceAll("',", "\",\"").replaceAll("\\{", "\\{\"").replaceAll("'\\}", "\"\\}");

        
        ObjectMapper mapper = new ObjectMapper();  
        //时间格式 兼容 返回值不一样
        SimpleDateFormat myDateFormat = new SimpleDateFormat("yyyy/MM/dd H:mm:ss");
        if(json2.indexOf("/")==-1){
            myDateFormat = new SimpleDateFormat("yyyy-MM-dd H:mm:ss");
        }
        mapper.setDateFormat(myDateFormat);
        //转化为list
        JavaType javaType = mapper.getTypeFactory().constructParametricType(ArrayList.class, Ratehexun.class); 
        List<Ratehexun> list = null;
        try {
            list = mapper.readValue(json2, javaType);
        } catch (JsonParseException e) {
            e.printStackTrace();
        } catch (JsonMappingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return list;
    }
}
