package com.smt.iptv.portal.entity.role;

import javax.persistence.Entity;
import javax.persistence.Table;

import com.smt.iptv.portal.core.IdEntity;

@Entity
@Table(name = "epg_role")
public class Role extends IdEntity {
    
    public Role() {
    }

    public Role(Long id) {
        this.id = id;
    }
    
    private String role; //角色标识 程序中判断使用,如"admin"
    private String resourceids; //拥有的资源
    private String description;

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getResourceids() {
        return resourceids;
    }

    public void setResourceids(String resourceids) {
        this.resourceids = resourceids;
    }

}
