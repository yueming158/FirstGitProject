package com.smt.iptv.portal.core;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.ResourceBundle;
import java.util.Set;

/**
 * 
 汉字转化为全拼
 * 
 * JDK版本: 1.4
 */
public class CnToSpell {
    private static ResourceBundle full = ResourceBundle.getBundle("zhspell"); 

    public static String getFullSpell(String cnStr) {
        if (null == cnStr || "".equals(cnStr.trim())) {
            return cnStr;
        }
        char[] chars = cnStr.toCharArray();
        StringBuffer retuBuf = new StringBuffer();
        for (int i = 0, Len = chars.length; i < Len; i++) {
                String spell =null;
                try{
                    spell = full.getString(Integer.toHexString(chars[i]));
                }catch (Exception e) {
                    retuBuf.append(chars[i]);
                }
                if (spell != null) {
                    retuBuf.append(spell);
                } 
        }
        return retuBuf.toString();
    }
 

    /**
     * 返回字符串的简拼,是汉字转化为简拼
     * 
     * @param cnStr
     *            String 字符串
     * @return String 转换成简拼后的字符串
     */
    public static String getSimpleSpell(String cnStr) {
        if (null == cnStr || "".equals(cnStr.trim())) {
            return cnStr;
        }
        char[] chars = cnStr.toCharArray();
        StringBuffer retuBuf = new StringBuffer();
        for (int i = 0, Len = chars.length; i < Len; i++) {
                String spell =null;
                try{
                    spell = full.getString(Integer.toHexString(chars[i]));
                }catch (Exception e) {
                    retuBuf.append(chars[i]);
                }
                if (spell != null) {
                    retuBuf.append(spell.charAt(0));
                } 
        }
        return retuBuf.toString();
    }

    public static String getFirstSpell(String cnStr) {
        return null;
    }
    
    public static void main(String[] args) {
        String[] s = { "123a深圳焱罨获取汉字全拼和首拼测试", "This is a test", "a,b; c[d]", "标，点。", "圆角数字１２３，特殊符号·￥%——……", "繁体字：西安會議", "西安", "棽 燊 顕 峣 山 " };
        for (int i = 0; i < s.length; i++) {
            long l1 = System.currentTimeMillis();
            System.out.println(s[i] + " 的新方法全拼:" + CnToSpell.getFullSpell(s[i]));
            System.out.println(s[i] + " 的新方法简拼:" + CnToSpell.getSimpleSpell(s[i]));
            System.out.println("获取全拼和首拼共用了" + (System.currentTimeMillis() - l1) + "毫秒/n");
        }
    }
    
}