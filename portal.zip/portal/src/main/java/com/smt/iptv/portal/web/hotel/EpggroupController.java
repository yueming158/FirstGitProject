package com.smt.iptv.portal.web.hotel;

import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.smt.iptv.portal.i18nentity.Epggroup;
import com.smt.iptv.portal.i18nentity.Epgvariable;
import com.smt.iptv.portal.service.cmp.EpggroupService;
import com.smt.iptv.portal.service.hotel.EpgvariableService;

/**
 * @author xjw
 */
@Controller
@RequestMapping(value = "/epggroup")
public class EpggroupController {

	private static final int PAGE_SIZE = 50;

	private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
	static {
		sortTypes.put("auto", "自动");
	}

	@Autowired
	private EpggroupService epggroupService;
    @Autowired
    private EpgvariableService epgvariableService;
	@RequestMapping(value = "/list")
	public String list(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
			@RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
		Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");

		Page<Epggroup> epggroups = epggroupService.getPageDesc( searchParams, pageNumber, PAGE_SIZE, sortType);

		model.addAttribute("epggroups", epggroups);
		model.addAttribute("sortType", sortType);
		model.addAttribute("sortTypes", sortTypes);
		// 将搜索条件编码成字符串，用于排序，分页的URL
		model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
		return "epggroup/epggroupList";
	}

	@RequestMapping(value = "create", method = RequestMethod.GET)
	public String createForm(Model model) {
		model.addAttribute("epggroup", new Epggroup());
		model.addAttribute("action", "create");
		return "epggroup/epggroupForm";
	}

	@RequestMapping(value = "create", method = RequestMethod.POST)
	public String create(Epggroup newEpggroup, RedirectAttributes redirectAttributes,HttpServletRequest request) {
		epggroupService.save(newEpggroup);
		//必须新增终端配置的数据epgvariable 中文 英文  其它文
		List<Epgvariable> list =epgvariableService.getByEpggroupid(1L);
		List<Epgvariable> newlist = Lists.newArrayList();
		if(list!=null)
		for(Epgvariable e:list){
		    Epgvariable newvariable = new Epgvariable();
		    newvariable.setDescription(e.getDescription());
		    newvariable.setEnabled(e.getEnabled());
		    newvariable.setEnumstr(e.getEnumstr());
		    newvariable.setEpggroupid(newEpggroup.getId());
		    newvariable.setHeight(e.getHeight());
		    newvariable.setName(e.getName());
		    newvariable.setType(e.getType());
		    newvariable.setWidth(e.getWidth());
		    newlist.add(newvariable);
		}
		epgvariableService.save(newlist);
		redirectAttributes.addFlashAttribute("message", "新增成功");
		return "redirect:/epggroup/list";
	}

	@RequestMapping(value = "update/{id}", method = RequestMethod.GET)
	public String updateForm(@PathVariable("id") Long id, Model model) {
		model.addAttribute("epggroup", epggroupService.findOne(id));
		model.addAttribute("action", "update");
		return "epggroup/epggroupForm";
	}

	@RequestMapping(value = "update", method = RequestMethod.POST)
	public String update(@ModelAttribute("preloadEpggroup") Epggroup epggroup, RedirectAttributes redirectAttributes) {
		epggroupService.save(epggroup);
		redirectAttributes.addFlashAttribute("message", "保存成功");
		return "redirect:/epggroup/list";
	}

	@RequestMapping(value = "delete/{id}")
	public String delete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
		epggroupService.delete(id);
		redirectAttributes.addFlashAttribute("message", "删除成功");
		return "redirect:/epggroup/list";
	}

	/**
	 * 使用@ModelAttribute, 实现Struts2 Preparable二次部分绑定的效果,先根据form的id从数据库查出Epggroup对象,再把Form提交的内容绑定到该对象上。
	 * 因为仅update()方法的form中有id属性，因此本方法在该方法中执行.
	 */
	@ModelAttribute("preloadEpggroup")
	public Epggroup getEpggroup(@RequestParam(value = "id", required = false) Long id) {
		if (id != null) {
			return epggroupService.findOne(id);
		}
		return null;
	}
}
