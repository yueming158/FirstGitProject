package com.smt.iptv.portal.i18nentity.dish;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.smt.iptv.portal.core.IdEntity;
import com.smt.iptv.portal.i18nentity.Category;
@Entity
@Table(name = "dishfeatured")
public class Dishfeatured extends IdEntity {
    
    public Dishfeatured() {
    }

    public Dishfeatured(Long id) {
        this.id = id;
    }
    
	private Dish dish;
	private Integer sequence;

    @ManyToOne
    @JoinColumn(name="dishid")
    public Dish getDish() {
        return dish;
    }

    public void setDish(Dish dish) {
        this.dish = dish;
    }

    public Integer getSequence() {
        return sequence;
    }

    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

}