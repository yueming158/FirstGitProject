package com.smt.iptv.portal.service.cmp;

import java.util.Date;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.entity.Liverecord;
import com.smt.iptv.portal.repository.video.LiverecordDao;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class LiverecordService extends BaseService<LiverecordDao, Liverecord> {
    public Integer getInnerCrossTimeRecor(String chancode,Date starttime,Date endtime){
        return dao.getInnerCrossTimeRecor(chancode, starttime, endtime).intValue();
    }
    
    public Integer getOuterCrossTimeRecord(String chancode,Date starttime){
        return dao.getOuterCrossTimeRecord(chancode, starttime).intValue();
    }
    
    public Integer getInnerCrossTimeRecor(Long id,String chancode,Date starttime,Date endtime){
        return dao.getInnerCrossTimeRecor(id,chancode, starttime, endtime).intValue();
    }
    
    public Integer getOuterCrossTimeRecord(Long id,String chancode,Date starttime){
        return dao.getOuterCrossTimeRecord(id,chancode, starttime).intValue();
    }
}
