package com.smt.iptv.portal.service.cmp;

import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.entity.Roomstatus;
import com.smt.iptv.portal.push.PushMessage;
import com.smt.iptv.portal.push.PushServer;
import com.smt.iptv.portal.repository.RoomstatusDao;
import com.smt.iptv.portal.service.task.BulletinTasker;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class RoomstatusService extends BaseService<RoomstatusDao, Roomstatus> {
    public List<Roomstatus> getAllOnOpen(){
        return dao.getAllOnOpen(new Date());
    }
    public List<Roomstatus> getLastRecordGroupByAccount(){
        return dao.getLastRecordGroupByAccount();
    }
    @Transactional(readOnly = false)
    public Roomstatus save(Roomstatus entity) {
        //如果是新增需要判断当前房间是否open
        if(entity.getId()==null){
            if(dao.getCountByAccount(entity.getAccount(),new Date())>0){
                return null;
            }
        }

        entity =dao.save(entity);
        //发送消息通知终端最新状态
        String content ="{\"status\":"+entity.getStatus()+",\"countdownsecond\":"+entity.getCountdownsecond()+"}";
        PushServer.sendMsg(entity.getAccount(), new PushMessage("roomstatus", content));
        //如果变化了 则刷新定时器中的数据
        BulletinTasker.setRoomstatusList(dao.getAllOnOpen(new Date()));
        //发送消息end
        return entity;
    }
}
