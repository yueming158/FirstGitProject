package com.smt.iptv.portal.i18nentity;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.portal.core.IdEntity;
import com.smt.iptv.portal.i18nentity.program.Program;
@Entity
@Table(name = "categoryprogram")
public class Categoryprogram extends IdEntity {
    
    public Categoryprogram() {
    }

    public Categoryprogram(Long id) {
        this.id = id;
    }
    
	private Category category;
	private Program program;
	private Integer sequence;

	@ManyToOne
	@JoinColumn(name="categoryid")
    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }
    @ManyToOne
    @JoinColumn(name="programid")
    public Program getProgram() {
        return program;
    }

    public Integer getSequence() {
        return sequence;
    }

    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

    public void setProgram(Program program) {
        this.program = program;
    }
    
}