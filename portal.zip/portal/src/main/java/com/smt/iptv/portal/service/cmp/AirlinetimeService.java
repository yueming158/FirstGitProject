package com.smt.iptv.portal.service.cmp;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springside.modules.mapper.JaxbMapper;

import com.smt.iptv.portal.core.HttpJDKUtil;
import com.smt.iptv.portal.entity.Airlinetime;
import com.smt.iptv.portal.repository.AirlinetimeDao;
import com.smt.iptv.portal.service.task.Airlines;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class AirlinetimeService extends BaseService<AirlinetimeDao, Airlinetime> {

    public List<Airlinetime> getAndSaveByAirlinecitycode(String startCity, String lastCity) {
        List<Airlinetime> list =dao.getByAirlinecitycode(startCity+lastCity);
        if(list==null||list.isEmpty()){
            Calendar c = Calendar.getInstance();
            c.add(Calendar.DAY_OF_MONTH, 2);
    
            String theDate = new SimpleDateFormat("yyyy-MM-dd").format(c.getTime());
            String url = "http://webservice.webxml.com.cn/webservices/DomesticAirline.asmx/getDomesticAirlinesTime?userID=&startCity=" + startCity + "&lastCity=" + lastCity + "&theDate=" + theDate;
            String xml = HttpJDKUtil.executeHttpGet(url, "utf-8");
            if (xml != null && xml.indexOf("<Airlines") != -1 && xml.indexOf("</Airlines>") != -1) {
                xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><DataSet>" + xml.substring(xml.indexOf("<Airlines"), xml.indexOf("</Airlines>"))
                        + "</Airlines></DataSet>";
                Airlines airlines = JaxbMapper.fromXml(xml.replace(":", "").replace("日<", "7<"), Airlines.class);
                if(airlines.getAirlines()!=null&&!airlines.getAirlines().isEmpty()&&StringUtils.isNotEmpty(airlines.getAirlines().get(0).getAirlinecode())){
                    for(Airlinetime at:airlines.getAirlines()){
                        at.setAirlinecitycode(startCity+lastCity);
                    }
                    list = (List<Airlinetime>) dao.save(airlines.getAirlines());
                }
            }
        }
        return list;
    }
}
