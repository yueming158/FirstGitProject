package com.smt.iptv.portal.web.program;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Maps;
import com.smt.iptv.portal.core.FileUploadUtil;
import com.smt.iptv.portal.i18nentity.program.Picture;
import com.smt.iptv.portal.i18nentity.program.Picturetype;
import com.smt.iptv.portal.i18nentity.program.Program;
import com.smt.iptv.portal.service.cmp.PictureService;
import com.smt.iptv.portal.service.cmp.PicturetypeService;
import com.smt.iptv.portal.service.cmp.ProgramService;

/**
 * Picture管理的Controller, 使用Restful风格的Urls:
 * 
 * List page : GET /picture/ Create page : GET /picture/create Create action :
 * POST /picture/create Update page : GET /picture/update/{id} Update action :
 * POST /picture/update Delete action : GET /picture/delete/{id}
 * 
 * @author xjw
 */
@Controller
@RequestMapping(value = "/picture")
public class PictureController {

    private static final int PAGE_SIZE = 50;

    private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
    static {
        sortTypes.put("auto", "自动");
        sortTypes.put("picturename", "名称");
    }

    @Autowired
    private PictureService pictureService;
    @Autowired
    private PicturetypeService picturetypeService;
    @Autowired
    private ProgramService programService;

    @RequestMapping(value = "/list")
    public String list(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");

        Page<Picture> pictures = pictureService.getPage(searchParams, pageNumber, PAGE_SIZE, sortType);

        model.addAttribute("pictures", pictures);
        model.addAttribute("sortType", sortType);
        model.addAttribute("sortTypes", sortTypes);
        // 将搜索条件编码成字符串，用于排序，分页的URL
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
        return "picture/pictureList";
    }

    @RequestMapping(value = "create", method = RequestMethod.GET)
    public String createForm(Model model) {
        model.addAttribute("picture", new Picture());
        model.addAttribute("action", "create");
        return "picture/pictureForm";
    }

    @RequestMapping(value = "create", method = RequestMethod.POST)
    public String create(@Valid Picture newPicture, RedirectAttributes redirectAttributes) {

        pictureService.save(newPicture);
        redirectAttributes.addFlashAttribute("message", "新增成功");
        return "redirect:/picture/list";
    }

    @RequestMapping(value = "update/{id}", method = RequestMethod.GET)
    public String updateForm(@PathVariable("id") Long id, Model model) {
        model.addAttribute("picture", pictureService.findOne(id));
        model.addAttribute("action", "update");
        return "picture/pictureForm";
    }

    @RequestMapping(value = "update", method = RequestMethod.POST)
    public String update(@Valid @ModelAttribute("preloadPicture") Picture picture, RedirectAttributes redirectAttributes) {
        pictureService.save(picture);
        redirectAttributes.addFlashAttribute("message", "保存成功");
        return "redirect:/picture/list";
    }

    @RequestMapping(value = "delete/{id}")
    public String delete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
        pictureService.delete(id);
        redirectAttributes.addFlashAttribute("message", "删除成功");
        return "redirect:/picture/list";
    }

    /**
     * 使用@ModelAttribute, 实现Struts2
     * Preparable二次部分绑定的效果,先根据form的id从数据库查出Picture对象,再把Form提交的内容绑定到该对象上。
     * 因为仅update()方法的form中有id属性，因此本方法在该方法中执行.
     */
    @ModelAttribute("preloadPicture")
    public Picture getPicture(@RequestParam(value = "id", required = false) Long id) {
        if (id != null) {
            return pictureService.findOne(id);
        }
        return null;
    }

    @RequestMapping(value = "program/{programid}", method = RequestMethod.GET)
    public String picture(@PathVariable("programid") Long programid, Model model) {
        Program program = programService.findOne(programid);
        List<Picturetype> picturetypes = picturetypeService.getByPicturetypecode(program.getProgramtype());
        model.addAttribute("picturetypes", picturetypes);
        model.addAttribute("program", program);
        return "/picture/picturePage";
    }

    @RequestMapping(value = "program/{programid}", method = RequestMethod.POST)
    public String pictureSave(@PathVariable("programid") Long programid, Model model,
            @RequestParam("file") MultipartFile multipartFile,
            @RequestParam(value = "picturetypeid") Long picturetypeid) {

        // 接受图片 保存在临时目录 并FTP到图片服务器这一步还没做
        if (multipartFile != null && multipartFile.getOriginalFilename() != null
                && multipartFile.getOriginalFilename().length() > 4) {
           
            // 压缩图片
            Picturetype picturetype =picturetypeService.findOne(picturetypeid);
            int  width = picturetype.getMaxwidth(); // 得到源图宽
            int  height = picturetype.getMaxheight(); // 得到源图长
            String relativePath ="program/";
            File file = FileUploadUtil.saveFile(multipartFile, relativePath,true,width,height);
            if(file==null){
                throw new RuntimeException("文件上传保存失败！");
            }
            
            try {
                Image src = javax.imageio.ImageIO.read(file); // 构造Image对象

                BufferedImage tag = new BufferedImage((int) width, (int) height, BufferedImage.TYPE_INT_RGB);   
                tag.getGraphics().drawImage(src.getScaledInstance(width, height, Image.SCALE_SMOOTH), 0, 0, null);  
                // JPEGImageEncoder可适用于其他图片类型的转换   
                ImageIO.write(tag, "jpg", file);
            } catch (IOException e) {
                e.printStackTrace();
            }
            // 将图片url等信息写入数据库
            Picture p = pictureService.getByProgramIdAndPicturetypeId(programid,picturetypeid);
            if(p==null){
                p = new Picture();
                p.setPicturetype(new Picturetype(picturetypeid));
                p.setProgram(new Program(programid));
            }else{
                FileUploadUtil.delete(p.getPictureurl());
            }
            p.setPicturename(file.getName());
            p.setPictureurl(relativePath+file.getName());
            p.setWidth(width);
            p.setHeight(height);
            p.setSize(file.length()+"");
            pictureService.save(p);
        }
        return "redirect:/picture/program/" + programid;
    }

    @RequestMapping(value = "program/{programid}/delete/{pictureid}", method = RequestMethod.GET)
    public String pictureDelete(@PathVariable("pictureid") Long pictureid, @PathVariable("programid") Long programid,
            HttpServletRequest request) {
        Picture picture = pictureService.findOne(pictureid);
        // 删除物理图片 //删除图片服务器上图片
        String rootPath ="/opt/upload/"+ picture.getPictureurl();
        /* 根据真实路径创建目录* */
        File file = new File(rootPath);
        try {
            file.delete();
        } catch (Exception e) {
        }
        pictureService.delete(pictureid);
        return "redirect:/picture/program/" + programid;
    }
}
