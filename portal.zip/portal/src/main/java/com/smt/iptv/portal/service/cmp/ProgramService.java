package com.smt.iptv.portal.service.cmp;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.core.CnToSpell;
import com.smt.iptv.portal.core.ServiceException;
import com.smt.iptv.portal.i18nentity.Category;
import com.smt.iptv.portal.i18nentity.program.Mediacontent;
import com.smt.iptv.portal.i18nentity.program.Picture;
import com.smt.iptv.portal.i18nentity.program.Picturetype;
import com.smt.iptv.portal.i18nentity.program.Program;
import com.smt.iptv.portal.i18nrepository.program.ProgramDao;
import com.smt.iptv.portal.model.SystemConstant;
import com.smt.iptv.portal.service.excel.ExcelDataArray;
import com.smt.iptv.portal.service.excel.POIExcelUtilProcess;
import com.smt.iptv.portal.web.ftp.FtpReader;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class ProgramService extends BaseService<ProgramDao, Program> {

    @Autowired
    private PictureService pictureService;
    
    @Autowired
    private MediacontentService mediacontentService;
    
    @Autowired
    private CategoryprogramService categoryprogramService;
   
    @Autowired
    private PicturetypeService picturetypeService;
    
    @Override
    @Transactional(readOnly = false)
    public void delete(Long id) {
        //在所有分类中删除节目 自动的
        //删除演员关系   自动的
        //删除类型关系   自动的
        //删除所有相关图片
        pictureService.deleteByProgramId(id);
        //删除所有媒体数据  连带删除了虚拟频道conten数据
        mediacontentService.deleteByProgramId(id);//
        //删除自己
        dao.delete(id);
    }
    
    public void batchadd(String categoryids,String excelpath ,String urltype){
        String filepath=SystemConstant.getURLValue("media_server_ftpurl_"+urltype);
        FtpReader.downFile(filepath+excelpath, "/res/");
        int lastindex =excelpath.lastIndexOf("/");
        String fileName="";
        if(lastindex==-1){
            fileName=excelpath;
        }else{
            fileName=excelpath.substring(lastindex+1);
        }
        File file = new File("/res/"+fileName);
        ExcelDataArray excelDataArray = null;
        if (file != null && file.isFile() 
                && (file.getName().endsWith(".xls")||file.getName().endsWith(".xlsx"))) {
            try {
                final int startRow = 1; //Excel数据开始的行数
                excelDataArray = POIExcelUtilProcess.importExcelFileToDataArray(new FileInputStream(file), startRow);
                if(excelDataArray!=null){
                    for(String [] row: excelDataArray.getDataArray()){
                        if(row==null||(row.length!=11)){
                            throw new RuntimeException("excel导入数据格式不正确");
                        }
                        Program p =new Program();
                        p.setProgramname(row[1]);
                        p.setYear(row[2]);
                        p.setStarrating(row[3].matches("\\d0")?row[4]:"100");
                        p.setAreaname(row[4]);
                        p.setGenrenames(row[5]);
                        p.setActornames(row[6]);
                        p.setWriternames(row[7]);
                        p.setDescription(row[8]);
                        p.setPrice(row[9].matches("\\d+")?Integer.parseInt(row[9]):0);
                        p.setLevel(row[10].matches("\\d+")?Integer.parseInt(row[10]):0);
                        p.setSearchname(CnToSpell.getSimpleSpell(p.getProgramname()));
                        p.setProgramtype("10");
                        p.setStatus("1");
                        //保存开始
                        dao.save(p);
                        p.setCpobjectcode(new DecimalFormat("PG"+LocaleContextHolder.getLocale().getLanguage().toUpperCase()+"0000000000").format(p.getId()));
                        dao.save(p);
                        Mediacontent m = new Mediacontent();
                        m.setProgram(p);
                        m.setSequence("1");
                        m.setStatus("0");
                        m.setDeleteflag("1");
                        m.setUrltype(urltype);//f f1 f2 f3
                        if(excelpath.indexOf("/")==-1){
                            m.setSourcefilename(row[0]);
                        }else{
                            m.setSourcefilename(excelpath.substring(0,excelpath.lastIndexOf("/")+1)+row[0]);
                        }
                        mediacontentService.save(m);
                        m.setCpobjectcode(new DecimalFormat("MOV"+LocaleContextHolder.getLocale().getLanguage().toUpperCase()+"0000000000@CRI").format(m.getId()));
                        mediacontentService.save(m);
                        //导航新增
                        categoryprogramService.save(p.getId(), categoryids);
                        //保存结束
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
                throw new ServiceException("xlsx文件内容格式不正确："+e.getMessage());
            }
        }else{
            throw new ServiceException("xlsx文件读取到本地失败");
        }
        file.delete();
    }

	public Map<String,Object> exportProgram() {
		Map<String,Object> map = new HashMap<String, Object>();
		List<String> pictures = new ArrayList<String>();
		HSSFWorkbook wb = new HSSFWorkbook();
        //生成一个sheet1
        HSSFSheet sheet = wb.createSheet("sheet1");
        //为sheet1生成第一行，用于放表头信息
        String[] heard = {"节目名称","节目导航","内容类型","评级","发行地区","出品年份","演员","导演","剧情介绍","点播小海报","点播大海报","价格","观看级别","影片类型"};
        createRow(sheet, 0, heard);
        List<Program> programs = getAll();
        if(null != programs && programs.size()>0)
        for (int i=0; i<programs.size();i++) {
        	Program program = programs.get(i);
        	List<Picture> pictureList = program.getPicturelist();
        	if(null!=pictureList && pictureList.size()>0){
        		for (Picture picture : pictureList) {
            		pictures.add(picture.getPictureurl());
				}
        	}
        	createRow(sheet, i+1, getProgramArray(program));
		}
        map.put("pictures", pictures);
        map.put("exportexcel", wb);
		return map;
	}
	
	
	private void createRow(HSSFSheet sheet,int rowNumber,Object[] values){
		HSSFRow row = sheet.createRow(rowNumber);
		for (int i=0;i<values.length;i++) {
			createCell(row, i, values[i]);
		}
	}
	
	private void createCell(HSSFRow row,int cellNumber,Object value){
		HSSFCell cell = row.createCell(cellNumber);
		if(value instanceof String){
		    cell.setCellValue((String)value);
		}else if(value instanceof Long) {
			  cell.setCellValue(((Long)value).toString());
		}else if(value instanceof Double) {
			  cell.setCellValue(((Double)value).toString());
		}else if(value instanceof Integer) {
			  cell.setCellValue(((Integer)value).toString());
		}else if(value instanceof Date) {
			  cell.setCellValue((Date)value);
		}
	}
	
	private Object[] getProgramArray(Program program){
		Object[] objectArray = new Object[14];
		objectArray[0] = program.getProgramname();
		List<Category> categoryList = program.getCategorylist();
		objectArray[1] = categorys(categoryList);
		objectArray[2] = program.getGenrenames();
		objectArray[3] = program.getStarrating();
		objectArray[4] = program.getAreaname();
		objectArray[5] = program.getYear();
		objectArray[6] = program.getActornames();
		objectArray[7] = program.getWriternames();
		objectArray[8] = program.getDescription();
		objectArray[9] = null;
		objectArray[10] = null;
		List<Picture> pictureList = program.getPicturelist();
		if(null!=pictureList && pictureList.size()>0){
			if(pictureList.size()==1){
				Picture picture = pictureList.get(0);
				picture(objectArray, picture);
			}else if(pictureList.size()==2){
				Picture picture = pictureList.get(0);
				picture(objectArray, picture);
				picture = pictureList.get(1);
				picture(objectArray, picture);
			}
		}
		objectArray[11] = program.getPrice();
		objectArray[12] = program.getLevel();
		objectArray[13] = program.getVip();
		return objectArray;
	}

	private void picture(Object[] objectArray, Picture picture) {
		if(picture.getPicturetype().getId()==1){
			objectArray[9] = picture.getPictureurl();
		}else {
			objectArray[10] = picture.getPictureurl();
		}
	}
	

	private String categorys(List<Category> categoryList){
		StringBuffer categorys = new StringBuffer();
		if(null!=categoryList && categoryList.size()>0){
			for(int i=0; i<categoryList.size();i++) {
				categorys.append(categoryList.get(i).getId());
				if(i<categoryList.size()-1){
					categorys.append(",");
				}
			}
		}
		return categorys.toString();
	}

	public void importprograms(String xlsPath) {
		HSSFWorkbook  wb = null;
		HSSFSheet sheet = null;
		HSSFRow row = null; 
		FileInputStream inputStream = null;
		if(null == xlsPath){
			return;
		}
		//解析excel
		try {
			inputStream = new FileInputStream(xlsPath);
			wb = new HSSFWorkbook(inputStream);
			sheet = wb.getSheetAt(0);
			//得到总行数
	        int rowNum = sheet.getLastRowNum();
	        row = sheet.getRow(0);
	        int colNum = row.getPhysicalNumberOfCells();
	        // 正文内容应该从第二行开始,第一行为表头的标题
	        for (int i = 1; i <= rowNum; i++) {
	            row = sheet.getRow(i);
	            int j = 0;
	            String objects[] = new String[colNum];
	            while (j < colNum) {
	                // 每个单元格的数据内容用"-"分割开，以后需要时用String类的replace()方法还原数据
	                // 也可以将每个单元格的数据设置到一个javabean的属性中，此时需要新建一个javabean
	                // str += getStringCellValue(row.getCell((short) j)).trim() +
	                // "-";
	            	objects[j] = getCellFormatValue(row.getCell(j));
	            	j++;
	            }
	            Program program = constructProgram(objects);
	            //新增节目
	            program.setSearchname(CnToSpell.getSimpleSpell(program.getProgramname()));
	            program.setStatus("0");
	            program.setProgramtype("10");
	            create(program, "cpobjectcode", "progam0000000000");
	    		savePictureList(objects[9],objects[10],program);
	        }
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			IOUtils.closeQuietly(inputStream);
			//删除文件
			File file = new File(xlsPath);
			if(file.exists()){
				file.delete();
			}
		}
		
		
	}
	
	
    private Program constructProgram(String[] objects) {
    	Program program = new Program();
		program.setProgramname(objects[0]);
		List<Category> categoryList = getCategoryList(objects[1]);		
		program.setCategorylist(categoryList);
		program.setGenrenames(objects[2]);
		program.setStarrating(objects[3]);
		program.setAreaname(objects[4]);
		program.setYear(objects[5]);
		program.setActornames(objects[6]);
		program.setWriternames(objects[7]);
		program.setDescription(objects[8]);
		if(!"".equals(objects[11].trim())){
			program.setPrice(Integer.valueOf(objects[11]));
		}
		if(!"".equals(objects[12].trim())){
			program.setPrice(Integer.valueOf(objects[12]));
		}
		program.setVip(objects[13]);
		return program;
	}

	private void  savePictureList(String picture1, String picture2,Program program) {
		if("".equals(picture1.trim())&&"".equals(picture2.trim())){
			return;
		}
		Picture smallPicture = new Picture();
		Picture bigPicture = new Picture();
		savePicture(picture1, program, smallPicture,0);
		savePicture(picture2, program, bigPicture,1);
	}

	private void savePicture(String picture1, Program program,
			Picture smallPicture,int index) {
		List<Picturetype>  ptypelist =picturetypeService.getByPicturetypecode(program.getProgramtype());
		smallPicture.setPicturetype(new Picturetype(ptypelist.get(index).getId()));
		smallPicture.setProgram(program);
		smallPicture.setPictureurl(picture1);
        pictureService.save(smallPicture);
	}

	private List<Category> getCategoryList(String category) {
		List<Category> categories = new ArrayList<Category>();
		if(null != category && !"".equals(category.trim())) {
			String categoryArray[] = category.split(",");
			for (String categoryId : categoryArray) {
				categories.add(new Category(Long.valueOf(categoryId)));
			}
		}
		return categories;
	}

	 /**
     * 根据HSSFCell类型设置数据
     * @param cell
     * @return
     */
    private String getCellFormatValue(HSSFCell cell) {
        String cellvalue = "";
        if (cell != null) {
            // 判断当前Cell的Type
            switch (cell.getCellType()) {
            // 如果当前Cell的Type为NUMERIC
            case HSSFCell.CELL_TYPE_NUMERIC:
            case HSSFCell.CELL_TYPE_FORMULA: {
                // 判断当前的cell是否为Date
                if (HSSFDateUtil.isCellDateFormatted(cell)) {
                    // 如果是Date类型则，转化为Data格式
                    
                    //方法1：这样子的data格式是带时分秒的：2011-10-12 0:00:00
                    //cellvalue = cell.getDateCellValue().toLocaleString();
                    
                    //方法2：这样子的data格式是不带带时分秒的：2011-10-12
                    Date date = cell.getDateCellValue();
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    cellvalue = sdf.format(date);
                    
                }
                // 如果是纯数字
                else {
                    // 取得当前Cell的数值
                    cellvalue = String.valueOf(cell.getNumericCellValue());
                }
                break;
            }
            // 如果当前Cell的Type为STRIN
            case HSSFCell.CELL_TYPE_STRING:
                // 取得当前的Cell字符串
                cellvalue = cell.getRichStringCellValue().getString();
                break;
            // 默认的Cell值
            default:
                cellvalue = "";
            }
        } else {
            cellvalue = "";
        }
        return cellvalue;

    }
}

