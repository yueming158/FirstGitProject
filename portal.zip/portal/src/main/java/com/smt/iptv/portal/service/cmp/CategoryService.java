package com.smt.iptv.portal.service.cmp;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.entity.Channel;
import com.smt.iptv.portal.i18nentity.Category;
import com.smt.iptv.portal.i18nentity.Game;
import com.smt.iptv.portal.i18nentity.Info;
import com.smt.iptv.portal.i18nentity.program.Program;
import com.smt.iptv.portal.i18nrepository.CategoryDao;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class CategoryService extends BaseService<CategoryDao, Category> {

    /**
     * 获取分类下的program
     * 
     * @param categoryid
     * @param programname
     * @param pageNumber
     * @param pageSize
     * @param sortType
     * @return
     */
    public Page<Program> getProgramByCategory(Long categoryid, String programname, int pageNumber, int pageSize,
            String sortType) {
        PageRequest pageRequest = buildPageRequest(pageNumber, pageSize, sortType);
        if (programname == null) {
            return dao.getProgramByCategory(categoryid, pageRequest);
        } else {
            programname = "%" + programname + "%";
            return dao.getProgramByCategory(categoryid, programname, pageRequest);
        }
    }

    /**
     * 获取某个类型下 未分类的节目
     * 
     */
    public Page<Program> getProgramExceptCategory(Long categoryid, String programtype, String name, int pageNumber,
            int pageSize, String sortType) {
        PageRequest pageRequest = buildPageRequest(pageNumber, pageSize, sortType);
        if (name == null) {
            return dao.getProgramExceptCategory(categoryid, programtype, pageRequest);
        } else {
            name = "%" + name + "%";
            return dao.getProgramExceptCategory(categoryid, programtype,name, pageRequest);
        }
    }



    @Transactional(readOnly = false)
    public boolean deleteSingleCategory(Long categoryid,String type){
        if(type!=null){
            Long id ;
            if("50".equals(type)){
                id=dao.getDeleteDishCategory(categoryid);
            }else if("51".equals(type)){
                id=dao.getDeleteGoodsCategory(categoryid);
            }else if("10".equals(type)){
                id=dao.getDeleteProgramCategory(categoryid);
            }else{
                return false;
            }
            if(id!=null){
                dao.delete(id);
                return true;
            }
        }
        return false;
    }
    
    public List<Category> getByCategorytype(String categorytype){
        return dao.getByCategorytype(categorytype);
    }
    public List<Category> getByCategorytypeAndParentid(String categorytype,Long parentid){
        return dao.getByCategorytypeAndParentid(categorytype,parentid);
    }
}
