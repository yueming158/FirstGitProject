package com.smt.iptv.portal.i18nrepository;

import com.smt.iptv.portal.i18nentity.Epggroup;
import com.smt.iptv.portal.repository.BaseDao;

public interface EpggroupDao extends BaseDao<Epggroup> {
}
