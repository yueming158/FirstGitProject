package com.smt.iptv.portal.web.program;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.smt.iptv.portal.core.HttpJDKUtil;
import com.smt.iptv.portal.core.StaticConstant;
import com.smt.iptv.portal.core.TelnetUtil;
import com.smt.iptv.portal.entity.Globalconfig;
import com.smt.iptv.portal.model.SystemConstant;
import com.smt.iptv.portal.service.cmp.GlobalconfigService;
import com.smt.iptv.portal.service.task.StbrestartJob;

/**
 * Globalconfig管理的Controller, 使用Restful风格的Urls:
 * 
 * @author xjw
 */
@Controller
@RequestMapping(value = "/globalconfig")
public class GlobalconfigController {

	private static final int PAGE_SIZE = 200;

	private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
	static {
		sortTypes.put("name", "自动");
		sortTypes.put("name", "名称");
	}

	@Autowired
	private GlobalconfigService globalconfigService;
    @Autowired
    StbrestartJob stbrestartJob;
	@RequestMapping(value = "/list")
	public String list(String mediacfg,String user, Model model) {
		List<Globalconfig> globalconfigs = globalconfigService.findAll(new Sort("name"));
        List<Globalconfig> mediacfgs =Lists.newArrayList();
        List<Globalconfig> cfgs =Lists.newArrayList();
        for(Globalconfig g:globalconfigs){
            if(g.getName().startsWith("CDN_")||g.getName().startsWith("media_server")
                    ||"load_balancing_vod".equals(g.getName())||"load_balancing".equals(g.getName())){
                String url = g.getValue();
                if (StringUtils.isNotBlank(url)&&url.matches("http://\\d+\\.\\d+\\.\\d+\\.\\d+:\\d+/.*")){
                        url= url.endsWith("/") ? url : url + "/";
                        int index =url.lastIndexOf(":");
                        String ip=url.substring(7, index);
                        String port=url.substring(index+1);
                        port =port.substring(0, port.indexOf("/"));
                        if(TelnetUtil.getHostStatus(ip,Integer.parseInt(port))){
                            g.setStatus("on");
                        }else{
                            g.setStatus("off");
                        }
                }
                mediacfgs.add(g);
            }
            if("HTTP_HEXUNRATE_ADDRESS".equals(g.getName())
                    ||"fileupload".equals(g.getName())
                    ||"push_server_port".equals(g.getName())
                    ||"cdn_httpserver_local_path".equals(g.getName())){ 
                cfgs.add(g);
            }
        }
        globalconfigs.removeAll(cfgs);
        globalconfigs.removeAll(mediacfgs);
        if("d".equals(user)){
            model.addAttribute("globalconfigs", "on".equals(mediacfg)?mediacfgs:globalconfigs);
        }else{
            model.addAttribute("globalconfigs", mediacfgs);
        }
        Page<Globalconfig> page = new PageImpl(globalconfigs,new PageRequest(0, 200),globalconfigs.size());
        model.addAttribute("page", page);
		return "globalconfig/globalconfigList";
	}

	@RequestMapping(value = "create", method = RequestMethod.GET)
	public String createForm(Model model) {
		model.addAttribute("globalconfig", new Globalconfig());
		model.addAttribute("action", "create");
		return "globalconfig/globalconfigForm";
	}

	@RequestMapping(value = "create", method = RequestMethod.POST)
	public String create(@Valid Globalconfig newGlobalconfig, RedirectAttributes redirectAttributes) {

		globalconfigService.save(newGlobalconfig);
		redirectAttributes.addFlashAttribute("message", "新增成功");
		return "redirect:/globalconfig/list";
	}

	@RequestMapping(value = "update/{id}", method = RequestMethod.GET)
	public String updateForm(@PathVariable("id") Long id, Model model) {
		model.addAttribute("globalconfig", globalconfigService.findOne(id));
		model.addAttribute("action", "update");
		return "globalconfig/globalconfigForm";
	}

	@RequestMapping(value = "update", method = RequestMethod.POST)
	public String update(@Valid @ModelAttribute("preloadGlobalconfig") Globalconfig globalconfig, RedirectAttributes redirectAttributes) {
		globalconfigService.save(globalconfig);
		//修改重启机顶盒指令
		if(StaticConstant.CFG_STBRESTARTJOB_HOUR.equals(globalconfig.getName())){
	        Integer hournum=-1;
	        try{
	            hournum=Integer.parseInt(globalconfig.getValue());
	            if(hournum>=0&&hournum<=23){
	                String cron = "0 0 "+globalconfig.getValue()+" * * ?";
	                if(!cron.equals(stbrestartJob.getCronExpression())){
    	                stbrestartJob.setCronExpression(cron); //?cron=0 0 0 * * ?  cron%3d0+*+*+*+*+%3f
    	                stbrestartJob.stop();
    	                stbrestartJob.start();
	                }
	            }
	        }catch (Exception e) {
	            
	        }
		}
		//修改重启机顶盒指令end
		//修改后自动更新
        List<Globalconfig> list = globalconfigService.getAll();
        for (Globalconfig g : list) {
            SystemConstant.map.put(g.getName(), g.getValue());
        }
        String sucess=HttpJDKUtil.executeHttpGet(SystemConstant.getURLValue("epg_server_address")+"refreshcfg", "utf-8");
		redirectAttributes.addFlashAttribute("message", "保存成功");
		return "redirect:/globalconfig/list";
	}

	@RequestMapping(value = "delete/{id}")
	public String delete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
		globalconfigService.delete(id);
		redirectAttributes.addFlashAttribute("message", "删除成功");
		return "redirect:/globalconfig/list";
	}

	/**
	 * 使用@ModelAttribute, 实现Struts2 Preparable二次部分绑定的效果,先根据form的id从数据库查出Globalconfig对象,再把Form提交的内容绑定到该对象上。
	 * 因为仅update()方法的form中有id属性，因此本方法在该方法中执行.
	 */
	@ModelAttribute("preloadGlobalconfig")
	public Globalconfig getGlobalconfig(@RequestParam(value = "id", required = false) Long id) {
		if (id != null) {
			return globalconfigService.findOne(id);
		}
		return null;
	}

}
