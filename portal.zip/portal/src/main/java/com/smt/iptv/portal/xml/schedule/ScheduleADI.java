package com.smt.iptv.portal.xml.schedule;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.google.common.collect.Lists;

/**
 * 使用JAXB2.0标注的待转换Java Bean.
 */
//根节点
@XmlRootElement(name="ADI")
//指定子节点的顺序
@XmlType(propOrder = {"namespace","cpCode","staffID", "objs"})
public class ScheduleADI {
    
    private String cpCode ="iptv";
    
    private String staffID="admin";
    
	private List<ScheduleNodeObject> objs = Lists.newArrayList();
	
    private String namespace ="http://www.w3.org/2001/XMLSchema-instance";
	

    @XmlAttribute(name="StaffID")
    public String getStaffID() {
        return staffID;
    }

    @XmlAttribute(name="CPCode")
    public String getCpCode() {
        return cpCode;
    }

    public void setCpCode(String cpCode) {
        this.cpCode = cpCode;
    }

    public void setStaffID(String staffID) {
        this.staffID = staffID;
    }

    @XmlElementWrapper(name = "Objects")
    @XmlElement(name = "Object")
    public List<ScheduleNodeObject> getObjs() {
        return objs;
    }


    public void setObjs(List<ScheduleNodeObject> objs) {
        this.objs = objs;
    }

    
    @XmlAttribute(name="xmlns:xsi")
    public String getNamespace() {
        return namespace;
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
