package com.smt.iptv.portal.i18nentity.music;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.smt.iptv.portal.core.IdEntity;

@Entity
@Table(name = "musiccategorymap")
public class Musiccategorymap extends IdEntity{
    private Musiccategory musiccategory;
    private Music music;
    private Integer sequence;
    @ManyToOne
    @JoinColumn(name="musiccategoryid")
    public Musiccategory getMusiccategory() {
        return musiccategory;
    }
    public void setMusiccategory(Musiccategory musiccategory) {
        this.musiccategory = musiccategory;
    }
    @ManyToOne
    @JoinColumn(name="musicid")
    public Music getMusic() {
        return music;
    }
    public void setMusic(Music music) {
        this.music = music;
    }
    public Integer getSequence() {
        return sequence;
    }
    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

}
