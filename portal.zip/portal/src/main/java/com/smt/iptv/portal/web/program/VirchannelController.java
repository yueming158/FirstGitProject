package com.smt.iptv.portal.web.program;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Maps;
import com.smt.iptv.portal.entity.Channel;
import com.smt.iptv.portal.entity.Virschedule;
import com.smt.iptv.portal.i18nentity.program.Mediacontent;
import com.smt.iptv.portal.service.cmp.ChannelService;
import com.smt.iptv.portal.service.cmp.MediacontentService;
import com.smt.iptv.portal.service.cmp.VirscheduleService;

/**
 * Channel管理的Controller, 使用Restful风格的Urls:
 * 
 * @author xjw
 */
@Controller
@RequestMapping(value = "/virchannel")
public class VirchannelController {

	private static final int PAGE_SIZE = 50;

	private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
	static {
		sortTypes.put("auto", "自动");
		sortTypes.put("channelname", "名称");
		sortTypes.put("channelnumber", "频道号");
	}

	@Autowired
	private ChannelService channelService;
	@Autowired
	private VirscheduleService virscheduleService;
	@Autowired
	private MediacontentService mediacontentService;
	/**
	 * 虚拟频道列表
	 * @param sortType
	 * @param pageNumber
	 * @param model
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/list")
	public String list(@RequestParam(value = "sortType", defaultValue = "channelnumber") String sortType,
			@RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
		Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");

		Page<Channel> channels = channelService.getPage( searchParams, pageNumber, PAGE_SIZE, sortType);

		model.addAttribute("channels", channels);
		model.addAttribute("sortType", sortType);
		model.addAttribute("sortTypes", sortTypes);
		// 将搜索条件编码成字符串，用于排序，分页的URL
		model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
		return "virchannel/virchannelList";
	}
	/**
	 * 虚拟频道的节目单列表
	 * @param sortType
	 * @param pageNumber
	 * @param model
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/schedulelist")
    public String scheduleList(@RequestParam(value = "sortType", defaultValue = "seq") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");

        Page<Virschedule> virschedules = virscheduleService.getPage( searchParams, pageNumber, 1000, sortType);

        model.addAttribute("virschedules", virschedules);
        model.addAttribute("sortType", sortType);
        Map<String, String> schedulesortTypes = Maps.newLinkedHashMap();
        schedulesortTypes.put("seq", "自动");
        schedulesortTypes.put("delaytime", "延迟时间");
        model.addAttribute("sortTypes", schedulesortTypes);
        // 将搜索条件编码成字符串，用于排序，分页的URL
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
        //if()
        if(channelService.findOne(Long.parseLong((String) searchParams.get("EQ_channel.id"))).getCycletime()==0){
            return "virchannel/virscheduleList";
        }else{
            return "virchannel/virscheduleList2";
        }
    }
	
	/**
	 * 待选节目单列表
	 * @param sortType
	 * @param pageNumber
	 * @param model
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "mediacontentlist", method = RequestMethod.GET)
    public String mediacontentlist(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request,
            Long channelId) {

        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");
        searchParams.put("EQ_urltype", "m");
        searchParams.put("EQ_status", "0");
        Page<Mediacontent> mediacontents = mediacontentService.getPage(searchParams, pageNumber, PAGE_SIZE, sortType);
        model.addAttribute("mediacontents", mediacontents);
        model.addAttribute("sortType", sortType);
        model.addAttribute("sortTypes", sortTypes);
        // 将搜索条件编码成字符串，用于排序，分页的URL
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_")+"&channelId="+channelId);
        model.addAttribute("channelId", channelId);
        model.addAttribute("action", "create");
        return "virchannel/virprogramselect";
    }

	/**
	 * 新增节目媒体内容到虚拟频道的关联关系
	 * @param redirectAttributes
	 * @param channCode
	 * @param contentids
	 * @return
	 */
    @RequestMapping(value = "selectadd/{channelId}")
    public String create(RedirectAttributes redirectAttributes,
            @PathVariable("channelId") Long channelId, @RequestParam(defaultValue="1") int days,
            @RequestParam(value = "contentids") String contentids) {
        String[] idsArr = contentids.split(",");
        
        List<Virschedule> list = new ArrayList<Virschedule>();
        for (String id : idsArr) {
            if (id.matches("\\d+")) {
                Mediacontent m = mediacontentService.findOne(Long.valueOf(id)); 
                
                Virschedule content = new Virschedule();
                content.setChannel(new Channel(channelId));
                content.setCpobjectcode(m.getCpobjectcode());
                String viewname =m.getMediacontentname();
                if(m.getProgram()!=null){
                    viewname=m.getProgram().getProgramname()+" - "+viewname;
                }
                content.setContentname(viewname);
                if(m.getDuration()==null){
                    content.setDelaytime(0);
                }else{
                    content.setDelaytime((days-1)*86400);
                }
                content.setSeq(0);
                //记住原始片源名称和时长
                content.setOldduration((m.getDuration()/1000)<0?0:(m.getDuration()/1000));
                content.setOldname(viewname);
                
                list.add(content);
            }
        }
        virscheduleService.save(list);
        redirectAttributes.addFlashAttribute("message", "创建成功");
        return "redirect:/virchannel/schedulelist?search_EQ_channel.id="+channelId;
    }
    /**
     * 删除关联关系
     * @param id
     * @param redirectAttributes
     * @param channCode
     * @return
     */
    @RequestMapping(value = "delete/{id}")
    public String delete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes,
            @RequestParam(value = "channelId") String channelId) {
        virscheduleService.delete(id);
        redirectAttributes.addFlashAttribute("message", "删除成功");
        return "redirect:/virchannel/schedulelist?search_EQ_channel.id=" + channelId;
    }
    
    /**
     * 编排节目单
     * @param id
     * @param redirectAttributes
     * @param channCode
     * @return
     */
    @RequestMapping(value = "updateschedule")
    public String updateschedule(@RequestParam(value = "sortType", defaultValue = "seq") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, ServletRequest request,
            RedirectAttributes redirectAttributes) {

        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");
        Page<Virschedule> virschedules = virscheduleService.getPage( searchParams, pageNumber, PAGE_SIZE, sortType);
        
        String [] ids =request.getParameterValues("ids");
        String [] contentnames =request.getParameterValues("contentnames");
        String [] delaytimes =request.getParameterValues("delaytimes");
        String [] seqs =request.getParameterValues("seqs");
        for(int i=0;i< virschedules.getContent().size();i++){
            Virschedule vs =virschedules.getContent().get(i);
            if(i<ids.length&&ids[i].equals(vs.getId()+"")&&delaytimes[i].matches("\\d+")&&seqs[i].matches("\\d+")){
                vs.setDelaytime(Integer.parseInt(delaytimes[i]));
                vs.setContentname(contentnames[i]);
                vs.setSeq(Integer.parseInt(seqs[i]));
            }
        }
        virscheduleService.save(virschedules.getContent());  
        
        // 将搜索条件编码成字符串，用于排序，分页的URL
        redirectAttributes.addFlashAttribute("message", "修改成功");
        return "redirect:/virchannel/schedulelist?search_EQ_channel.id=" + request.getParameter("search_EQ_channel.id");
    }   
}
