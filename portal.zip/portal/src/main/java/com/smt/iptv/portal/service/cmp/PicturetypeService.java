package com.smt.iptv.portal.service.cmp;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.i18nentity.program.Picturetype;
import com.smt.iptv.portal.i18nrepository.program.PicturetypeDao;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class PicturetypeService extends BaseService<PicturetypeDao, Picturetype> {

    public List<Picturetype> getByPicturetypecode(String picturetypecode) {
        return dao.getByPicturetypecode(picturetypecode);
    }

    public Long getByPictureCountByType(Long picturetypeid) {
        return dao.getByPictureCountByType(picturetypeid);
    }
}
