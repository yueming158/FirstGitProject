package com.smt.iptv.portal.repository.video;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.smt.iptv.portal.entity.Channel;
import com.smt.iptv.portal.repository.BaseDao;

public interface ChannelDao extends BaseDao<Channel> {
    @Query("delete from Slavechannel where channel.id=?1")
    @Modifying
    void deleteSlavechannel(Long id);
    @Query("delete from Virschedule where channel.id=?1")
    @Modifying
    void deleteVirschedule(Long id);
    
}
