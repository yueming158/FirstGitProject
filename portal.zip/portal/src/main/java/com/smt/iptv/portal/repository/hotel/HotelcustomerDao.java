package com.smt.iptv.portal.repository.hotel;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.smt.iptv.portal.entity.hotel.Hotelcustomer;
import com.smt.iptv.portal.entity.hotel.Hotelroom;
import com.smt.iptv.portal.repository.BaseDao;

public interface HotelcustomerDao extends BaseDao<Hotelcustomer> {
    @Query("SELECT r from Hotelroom r WHERE not EXISTS(SELECT 1 FROM Hotelcustomer c WHERE c.hotelroom.id=r.id and c.status='1')")
    public List<Hotelroom> getEmptyRoomList();
    
    public List<Hotelcustomer> getByHotelroomIdAndStatus(Long id,String status);
    public List<Hotelcustomer> getByStatus(String status);
    @Query("update Hotelcall set checkinstatus=?2 where iptvusername=?1 and checkinstatus<>?2")
    @Modifying
    public void updateHotelcallStatus(String iptvusername,String status);
    
    @Query(nativeQuery=true, value="update bulletinstatus set expirestatus=?2 where iptvprofileid=?1 and EXISTS (select 1 from bulletin where bulletin.id=bulletinid and bulletin.type='3')")
    @Modifying
    public void updateBulletinStatus(Long id,String status);
    
    public List<Hotelcustomer> getByHotelroomRoomno(String roomNo);
    public List<Hotelcustomer> getByHotelroomRoomnoAndStatus(String roomNo,String status);
    
    @Query("SELECT c from Hotelcustomer c WHERE c.id=(SELECT max(id) FROM Hotelcustomer c2 WHERE c2.hotelroom.roomno=?1)")
    public Hotelcustomer getLastGuestByRoomno(String roomNo);
    //public void updateHotelcallStatus(Long id,String status);
}
