package com.smt.iptv.portal.entity.role;

import javax.persistence.Entity;
import javax.persistence.Table;

import com.smt.iptv.portal.core.IdEntity;

@Entity
@Table(name = "epg_resource")
public class Resource extends IdEntity {
    public Resource() {
    }

    public Resource(Long id) {
        this.id = id;
    }
    private String name; //资源名称
    private String url; //资源路径
    private String permission; //权限字符串
    private String enabled; //是否开启
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getUrl() {
        return url;
    }
    public void setUrl(String url) {
        this.url = url;
    }
    public String getPermission() {
        return permission;
    }
    public void setPermission(String permission) {
        this.permission = permission;
    }

    public String getEnabled() {
        return enabled;
    }

    public void setEnabled(String enabled) {
        this.enabled = enabled;
    }

}
