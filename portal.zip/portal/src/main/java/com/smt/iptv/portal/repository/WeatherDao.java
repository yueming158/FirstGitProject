package com.smt.iptv.portal.repository;

import java.util.Date;
import java.util.List;

import com.smt.iptv.portal.entity.Weather;

public interface WeatherDao extends BaseDao<Weather> {
    
    public List<Weather> findByCitycode(String citycode);
    public Weather findByCitycodeAndWeatherdate(String citycode,Date date); 
    public List<Weather> findByCitycodeAndWeatherdateBetween(String citycode,Date startDate,Date endDate);
}
