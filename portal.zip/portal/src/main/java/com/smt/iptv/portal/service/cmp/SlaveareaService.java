package com.smt.iptv.portal.service.cmp;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.entity.Slavearea;
import com.smt.iptv.portal.repository.video.SlaveareaDao;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class SlaveareaService extends BaseService<SlaveareaDao, Slavearea> {

}
