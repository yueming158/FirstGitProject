package com.smt.iptv.portal.entity.hotel;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.format.annotation.DateTimeFormat;

import com.smt.iptv.portal.core.IdEntity;

@Entity
@Table(name = "hotelcall")
public class Hotelcall extends IdEntity {
    
    public Hotelcall() {
    }

    public Hotelcall(Long id) {
        this.id = id;
    }
    private String roomname;
    private String iptvusername;
	private String reqtype; // 1退房 2续房 3叫醒服务 4打扫房间 5洗衣服务
	private String reqstatus;//1待处理 2已响应 3已进行（完成）4已取消
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date appointmenttime;
	private Date reqtime;
	private Date rsptime;
	private Date comptime;
	private String checkinstatus;
	
    public String getRoomname() {
        return roomname;
    }

    public void setRoomname(String roomname) {
        this.roomname = roomname;
    }

    public String getIptvusername() {
        return iptvusername;
    }

    public void setIptvusername(String iptvusername) {
        this.iptvusername = iptvusername;
    }

    public String getReqtype() {
        return reqtype;
    }

    public void setReqtype(String reqtype) {
        this.reqtype = reqtype;
    }

    public String getReqstatus() {
        return reqstatus;
    }

    public void setReqstatus(String reqstatus) {
        this.reqstatus = reqstatus;
    }

    public Date getAppointmenttime() {
        return appointmenttime;
    }

    public void setAppointmenttime(Date appointmenttime) {
        this.appointmenttime = appointmenttime;
    }

    public Date getReqtime() {
        return reqtime;
    }

    public void setReqtime(Date reqtime) {
        this.reqtime = reqtime;
    }

    public Date getRsptime() {
        return rsptime;
    }

    public void setRsptime(Date rsptime) {
        this.rsptime = rsptime;
    }

    public Date getComptime() {
        return comptime;
    }

    public void setComptime(Date comptime) {
        this.comptime = comptime;
    }

    public String getCheckinstatus() {
        return checkinstatus;
    }

    public void setCheckinstatus(String checkinstatus) {
        this.checkinstatus = checkinstatus;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}