package com.smt.iptv.portal.web.hotel;

import java.io.File;
import java.util.Map;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Maps;
import com.smt.iptv.portal.core.FileUploadUtil;
import com.smt.iptv.portal.entity.hotel.Hotel;
import com.smt.iptv.portal.service.cmp.PicturetypeService;
import com.smt.iptv.portal.service.hotel.HotelService;

/**
 * Hotel管理的Controller, 使用Restful风格的Urls:
 * 
 * List page     : GET /hotel/
 * Create page   : GET /hotel/create
 * Create action : POST /hotel/create
 * Update page   : GET /hotel/update/{id}
 * Update action : POST /hotel/update
 * Delete action : GET /hotel/delete/{id}
 * 
 * @author xjw
 */
@Controller
@RequestMapping(value = "/hotel")
public class HotelController {

	private static final int PAGE_SIZE = 50;

	private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
	static {
		sortTypes.put("auto", "自动");
		sortTypes.put("hotelname", "名称");
	}

	@Autowired
	private HotelService hotelService;
    @Autowired
    private PicturetypeService  picturetypeService;
	@RequestMapping(value = "/list")
	public String list(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
			@RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
		Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");

		Page<Hotel> hotels = hotelService.getPage( searchParams, pageNumber, PAGE_SIZE, sortType);

		model.addAttribute("hotels", hotels);
		model.addAttribute("sortType", sortType);
		model.addAttribute("sortTypes", sortTypes);
		// 将搜索条件编码成字符串，用于排序，分页的URL
		model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
		return "hotel/hotelList";
	}

	@RequestMapping(value = "create", method = RequestMethod.GET)
	public String createForm(Model model) {
		model.addAttribute("hotel", new Hotel());
		model.addAttribute("action", "create");
		return "hotel/hotelForm";
	}

	@RequestMapping(value = "create", method = RequestMethod.POST)
	public String create(@Valid Hotel newHotel, RedirectAttributes redirectAttributes) {

		hotelService.save(newHotel);
		redirectAttributes.addFlashAttribute("message", "新增成功");
		return "redirect:/hotel/list";
	}

	@RequestMapping(value = "update/{id}", method = RequestMethod.GET)
	public String updateForm(@PathVariable("id") Long id, Model model) {
		model.addAttribute("hotel", hotelService.findOne(id));
		model.addAttribute("action", "save");
		return "hotel/hotelForm";
	}

	@RequestMapping(value = "update", method = RequestMethod.POST)
	public String update(@Valid @ModelAttribute("preloadHotel") Hotel hotel, RedirectAttributes redirectAttributes) {
		hotelService.save(hotel);
		redirectAttributes.addFlashAttribute("message", "保存成功");
		return "redirect:/hotel/list";
	}

	@RequestMapping(value = "delete/{id}")
	public String delete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
		hotelService.delete(id);
		redirectAttributes.addFlashAttribute("message", "删除成功");
		return "redirect:/hotel/list";
	}

	/**
	 * 使用@ModelAttribute, 实现Struts2 Preparable二次部分绑定的效果,先根据form的id从数据库查出Hotel对象,再把Form提交的内容绑定到该对象上。
	 * 因为仅update()方法的form中有id属性，因此本方法在该方法中执行.
	 */
	@ModelAttribute("preloadHotel")
	public Hotel getHotel(@RequestParam(value = "id", required = false) Long id) {
		if (id != null) {
			return hotelService.findOne(id);
		}
		return null;
	}

	
	@RequestMapping(value = "save", method = RequestMethod.POST)
    public String save(@Valid @ModelAttribute("preloadHotel") Hotel hotel, RedirectAttributes redirectAttributes,
            @RequestParam("file") MultipartFile multipartFile,@RequestParam("file2") MultipartFile multipartFile2,
            HttpServletRequest request) {
        String relativePath ="hotel/";
        if(!multipartFile.isEmpty()){	        
            File file = FileUploadUtil.saveFile(multipartFile, relativePath,true,0,0);
            FileUploadUtil.delete(hotel.getHotellogo());
	        hotel.setHotellogo(relativePath+file.getName());
	    }
        if(!multipartFile2.isEmpty()){
            File file2 = FileUploadUtil.saveFile(multipartFile2, relativePath,true,0,0);
            FileUploadUtil.delete(hotel.getHotelimage());
	        hotel.setHotelimage(relativePath+file2.getName());
	    }
        hotelService.save(hotel);
        redirectAttributes.addFlashAttribute("message", "保存成功");
        return "redirect:/hotel/list";
	}

}
