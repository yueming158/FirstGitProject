package com.smt.iptv.portal.repository.video;

import org.springframework.data.jpa.repository.Query;

import com.smt.iptv.portal.entity.Channel;
import com.smt.iptv.portal.entity.Physicalchannel;
import com.smt.iptv.portal.repository.BaseDao;

public interface PhysicalchannelDao extends BaseDao<Physicalchannel> {
    @Query("select c.cpobjectcode from Channel c where c.physicalchannel.id=?1")
    public String getChannelCode(Long physicalchannelId);
}
