package com.smt.iptv.portal.service.hotel;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.smt.iptv.portal.core.HttpJDKUtil;
import com.smt.iptv.portal.entity.Weather;
import com.smt.iptv.portal.repository.WeatherDao;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class WeatherService {

    private static Map<String, String> logoMap = new HashMap<String, String>();
    static {
        logoMap.put("晴", "static/images/weather/01qing.png");
        logoMap.put("多云", "static/images/weather/02duoyun.png");
        logoMap.put("阴", "static/images/weather/03yin.png");
        logoMap.put("阵雨", "static/images/weather/04zhenyu.png");
        logoMap.put("雷阵雨", "static/images/weather/05leizhenyu.png");
        logoMap.put("雷阵雨伴有冰雹", "static/images/weather/06leizhenyubingbao.png");
        logoMap.put("雨夹雪", "static/images/weather/07yujiaxue.png");
        logoMap.put("小雨", "static/images/weather/08xiaoyu.png");
        logoMap.put("中雨", "static/images/weather/09zhongyu.png");
        logoMap.put("大雨", "static/images/weather/10dayu.png");
        logoMap.put("暴雨", "static/images/weather/11baoyu.png");
        logoMap.put("大暴雨", "static/images/weather/12dabaoyu.png");
        logoMap.put("特大暴雨", "static/images/weather/13tedabaoyu.png");
        logoMap.put("阵雪", "static/images/weather/14zhenxue.png");
        logoMap.put("小雪", "static/images/weather/15xiaoxue.png");
        logoMap.put("中雪", "static/images/weather/16zhongxue.png");
        logoMap.put("大雪", "static/images/weather/17daxue.png");
        logoMap.put("暴雪", "static/images/weather/18baoxue.png");
        logoMap.put("雾", "static/images/weather/19wu.png");
        logoMap.put("冻雨", "static/images/weather/20dongyu.png");
        logoMap.put("沙尘暴", "static/images/weather/21shachenbao.png");
        logoMap.put("小到中雨", "static/images/weather/22zhongyu.png");
        logoMap.put("中到大雨", "static/images/weather/23dayu.png");
        logoMap.put("大到暴雨", "static/images/weather/24baoyu.png");
        logoMap.put("暴雨到大暴雨", "static/images/weather/25dabaoyu.png");
        logoMap.put("大暴雨到特大暴雨", "static/images/weather/26tedabaoyu.png");
        logoMap.put("小到中雪", "static/images/weather/27zhongxue.png");
        logoMap.put("中到大雪", "static/images/weather/28daxue.png");
        logoMap.put("大到暴雪", "static/images/weather/29baoxue.png");
        logoMap.put("浮尘", "static/images/weather/30fuchen.png");
        logoMap.put("扬沙", "static/images/weather/31yangsha.png");
        logoMap.put("强沙尘暴", "static/images/weather/32qiangshachenbao.png");
        logoMap.put("霾", "static/images/weather/33mai.png");
    }

    @Autowired
    private WeatherDao currentWeatherDao;

    public List<Weather> findByCitycode(String citycode) {
        return currentWeatherDao.findByCitycode(citycode);
    }

    public Weather findByCitycodeAndWeatherdate(String citycode, Date date) {
        return currentWeatherDao.findByCitycodeAndWeatherdate(citycode, date);
    }

    public List<Weather> findByCitycodeAndWeatherdateBetween(String citycode, Date startDate, Date endDate) {
        return currentWeatherDao.findByCitycodeAndWeatherdateBetween(citycode, startDate, endDate);
    }

    @Transactional(readOnly = false)
    public void refreshWeatherData(String cityCode) {
        String url = "http://m.weather.com.cn/data/" + cityCode + ".html";
        String jsondata = HttpJDKUtil.executeHttpGet(url, "utf-8");
        if (jsondata != null && jsondata.length() > 100) {

            List<Weather> list = jsonToWeather(jsondata);
            // 得到6个weather对象
            // 查询出6天的天气
            List<Weather> oldlist = currentWeatherDao.findByCitycode(cityCode);// 数据库只存在6条记录
            // 对比 如果存在哪一天 则 把id加上 等待update
//            int i = 0;
//            for (Weather w : dbweathers) {
//                list.get(i).setId(w.getId());
//                i++;
//                if (i == list.size()) {
//                    break;
//                }
//            }
            if(list!=null){
                for(int i=0;i<list.size();i++){
                    if(oldlist!=null&&!oldlist.isEmpty()){
                        list.get(i).setId(oldlist.get(0).getId());
                        oldlist.remove(0);
                    }else{
                        break;
                    }
                }
                if(!oldlist.isEmpty()){
                    currentWeatherDao.delete(oldlist);
                }
            }
            currentWeatherDao.save(list);
        }
    }

    // public static void main(String[] args) throws JsonParseException,
    // JsonMappingException, IOException {
    // String jsondata =
    // "{\"weatherinfo\":{\"city\":\"深圳\",\"city_en\":\"shenzhen\",\"date_y\":\"2013年6月20日\",\"date\":\"\",\"week\":\"星期四\",\"fchh\":\"18\",\"cityid\":\"101280601\",\"temp1\":\"27℃~33℃\",\"temp2\":\"26℃~31℃\",\"temp3\":\"25℃~31℃\",\"temp4\":\"26℃~30℃\",\"temp5\":\"26℃~31℃\",\"temp6\":\"27℃~32℃\",\"tempF1\":\"80.6℉~91.4℉\",\"tempF2\":\"78.8℉~87.8℉\",\"tempF3\":\"77℉~87.8℉\",\"tempF4\":\"78.8℉~86℉\",\"tempF5\":\"78.8℉~87.8℉\",\"tempF6\":\"80.6℉~89.6℉\",\"weather1\":\"多云转雷阵雨\",\"weather2\":\"阵雨\",\"weather3\":\"阵雨\",\"weather4\":\"阵雨\",\"weather5\":\"阵雨\",\"weather6\":\"阵雨\",\"img1\":\"1\",\"img2\":\"4\",\"img3\":\"3\",\"img4\":\"99\",\"img5\":\"3\",\"img6\":\"99\",\"img7\":\"3\",\"img8\":\"99\",\"img9\":\"3\",\"img10\":\"99\",\"img11\":\"3\",\"img12\":\"99\",\"img_single\":\"4\",\"img_title1\":\"多云\",\"img_title2\":\"雷阵雨\",\"img_title3\":\"阵雨\",\"img_title4\":\"阵雨\",\"img_title5\":\"阵雨\",\"img_title6\":\"阵雨\",\"img_title7\":\"阵雨\",\"img_title8\":\"阵雨\",\"img_title9\":\"阵雨\",\"img_title10\":\"阵雨\",\"img_title11\":\"阵雨\",\"img_title12\":\"阵雨\",\"img_title_single\":\"雷阵雨\",\"wind1\":\"微风\",\"wind2\":\"微风\",\"wind3\":\"微风\",\"wind4\":\"微风\",\"wind5\":\"微风\",\"wind6\":\"微风\",\"fx1\":\"微风\",\"fx2\":\"微风\",\"fl1\":\"小于3级\",\"fl2\":\"小于3级\",\"fl3\":\"小于3级\",\"fl4\":\"小于3级\",\"fl5\":\"小于3级\",\"fl6\":\"小于3级\",\"index\":\"炎热\",\"index_d\":\"天气炎热，建议着短衫、短裙、短裤、薄型T恤衫等清凉夏季服装。\",\"index48\":\"热\",\"index48_d\":\"天气热，建议着短裙、短裤、短薄外套、T恤等夏季服装。\",\"index_uv\":\"中等\",\"index48_uv\":\"中等\",\"index_xc\":\"不宜\",\"index_tr\":\"一般\",\"index_co\":\"较不舒适\",\"st1\":\"31\",\"st2\":\"26\",\"st3\":\"29\",\"st4\":\"24\",\"st5\":\"29\",\"st6\":\"23\",\"index_cl\":\"较不宜\",\"index_ls\":\"不宜\",\"index_ag\":\"不易发\"}}";
    // List<Weather> list = jsonToWeather(jsondata);
    // }

    @Transactional(readOnly = false)
    public void refreshWeatherData2(String cityCode) {// 1903 深圳
        // String url = "http://forcast.weathertv.cn/live/" + cityCode +".shtml";
        String url = "http://forcast.weathertv.cn/forecast/" + cityCode + ".shtml";
        String htmldata = HttpJDKUtil.executeHttpGet(url, "utf-8");
        if (htmldata != null && htmldata.length() > 100) {

            List<Weather> list = htmlToWeather(htmldata, cityCode);
            // 得到6个weather对象
            // 查询出6天的天气
            List<Weather> oldlist = currentWeatherDao.findByCitycode(cityCode);// 数据库存在7条记录
            // 对比 如果存在哪一天 则 把id加上 等待update 
//            if(list!=null&&oldlist!=null){ 
//                int i = 0;
//                for (Weather w : oldlist) {
//                    list.get(i).setId(w.getId());
//                    i++;
//                    if (i == list.size()) { 
//                        break;
//                    }
//                }
//            }
            if(list!=null){
                for(int i=0;i<list.size();i++){
                    if(oldlist!=null&&!oldlist.isEmpty()){
                        list.get(i).setId(oldlist.get(0).getId());
                        oldlist.remove(0);
                    }else{
                        break;
                    }
                }
                if(!oldlist.isEmpty()){
                    currentWeatherDao.delete(oldlist);
                }
                currentWeatherDao.save(list);
            }
        }
    }

    /**
     * 数据来源
     * 
     * @param hltmdata
     * @return class="forecast_7day_prev"
     */
    private List<Weather> htmlToWeather(String htmldata, String cityCode) {
        if(StringUtils.isEmpty(htmldata)){
            return null;
        }
        List<Weather> list = new ArrayList<Weather>();
        int infostart = htmldata.indexOf("<span class=\"city_name\">");
        int end = htmldata.lastIndexOf("class=\"forecast_7day_prev\"");
        if(infostart==-1||end==-1){
            return null;
        }
        htmldata = htmldata.substring(infostart, end);
        String cityName = htmldata.substring(24, htmldata.indexOf("<input"));

        String dayStr = new SimpleDateFormat("yyyy").format(new Date());//htmldata.substring(htmldata.indexOf("<h3>逐6小时精细化预报（") + 14, htmldata.indexOf("<h3>逐6小时精细化预报（") + 18);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM月dd日");

        int start = htmldata.indexOf("class=\"forecast_7day_prev\"");
        htmldata = htmldata.substring(start);
        String[] daydataArr = htmldata.split("</li>");
        Date date = null;
        int i = 0;
        for (String day : daydataArr) {
            if (day.indexOf("<div class=\"date\">") != -1) {

                String txt = day.substring(day.indexOf("class=\"txt\">") + 12, day.lastIndexOf("</div>"));
                Weather w = new Weather();
                w.setTemp(txt.split("<br/>")[1]);
                w.setWeather(txt.split("<br/>")[0]);
                w.setCitycode(cityCode);
                w.setCityname(cityName);
                w.setCurrenttemp(w.getTemp().split("～")[0]);// 需要写入
                w.setLogourl(logoMap.get(w.getWeather().split("转")[0]));
                if (logoMap.get(w.getWeather().split("转")[0]) == null && w.getWeather().split("转").length > 1) {
                    w.setLogourl(logoMap.get(w.getWeather().split("转")[1]));
                }
                if (date == null) {
                    try {
                        date = sdf.parse(dayStr + day.substring(day.indexOf("<div class=\"date\">") + 18, day.indexOf("<br/>")));
                    } catch (ParseException e) {
                        date =new Date();
                    }
                }
                w.setWeatherdate(addDay(date, i));// 加天 操作 日历类
                i++;
                list.add(w);
            }
        }
        return list;
    }

    public static void main(String[] args) {
        new WeatherService().refreshWeatherData2("1903");
    }

    private List<Weather> jsonToWeather(String jsondata) {

        ObjectMapper mapper = new ObjectMapper();
        JsonNode jsonNode;
        List<Weather> list = new ArrayList<Weather>();
        try {
            jsonNode = mapper.readTree(jsondata).get("weatherinfo");
            SimpleDateFormat myDateFormat = new SimpleDateFormat("yyyy年MM月dd日");
            // mapper.setDateFormat(myDateFormat);
            for (int i = 1; i < 7; i++) {
                Weather w = new Weather();
                w.setTemp(jsonNode.get("temp" + i).textValue());
                w.setWeather(jsonNode.get("weather" + i).textValue());
                w.setWd(jsonNode.get("wind" + i).textValue());
                w.setWs(jsonNode.get("fl" + i).textValue());
                w.setCitycode(jsonNode.get("cityid").textValue());
                w.setCityname(jsonNode.get("city").textValue());
                w.setCurrenttemp(w.getTemp().split("~")[0]);// 需要写入
                w.setLogourl(logoMap.get(w.getWeather().split("转")[0]));
                if (logoMap.get(w.getWeather().split("转")[0]) == null && w.getWeather().split("转").length > 1) {
                    w.setLogourl(logoMap.get(w.getWeather().split("转")[1]));
                }
                try {
                    Date day = myDateFormat.parse(jsonNode.get("date_y").textValue());
                    w.setWeatherdate(addDay(day, i - 1));// 加天 操作 日历类
                } catch (ParseException e) {
                    continue;
                }
                list.add(w);
            }
        } catch (JsonProcessingException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        } catch (IOException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }
        return list;
    }

    private Date addDay(Date date, int n) {
        Calendar cd = Calendar.getInstance();
        cd.setTime(date);
        cd.add(Calendar.DATE, n);// 增加一天
        return cd.getTime();
    }
}
