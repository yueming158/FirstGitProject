package com.smt.iptv.portal.core;

import java.io.IOException;

import org.apache.commons.net.telnet.TelnetClient;

public class TelnetUtil {
    public static boolean getHostStatus(String ip,int port) {
        TelnetClient telnet = new TelnetClient();
        telnet.setConnectTimeout(300);
        telnet.setDefaultTimeout(300);
        try {   
            telnet.connect(ip,port);
        } catch (IOException e) {
            return false;
        }
        try {
            telnet.disconnect();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return true;
    }
}