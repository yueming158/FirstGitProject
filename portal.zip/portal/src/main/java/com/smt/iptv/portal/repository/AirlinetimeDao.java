package com.smt.iptv.portal.repository;

import java.util.List;

import com.smt.iptv.portal.entity.Airlinetime;

public interface AirlinetimeDao extends BaseDao<Airlinetime> {
    List<Airlinetime> getByAirlinecitycode(String citycode);
}
