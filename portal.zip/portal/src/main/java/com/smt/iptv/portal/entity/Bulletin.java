package com.smt.iptv.portal.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.format.annotation.DateTimeFormat;

import com.smt.iptv.portal.core.IdEntity;
@Entity
@Table(name = "bulletin")
public class Bulletin extends IdEntity {
    
    public Bulletin() {
    }

    public Bulletin(Long id) {
        this.id = id;
    }

    private String type;//1即时公告 2延时公告 3个人消息4延时个人消息  5周期定时发送公告
    private String status; //0已过期 //1 未发布 2 发布  
    private String important; //1重要 0 一般
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private Date releasetime;
    private Integer loopnumber;
	private String content;
    private Date creatdate;
    
    //private String important;
    //private String releasetime;
    //private String loopnumber;
    private String loopintervaltime;
    //private String content;
    //private String readstatus;
    //private String type;
    private String cronexpression;
    private Long epggroupid;
    
    public Long getEpggroupid() {
		return epggroupid;
	}

	public void setEpggroupid(Long epggroupid) {
		this.epggroupid = epggroupid;
	}

	public String getCronexpression() {
		return cronexpression;
	}

	public void setCronexpression(String cronexpression) {
		this.cronexpression = cronexpression;
	}

	public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getImportant() {
        return important;
    }

    public void setImportant(String important) {
        this.important = important;
    }

    public Date getReleasetime() {
        return releasetime;
    }

    public void setReleasetime(Date releasetime) {
        this.releasetime = releasetime;
    }

    public Integer getLoopnumber() {
        return loopnumber;
    }

    public void setLoopnumber(Integer loopnumber) {
        this.loopnumber = loopnumber;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Date getCreatdate() {
        return creatdate;
    }

    public void setCreatdate(Date creatdate) {
        this.creatdate = creatdate;
    }
    
    public String getLoopintervaltime() {
        return loopintervaltime;
    }

    public void setLoopintervaltime(String loopintervaltime) {
        this.loopintervaltime = loopintervaltime;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}