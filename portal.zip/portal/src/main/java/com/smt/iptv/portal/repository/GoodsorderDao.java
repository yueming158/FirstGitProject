package com.smt.iptv.portal.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.smt.iptv.portal.entity.Goodsorder;
import com.smt.iptv.portal.entity.Goodsordermap;

public interface GoodsorderDao extends BaseDao<Goodsorder> {
    @Query("select m from Goodsordermap m where m.orderid =?1")
    public List<Goodsordermap> getGoodsListByOrder(Long orderid);
    
    @Query(nativeQuery=true,value="update goodsorder set checkinstatus=?2 where username=?1 and checkinstatus<>?2")
    @Modifying
    public void updateGoodsorderStatus(String iptvusername,String status);
    
    @Query(nativeQuery=true,value="delete from dishcart where username=?1")
    @Modifying
    public void deleteGoodscart(String iptvusername);
}
