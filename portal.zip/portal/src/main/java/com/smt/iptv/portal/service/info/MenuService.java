package com.smt.iptv.portal.service.info;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.i18nentity.info.Menu;
import com.smt.iptv.portal.i18nrepository.info.MenuDao;
import com.smt.iptv.portal.service.cmp.BaseService;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class MenuService extends BaseService<MenuDao, Menu> {
    public Menu getByCode(String code){
        
        return dao.getByCode( code);
    }
    /**
     * 这里是获取所有信息发布模板的菜单的集合。
     * @return
     */
    public List<Menu> getInfoTemplateMenu(){
        return dao.getInfoTemplateMenu();
    }
    public List<Menu> getByInfotemplateCode(String code){
        return dao.getByInfotemplateCode(code);
    }
    
    public List<Menu> getByParentid(Long id){
        
        return dao.getByParentid( id);
    }
    public List<Menu> getByInfotemplateId(Long id){
        
        return dao.getByInfotemplateId(id);
    }
    public List<Menu> findAll(Sort sort){
        return (List<Menu>) dao.findAll(sort);
    }
}
