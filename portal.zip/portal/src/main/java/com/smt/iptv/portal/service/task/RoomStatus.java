package com.smt.iptv.portal.service.task;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlValue;
/*
 *       <RoomType>豪华标间</RoomType>
      <RoomNo>101</RoomNo>
      <Note>null</Note>
      <GuestName>张三</GuestName>
      <Mobile/>
      <IdCardNo>340101190001010877</IdCardNo>
      <MemberCardNo>null</MemberCardNo>
      <CheckInTime>2015-03-29 11:44</CheckInTime>
      <CheckOutTime>2015-03-30 14:00</CheckOutTime>
      <SumRegisterBalance>0</SumRegisterBalance>
 */
public class RoomStatus {
    public RoomStatus() {
        
    }
    
    private String roomType;
    private String roomNo;
    private String guestName;
    private String idCardNo;
    private String checkInTime;
    private String checkOutTime;
    @XmlElement(name="RoomType")
    public String getRoomType() {
        return roomType;
    }
    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }
    @XmlElement(name="RoomNo")
    public String getRoomNo() {
        return roomNo;
    }
    public void setRoomNo(String roomNo) {
        this.roomNo = roomNo;
    }
    @XmlElement(name="GuestName")
    public String getGuestName() {
        return guestName;
    }
    public void setGuestName(String guestName) {
        this.guestName = guestName;
    }
    @XmlElement(name="IdCardNo")
    public String getIdCardNo() {
        return idCardNo;
    }
    public void setIdCardNo(String idCardNo) {
        this.idCardNo = idCardNo;
    }
    @XmlElement(name="CheckInTime")
    public String getCheckInTime() {
        return checkInTime;
    }
    public void setCheckInTime(String checkInTime) {
        this.checkInTime = checkInTime;
    }
    @XmlElement(name="CheckOutTime")
    public String getCheckOutTime() {
        return checkOutTime;
    }
    public void setCheckOutTime(String checkOutTime) {
        this.checkOutTime = checkOutTime;
    }

}
