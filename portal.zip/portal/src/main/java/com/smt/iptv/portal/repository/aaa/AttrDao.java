package com.smt.iptv.portal.repository.aaa;

import java.util.List;

import com.smt.iptv.portal.entity.aaa.Attr;
import com.smt.iptv.portal.repository.BaseDao;

public interface AttrDao extends BaseDao<Attr> {
    List<Attr> getByUsetype(String type);
}
