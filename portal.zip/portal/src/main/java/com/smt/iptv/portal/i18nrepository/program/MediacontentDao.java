package com.smt.iptv.portal.i18nrepository.program;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.smt.iptv.portal.i18nentity.program.Mediacontent;
import com.smt.iptv.portal.repository.BaseDao;

public interface MediacontentDao extends BaseDao<Mediacontent> {
    @Query("delete from Mediacontent m where m.program.id=?1")
    @Modifying
    public void deleteByProgramId(Long programId);
    
    public List<Mediacontent> getByProgramId(Long programId);
    
    @Query("select count(m) from Mediacontent m where m.program.id=?1")
    public Long getCountByProgramId(Long programId);
}
