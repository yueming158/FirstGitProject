package com.smt.iptv.portal.model;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.smt.iptv.portal.core.IdEntity;

public class Program extends IdEntity {
    
    public Program() {
    }

    public Program(Long id) {
        this.id = id;
    }
//    programname
//    searchname
//    createdate
//    status
//    year
//    starrating
//    areaname
//    programtype
//    genrenames
//    actornames
//    writernames
//    description
//    cpobjectcode
//    playurl
//    duration
    private String programname;
    private String searchname;
    private String year;
    private String starrating;
    private String areaname;
    private String programtype;
    private String genrenames;
    private String actornames;
    private String writernames;
    private String description;

    @JsonIgnore
    private String cpobjectcode;
    @JsonIgnore
    private int duration;
    @JsonIgnore
    private String pictureurl;

    public String getProgramname() {
        return programname;
    }
    @JsonIgnore
    public String getPlayurl() {
        return  SystemConstant.getURLValue("CDN_server_address")+this.cpobjectcode;
    }

    public String getImageurl() {
        return SystemConstant.getURLValue("image_server_httpprefix")+this.pictureurl;
    }
    
    
    public void setProgramname(String programname) {
        this.programname = programname;
    }

    public String getSearchname() {
        return searchname;
    }

    public void setSearchname(String searchname) {
        this.searchname = searchname;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getStarrating() {
        return starrating;
    }

    public void setStarrating(String starrating) {
        this.starrating = starrating;
    }

    public String getAreaname() {
        return areaname;
    }

    public void setAreaname(String areaname) {
        this.areaname = areaname;
    }

    public String getProgramtype() {
        return programtype;
    }

    public void setProgramtype(String programtype) {
        this.programtype = programtype;
    }

    public String getGenrenames() {
        return genrenames;
    }

    public void setGenrenames(String genrenames) {
        this.genrenames = genrenames;
    }

    public String getActornames() {
        return actornames;
    }

    public void setActornames(String actornames) {
        this.actornames = actornames;
    }

    public String getWriternames() {
        return writernames;
    }

    public void setWriternames(String writernames) {
        this.writernames = writernames;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCpobjectcode() {
        return cpobjectcode;
    }

    public void setCpobjectcode(String cpobjectcode) {
        this.cpobjectcode = cpobjectcode;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public String getpictureurl() {
        return pictureurl;
    }

    public void setpictureurl(String pictureurl) {
        this.pictureurl = pictureurl;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}