package com.smt.iptv.portal.i18nentity;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.portal.core.IdEntity;
@Entity
@Table(name = "city")
public class City extends IdEntity {
    
    public City() {
    }

    public City(Long id) {
        this.id = id;
    }
    
	private String cityname;
	private String cityaircode;
	private String cityweathercode;

    public String getCityname() {
        return cityname;
    }

    public void setCityname(String cityname) {
        this.cityname = cityname;
    }

    public String getCityaircode() {
        return cityaircode;
    }

    public void setCityaircode(String cityaircode) {
        this.cityaircode = cityaircode;
    }

    public String getCityweathercode() {
        return cityweathercode;
    }

    public void setCityweathercode(String cityweathercode) {
        this.cityweathercode = cityweathercode;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}