package com.smt.iptv.portal.service.cmp;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.entity.Customizedchannelno;
import com.smt.iptv.portal.repository.video.CustomizedchannelnoDao;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class CustomizedchannelnoService extends BaseService<CustomizedchannelnoDao, Customizedchannelno> {

    public List<Customizedchannelno> findByChannelgroup(String channelgroup) {
        return dao.findByChannelgroup(channelgroup);
    }

    public List<Customizedchannelno> findByChannelgroupAndView(String channelgroup, String view) {
        Sort sort = new Sort(Sort.DEFAULT_DIRECTION, "channelnumber");
        return dao.findByChannelgroupAndView(channelgroup, view,sort);
    }

    @Transactional(readOnly = false)
    public void delete(List<Customizedchannelno> entities) {
        dao.delete(entities);
    }

    @Transactional(readOnly = false)
    public void deleteByChannelid(Long id) {
        dao.deleteByChannelid(id);
    }

}
