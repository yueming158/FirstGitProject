package com.smt.iptv.portal.service.task;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.google.common.collect.Lists;

/**
 * 使用JAXB2.0标注的待转换Java Bean.
 */
@XmlRootElement(name="IpmsResponse")
public class RoomstatusResponse {
    
    public RoomstatusResponse() {
        
    }

    private List<RoomStatus> roomStatuses = Lists.newArrayList();


    @XmlElementWrapper(name = "RoomStatuses")
    @XmlElement(name = "RoomStatus")
    public List<RoomStatus> getRoomStatuses() {
        return roomStatuses;
    }

    public void setRoomStatuses(List<RoomStatus> roomStatuses) {
        this.roomStatuses = roomStatuses;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
