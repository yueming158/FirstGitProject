package com.smt.iptv.portal.core;

import java.lang.reflect.Field;

import com.smt.iptv.portal.entity.Timezone;

public class PageBuilder {
    public static void main(String[] args) {
        Class<Timezone> clazz=Timezone.class;
        String classname=clazz.getSimpleName().toLowerCase();
        StringBuffer sb = new StringBuffer();
        for(Field f: clazz.getDeclaredFields()){
           sb.append(buildpage(classname,f.getName()));
        }
        System.out.println(sb.toString());
    }

    private static String buildpage(String classname,String propertyname) {
       return     "    <div class=\"control-group\">\n"
                + "        <label for=\""+classname+"_"+propertyname+"\" class=\"control-label\">修改此处名称:</label>\n"
                + "        <div class=\"controls\">\n"
                + "            <input type=\"text\" id=\""+classname+"_"+propertyname+"\" name=\""+propertyname+"\"  value=\"${"+classname+"."+propertyname+"}\" class=\"input-large required\" />\n"
                + "        </div>\n" + "    </div>\n";
        
    }
}
