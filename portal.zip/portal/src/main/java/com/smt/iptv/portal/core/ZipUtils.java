package com.smt.iptv.portal.core;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import org.apache.commons.io.IOUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.smt.iptv.portal.model.SystemConstant;

public class ZipUtils {
	/**
	   * 对Excel以及图片文件进行压缩
	   * 
	   * @param wb
	   */
	  public static void zip(File targetFile, HSSFWorkbook wbs , List<String> pictures) {
	    if (wbs == null) {
	      return;
	    }
	    ZipOutputStream zos = null;
	    try {
	        zos = new ZipOutputStream(new FileOutputStream(targetFile));
	        ZipEntry entry = new ZipEntry(String.valueOf(System.currentTimeMillis())+".xls");
	        // 设置压缩包的入口
	        zos.putNextEntry(entry);
	        wbs.write(zos);
	        zos.flush();
	        String rootPath = SystemConstant.getValue("fileupload");
	        for (String picture : pictures) {
	        	InputStream in=new FileInputStream(rootPath+"/"+picture);
	        	entry = new ZipEntry(picture.substring(picture.indexOf("/")+1));
	 	        // 设置压缩包的入口
	 	        zos.putNextEntry(entry);
	 	        int len=0; 
	 	        byte[]buffer=new byte[1024];  
	 	        while(-1!=(len=in.read(buffer))) {  
	 	    	 zos.write(buffer, 0, len);  
	 	        }  
	 	        in.close();
	 	        zos.flush();
			}
	        zos.close();
	    } catch (IOException e) {
	      e.printStackTrace();
	    }
	  }
	  
	  
	  public static String unzip(InputStream in,String outputDirectory){
		  String xlsPath = null;
		  if(in == null){
			  return null;
		  } 
		  ZipEntry zipEntry = null;  
          FileOutputStream out = null;  
          String fileName = null;  
          ZipInputStream zipIn = new ZipInputStream(in); 
          try{ 
        	  while ((zipEntry = zipIn.getNextEntry()) != null) {  
        		  //如果是文件，则直接在对应路径下生成   
        		  fileName = zipEntry.getName();
        		  File file = new File(outputDirectory+fileName);
        		  if(fileName.endsWith(".xls")){
        			  xlsPath = outputDirectory+fileName;
        		  }
        		  file.createNewFile();  
                  out = new FileOutputStream(file);  
                  int b = 0;
                  while ((b = zipIn.read()) != -1){  
                      out.write(b);  
                  }  
                  out.close();
        	  }
          }catch (Exception e) {
        	  e.printStackTrace();
          } finally{  
              IOUtils.closeQuietly(zipIn);  
              IOUtils.closeQuietly(in);  
              IOUtils.closeQuietly(out);  
          }  
          return xlsPath;
	  }
}
