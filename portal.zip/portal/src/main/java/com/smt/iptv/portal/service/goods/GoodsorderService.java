package com.smt.iptv.portal.service.goods;

import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.entity.Goodsorder;
import com.smt.iptv.portal.entity.Goodsordermap;
import com.smt.iptv.portal.repository.GoodsorderDao;
import com.smt.iptv.portal.service.cmp.BaseService;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class GoodsorderService extends BaseService<GoodsorderDao, Goodsorder> {
    public List<Goodsordermap> getGoodsListByOrder(Long orderid){
        return dao.getGoodsListByOrder(orderid);
    }
    
    @Transactional(readOnly = false)
    public Goodsorder verify(Long id,String name) {
        Goodsorder goodsorder = dao.findOne(id);
        if (goodsorder != null) {
            goodsorder.setStatus("2");
            goodsorder.setVerifytime(new Date());
            goodsorder.setVerifypeople(name);
            return dao.save(goodsorder);
        } else {
            return null;
        }
    }
    @Transactional(readOnly = false)
    public Goodsorder complete(Long id ) {
        Goodsorder goodsorder = dao.findOne(id);
        if (goodsorder != null) {
            goodsorder.setStatus("4");
            goodsorder.setCompletetime(new Date());
            return dao.save(goodsorder);
        } else {
            return null;
        }
    }
    @Transactional(readOnly = false)
    public Goodsorder cancel(Long id ) {
        Goodsorder goodsorder = dao.findOne(id);
        if (goodsorder != null) {
            goodsorder.setStatus("5");
            goodsorder.setCompletetime(new Date());
            return dao.save(goodsorder);
        } else {
            return null;
        }
    }
}
