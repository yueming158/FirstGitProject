package com.smt.iptv.portal.repository.hotel;

import com.smt.iptv.portal.entity.hotel.Hotelcall;
import com.smt.iptv.portal.repository.BaseDao;

public interface HotelcallDao extends BaseDao<Hotelcall> {

}
