package com.smt.iptv.portal.web.program;

import java.util.Map;

import javax.servlet.ServletRequest;
import javax.validation.Valid;

import org.apache.shiro.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Maps;
import com.smt.iptv.portal.entity.Personmessage;
import com.smt.iptv.portal.push.PushMessage;
import com.smt.iptv.portal.push.PushServer;
import com.smt.iptv.portal.service.account.ShiroDbRealm.ShiroUser;
import com.smt.iptv.portal.service.cmp.PersonmessageService;

/**
 * @author xjw
 */
@Controller
@RequestMapping(value = "/personmessage")
public class PersonmessageController {

	private static final int PAGE_SIZE = 50;

	private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
	static {
		sortTypes.put("auto", "自动");
		//sortTypes.put("title", "标题");
	}

	@Autowired
	private PersonmessageService personmessageService;

	@RequestMapping(value = "/list")
	public String list(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
			@RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
		Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");

		Page<Personmessage> personmessages = personmessageService.getPage( searchParams, pageNumber, PAGE_SIZE, sortType);

		model.addAttribute("personmessages", personmessages);
		model.addAttribute("sortType", sortType);
		model.addAttribute("sortTypes", sortTypes);
		// 将搜索条件编码成字符串，用于排序，分页的URL
		model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
		return "personmessage/personmessageList";
	}

	@RequestMapping(value = "create", method = RequestMethod.GET)
	public String createForm(Model model) {
		model.addAttribute("personmessage", new Personmessage());
		model.addAttribute("action", "create");
		return "personmessage/personmessageForm";
	}

	@RequestMapping(value = "create", method = RequestMethod.POST)
	public String create(@Valid Personmessage newPersonmessage, RedirectAttributes redirectAttributes) {
	        newPersonmessage.setStatus("2");
            personmessageService.save(newPersonmessage);
            PushServer.sendMsgToAll(new PushMessage("personmsg", newPersonmessage.getContent()));
            redirectAttributes.addFlashAttribute("message", "发布成功");
		return "redirect:/personmessage/list";
	}

	@RequestMapping(value = "update/{id}", method = RequestMethod.GET)
	public String updateForm(@PathVariable("id") Long id, Model model) {
		model.addAttribute("personmessage", personmessageService.findOne(id));
		model.addAttribute("action", "update");
		return "personmessage/personmessageForm";
	}

	@RequestMapping(value = "update", method = RequestMethod.POST)
	public String update(@Valid @ModelAttribute("preloadPersonmessage") Personmessage personmessage, RedirectAttributes redirectAttributes) {
	    if("1".equals(personmessage.getStatus())){
	        personmessageService.save(personmessage);
	        redirectAttributes.addFlashAttribute("message", "保存成功");
	    }else{
	        redirectAttributes.addFlashAttribute("message", "公告已发布，无法修改");
	    }
		return "redirect:/personmessage/list";
	}

	@RequestMapping(value = "delete/{id}")
	public String delete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
		personmessageService.delete(id);
		redirectAttributes.addFlashAttribute("message", "删除成功");
		return "redirect:/personmessage/list";
	}

	/**
	 * 使用@ModelAttribute, 实现Struts2 Preparable二次部分绑定的效果,先根据form的id从数据库查出Personmessage对象,再把Form提交的内容绑定到该对象上。
	 * 因为仅update()方法的form中有id属性，因此本方法在该方法中执行.
	 */
	@ModelAttribute("preloadPersonmessage")
	public Personmessage getPersonmessage(@RequestParam(value = "id", required = false) Long id) {
		if (id != null) {
			return personmessageService.findOne(id);
		}
		return null;
	}

	/**
	 * 取出Shiro中的当前用户Id.
	 */
	private Long getCurrentUserId() {
		ShiroUser user = (ShiroUser) SecurityUtils.getSubject().getPrincipal();
		return user.id;
	}
}
