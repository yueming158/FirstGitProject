package com.smt.iptv.portal.repository.video;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.smt.iptv.portal.entity.Customizedchannelno;
import com.smt.iptv.portal.repository.BaseDao;

public interface CustomizedchannelnoDao extends BaseDao<Customizedchannelno> {

    public List<Customizedchannelno> findByChannelgroup(String channelgroup);
    
    public List<Customizedchannelno> findByChannelgroupAndView(String channelgroup,String view,Sort sort);
    @Query("delete from Customizedchannelno c where c.channel.id=?1")
    @Modifying
    public void deleteByChannelid(Long id);
}
