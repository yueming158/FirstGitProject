package com.smt.iptv.portal.entity.aaa;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.portal.core.IdEntity;
@Entity
@Table(name = "aaa_attr")
public class Attr extends IdEntity {
    public Attr() {
    }

    public Attr(Long id) {
        this.id = id;
    }
    public final static String TYPE_USER="1";
    public final static String TYPE_PRODUCTOFFER="2";
    public final static String TYPE_PRODUCT_RESOURCE_TYPE="3";
    private String usetype;//用途
    private String type;// 属性数据类型   1.账户用 2.商品使用 3.产品类型使用
    private String name; // 属性名
    private String attrkey; // 属性key
    private String value;
    private String enumstr; // 枚举定义

    public String getUsetype() {
        return usetype;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAttrkey() {
        return attrkey;
    }

    public void setAttrkey(String attrkey) {
        this.attrkey = attrkey;
    }

    @Transient
    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public void setUsetype(String usetype) {
        this.usetype = usetype;
    }

    public String getEnumstr() {
        return enumstr;
    }

    public void setEnumstr(String enumstr) {
        this.enumstr = enumstr;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
}