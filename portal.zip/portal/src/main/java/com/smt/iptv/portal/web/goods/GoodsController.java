package com.smt.iptv.portal.web.goods;

import java.io.File;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Maps;
import com.smt.iptv.portal.core.FileUploadUtil;
import com.smt.iptv.portal.i18nentity.goods.Goods;
import com.smt.iptv.portal.i18nentity.goods.Goodsfeatured;
import com.smt.iptv.portal.i18nentity.program.Picturetype;
import com.smt.iptv.portal.service.cmp.PicturetypeService;
import com.smt.iptv.portal.service.goods.GoodsService;
import com.smt.iptv.portal.service.goods.GoodsfeaturedService;

/**
 * Goods管理的Controller, 使用Restful风格的Urls:
 * 
 * List page : GET /goods/ Create page : GET /goods/create Create action : POST
 * /goods/create Update page : GET /goods/update/{id} Update action : POST
 * /goods/update Delete action : GET /goods/delete/{id}
 * 
 * @author xjw
 */
@Controller
@RequestMapping(value = "/goods")
public class GoodsController {

    private static final int PAGE_SIZE = 50;

    private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
    static {
        sortTypes.put("auto", "自动");
        sortTypes.put("goodsname", "名称");
    }

    @Autowired
    private GoodsService goodsService;
    @Autowired
    private PicturetypeService  picturetypeService;
    @RequestMapping(value = "/list")
    public String list(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");

        Page<Goods> goodss = goodsService.getPage(searchParams, pageNumber, PAGE_SIZE, sortType);

        model.addAttribute("goodss", goodss);
        model.addAttribute("sortType", sortType);
        model.addAttribute("sortTypes", sortTypes);
        // 将搜索条件编码成字符串，用于排序，分页的URL
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
        return "goods/goodsList";
    }

    @RequestMapping(value = "create", method = RequestMethod.GET)
    public String createForm(Model model) {
        model.addAttribute("goods", new Goods());
        model.addAttribute("action", "create");
        int  width =0;
        int  height =0;
        String size="0";
        List<Picturetype>  ptypelist =picturetypeService.getByPicturetypecode("103");
        if(ptypelist !=null&&ptypelist.size()==1){
            width = ptypelist.get(0).getMaxwidth(); // 得到源图宽
            height = ptypelist.get(0).getMaxheight(); // 得到源图长
            size = ptypelist.get(0).getFilemaxsize(); // 得到源图大小
        }
        model.addAttribute("width", width);
        model.addAttribute("height", height);
        model.addAttribute("size", size);
        return "goods/goodsForm";
    }

    @RequestMapping(value = "create", method = RequestMethod.POST)
    public String create(@Valid Goods newGoods,int width ,int height, RedirectAttributes redirectAttributes, MultipartFile file) {
        String relativePath ="goods/";
        if(!file.isEmpty()){
            File descfile = FileUploadUtil.saveFile(file, relativePath,true,width,height);
            newGoods.setImage(relativePath+ descfile.getName());
        }
        goodsService.save(newGoods);
        redirectAttributes.addFlashAttribute("message", "创建成功");
        return "redirect:/goods/list";
    }

    @RequestMapping(value = "update/{id}", method = RequestMethod.GET)
    public String updateForm(@PathVariable("id") Long id, Model model) {
        Goods goods =goodsService.findOne(id);
        model.addAttribute("goods", goods);
        List<Goods> recommends = goodsService.getRecommends(id);
        model.addAttribute("recommends", recommends);
        model.addAttribute("action", "update");
        int  width =0;
        int  height =0;
        String size="0";
        List<Picturetype>  ptypelist =picturetypeService.getByPicturetypecode("103");
        if(ptypelist !=null&&ptypelist.size()==1){
            width = ptypelist.get(0).getMaxwidth(); // 得到源图宽
            height = ptypelist.get(0).getMaxheight(); // 得到源图长
            size = ptypelist.get(0).getFilemaxsize(); // 得到源图大小
        }
        model.addAttribute("width", width);
        model.addAttribute("height", height);
        model.addAttribute("size", size);
        return "goods/goodsForm";
    }

    @RequestMapping(value = "update", method = RequestMethod.POST)
    public String update(@Valid @ModelAttribute("preloadGoods") Goods goods,int width ,int height, RedirectAttributes redirectAttributes, 
            MultipartFile file) {
        String relativePath ="goods/";
        if(!file.isEmpty()){
            File descimgfile = FileUploadUtil.saveFile(file, relativePath,true,width,height);
            FileUploadUtil.delete(goods.getImage());
            goods.setImage(relativePath+ descimgfile.getName());
        }
        goodsService.save(goods);
        redirectAttributes.addFlashAttribute("message", "保存成功");
        return "redirect:/goods/list";
    }

    @RequestMapping(value = "delete/{id}")
    public String delete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
        goodsService.deleteGoodsAndCartAndFeatured(id);
        redirectAttributes.addFlashAttribute("message", "删除成功");
        return "redirect:/goods/list";
    }

    /**
     * 使用@ModelAttribute, 实现Struts2
     * Preparable二次部分绑定的效果,先根据form的id从数据库查出Goods对象,再把Form提交的内容绑定到该对象上。
     * 因为仅update()方法的form中有id属性，因此本方法在该方法中执行.
     */
    @ModelAttribute("preloadGoods")
    public Goods getGoods(@RequestParam(value = "id", required = false) Long id) {
        if (id != null) {
            return goodsService.findOne(id);
        }
        return null;
    }
    //添加推荐
    @RequestMapping(value = "/select",method = RequestMethod.GET)
    public String select(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");
        Page<Goods> goodss = goodsService.getPage(searchParams, pageNumber, PAGE_SIZE, sortType);
        model.addAttribute("goodss", goodss);
        model.addAttribute("sortType", sortType);
        model.addAttribute("sortTypes", sortTypes);
        // 将搜索条件编码成字符串，用于排序，分页的URL
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
        return "goods/goodsSelect";
    }
}
