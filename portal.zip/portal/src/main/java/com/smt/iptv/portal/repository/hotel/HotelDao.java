package com.smt.iptv.portal.repository.hotel;

import com.smt.iptv.portal.entity.hotel.Hotel;
import com.smt.iptv.portal.repository.BaseDao;

public interface HotelDao extends BaseDao<Hotel> {

}
