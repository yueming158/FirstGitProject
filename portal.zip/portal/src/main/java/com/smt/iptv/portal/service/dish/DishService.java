package com.smt.iptv.portal.service.dish;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;
import com.smt.iptv.portal.i18nentity.dish.Dish;
import com.smt.iptv.portal.i18nrepository.dish.DishDao;
import com.smt.iptv.portal.service.cmp.BaseService;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class DishService extends BaseService<DishDao, Dish> {
    
    public List<Dish> getRecommends(Long id){
        Dish d = dao.findOne(id);
        if(d!=null&& StringUtils.isNotEmpty(d.getRecommend())){
            List<Long> idList =Lists.newArrayList();
            String [] idArr =d.getRecommend().split(",");
            for(String idStr:idArr){
                if(idStr.matches("\\d+")){
                    idList.add(Long.parseLong(idStr));
                }
            }
            if(idList.size()>0){
                return (List<Dish>)dao.findAll(idList);
            }
        }
        return null;//dao.findAll();
    }
    @Transactional(readOnly = false)
    public void deleteDishAndCartAndFeatured(Long dishId){
        dao.deleteFeatured(dishId);
        dao.deleteCartWithDishId(dishId);
        dao.delete(dishId);
    }
}
