package com.smt.iptv.portal.web.dish;

import java.util.List;
import java.util.Map;

import javax.servlet.ServletRequest;
import javax.validation.Valid;

import org.apache.shiro.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Maps;
import com.smt.iptv.portal.entity.Dishorder;
import com.smt.iptv.portal.entity.Dishordermap;
import com.smt.iptv.portal.service.account.ShiroDbRealm.ShiroUser;
import com.smt.iptv.portal.service.dish.DishorderService;

/**
 * Dishorder管理的Controller, 使用Restful风格的Urls:
 * 
 * List page     : GET /dishorder/
 * Create page   : GET /dishorder/create
 * Create action : POST /dishorder/create
 * Update page   : GET /dishorder/update/{id}
 * Update action : POST /dishorder/update
 * Delete action : GET /dishorder/delete/{id}
 * 
 * @author xjw
 */
@Controller
@RequestMapping(value = "/dishorder")
public class DishorderController {

	private static final int PAGE_SIZE = 50;

	private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
	static {
		sortTypes.put("auto", "自动");
		sortTypes.put("dishordername", "名称");
	}

	@Autowired
	private DishorderService dishorderService;

	@RequestMapping(value = "/list")
	public String list(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
			@RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
		Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");

		Page<Dishorder> dishorders = dishorderService.getPage( searchParams, pageNumber, PAGE_SIZE, sortType);

		model.addAttribute("dishorders", dishorders);
		model.addAttribute("sortType", sortType);
		model.addAttribute("sortTypes", sortTypes);
		// 将搜索条件编码成字符串，用于排序，分页的URL
		model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
		return "dishorder/dishorderList";
	}

	@RequestMapping(value = "create", method = RequestMethod.GET)
	public String createForm(Model model) {
		model.addAttribute("dishorder", new Dishorder());
		model.addAttribute("action", "create");
		return "dishorder/dishorderForm";
	}

	@RequestMapping(value = "create", method = RequestMethod.POST)
	public String create(@Valid Dishorder newDishorder, RedirectAttributes redirectAttributes) {

		dishorderService.save(newDishorder);
		redirectAttributes.addFlashAttribute("message", "新增成功");
		return "redirect:/dishorder/list";
	}

	@RequestMapping(value = "update/{id}", method = RequestMethod.GET)
	public String updateForm(@PathVariable("id") Long id, Model model) {
		model.addAttribute("dishorder", dishorderService.findOne(id));
		List<Dishordermap> maps =dishorderService.getDishListByOrder(id);
        model.addAttribute("maps", maps);
		model.addAttribute("action", "save");
		return "dishorder/dishorderForm";
	}

	@RequestMapping(value = "update", method = RequestMethod.POST)
	public String update(@Valid @ModelAttribute("preloadDishorder") Dishorder dishorder, RedirectAttributes redirectAttributes) {
		dishorderService.save(dishorder);
		redirectAttributes.addFlashAttribute("message", "保存成功");
		return "redirect:/dishorder/list";
	}

	@RequestMapping(value = "delete/{id}")
	public String delete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
		dishorderService.delete(id);
		redirectAttributes.addFlashAttribute("message", "删除成功");
		return "redirect:/dishorder/list";
	}

	/**
	 * 使用@ModelAttribute, 实现Struts2 Preparable二次部分绑定的效果
	 */
	@ModelAttribute("preloadDishorder")
	public Dishorder getDishorder(@RequestParam(value = "id", required = false) Long id) {
		if (id != null) {
			return dishorderService.findOne(id);
		}
		return null;
	}
    @RequestMapping(value = "detail", method = RequestMethod.GET)
    public String detail(Long id, Model model) {
        Dishorder dishorder =dishorderService.findOne(id);
        List<Dishordermap> maps =dishorderService.getDishListByOrder(id);
        model.addAttribute("maps", maps);
        model.addAttribute("dishorder", dishorder);
        return "dishorder/detail";
    }
    
    @RequestMapping(value = "verify/{id}")
    public String response(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
        ShiroUser user = (ShiroUser) SecurityUtils.getSubject().getPrincipal();
        if (dishorderService.verify(id,user.getName()) != null) {
            redirectAttributes.addFlashAttribute("message", "订单已核对");
        } else {
            redirectAttributes.addFlashAttribute("message", "订单核对错误");
        }
        return "redirect:/dishorder/list";
    }
    @RequestMapping(value = "complete/{id}")
    public String complete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {

        if (dishorderService.complete(id) != null) {
            redirectAttributes.addFlashAttribute("message", "订单完成并关闭");
        } else {
            redirectAttributes.addFlashAttribute("message", "订单关闭失败");
        }
        return "redirect:/dishorder/list";
    }
    @RequestMapping(value = "cancel/{id}")
    public String cancel(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {

        if (dishorderService.cancel(id) != null) {
            redirectAttributes.addFlashAttribute("message", "订单已取消");
        } else {
            redirectAttributes.addFlashAttribute("message", "订单取消失败");
        }
        return "redirect:/dishorder/list";
    }
    
    @RequestMapping(value = "/newordercount")
    @ResponseBody
    public int newordercount() {
        return dishorderService.getNewOrderCount();
    }
}
