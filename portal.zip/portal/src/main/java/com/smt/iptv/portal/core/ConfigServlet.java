package com.smt.iptv.portal.core;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.smt.iptv.portal.entity.Globalconfig;
import com.smt.iptv.portal.model.SystemConstant;
import com.smt.iptv.portal.push.PushServer;
import com.smt.iptv.portal.repository.GlobalconfigDao;

public class ConfigServlet extends HttpServlet {

    private static final long serialVersionUID = 6518116926795353891L;

    public ConfigServlet() {
        super();
    }

    public void destroy() {
        super.destroy();
        // Put your code here
    }

    public void init() throws ServletException {
        load();
        //PushServer.init(10000);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) {
        load();
        PrintWriter out;
        try {
            out = response.getWriter();
            out.print("{success:true}");
            out.flush();
            out.close();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) {
        doPost(request, response);
    }

    private void load() {

        WebApplicationContext webApplicationContext = WebApplicationContextUtils
                .getRequiredWebApplicationContext(getServletContext());
        GlobalconfigDao dao = (GlobalconfigDao) webApplicationContext.getBean("globalconfigDao");
        List<Globalconfig> list = (List<Globalconfig>) dao.findAll();
        for (Globalconfig g : list) {
            SystemConstant.map.put(g.getName(), g.getValue());
        }
        
    }

}
