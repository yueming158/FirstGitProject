package com.smt.iptv.portal.entity;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.portal.core.IdEntity;
@Entity
@Table(name = "physicalchannel")
public class Physicalchannel extends IdEntity {
    
    public Physicalchannel() {
    }

    public Physicalchannel(Long id) {
        this.id = id;
    }
	private String cpobjectcode;
	private String bitratedef;
	private String ip;
	private String port;
	private String sourceip;
	private String sourceport;  
    private String encoderip;
    private String encoderport;
    private String drmrecvip;
    private String drmrecvport;
    private Integer frequency;
    private Integer pmtpid;
    private String channelurl;  
    private String timeshifturl;
    private String unicasturl;


    public String getCpobjectcode() {
        return cpobjectcode;
    }

    public void setCpobjectcode(String cpobjectcode) {
        this.cpobjectcode = cpobjectcode;
    }

    public String getBitratedef() {
        return bitratedef;
    }

    public void setBitratedef(String bitratedef) {
        this.bitratedef = bitratedef;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public String getSourceip() {
        return sourceip;
    }

    public void setSourceip(String sourceip) {
        this.sourceip = sourceip;
    }

    public String getSourceport() {
        return sourceport;
    }

    public void setSourceport(String sourceport) {
        this.sourceport = sourceport;
    }

    public String getEncoderip() {
        return encoderip;
    }

    public void setEncoderip(String encoderip) {
        this.encoderip = encoderip;
    }

    public String getEncoderport() {
        return encoderport;
    }

    public void setEncoderport(String encoderport) {
        this.encoderport = encoderport;
    }

    public String getDrmrecvip() {
        return drmrecvip;
    }

    public void setDrmrecvip(String drmrecvip) {
        this.drmrecvip = drmrecvip;
    }

    public String getDrmrecvport() {
        return drmrecvport;
    }

    public void setDrmrecvport(String drmrecvport) {
        this.drmrecvport = drmrecvport;
    }

    public Integer getFrequency() {
        return frequency;
    }

    public void setFrequency(Integer frequency) {
        
        this.frequency = frequency;
    }

    public Integer getPmtpid() {
        return pmtpid;
    }

    public void setPmtpid(Integer pmtpid) {
        this.pmtpid = pmtpid;
    }

    public String getChannelurl() {
        return channelurl;
    }

    public void setChannelurl(String channelurl) {
        this.channelurl = channelurl;
    }

    public String getTimeshifturl() {
        return timeshifturl;
    }

    public void setTimeshifturl(String timeshifturl) {
        this.timeshifturl = timeshifturl;
    }

    public String getUnicasturl() {
        return unicasturl;
    }

    public void setUnicasturl(String unicasturl) {
        this.unicasturl = unicasturl;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((bitratedef == null) ? 0 : bitratedef.hashCode());
        result = prime * result + ((channelurl == null) ? 0 : channelurl.hashCode());
        result = prime * result + ((cpobjectcode == null) ? 0 : cpobjectcode.hashCode());
        result = prime * result + ((drmrecvip == null) ? 0 : drmrecvip.hashCode());
        result = prime * result + ((drmrecvport == null) ? 0 : drmrecvport.hashCode());
        result = prime * result + ((encoderip == null) ? 0 : encoderip.hashCode());
        result = prime * result + ((encoderport == null) ? 0 : encoderport.hashCode());
        result = prime * result + ((frequency == null) ? 0 : frequency.hashCode());
        result = prime * result + ((ip == null) ? 0 : ip.hashCode());
        result = prime * result + ((pmtpid == null) ? 0 : pmtpid.hashCode());
        result = prime * result + ((port == null) ? 0 : port.hashCode());
        result = prime * result + ((sourceip == null) ? 0 : sourceip.hashCode());
        result = prime * result + ((sourceport == null) ? 0 : sourceport.hashCode());
        result = prime * result + ((timeshifturl == null) ? 0 : timeshifturl.hashCode());
        result = prime * result + ((unicasturl == null) ? 0 : unicasturl.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        Physicalchannel other = (Physicalchannel) obj;
        if (bitratedef == null) {
            if (other.bitratedef != null)
                return false;
        } else if (!bitratedef.equals(other.bitratedef))
            return false;
        if (channelurl == null) {
            if (other.channelurl != null)
                return false;
        } else if (!channelurl.equals(other.channelurl))
            return false;
        if (cpobjectcode == null) {
            if (other.cpobjectcode != null)
                return false;
        } else if (!cpobjectcode.equals(other.cpobjectcode))
            return false;
        if (drmrecvip == null) {
            if (other.drmrecvip != null)
                return false;
        } else if (!drmrecvip.equals(other.drmrecvip))
            return false;
        if (drmrecvport == null) {
            if (other.drmrecvport != null)
                return false;
        } else if (!drmrecvport.equals(other.drmrecvport))
            return false;
        if (encoderip == null) {
            if (other.encoderip != null)
                return false;
        } else if (!encoderip.equals(other.encoderip))
            return false;
        if (encoderport == null) {
            if (other.encoderport != null)
                return false;
        } else if (!encoderport.equals(other.encoderport))
            return false;
        if (frequency == null) {
            if (other.frequency != null)
                return false;
        } else if (!frequency.equals(other.frequency))
            return false;
        if (ip == null) {
            if (other.ip != null)
                return false;
        } else if (!ip.equals(other.ip))
            return false;
        if (pmtpid == null) {
            if (other.pmtpid != null)
                return false;
        } else if (!pmtpid.equals(other.pmtpid))
            return false;
        if (port == null) {
            if (other.port != null)
                return false;
        } else if (!port.equals(other.port))
            return false;
        if (sourceip == null) {
            if (other.sourceip != null)
                return false;
        } else if (!sourceip.equals(other.sourceip))
            return false;
        if (sourceport == null) {
            if (other.sourceport != null)
                return false;
        } else if (!sourceport.equals(other.sourceport))
            return false;
        if (timeshifturl == null) {
            if (other.timeshifturl != null)
                return false;
        } else if (!timeshifturl.equals(other.timeshifturl))
            return false;
        if (unicasturl == null) {
            if (other.unicasturl != null)
                return false;
        } else if (!unicasturl.equals(other.unicasturl))
            return false;
        return true;
    }
    
}