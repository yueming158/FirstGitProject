package com.smt.iptv.portal.model;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.portal.core.IdEntity;


public class PhysicalChannel extends IdEntity {


	public PhysicalChannel() {
	}

	public PhysicalChannel(Long id) {
		this.id = id;
	}
	private String cpobjectcode;
	private String bitratedef;
	private String ip;
	private String port;
	private String sourceip;
	private String sourceport;
	private String encoderip;
	private String encoderport;
	private String drmrecvip;
	private String drmrecvport;
	private String frequency;
	private String pmtpid;
	private String channelurl;
	private String timeshifturl;
	private String unicasturl;

    public String getCpobjectcode() {
        return cpobjectcode;
    }

    public void setCpobjectcode(String cpobjectcode) {
        this.cpobjectcode = cpobjectcode;
    }

    public String getBitratedef() {
        return bitratedef;
    }

    public void setBitratedef(String bitratedef) {
        this.bitratedef = bitratedef;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public String getSourceip() {
        return sourceip;
    }

    public void setSourceip(String sourceip) {
        this.sourceip = sourceip;
    }

    public String getSourceport() {
        return sourceport;
    }

    public void setSourceport(String sourceport) {
        this.sourceport = sourceport;
    }

    public String getEncoderip() {
        return encoderip;
    }

    public void setEncoderip(String encoderip) {
        this.encoderip = encoderip;
    }

    public String getEncoderport() {
        return encoderport;
    }

    public void setEncoderport(String encoderport) {
        this.encoderport = encoderport;
    }

    public String getDrmrecvip() {
        return drmrecvip;
    }

    public void setDrmrecvip(String drmrecvip) {
        this.drmrecvip = drmrecvip;
    }

    public String getDrmrecvport() {
        return drmrecvport;
    }

    public void setDrmrecvport(String drmrecvport) {
        this.drmrecvport = drmrecvport;
    }

    public String getFrequency() {
        return frequency;
    }

    public void setFrequency(String frequency) {
        this.frequency = frequency;
    }

    public String getPmtpid() {
        return pmtpid;
    }

    public void setPmtpid(String pmtpid) {
        this.pmtpid = pmtpid;
    }

    public String getChannelurl() {
        return channelurl;
    }

    public void setChannelurl(String channelurl) {
        this.channelurl = channelurl;
    }

    public String getTimeshifturl() {
        return timeshifturl;
    }

    public void setTimeshifturl(String timeshifturl) {
        this.timeshifturl = timeshifturl;
    }

    public String getUnicasturl() {
        return unicasturl;
    }

    public void setUnicasturl(String unicasturl) {
        this.unicasturl = unicasturl;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}