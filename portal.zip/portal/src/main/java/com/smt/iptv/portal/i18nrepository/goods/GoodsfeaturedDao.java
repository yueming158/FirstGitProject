package com.smt.iptv.portal.i18nrepository.goods;

import com.smt.iptv.portal.i18nentity.goods.Goodsfeatured;
import com.smt.iptv.portal.repository.BaseDao;

public interface GoodsfeaturedDao  extends BaseDao<Goodsfeatured>{
    public Goodsfeatured getByGoodsId(Long goodsId);
}
