package com.smt.iptv.portal.i18nentity.info;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.portal.core.IdEntity;
@Entity
@Table(name = "infotemplate")
public class Infotemplate extends IdEntity {
    
    public Infotemplate() {
    }

    public Infotemplate(Long id) {
        this.id = id;
    }

	private String name;
	private String code;
	private String field;
	private String head;
	private Integer swidth;
	private Integer sheight;
	private Integer lwidth;
	private Integer lheight;
	private String enabled;
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public String getHead() {
        return head;
    }

    public void setHead(String head) {
        this.head = head;
    }

    public Integer getSwidth() {
        return swidth;
    }

    public void setSwidth(Integer swidth) {
        this.swidth = swidth;
    }

    public Integer getSheight() {
        return sheight;
    }

    public void setSheight(Integer sheight) {
        this.sheight = sheight;
    }

    public Integer getLwidth() {
        return lwidth;
    }

    public void setLwidth(Integer lwidth) {
        this.lwidth = lwidth;
    }

    public Integer getLheight() {
        return lheight;
    }

    public void setLheight(Integer lheight) {
        this.lheight = lheight;
    }

    public String getEnabled() {
        return enabled;
    }

    public void setEnabled(String enabled) {
        this.enabled = enabled;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}