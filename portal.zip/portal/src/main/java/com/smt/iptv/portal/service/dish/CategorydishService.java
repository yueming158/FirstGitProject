package com.smt.iptv.portal.service.dish;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.i18nentity.dish.Categorydish;
import com.smt.iptv.portal.i18nentity.dish.Dish;
import com.smt.iptv.portal.i18nrepository.dish.CategorydishDao;
import com.smt.iptv.portal.service.cmp.BaseService;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class CategorydishService extends BaseService<CategorydishDao, Categorydish>{
    /**
     * 获取某个类型下 未分类的菜品
     * 
     */
    public Page<Dish> getDishExceptCategory(Long categoryid, int pageNumber,
            int pageSize, String sortType) {
        PageRequest pageRequest = buildPageRequest(pageNumber, pageSize, sortType);
            return dao.getDishExceptCategory(categoryid, pageRequest);

    }
    
    @Transactional(readOnly = false)
    public void deleteAll(Long [] ids) {
        if(ids!=null)
        for(Long id:ids){
            dao.delete(id);
        }
    }
}
