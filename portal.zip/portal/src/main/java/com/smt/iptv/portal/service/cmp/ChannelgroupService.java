package com.smt.iptv.portal.service.cmp;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.entity.Channelgroup;
import com.smt.iptv.portal.repository.video.ChannelgroupDao;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class ChannelgroupService extends BaseService<ChannelgroupDao, Channelgroup> {

    @Transactional(readOnly = false)
    public boolean deleteSingle(Long id) {
        Long channelgroupid=dao.getSingleChannelgroupId(id);
        if(channelgroupid!=null){
            dao.delete(channelgroupid);
            return true;
        }
        return false;
    }
    public Channelgroup getBychannelgroupcode(String channelgroupcode){
        return dao.getBychannelgroupcode(channelgroupcode);
    }
}
