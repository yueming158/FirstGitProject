package com.smt.iptv.portal.service.cmp;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.entity.Appupdateinfo;
import com.smt.iptv.portal.repository.AppupdateinfoDao;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class AppupdateinfoService extends BaseService<AppupdateinfoDao, Appupdateinfo> {
    public Appupdateinfo getAppupdateinfoForInitConfig(){
        return dao.getAppupdateinfoForInitConfig();
    }
}
