package com.smt.iptv.portal.service.aaa;

import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.entity.aaa.Productoffer;
import com.smt.iptv.portal.repository.aaa.ProductofferDao;
import com.smt.iptv.portal.service.cmp.BaseService;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class ProductofferService extends BaseService<ProductofferDao, Productoffer> {
	public Page<Productoffer> getProductoffers(Map<String, Object> searchParams, int pageNumber, int pageSize,
            String sortType,List<Long> orderedPrdouctofferIds){
		orderedPrdouctofferIds.add(0l);
		PageRequest page = buildPageRequestDesc(pageNumber, pageSize, sortType);
		

		String productofferName = (String) searchParams.get("LIKE_productofferName");
		String productofferType = (String) searchParams.get("EQ_productoffertype");
		String strategytype = (String) searchParams.get("EQ_strategytype");
		if(null == productofferName) {
			productofferName = "";
		}	
		productofferName = "%"+productofferName+"%";
		if(null == strategytype || "".equals(strategytype)) {
			return dao.getProductoffers(productofferName,productofferType,orderedPrdouctofferIds,page);
		}
		return dao.getProductoffers(productofferName, productofferType, strategytype, orderedPrdouctofferIds, page);	
	}
}
