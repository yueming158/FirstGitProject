package com.smt.iptv.portal.web.program;

import java.io.File;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import apk.parser.ApkInfo;
import apk.parser.GetApkInfo;

import com.google.common.collect.Maps;
import com.smt.iptv.portal.core.FileUploadUtil;
import com.smt.iptv.portal.i18nentity.Game;
import com.smt.iptv.portal.i18nentity.program.Picturetype;
import com.smt.iptv.portal.service.cmp.GameService;
import com.smt.iptv.portal.service.cmp.PicturetypeService;
import com.smt.iptv.portal.service.info.MenuService;

/**
 * Game管理的Controller, 使用Restful风格的Urls:
 * 
 * List page : GET /game/ Create page : GET /game/create Create action : POST
 * /game/create Update page : GET /game/update/{id} Update action : POST
 * /game/update Delete action : GET /game/delete/{id}
 * 
 * @author xjw
 */
@Controller
@RequestMapping(value = "/game")
public class GameController {
    private static final long GAME_TEMPLATE_ID = 19L;
    private static final int PAGE_SIZE = 50;

    private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
    static {
        sortTypes.put("auto", "自动");
        sortTypes.put("gamename", "名称");
    }

    @Autowired
    private GameService gameService;
    @Autowired
    private MenuService menuService;
    @Autowired
    private PicturetypeService  picturetypeService;
    @RequestMapping(value = "/list")
    public String list(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");

        Page<Game> games = gameService.getPage(searchParams, pageNumber, PAGE_SIZE, sortType);
        model.addAttribute("gamemenutypes", menuService.getByInfotemplateId((GAME_TEMPLATE_ID)));
        model.addAttribute("games", games);
        model.addAttribute("sortType", sortType);
        model.addAttribute("sortTypes", sortTypes);
        // 将搜索条件编码成字符串，用于排序，分页的URL
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
        return "game/gameList";
    }

    @RequestMapping(value = "create", method = RequestMethod.GET)
    public String createForm(Model model) {
        model.addAttribute("gamemenutypes", menuService.getByInfotemplateId((GAME_TEMPLATE_ID)));
        model.addAttribute("game", new Game());
        model.addAttribute("action", "create");
        int  width =0;
        int  height =0;
        String size="0";
        List<Picturetype>  ptypelist =picturetypeService.getByPicturetypecode("102");
        if(ptypelist !=null&&ptypelist.size()==1){
            width = ptypelist.get(0).getMaxwidth(); // 得到源图宽
            height = ptypelist.get(0).getMaxheight(); // 得到源图长
            size = ptypelist.get(0).getFilemaxsize(); // 得到源图大小
        }
        model.addAttribute("width", width);
        model.addAttribute("height", height);
        model.addAttribute("size", size);
        return "game/gameForm";
    }

    @RequestMapping(value = "create", method = RequestMethod.POST)
    public String create(@Valid Game newGame,int width ,int height, RedirectAttributes redirectAttributes, MultipartFile imgfile, MultipartFile file) {
        String relativePath = "game/";
        File descimgfile = FileUploadUtil.saveFile(imgfile, relativePath, true,width,height);
        if(descimgfile!=null&&descimgfile.isFile()){
            newGame.setImgurl(relativePath + descimgfile.getName());
        }
        File descfile = FileUploadUtil.saveFile(file, relativePath, true,0,0);
        if(descfile!=null&&descfile.isFile()){
            newGame.setDownurl(relativePath + descfile.getName());
            //自动获取包名
            ApkInfo apk =GetApkInfo.getApkInfoByFilePath(descfile);
            if(apk!=null){
                newGame.setGamepackage(apk.getPackageName());
                newGame.setEntrance(apk.getMainName());
                newGame.setGamesize(new Long(descfile.length()).intValue());
            }else{
                redirectAttributes.addFlashAttribute("message", "无法识别APK文件");
                return "redirect:/game/list";
            }
        }
        gameService.save(newGame);
        redirectAttributes.addFlashAttribute("message", "创建成功");
        return "redirect:/game/list";
    }

    @RequestMapping(value = "update/{id}", method = RequestMethod.GET)
    public String updateForm(@PathVariable("id") Long id, Model model) {
        model.addAttribute("gamemenutypes", menuService.getByInfotemplateId((GAME_TEMPLATE_ID)));
        model.addAttribute("game", gameService.findOne(id));
        model.addAttribute("action", "update");
        int  width =0;
        int  height =0;
        String size="0";
        List<Picturetype>  ptypelist =picturetypeService.getByPicturetypecode("102");
        if(ptypelist !=null&&ptypelist.size()==1){
            width = ptypelist.get(0).getMaxwidth(); // 得到源图宽
            height = ptypelist.get(0).getMaxheight(); // 得到源图长
            size = ptypelist.get(0).getFilemaxsize(); // 得到源图大小
        }
        model.addAttribute("width", width);
        model.addAttribute("height", height);
        model.addAttribute("size", size);
        return "game/gameForm";
    }

    @RequestMapping(value = "update", method = RequestMethod.POST)
    public String update(@Valid @ModelAttribute("preloadGame") Game game,int width ,int height,RedirectAttributes redirectAttributes, MultipartFile imgfile, MultipartFile file) {
        String relativePath = "game/";
        File descfile = FileUploadUtil.saveFile(file, relativePath, true,0,0);
        if (descfile!=null&&descfile.isFile()) {
            if(!(relativePath + descfile.getName()).equals(game.getDownurl())){
                FileUploadUtil.delete(game.getDownurl());
                game.setDownurl(relativePath + descfile.getName());
            }
        }
        File descimgfile = FileUploadUtil.saveFile(imgfile, relativePath, true,width,height);
        if (descimgfile!=null&&descimgfile.isFile()) {
            FileUploadUtil.delete(game.getImgurl());
            game.setImgurl(relativePath + descimgfile.getName());
            //自动获取包名
            ApkInfo apk =GetApkInfo.getApkInfoByFilePath(descfile);
            if(apk!=null){
                game.setGamepackage(apk.getPackageName());
                game.setEntrance(apk.getMainName());
                game.setGamesize(new Long(descfile.length()).intValue());
            }else{
                redirectAttributes.addFlashAttribute("message", "无法识别APK文件");
                return "redirect:/game/list";
            }
        }
        gameService.save(game);
        redirectAttributes.addFlashAttribute("message", "保存成功");
        return "redirect:/game/list";
    }

    @RequestMapping(value = "delete/{id}")
    public String delete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
        gameService.delete(id);
        redirectAttributes.addFlashAttribute("message", "删除成功");
        return "redirect:/game/list";
    }

    /**
     * 使用@ModelAttribute, 实现Struts2
     * Preparable二次部分绑定的效果,先根据form的id从数据库查出Game对象,再把Form提交的内容绑定到该对象上。
     * 因为仅update()方法的form中有id属性，因此本方法在该方法中执行.
     */
    @ModelAttribute("preloadGame")
    public Game getGame(@RequestParam(value = "id", required = false) Long id) {
        if (id != null) {
            return gameService.findOne(id);
        }
        return null;
    }

}
