package com.smt.iptv.portal.web.dish;

import java.io.File;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Maps;
import com.smt.iptv.portal.core.FileUploadUtil;
import com.smt.iptv.portal.i18nentity.dish.Dish;
import com.smt.iptv.portal.i18nentity.dish.Dishfeatured;
import com.smt.iptv.portal.i18nentity.program.Picturetype;
import com.smt.iptv.portal.service.cmp.PicturetypeService;
import com.smt.iptv.portal.service.dish.DishService;
import com.smt.iptv.portal.service.dish.DishfeaturedService;

/**
 * Dish管理的Controller, 使用Restful风格的Urls:
 * 
 * List page : GET /dish/ Create page : GET /dish/create Create action : POST
 * /dish/create Update page : GET /dish/update/{id} Update action : POST
 * /dish/update Delete action : GET /dish/delete/{id}
 * 
 * @author xjw
 */
@Controller
@RequestMapping(value = "/dish")
public class DishController {

    private static final int PAGE_SIZE = 50;

    private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
    static {
        sortTypes.put("auto", "自动");
        sortTypes.put("dishname", "名称");
    }

    @Autowired
    private DishService dishService;
    @Autowired
    private PicturetypeService  picturetypeService;
    @RequestMapping(value = "/list")
    public String list(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");

        Page<Dish> dishs = dishService.getPage(searchParams, pageNumber, PAGE_SIZE, sortType);

        model.addAttribute("dishs", dishs);
        model.addAttribute("sortType", sortType);
        model.addAttribute("sortTypes", sortTypes);
        // 将搜索条件编码成字符串，用于排序，分页的URL
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
        return "dish/dishList";
    }

    @RequestMapping(value = "create", method = RequestMethod.GET)
    public String createForm(Model model) {
        model.addAttribute("dish", new Dish());
        model.addAttribute("action", "create");
        int  width =0;
        int  height =0;
        String size="0";
        List<Picturetype>  ptypelist =picturetypeService.getByPicturetypecode("103");
        if(ptypelist !=null&&ptypelist.size()==1){
            width = ptypelist.get(0).getMaxwidth(); // 得到源图宽
            height = ptypelist.get(0).getMaxheight(); // 得到源图长
            size = ptypelist.get(0).getFilemaxsize(); // 得到源图大小
        }
        model.addAttribute("width", width);
        model.addAttribute("height", height);
        model.addAttribute("size", size);
        return "dish/dishForm";
    }

    @RequestMapping(value = "create", method = RequestMethod.POST)
    public String create(@Valid Dish newDish,int width ,int height, RedirectAttributes redirectAttributes, MultipartFile file) {
        String relativePath ="dish/";
        if(!file.isEmpty()){
            File descfile = FileUploadUtil.saveFile(file, relativePath,true,width,height);
            newDish.setImage(relativePath+ descfile.getName());
        }
        dishService.save(newDish);
        redirectAttributes.addFlashAttribute("message", "创建成功");
        return "redirect:/dish/list";
    }

    @RequestMapping(value = "update/{id}", method = RequestMethod.GET)
    public String updateForm(@PathVariable("id") Long id, Model model) {
        Dish dish =dishService.findOne(id);
        model.addAttribute("dish", dish);
        List<Dish> recommends = dishService.getRecommends(id);
        model.addAttribute("recommends", recommends);
        model.addAttribute("action", "update");
        int  width =0;
        int  height =0;
        String size="0";
        List<Picturetype>  ptypelist =picturetypeService.getByPicturetypecode("103");
        if(ptypelist !=null&&ptypelist.size()==1){
            width = ptypelist.get(0).getMaxwidth(); // 得到源图宽
            height = ptypelist.get(0).getMaxheight(); // 得到源图长
            size = ptypelist.get(0).getFilemaxsize(); // 得到源图大小
        }
        model.addAttribute("width", width);
        model.addAttribute("height", height);
        model.addAttribute("size", size);
        return "dish/dishForm";
    }

    @RequestMapping(value = "update", method = RequestMethod.POST)
    public String update(@Valid @ModelAttribute("preloadDish") Dish dish,int width ,int height, RedirectAttributes redirectAttributes, 
            MultipartFile file) {
        String relativePath ="dish/";
        if(!file.isEmpty()){
            File descimgfile = FileUploadUtil.saveFile(file, relativePath,true,width,height);
            FileUploadUtil.delete(dish.getImage());
            dish.setImage(relativePath+ descimgfile.getName());
        }
        dishService.save(dish);
        redirectAttributes.addFlashAttribute("message", "保存成功");
        return "redirect:/dish/list";
    }

    @RequestMapping(value = "delete/{id}")
    public String delete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
        dishService.deleteDishAndCartAndFeatured(id);
        redirectAttributes.addFlashAttribute("message", "删除成功");
        return "redirect:/dish/list";
    }

    /**
     * 使用@ModelAttribute, 实现Struts2
     * Preparable二次部分绑定的效果,先根据form的id从数据库查出Dish对象,再把Form提交的内容绑定到该对象上。
     * 因为仅update()方法的form中有id属性，因此本方法在该方法中执行.
     */
    @ModelAttribute("preloadDish")
    public Dish getDish(@RequestParam(value = "id", required = false) Long id) {
        if (id != null) {
            return dishService.findOne(id);
        }
        return null;
    }
    //添加推荐
    @RequestMapping(value = "/select",method = RequestMethod.GET)
    public String select(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");
        Page<Dish> dishs = dishService.getPage(searchParams, pageNumber, PAGE_SIZE, sortType);
        model.addAttribute("dishs", dishs);
        model.addAttribute("sortType", sortType);
        model.addAttribute("sortTypes", sortTypes);
        // 将搜索条件编码成字符串，用于排序，分页的URL
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
        return "dish/dishSelect";
    }
}
