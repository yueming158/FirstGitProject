package com.smt.iptv.portal.web.model;

import java.util.Collections;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.collect.Lists;
import com.smt.iptv.portal.core.CnToSpell;


public  class FileNode implements Comparable<FileNode>{
    
    private int id;
    private int pId;
    private String name;
    private boolean click;
    @JsonProperty("isParent")
    private boolean isParent=false;
    
    public FileNode() {
        super();
    }
    
    public FileNode(int id, int pId, String name, boolean click) {
        super();
        this.id = id;
        this.pId = pId;
        this.name = name;
        this.click = click;
        this.isParent=false;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public int getpId() {
        return pId;
    }
    public void setpId(int pId) {
        this.pId = pId;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public boolean isClick() {
        return click;
    }
    public void setClick(boolean click) {
        this.click = click;
    }

    public boolean isParent() {
        return isParent;
    }

    public void setParent(boolean isParent) {
        this.isParent = isParent;
    }

    @Override
    public int compareTo(FileNode o) {
        return CnToSpell.getSimpleSpell(this.getName()).compareToIgnoreCase(CnToSpell.getSimpleSpell(o.getName()));
    }

}