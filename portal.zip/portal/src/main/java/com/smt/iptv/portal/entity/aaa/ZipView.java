package com.smt.iptv.portal.entity.aaa;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.web.servlet.view.AbstractView;

import com.smt.iptv.portal.core.ZipUtils;


public class ZipView extends AbstractView {

	  @Override
	  protected void renderMergedOutputModel(Map<String, Object> model,
	      HttpServletRequest request, HttpServletResponse response)
	      throws Exception {
	    HSSFWorkbook wbs = generateExcel(model);
	    File file = getFile();
	    ZipUtils.zip(getFile(), wbs, generatePictures(model));
	    response.setContentType("application/octet-stream");
	    String name = URLEncoder.encode("节目数据.zip", "UTF-8");
	    response.setHeader("Content-disposition", "attachment;filename="
	        + name);
	    OutputStream os = response.getOutputStream();
	    IOUtils.copy(new FileInputStream(file), os);
	    os.flush();
	    os.close();
	    file.delete();
	  }
	  
	  

	  private HSSFWorkbook generateExcel(Map<String, Object> model) {		
		return (HSSFWorkbook) model.get("exportexcel");
	  }
	  
	  private List<String> generatePictures(Map<String, Object> model) {		
		 return (List<String>) model.get("pictures");
	  }

	 private File getFile(){
	    String targetPath = "/ziptarget/zip/";
	    File file = new File(targetPath);
	    if( !file.exists() ){
	      file.mkdirs();
	    }
	    String fileName = "export.zip";
	    File f = new File(targetPath+fileName);
	    if( !f.exists() ){
	      try {
	        File.createTempFile("export", ".zip");
	      } catch (IOException e) {
	        e.printStackTrace();
	      }
	    }
	    return f;
	  }
}
