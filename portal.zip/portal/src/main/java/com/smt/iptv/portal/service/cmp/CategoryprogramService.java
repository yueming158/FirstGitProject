package com.smt.iptv.portal.service.cmp;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;
import com.smt.iptv.portal.i18nentity.Category;
import com.smt.iptv.portal.i18nentity.Categoryprogram;
import com.smt.iptv.portal.i18nentity.program.Program;
import com.smt.iptv.portal.i18nrepository.CategoryprogramDao;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class CategoryprogramService extends BaseService<CategoryprogramDao, Categoryprogram>{
    @Transactional(readOnly = false)
    public void save(Long programid,String categoryids){
        if(programid!=null&&categoryids!=null){
            List<Categoryprogram> list =dao.getByProgramId(programid);
            for (String idStr : categoryids.split(",")) {
                boolean isNew=true;
                Long cid =Long.parseLong(idStr);
                for(Categoryprogram cp:list){
                    if(cp.getCategory().getId()==cid){
                        isNew=false;
                        break;
                    }
                }
                if(isNew){
                    Categoryprogram cp = new Categoryprogram();
                    cp.setCategory(new Category(cid));
                    cp.setProgram(new Program(programid));
                    list.add(cp);
                }
            }
            List<Categoryprogram> deletelist =Lists.newArrayList();
            for(Categoryprogram cp:list){
                boolean isDelete=true;
                for (String idStr : categoryids.split(",")) {
                    Long cid =Long.parseLong(idStr);
                    if(cp.getCategory().getId()==cid){
                        isDelete=false;
                        break;
                    }
                }
                if(isDelete){
                    deletelist.add(cp);
                }
            }
            list.removeAll(deletelist);
            dao.save(list);
            dao.delete(deletelist);
        }

    }
    @Transactional(readOnly = false)
    public void updateAllSequence(Integer offset,Long categoryid){
        dao.updateAllSequence(offset,categoryid);
    }
    @Transactional(readOnly = false)
    public void deleteAll(Long [] ids) {
        if(ids!=null)
        for(Long id:ids){   
            dao.delete(id);
        }
    }
    
}
