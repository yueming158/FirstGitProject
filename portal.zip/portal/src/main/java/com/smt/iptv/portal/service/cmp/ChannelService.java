package com.smt.iptv.portal.service.cmp;

import java.text.DecimalFormat;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.core.ServiceException;
import com.smt.iptv.portal.entity.Channel;
import com.smt.iptv.portal.entity.Slavechannel;
import com.smt.iptv.portal.repository.video.ChannelDao;
import com.smt.iptv.portal.service.send.ChannelLoaderService;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class ChannelService extends BaseService<ChannelDao, Channel> {

    @Autowired
    private ChannelLoaderService channelLoaderService;

    @Autowired
    private SlavechannelService slavechannelService;
    @Autowired
    private PhysicalchannelService physicalchannelService; 
    
    @Autowired
    private ScheduleService scheduleService;
    
    @Autowired
    private CustomizedchannelnoService customizedchannelnoService;
    
    /**
     * 
     * @param entity 要新增的new状态对象 无ID
     * @param Field   新增时需要默认添加编码的字段名
     * @param dcmFmtStr    默认编码的DecimalFormat格式，根据ID得到编码值。
     */
    
    @Transactional(readOnly = false)
    public void create(Channel entity,String propertyName,String dcmFmtStr) {
        dao.save(entity);
        //int index=dcmFmtStr.indexOf("0");
        //dcmFmtStr =dcmFmtStr.substring(0, index)+LocaleContextHolder.getLocale().getLanguage()+dcmFmtStr.substring(index);
        DecimalFormat dcmFmt = new DecimalFormat(dcmFmtStr);
        String code =dcmFmt.format(entity.getId());
        String methodEnd = propertyName.substring(0,1).toUpperCase() + propertyName.substring(1);
            try {
                entity.getClass().getMethod("set"+methodEnd, String.class).invoke(entity, code);
            } catch (Exception e) {
                throw new ServiceException(e);
            } 
        entity.setChannelnumber(entity.getId().intValue()); 
        dao.save(entity);
        Slavechannel slavechannel = new Slavechannel();
        slavechannel.setChannel(entity);
        slavechannel.setAreacode("all");
        slavechannelService.save(slavechannel);
        channelLoaderService.regist(entity);
    }

    @Transactional(readOnly = false)
    public Channel save(Channel entity) {
        // 新增或者修改loader
        if(entity.getId()==null||entity.getId()==0L){ 
            dao.save(entity);
            channelLoaderService.regist(entity);
        }else{
            dao.save(entity);
            channelLoaderService.update(entity);
        }
        return entity;
    }
    
    @Transactional(readOnly = false)
    public void deleteAllRel(Long id) {
        //删除loader
        Channel c =dao.findOne(id);
        if(c!=null){
            //还需删除节目表
            scheduleService.deleteByChannelId(id);
            //删除客户化频道
            customizedchannelnoService.deleteByChannelid(id);
            //删除 slavechannel 必须删除
            dao.deleteSlavechannel(id);
            //删除 virschedule 必须删除
            dao.deleteVirschedule(id);
            channelLoaderService.delete(c);
            //删除物理频道
            if(c.getPhysicalchannel()!=null){
                physicalchannelService.delete(c.getPhysicalchannel().getId());
            }
            //删除自己
            dao.delete(id);
        }
    }
    /*
     * 未使用
     
    @Transactional(readOnly = false)
    public void delete(Channel entity) {
        //删除loader
        Channel c =dao.findOne(entity.getId());
        if(c!=null){
            channelLoaderService.delete(c);
            if(c.getPhysicalchannel()!=null){
                physicalchannelService.delete(c.getPhysicalchannel().getId());
            }
            dao.delete(entity); 
        }
        //删除 loader
    }
    */
}
