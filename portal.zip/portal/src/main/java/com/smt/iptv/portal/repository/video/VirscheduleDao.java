package com.smt.iptv.portal.repository.video;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.smt.iptv.portal.entity.Virschedule;
import com.smt.iptv.portal.repository.BaseDao;

public interface VirscheduleDao  extends BaseDao<Virschedule>{
    
    @Query("delete from Virschedule v where cpobjectcode=?1")
    @Modifying
    public void deleteByCpobjectcode(String cpobjectcode);

    public Virschedule getByCpobjectcode(String cpobjectcode);
    
    public List<Virschedule> getByChannelCpobjectcode(String ChannelCode);
    
}
