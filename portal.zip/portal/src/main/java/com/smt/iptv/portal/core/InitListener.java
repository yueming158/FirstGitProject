package com.smt.iptv.portal.core;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.springframework.context.ApplicationContext;

import com.smt.iptv.portal.push.PushServer;

public class InitListener implements ServletContextListener{

    private ApplicationContext context;
    @Override
    public void contextInitialized(ServletContextEvent sce) {
        // TODO Auto-generated method stub
        // 应用开始的时候初始化mina，会创建一个NioSocketAcceptor进程
       // context = new ClassPathXmlApplicationContext("applicationContext.xml");
       PushServer.init(10000);
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        // TODO Auto-generated method stub
        // 应用关闭的时候调用NioSocketAcceptor的dispose()方法
        // ioAcceptor就是定义在applicationContext-minaServer.xml中的bean名字
        //NioSocketAcceptor nioacceptor = (NioSocketAcceptor)context.getBean("ioAcceptor");
        //nioacceptor.dispose();
        PushServer.close();
    }

}
