package com.smt.iptv.portal.i18nentity.program;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.portal.core.IdEntity;
@Entity
@Table(name = "castrole")
public class Castrole extends IdEntity {
    
    public Castrole() {
    }

    public Castrole(Long id) {
        this.id = id;
    }
    
    private String castrolename;
    private String cpobjectcode;
    private String description;
    private String programtype;

    public String getCastrolename() {
        return castrolename;
    }

    public void setCastrolename(String castrolename) {
        this.castrolename = castrolename;
    }

    public String getCpobjectcode() {
        return cpobjectcode;
    }

    public void setCpobjectcode(String cpobjectcode) {
        this.cpobjectcode = cpobjectcode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getProgramtype() {
        return programtype;
    }

    public void setProgramtype(String programtype) {
        this.programtype = programtype;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}