package com.smt.iptv.portal.web.program;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.smt.iptv.portal.i18nentity.Category;
import com.smt.iptv.portal.i18nentity.Categoryprogram;
import com.smt.iptv.portal.i18nentity.program.Program;
import com.smt.iptv.portal.service.cmp.CategoryService;
import com.smt.iptv.portal.service.cmp.CategoryprogramService;
import com.smt.iptv.portal.service.info.MenuService;

/**
 * Category管理的Controller, 使用Restful风格的Urls:
 * 
 * List page : GET /category/ Create page : GET /category/create Create action :
 * POST /category/create Update page : GET /category/update/{id} Update action :
 * POST /category/update Delete action : GET /category/delete/{id}
 * 
 * @author xjw
 */
@Controller
@RequestMapping(value = "/category")
public class CategoryController {

    private static final int PAGE_SIZE = 50;

    private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
    static {
        sortTypes.put("sequence", "自动");
    }
    private final static String VOD_TEMP_CODE ="lvb_x_vod_a";
    @Autowired
    private MenuService menuService;
    @Autowired
    private CategoryService categoryService;
    @Autowired
    private CategoryprogramService categoryprogramService;

    @RequestMapping(value = "/list")
    public String list(@RequestParam(value = "sortType", defaultValue = "sequence") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");
        searchParams.put("EQ_categorytype", "10");
        Page<Category> categorys = categoryService.getPage(searchParams, pageNumber, PAGE_SIZE, sortType);
        model.addAttribute("menus", menuService.getByInfotemplateCode(VOD_TEMP_CODE));
        model.addAttribute("categorys", categorys);
        model.addAttribute("sortType", sortType);
        model.addAttribute("sortTypes", sortTypes);
        // 将搜索条件编码成字符串，用于排序，分页的URL
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
        return "category/categoryList";
    }
    @RequestMapping(value = "/ajaxlist")
    public String ajaxlist(@RequestParam(value = "sortType", defaultValue = "sequence") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");
        searchParams.put("EQ_categorytype", "10");
        Page<Category> categorys = categoryService.getPage(searchParams, pageNumber, PAGE_SIZE, sortType);
        model.addAttribute("menus", menuService.getByInfotemplateCode(VOD_TEMP_CODE));
        model.addAttribute("categorys", categorys);
        model.addAttribute("sortType", sortType);
        model.addAttribute("sortTypes", sortTypes);
        // 将搜索条件编码成字符串，用于排序，分页的URL
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
        return "category/categoryajaxList";
    }
    @RequestMapping(value = "create", method = RequestMethod.GET)
    public String createForm(Model model,Category category,
            @RequestParam(value = "parentname",defaultValue = "根目录",required=false) String parentname) {
        model.addAttribute("menus", menuService.getByInfotemplateCode(VOD_TEMP_CODE));
        model.addAttribute("parentname", parentname);
        model.addAttribute("category", category);
        model.addAttribute("action", "create");
        return "category/categoryForm";
    }

    @RequestMapping(value = "create", method = RequestMethod.POST)
    public String create(@Valid Category newCategory,String tabindex, RedirectAttributes redirectAttributes) {
        categoryService.create(newCategory, "cpobjectcode", "cate0000000000");
        redirectAttributes.addFlashAttribute("message", "新增成功");
        redirectAttributes.addFlashAttribute("tabindex", tabindex);
        return "redirect:/category/list";
    }

    @RequestMapping(value = "update/{id}", method = RequestMethod.GET)
    public String updateForm(@PathVariable("id") Long id, Model model,
            @RequestParam(value = "parentname",defaultValue = "根目录",required=false) String parentname) {
        model.addAttribute("menus", menuService.getByInfotemplateCode(VOD_TEMP_CODE));
        model.addAttribute("parentname", parentname);
        model.addAttribute("category", categoryService.findOne(id));
        model.addAttribute("action", "update");
        return "category/categoryForm";
    }

    @RequestMapping(value = "update", method = RequestMethod.POST)
    public String update(@Valid @ModelAttribute("preloadCategory") Category category,String tabindex,
            RedirectAttributes redirectAttributes) {
        categoryService.save(category);
        redirectAttributes.addFlashAttribute("message", "保存成功");
        redirectAttributes.addFlashAttribute("tabindex", tabindex);
        return "redirect:/category/list";
    }

    @RequestMapping(value = "delete/{id}")
    public String delete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes,
            @RequestParam(value = "categorytype", defaultValue = "50",required =false) String categorytype,String tabindex) {
        boolean sucess = categoryService.deleteSingleCategory(id,categorytype);//删除 单独的记录，如果有关联记录则删除不成功
        if(sucess){
            redirectAttributes.addFlashAttribute("message", "删除成功");
        }else{
            redirectAttributes.addFlashAttribute("message", "该导航包含下级导航或内容，无法删除");
        }
        redirectAttributes.addFlashAttribute("tabindex", tabindex);
        return "redirect:/category/list";
    }

    @RequestMapping(value = "/contentlist/{categorytype}/{categoryid}")
    public String contentlist(@PathVariable("categorytype") String categorytype,
            @PathVariable("categoryid") Long categoryid,
            @RequestParam(value = "sortType", defaultValue = "sequence") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");
        if(!searchParams.containsKey("EQ_category.id")&&categoryid!=null){
            searchParams.put("EQ_category.id", categoryid + "");
        }
        model.addAttribute("categoryid", categoryid + "");
        model.addAttribute("categorytype", categorytype);
        model.addAttribute("sortType", sortType);
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));// 将搜索条件编码成字符串，用于排序，分页的URL
        Map<String, String> sortTypes2 = Maps.newLinkedHashMap();
        Page categorycontents = null;
        String returnUrl = "";
        if(categorytype.startsWith("1")) {//"10"."11"."17"."19"
            categorycontents = categoryprogramService.getPage(searchParams, pageNumber, PAGE_SIZE, sortType);
            returnUrl = "category/categoryprogramList";
        }
        model.addAttribute("categorycontents", categorycontents);
        model.addAttribute("sortTypes", sortTypes2);
        return returnUrl;
    }

    @RequestMapping(value = "/select/{categorytype}/{categoryid}")
    public String select(@PathVariable("categorytype") String categorytype,
            @PathVariable("categoryid") Long categoryid,
            @RequestParam(value = "sortType", defaultValue = "auto") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");
        model.addAttribute("categoryid", categoryid + "");
        model.addAttribute("categorytype", categorytype);
        model.addAttribute("sortType", sortType);
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
        Map<String, String> sortTypes2 = Maps.newLinkedHashMap();
        sortTypes2.put("auto", "自动");
        Page exceptcontents = null;
        String returnUrl = "";   
        if(categorytype.startsWith("1")){//"10"."11"."17"."19"
            exceptcontents = categoryService.getProgramExceptCategory(categoryid, categorytype,(String)searchParams.get("LIKE_programname"), pageNumber, PAGE_SIZE,
                    sortType);
            sortTypes2.put("programname", "名称");
            returnUrl= "category/categoryprogramselect";
        }
        model.addAttribute("exceptcontents", exceptcontents);
        model.addAttribute("sortTypes", sortTypes);
        return returnUrl;
    }

    @RequestMapping(value = "/selectadd/{categorytype}/{categoryid}")
    public String selectadd(@PathVariable("categorytype") String categorytype,
            @PathVariable("categoryid") Long categoryid,
            @RequestParam(value = "contentids", defaultValue = "") String contentids,
            RedirectAttributes redirectAttributes) {

        String[] idsArr = contentids.split(",");
       if(categorytype.startsWith("1")) {//"10"."11"."17"."19"
            List<Categoryprogram> list = new ArrayList<Categoryprogram>();
            int i=1;
            for (String s : idsArr) {
                if (s.matches("\\d+")) {
                    Categoryprogram cp = new Categoryprogram();
                    cp.setCategory(new Category(categoryid));
                    cp.setProgram(new Program(Long.parseLong(s)));
                    cp.setSequence(i++);
                    list.add(cp);
                }
            }
            if(!list.isEmpty()){
                categoryprogramService.updateAllSequence(list.size(),categoryid);
                categoryprogramService.save(list);
            }
        }
        redirectAttributes.addFlashAttribute("message", "关联成功");
        return "redirect:/category/contentlist/" + categorytype + "/" + categoryid;
    }
    //单删
    @RequestMapping(value = "deletecontent/{categorytype}/{categoryid}/{contentid}")
    public String deletecontent(@PathVariable("categorytype") String categorytype,
            @PathVariable("categoryid") Long categoryid, @PathVariable("contentid") Long contentid,
            RedirectAttributes redirectAttributes) {
        if(categorytype.startsWith("1")){//"10"."11"."17"."19"
            categoryprogramService.delete(contentid);
        }
        return "redirect:/category/contentlist/" + categorytype + "/" + categoryid;
    }
    //批删
    @RequestMapping(value = "deletecontents")
    public String deletecontents(String categorytype,Long categoryid, Long [] cpids,
            RedirectAttributes redirectAttributes) {
        if(categorytype.startsWith("1")){//"10"."11"."17"."19"
            categoryprogramService.deleteAll(cpids);
        }
        return "redirect:/category/contentlist/" + categorytype + "/" + categoryid;
    }
    /**
     * 使用@ModelAttribute, 实现Struts2
     * Preparable二次部分绑定的效果,先根据form的id从数据库查出Category对象,再把Form提交的内容绑定到该对象上。
     * 因为仅update()方法的form中有id属性，因此本方法在该方法中执行.
     */
    @ModelAttribute("preloadCategory")
    public Category getCategory(@RequestParam(value = "id", required = false) Long id) {
        if (id != null) {
            return categoryService.findOne(id);
        }
        return null;
    }

    @RequestMapping(value = "/checkboxlist")
    public String checkboxlist(Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");

        Page<Category> categorys = categoryService.getPage(searchParams, 1, PAGE_SIZE, "auto");

        model.addAttribute("categorys", categorys);
        model.addAttribute("sortType", "auto");
        model.addAttribute("sortTypes", sortTypes);
        // 将搜索条件编码成字符串，用于排序，分页的URL
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
        return "program/categorys";
    }

    

    @RequestMapping(value = "/sortlist/{categorytype}/{categoryid}")
    public String sortlist(@PathVariable("categorytype") String categorytype,
            @PathVariable("categoryid") Long categoryid,
            @RequestParam(value = "sortType", defaultValue = "sequence") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");
        if(!searchParams.containsKey("EQ_category.id")&&categoryid!=null){
            searchParams.put("EQ_category.id", categoryid + "");
        }
        model.addAttribute("categoryid", categoryid + "");
        model.addAttribute("categorytype", categorytype);
        model.addAttribute("sortType", sortType);
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));// 将搜索条件编码成字符串，用于排序，分页的URL
       
        String returnUrl = null;
        if(categorytype.startsWith("1")){//"10"."11"."17"."19"
            Page<Categoryprogram> maps = categoryprogramService.getPage(searchParams, pageNumber, 1000, sortType);
            Page<Categoryprogram>  maps2 = categoryprogramService.getPage(searchParams, pageNumber+1, 1000, sortType);
            model.addAttribute("maps", maps);
            model.addAttribute("maps2", maps2);
            return "category/categoryprogramSort";
        }else{
            throw new RuntimeException("暂只支持节目分类");
        }
    }
    /**
     * 排序
     * @throws UnsupportedEncodingException 
     */
    @RequestMapping(value = "/sortlist/{categorytype}" ,method = RequestMethod.POST)
    @ResponseBody
    public byte[] sortlistsave(@PathVariable("categorytype") String categorytype,Long [] ids,Integer [] sequences) throws UnsupportedEncodingException  {

        if(categorytype.startsWith("1")){//"10"."11"."17"."19"
            List<Categoryprogram> list =Lists.newArrayList();
            for(int i=0;i<ids.length;i++){
                Categoryprogram cp =categoryprogramService.findOne(ids[i]);
                cp.setSequence(sequences[i]);
                list.add(cp);
            }
            categoryprogramService.save(list);
        }else{
            throw new RuntimeException("暂只支持节目分类");
        }
        
        return "保存成功".getBytes("utf-8");
    }
}
