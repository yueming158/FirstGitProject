package com.smt.iptv.portal.service.aaa;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.entity.aaa.Product;
import com.smt.iptv.portal.repository.aaa.ProductDao;
import com.smt.iptv.portal.service.cmp.BaseService;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class ProductService extends BaseService<ProductDao, Product> {
	  public final static String COMMA = ","; 
	  public Page<Product> getNotLinkedProduct(String productname, String resourcetype,String productIds,int pageNumber,
	            int pageSize, String sortType) {	  
	        PageRequest pageRequest = buildPageRequest(pageNumber, pageSize, sortType);
	        List<Long> productIdList = getProductIdList(productIds);
			if(null==productname){
				productname="";
			}
			productname="%"+productname+"%";	
			if(null == resourcetype||resourcetype.trim().equals("")){
				 return dao.getNotLinkedProduct(productname,productIdList,pageRequest);
			}else {
				return dao.getNotLinkedProduct(productname, Integer.valueOf(resourcetype),productIdList, pageRequest);
			}
	  }
	  
	  private List<Long> getProductIdList(String productIds) {
		  List<Long> productIdList = new ArrayList<Long>();
		  productIdList.add(-1l);
		  if(null != productIds && !productIds.trim().equals("")) {
			  String productIdArray[] = productIds.split(COMMA);
			  for (String productId : productIdArray) {
				  productIdList.add(Long.parseLong(productId));
			  }
		  }
		  return productIdList;
	  }
}
