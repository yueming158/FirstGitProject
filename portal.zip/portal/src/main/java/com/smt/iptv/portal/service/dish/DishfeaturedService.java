package com.smt.iptv.portal.service.dish;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.i18nentity.dish.Dishfeatured;
import com.smt.iptv.portal.i18nrepository.dish.DishfeaturedDao;
import com.smt.iptv.portal.service.cmp.BaseService;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class DishfeaturedService extends BaseService<DishfeaturedDao, Dishfeatured>{
    public Dishfeatured getByDishId(Long dishId){
        return dao.getByDishId(dishId);
    }
}
