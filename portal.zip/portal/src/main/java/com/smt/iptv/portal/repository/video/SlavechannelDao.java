package com.smt.iptv.portal.repository.video;

import com.smt.iptv.portal.entity.Slavechannel;
import com.smt.iptv.portal.repository.BaseDao;

public interface SlavechannelDao extends BaseDao<Slavechannel> {
    public Slavechannel getByChannelId(Long channelid);
}
