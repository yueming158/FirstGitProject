package com.smt.iptv.portal.service.hotel;

import java.util.Date;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.entity.hotel.Hotelcall;
import com.smt.iptv.portal.repository.hotel.HotelcallDao;
import com.smt.iptv.portal.service.cmp.BaseService;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class HotelcallService extends BaseService<HotelcallDao, Hotelcall> {

    private static final String REQUEST = "1";
    private static final String RESPONSE = "2";
    private static final String COMPLETE = "3";
    private static final String CANCEL = "4";
    @Transactional(readOnly = false)
    public Hotelcall response(Long id) {
        Hotelcall call = dao.findOne(id);
        if (call != null) {
            call.setReqstatus(RESPONSE);
            call.setRsptime(new Date());
            return dao.save(call);
        } else {
            return null;
        }
    }
    @Transactional(readOnly = false)
    public Hotelcall complete(Long id) {
        Hotelcall call = dao.findOne(id);
        if (call != null) {
            call.setReqstatus(COMPLETE);
            call.setComptime(new Date());
            return dao.save(call);
        } else {
            return null;
        }
    }
    @Transactional(readOnly = false)
    public Hotelcall cancel(Long id) {
        Hotelcall call = dao.findOne(id);
        if (call != null) {
            call.setReqstatus(CANCEL);
            call.setComptime(new Date());
            return dao.save(call);
        } else {
            return null;
        }
    }
}
