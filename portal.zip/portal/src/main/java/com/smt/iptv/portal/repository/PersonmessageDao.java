package com.smt.iptv.portal.repository;

import com.smt.iptv.portal.entity.Personmessage;

public interface PersonmessageDao extends BaseDao<Personmessage> {

}
