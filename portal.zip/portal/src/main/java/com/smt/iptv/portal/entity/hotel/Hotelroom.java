package com.smt.iptv.portal.entity.hotel;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.portal.core.IdEntity;
import com.smt.iptv.portal.entity.Iptvprofile;
@Entity
@Table(name = "hotelroom")
public class Hotelroom extends IdEntity {
    
    public Hotelroom() {
    }

    public Hotelroom(Long id) {
        this.id = id;
    }
    public Hotelroom(String roomname) {
        this.roomname = roomname;
    }
    private Iptvprofile iptvprofile;
	private String roomname; //如果是酒店即时房间名 如果是个人就是 用户名
	private String roomno;//如果是酒店 就是房间号 如果是个人就是手机号
    private String vodfree;
    private String onlylive;
	private String customername;
	
	private String usetype; //个人还是酒店
	
	private String certificatecard;
	private String useraddress;
	private String username;
	private String usertel;
	
    @OneToOne(cascade={CascadeType.ALL})
    @JoinColumn(name = "iptvprofileid")
    public Iptvprofile getIptvprofile() {
        return iptvprofile;
    }

    public void setIptvprofile(Iptvprofile iptvprofile) {
        this.iptvprofile = iptvprofile;
    }

    public String getRoomname() {
        return roomname;
    }

    public void setRoomname(String roomname) {
        this.roomname = roomname;
    }
    
    public String getRoomno() {
        return roomno;
    }

    public void setRoomno(String roomno) {
        this.roomno = roomno;
    }

    @Transient
    public String getCustomername() {
        return customername;
    }

    public void setCustomername(String customername) {
        this.customername = customername;
    }

    public String getVodfree() {
        return vodfree;
    }

    public void setVodfree(String vodfree) {
        this.vodfree = vodfree;
    }

    public String getOnlylive() {
        return onlylive;
    }

    public void setOnlylive(String onlylive) {
        this.onlylive = onlylive;
    }

    public String getUsetype() {
        return usetype;
    }

    public void setUsetype(String usetype) {
        this.usetype = usetype;
    }

    public String getCertificatecard() {
        return certificatecard;
    }

    public void setCertificatecard(String certificatecard) {
        this.certificatecard = certificatecard;
    }

    public String getUseraddress() {
        return useraddress;
    }

    public void setUseraddress(String useraddress) {
        this.useraddress = useraddress;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUsertel() {
        return usertel;
    }

    public void setUsertel(String usertel) {
        this.usertel = usertel;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}