package com.smt.iptv.portal.i18nrepository.program;

import java.util.List;

import com.smt.iptv.portal.i18nentity.program.Genre;
import com.smt.iptv.portal.repository.BaseDao;

public interface GenreDao extends BaseDao<Genre> {
    public List<Genre> getByProgramtype(String type);
}
