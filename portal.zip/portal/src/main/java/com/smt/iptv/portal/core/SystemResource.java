package com.smt.iptv.portal.core;

import java.util.Locale;
import java.util.ResourceBundle;

public class SystemResource {
    private static Locale locale = new Locale("zh", "CN"); 
    private static ResourceBundle resb = ResourceBundle.getBundle("system", locale); 
    
    public static String  getString(String key){
        try{
            return resb.getString(key);
        }catch (Exception e) {
            return null;
        }
    }
    public static Integer  getInteger(String key){
        try{
            return Integer.valueOf(resb.getString(key));
        }catch (Exception e) {
            return null;
        }
        
    }
}
