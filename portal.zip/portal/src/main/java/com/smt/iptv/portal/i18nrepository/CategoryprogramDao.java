package com.smt.iptv.portal.i18nrepository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.smt.iptv.portal.i18nentity.Categoryprogram;
import com.smt.iptv.portal.repository.BaseDao;

public interface CategoryprogramDao  extends BaseDao<Categoryprogram>{
    public List<Categoryprogram> getByProgramId(Long programId);
    @Query("update Categoryprogram cp set cp.sequence=cp.sequence+?1 where categoryid=?2")
    @Modifying
    public void updateAllSequence(Integer offset,Long categoryid);
}
