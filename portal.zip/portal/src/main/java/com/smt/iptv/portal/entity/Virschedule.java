package com.smt.iptv.portal.entity;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.portal.core.IdEntity;
import com.smt.iptv.portal.i18nentity.program.Mediacontent;
@Entity
@Table(name = "virschedule")
public class Virschedule extends IdEntity {
    
    public Virschedule() {
    }

    public Virschedule(Long id) {
        this.id = id;
    }
    
    private Channel channel;
	private String contentname;
	private String cpobjectcode;//mediacontent的objectcode
	private Integer delaytime;
	private Integer seq;
	private String oldname; //不再强制关联记住原始片源信息 
	private Integer oldduration; //不再强制关联记住原始片源信息
    public String getContentname() {
        return contentname;
    }

    public void setContentname(String contentname) {
        this.contentname = contentname;
    }

    public Integer getDelaytime() {
        return delaytime;
    }

    public void setDelaytime(Integer delaytime) {
        this.delaytime = delaytime;
    }
    
    public Integer getSeq() {
        return seq;
    }

    public void setSeq(Integer seq) {
        this.seq = seq;
    }

    @ManyToOne
    @JoinColumn(name="channelid")
    public Channel getChannel() {
        return channel;
    }

    public void setChannel(Channel channel) {
        this.channel = channel;
    }

    public String getCpobjectcode() {
        return cpobjectcode;
    }

    public void setCpobjectcode(String cpobjectcode) {
        this.cpobjectcode = cpobjectcode;
    }

    public String getOldname() {
        return oldname;
    }

    public void setOldname(String oldname) {
        this.oldname = oldname;
    }

    public Integer getOldduration() {
        return oldduration;
    }

    public void setOldduration(Integer oldduration) {
        this.oldduration = oldduration;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}