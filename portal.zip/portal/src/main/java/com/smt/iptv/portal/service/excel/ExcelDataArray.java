package com.smt.iptv.portal.service.excel;
/**
 * POI转化的excel数据结构
 * @author Administrator
 *
 */
public class ExcelDataArray {
    private String[][] dataArray;
    private int rowNum; //行数
    private int lineNum; //列数
    public ExcelDataArray(int rowNum, int lineNum) {
        this.rowNum = rowNum;
        this.lineNum = lineNum;
        dataArray = new String[rowNum][lineNum];
    }
    public String[][] getDataArray() {
        return dataArray;
    }
    public void setDataArray(String[][] dataArray) {
        this.dataArray = dataArray;
    }
    public int getRowNum() {
        return rowNum;
    }
    public void setRowNum(int rowNum) {
        this.rowNum = rowNum;
    }
    public int getLineNum() {
        return lineNum;
    }
    public void setLineNum(int lineNum) {
        this.lineNum = lineNum;
    }
    
    /**
     * 设置rowIndex行，lineIndex列的数据
     * @param rowIndex
     * @param lineIndex
     * @param value
     * @return
     */
    public String setColumn(int rowIndex, int lineIndex, String value){
        dataArray[rowIndex][lineIndex] = value;
        return dataArray[rowIndex][lineIndex];
    }
    
    
    /**
     * 获取rowIndex行，lineIndex列的数据
     * @param rowIndex
     * @param lineIndex
     * @return
     */
    public String getColumnColumn(int rowIndex, int lineIndex){
        return dataArray[rowIndex][lineIndex];
    }
    
}