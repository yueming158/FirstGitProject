package com.smt.iptv.portal.push;

import java.net.InetSocketAddress;
import java.nio.charset.Charset;

import org.apache.mina.core.RuntimeIoException;
import org.apache.mina.core.future.ConnectFuture;
import org.apache.mina.core.service.IoConnector;
import org.apache.mina.core.service.IoHandlerAdapter;
import org.apache.mina.core.session.IdleStatus;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.filter.codec.textline.TextLineCodecFactory;
import org.apache.mina.filter.logging.LoggingFilter;
import org.apache.mina.transport.socket.nio.NioSocketConnector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springside.modules.mapper.JsonMapper;


public class MyClient {
    
    private static final Logger logger = LoggerFactory.getLogger(MyClient.class);
    
    public static void main(String[] args) {
        
        for(int i=10001;i<10003;i++){
            connect(""+i);
            System.out.println("123");
        }
        //connector.dispose();
    }

    private static void connect(final String userid ) {
        
        IoConnector connector = new NioSocketConnector();
        connector.setConnectTimeoutMillis(10 * 1000);
        
        connector.getFilterChain().addLast("logger", new LoggingFilter());
        //connector.getFilterChain().addLast("codec", new ProtocolCodecFilter(new ObjectSerializationCodecFactory()));
        connector.getFilterChain().addLast("codec", new ProtocolCodecFilter(new TextLineCodecFactory(Charset.forName("UTF-8"))));
        connector.setHandler(new IoHandlerAdapter() {
            
            @Override
            public void sessionCreated(IoSession session) throws Exception {
                logger.info("client created");
            }

            @Override
            public void sessionOpened(IoSession session) throws Exception {
                PushMessage m = new PushMessage("login",userid);
                session.write(new JsonMapper().toJson(m));
                //session.write("0");
            }

            @Override
            public void sessionClosed(IoSession session) throws Exception {
                logger.info("client closed");
            }

            @Override
            public void sessionIdle(IoSession session, IdleStatus status) throws Exception {
                logger.info("client idle");
            }

            @Override
            public void exceptionCaught(IoSession session, Throwable cause) throws Exception {
                logger.error(cause.getMessage(), cause);
                session.close(true);
            }

            @Override
            public void messageReceived(IoSession session, Object message) throws Exception {
                if("0".equals(message)){return;}
                PushMessage pushMessage = new JsonMapper().fromJson((String)message, PushMessage.class);
                logger.info("Received message " + pushMessage.getContent());
                session.write(new JsonMapper().toJson(new PushMessage("ack", pushMessage.getMsgid())));
            }

            @Override
            public void messageSent(IoSession session, Object message) throws Exception {
                logger.info("Sent message " + message);
            }
        });

        IoSession session = null;
        try {
            ConnectFuture future = connector.connect(new InetSocketAddress("localhost", 10000));
            future.awaitUninterruptibly();
            session = future.getSession();
        } catch (RuntimeIoException e) {
            logger.error(e.getMessage(), e);
        }
       // session.getCloseFuture().awaitUninterruptibly();
    }
}