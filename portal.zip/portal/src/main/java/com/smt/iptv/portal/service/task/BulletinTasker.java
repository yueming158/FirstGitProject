package com.smt.iptv.portal.service.task;

import java.util.Calendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.common.collect.Lists;
import com.smt.iptv.portal.entity.Bulletin;
import com.smt.iptv.portal.entity.Roomstatus;
import com.smt.iptv.portal.push.PushMessage;
import com.smt.iptv.portal.push.PushServer;
import com.smt.iptv.portal.service.cmp.BulletinService;
import com.smt.iptv.portal.service.cmp.IptvprofileService;
import com.smt.iptv.portal.service.cmp.RoomstatusService;

@Component
public class BulletinTasker {
    private static List<Roomstatus> roomstatusList=null;
    @Autowired
    private RoomstatusService roomstatusService;
    @Autowired
    private BulletinService bulletinService;
	@Autowired
	private IptvprofileService iptvprofileService;
    /**
     * 每分钟去数据库中查看有没有延时的公告 如有即将到期的延时公告则发布
     */
    public void bulletinJob() {
        
        Long nowTime =System.currentTimeMillis();
        if(roomstatusList==null){
            roomstatusList =roomstatusService.getAllOnOpen();
            if(roomstatusList==null){
                roomstatusList = Lists.newArrayList();
            }
        }
        synchronized (roomstatusList) {
            for(int i=roomstatusList.size()-1;i>=0;i--){
                Roomstatus r=roomstatusList.get(i);
                //结束时间减去当前时间小于5分钟 并且大于4分钟  && 开始时间小于当前时间
                //System.out.println(r.getEndtime().getTime()+"-"+nowTime+":"+(r.getEndtime().getTime()-nowTime)+"<="+1000*300L);
                if(r.getEndtime()!=null&&r.getStarttime()!=null
                        &&r.getEndtime().getTime()-nowTime<=1000*300L+10L
                            //&&r.getEndtime().getTime()-nowTime>1000*240L
                            &&r.getStarttime().getTime()<nowTime){
                    String content ="{\"status\":"+r.getStatus()+",\"countdownsecond\":"+r.getCountdownsecond()+"}";
                    PushServer.sendMsg(r.getAccount(), new PushMessage("roomstatus", content));
                    roomstatusList.remove(r);
                } else if(r.getEndtime().getTime()<=nowTime){
                    String content ="{\"status\":"+r.getStatus()+",\"countdownsecond\":"+r.getCountdownsecond()+"}";
                    PushServer.sendMsg(r.getAccount(), new PushMessage("roomstatus", content));
                    roomstatusList.remove(r);
                }
            }
        }
        
        
        //读取数据 发送消息
        List<Bulletin> list = bulletinService.getByTypeAndStatus("2","1");//未发布的延时公告
        List<Bulletin> newList = Lists.newArrayList();;
        if(list!=null){
            for(Bulletin bulletin :list){
                if(bulletin.getReleasetime().getTime()-System.currentTimeMillis()<60000)//当前时间距离预定发布时间小于60秒
                {
                    bulletin.setStatus("2");
                    newList.add(bulletin); //加入发布列表
                }
            }
        }
        List<Bulletin> list2 = bulletinService.getByTypeAndStatus("4","1");
        if(list!=null){
            for(Bulletin bulletin :list2){
                if(bulletin.getReleasetime().getTime()-System.currentTimeMillis()<60000)//当前时间距离发布时间小于60秒
                {
                    bulletin.setStatus("2");
                    newList.add(bulletin);
                }
            }
        }
        if(!newList.isEmpty()){//发布列表不为空
            bulletinService.save(newList);
            for (Bulletin bulletin : newList) {
            	//全体
        		if("2".equals(bulletin.getType())){
        			PushServer.sendMsgToAll(new PushMessage("msg", ""));
        		}
        		//房间
        		else if("4".equals(bulletin.getType())){
        			List<Long> iptvprofileid = bulletinService.getIptvprofileidByBulletinid(bulletin.getId());
        			if(null!=iptvprofileid && iptvprofileid.size()>0) {
        				for (Long id : iptvprofileid) {
        					PushServer.sendMsg(iptvprofileService.findOne(id).getIptvusername(), new PushMessage("msg", ""));
        				}
        			}
        		}
        		//分组
        		else if("8".equals(bulletin.getType())){
        			List<String> iptvprofileid = iptvprofileService.getProfileIdByGroup(bulletin.getEpggroupid());		
        			if(null!=iptvprofileid && iptvprofileid.size()>0) {
        				for (String id : iptvprofileid) {
        					PushServer.sendMsg(id, new PushMessage("msg", ""));
        				}
        			}
        		}
			}
        }
        if(Calendar.getInstance().get(Calendar.MINUTE)%5==0){
            PushServer.LogRuningStatus();
        }
    }
    public static void setRoomstatusList(List<Roomstatus> roomstatusList) {
        BulletinTasker.roomstatusList = roomstatusList;
    }
    
}
