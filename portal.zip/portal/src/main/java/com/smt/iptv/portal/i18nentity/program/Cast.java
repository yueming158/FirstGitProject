package com.smt.iptv.portal.i18nentity.program;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.portal.core.IdEntity;
@Entity
@Table(name = "cast")
public class Cast extends IdEntity {
    
    public Cast() {
    }

    public Cast(Long id) {
        this.id = id;
    }
    
	private String castname;
	private String cpobjectcode;
	private String searchname;
	private String sex;
	private String birthday;
	private String areaname;  
    private String description;
    private Castrole castrole;
    
    @ManyToOne
    @JoinColumn(name = "castroleid")
    public Castrole getCastrole() {
        return castrole;
    }

    public void setCastrole(Castrole castrole) {
        this.castrole = castrole;
    }

    public String getCastname() {
        return castname;
    }

    public void setCastname(String castname) {
        this.castname = castname;
    }

    public String getCpobjectcode() {
        return cpobjectcode;
    }

    public void setCpobjectcode(String cpobjectcode) {
        this.cpobjectcode = cpobjectcode;
    }

    public String getSearchname() {
        return searchname;
    }

    public void setSearchname(String searchname) {
        this.searchname = searchname;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getAreaname() {
        return areaname;
    }

    public void setAreaname(String areaname) {
        this.areaname = areaname;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }


    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}