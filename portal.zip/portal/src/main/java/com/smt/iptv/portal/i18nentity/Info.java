package com.smt.iptv.portal.i18nentity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.hibernate.engine.internal.Cascade;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.smt.iptv.portal.core.IdEntity;
@Entity
@Table(name = "info")
public class Info extends IdEntity {
    
    public Info() {
    }

    public Info(Long id) {
        this.id = id;
    }
    
	private String infoname;
	private String infotype;
	private String infotext;
	private String infoimg;
	private String contenturl;
	//private Mediacontent mediacontent;
	private Date infodate;  
	private String usetype;
//    @JsonIgnore
//    @ManyToOne(cascade=Cascade.  )
//    @JoinColumn(name = "mediacontentid")
//    public Mediacontent getMediacontent() {
//        return mediacontent;
//    }
//
//    public void setMediacontent(Mediacontent mediacontent) {
//        this.mediacontent = mediacontent;
//    }

	
	
    public String getInfoname() {
        return infoname;
    }

    public void setInfoname(String infoname) {
        this.infoname = infoname;
    }

    public String getInfotype() {
        return infotype;
    }

    public void setInfotype(String infotype) {
        this.infotype = infotype;
    }

    public String getInfotext() {
        return infotext;
    }

    public void setInfotext(String infotext) {
        this.infotext = infotext;
    }

    public String getInfoimg() {
        return infoimg;
    }

    public void setInfoimg(String infoimg) {
        this.infoimg = infoimg;
    }

    public String getContenturl() {
        return contenturl;
    }

    public void setContenturl(String contenturl) {
        this.contenturl = contenturl;
    }

    public Date getInfodate() {
        return infodate;
    }

    public void setInfodate(Date infodate) {
        this.infodate = infodate;
    }

    public String getUsetype() {
        return usetype;
    }

    public void setUsetype(String usetype) {
        this.usetype = usetype;
    }
    
    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}