package com.smt.iptv.portal.core;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.springframework.web.multipart.MultipartFile;

import com.smt.iptv.portal.model.SystemConstant;


public class FileUploadUtil {

    private static String getUniqueName(String oldName,String[] files) {
        String suffix = oldName.substring(oldName.lastIndexOf("."));
        for (String file : files) {
            if (file.equals(oldName)) {
                String name = oldName.substring(0, oldName.lastIndexOf("."));
                if (name.matches(".*_\\d+_")) {
                    name =name.substring(0, name.length() - 1);
                    Integer n = Integer.valueOf(name.substring(name.lastIndexOf("_")+1));
                    name = name.substring(0, name.lastIndexOf("_")) + "_" + (n + 1) + "_" + suffix;
                } else {
                    name = name + "_1_" + suffix;
                }
                oldName = getUniqueName(name, files);
            }
        }
        return oldName;
    }

    private static String getNewName(String oldName) {
      if(oldName!=null&&oldName.lastIndexOf(".")!=-1){
          return  System.currentTimeMillis()+oldName.substring(oldName.lastIndexOf("."));
      }else{
          return  System.currentTimeMillis()+"";
      }
  }
    
    public static File saveFile(MultipartFile multipartFile, String relativePath,boolean rename,int width,int height) {
        String rootPath = SystemConstant.getValue("fileupload");
        String folderPath="";
        if(rootPath.endsWith("/")){
            if(relativePath.startsWith("/")){
                folderPath = rootPath.substring(0,rootPath.length()-1)+relativePath;
            }else{
                folderPath = rootPath+relativePath;
            }
        }else{
            if(relativePath.startsWith("/")){
                folderPath = rootPath+relativePath;
            }else{
                folderPath = rootPath+"/"+relativePath;
            }
        }
        if (multipartFile != null && multipartFile.getOriginalFilename() != null
                && multipartFile.getOriginalFilename().length() > 4) {
            /* 根据真实路径创建目录* */
            File  folder = new File(folderPath);
            if (!folder.exists()){
                folder.mkdirs();
            }
            String FullfileName =null;
            if(rename){
                FullfileName = folderPath + getNewName(multipartFile.getOriginalFilename());
            }else{
                FullfileName = folderPath + getUniqueName(multipartFile.getOriginalFilename(),folder.list());// File.separator
            }

            File file = new File(FullfileName);
            try {
                if(width>0&&height>0){
                    //如果指定了图片固定长宽， 则修改图片尺寸。
                    BufferedImage src = javax.imageio.ImageIO.read(multipartFile.getInputStream()); // 构造Image对象
                    if(src.getWidth()>width||src.getHeight()>height){
                        BufferedImage tag = new BufferedImage( width, height, BufferedImage.TYPE_INT_RGB);   
                        tag.getGraphics().drawImage(src.getScaledInstance(width, height, Image.SCALE_SMOOTH), 0, 0, null);  
                        // JPEGImageEncoder可适用于其他图片类型的转换   
                        ImageIO.write(tag, "jpg", file);
                    }else{
                        multipartFile.transferTo(file);
                    }
                }else{
                    multipartFile.transferTo(file);
                }
            } catch (IllegalStateException e) {
                throw new RuntimeException("文件拷贝失败:"+e.getMessage());
            } catch (IOException e) {
                throw new RuntimeException("文件拷贝失败:"+e.getMessage());
            }
            return file;
        }else{
            return null;
        }
    }
    
    public static void delete(String oldfilePath) {
        if(oldfilePath==null){
            return ;
        }
        String rootPath = SystemConstant.getValue("fileupload");
        if(rootPath.endsWith("/")){
            oldfilePath=rootPath+oldfilePath;
        }else{
            oldfilePath = rootPath+"/"+oldfilePath;
        }
        File  file = new File(oldfilePath);
        if(file.isFile()){
            FileUtils.deleteQuietly(file);
        }
    }
    
}
