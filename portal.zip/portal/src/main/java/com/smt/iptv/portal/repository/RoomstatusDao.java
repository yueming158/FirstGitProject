package com.smt.iptv.portal.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;

import com.smt.iptv.portal.entity.Roomstatus;

public interface RoomstatusDao extends BaseDao<Roomstatus> {
    @Query("select r from Roomstatus r where r.endtime>?1 and starttime<?1")
    List<Roomstatus> getAllOnOpen(Date now);
    @Query( nativeQuery =true, value="select r.* from roomstatus r where r.id in(select max(id) from roomstatus r2 group by r2.account)")
    List<Roomstatus> getLastRecordGroupByAccount();
    @Query("select count(r) from Roomstatus r where r.account=?1 and r.endtime>?2")
    Long getCountByAccount(String account,Date now);
}
