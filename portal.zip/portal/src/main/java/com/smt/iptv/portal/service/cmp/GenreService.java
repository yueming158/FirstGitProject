package com.smt.iptv.portal.service.cmp;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.i18nentity.program.Genre;
import com.smt.iptv.portal.i18nrepository.program.GenreDao;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class GenreService extends BaseService<GenreDao, Genre> {
    public List<Genre> getByProgramtype(String type){
        return dao.getByProgramtype(type);
    }
}
