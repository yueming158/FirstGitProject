package com.smt.iptv.portal.web.info;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletRequest;
import javax.validation.Valid;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Maps;
import com.smt.iptv.portal.core.FileUploadUtil;
import com.smt.iptv.portal.i18nentity.Epggroup;
import com.smt.iptv.portal.i18nentity.info.Infocontent;
import com.smt.iptv.portal.i18nentity.info.Infotemplate;
import com.smt.iptv.portal.i18nentity.info.Menu;
import com.smt.iptv.portal.service.cmp.EpggroupService;
import com.smt.iptv.portal.service.info.InfocontentService;
import com.smt.iptv.portal.service.info.InfotemplateService;
import com.smt.iptv.portal.service.info.MenuService;

/**
 * @author xjw
 */
@Controller
@RequestMapping(value = "/infocontent")
public class InfocontentController {

    private static final int PAGE_SIZE = 50;

    private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
    static {
        sortTypes.put("id", "自动");
    }

    @Autowired
    private InfocontentService infocontentService;
    @Autowired
    private MenuService menuService;
    @Autowired
    private InfotemplateService infotemplateService;
    @Autowired
    private EpggroupService epggroupService;

    // @RequestMapping(value = "/list")
    // public String list(@RequestParam(value = "sortType", defaultValue = "id")
    // String sortType,
    // @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model
    // model, ServletRequest request) {
    // Map<String, Object> searchParams =
    // Servlets.getParametersStartingWith(request, "search_");
    //
    // Page<Infocontent> infocontents = infocontentService.getPage(
    // searchParams, pageNumber, PAGE_SIZE, sortType);
    // model.addAttribute("infocontents", infocontents);
    // model.addAttribute("infotemplates", infotemplateService.getAll());
    // model.addAttribute("menus", menuService.getInfoTemplateMenu());
    // model.addAttribute("epggroups", epggroupService.getAll());//group
    // model.addAttribute("sortType", sortType);
    // model.addAttribute("sortTypes", sortTypes);
    // // 将搜索条件编码成字符串，用于排序，分页的URL
    // model.addAttribute("searchParams",
    // Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
    // return "infocontent/infocontentList";
    // }
    // @RequestMapping(value = "/ajaxlist")
    // public String ajaxlist(@RequestParam(value = "sortType", defaultValue =
    // "id") String sortType,
    // @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model
    // model, ServletRequest request) {
    // Map<String, Object> searchParams =
    // Servlets.getParametersStartingWith(request, "search_");
    //
    // Page<Infocontent> infocontents = infocontentService.getPage(
    // searchParams, pageNumber, PAGE_SIZE, sortType);
    // model.addAttribute("infocontents", infocontents);
    // model.addAttribute("infotemplates", infotemplateService.getAll());
    // model.addAttribute("menus", menuService.getInfoTemplateMenu());
    // model.addAttribute("epggroups", epggroupService.getAll());//group
    // model.addAttribute("sortType", sortType);
    // model.addAttribute("sortTypes", sortTypes);
    // model.addAttribute("menucode",
    // request.getParameter("search_EQ_menucode"));
    // // 将搜索条件编码成字符串，用于排序，分页的URL
    // model.addAttribute("searchParams",
    // Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
    // return "infocontent/infocontentajaxList";
    // }
    @RequestMapping(value = "create", method = RequestMethod.GET)
    public String createForm(Model model, String menucode, Long epggroupid) {
        model.addAttribute("epggroupid", epggroupid);
        model.addAttribute("infocontent", new Infocontent());
        model.addAttribute("action", "create");
        List<Menu> menus = menuService.getInfoTemplateMenu();
        model.addAttribute("menus", menus);
        Infotemplate infotemplate;
        if (menucode != null) {
            Menu menu = menuService.getByCode(menucode);
            if (menu != null && menu.getInfotemplate() != null) {
                infotemplate = menu.getInfotemplate();
            } else {
                throw new RuntimeException("该菜单找不到模板");
            }
        } else {
            if (menus.size() > 0 && menus.get(0).getInfotemplate() != null) {
                infotemplate = menus.get(0).getInfotemplate();
            } else {
                throw new RuntimeException("该菜单找不到模板");
            }
        }
        model.addAttribute("infotemplate", infotemplate);
        model.addAttribute("swidth", infotemplate.getSwidth());
        model.addAttribute("sheight", infotemplate.getSheight());
        model.addAttribute("lwidth", infotemplate.getLwidth());
        model.addAttribute("lheight", infotemplate.getLheight());
        model.addAttribute("size", 1024);
        String[] heads = { "资讯文字1", "资讯文字2", "资讯文字3", "资讯文字4", "资讯文字5", "资讯文字6", "资讯文字7", "图片8", "图片9" };
        if (infotemplate.getHead() != null && infotemplate.getHead().split(",").length == 9) {
            heads = infotemplate.getHead().split(",");
        }
        model.addAttribute("heads", heads);
        return "infocontent/infocontentForm";
    }

    @RequestMapping(value = "create", method = RequestMethod.POST)
    public String create(@Valid Infocontent newInfocontent, @RequestParam(defaultValue = "0") int swidth, @RequestParam(defaultValue = "0") int sheight,
            @RequestParam(defaultValue = "0") int lwidth, @RequestParam(defaultValue = "0") int lheight,
            @RequestParam(required = false) MultipartFile smallimageFile, @RequestParam(required = false) MultipartFile largeimageFile,
            RedirectAttributes redirectAttributes, ServletRequest request, Long epggroupid) {
        String relativePath = "infocontent/";
        if (smallimageFile != null && !smallimageFile.isEmpty()) {
            File descfile = FileUploadUtil.saveFile(smallimageFile, relativePath, true, swidth, sheight);
            if (descfile != null) {
                newInfocontent.setSmallimageurl(relativePath + descfile.getName());
            }
        }
        if (largeimageFile != null && !largeimageFile.isEmpty()) {
            File descfile = FileUploadUtil.saveFile(largeimageFile, relativePath, true, lwidth, lheight);
            if (descfile != null) {
                newInfocontent.setLargeimageurl(relativePath + descfile.getName());
            }
        }
        infocontentService.save(newInfocontent);
        redirectAttributes.addFlashAttribute("message", "新增成功");
        redirectAttributes.addFlashAttribute("menucode", newInfocontent.getMenucode());
        return "redirect:/infocontent/treelist?epggroupid=" + epggroupid;
    }

    @RequestMapping(value = "update/{id}", method = RequestMethod.GET)
    public String updateForm(@PathVariable("id") Long id, Model model, Long epggroupid) {
        model.addAttribute("epggroupid", epggroupid);
        Infocontent infocontent = infocontentService.findOne(id);
        model.addAttribute("infocontent", infocontent);
        model.addAttribute("action", "update");
        Menu menu = menuService.getByCode(infocontent.getMenucode());
        model.addAttribute("menu", menu);
        Infotemplate infotemplate = menu.getInfotemplate();
        model.addAttribute("infotemplate", infotemplate);
        model.addAttribute("swidth", infotemplate.getSwidth());
        model.addAttribute("sheight", infotemplate.getSheight());
        model.addAttribute("lwidth", infotemplate.getLwidth());
        model.addAttribute("lheight", infotemplate.getLheight());
        model.addAttribute("size", 1024);
        String[] heads = { "资讯文字1", "资讯文字2", "资讯文字3", "资讯文字4", "资讯文字5", "资讯文字6", "资讯文字7", "图片8", "图片9" };
        if (infotemplate.getHead() != null && infotemplate.getHead().split(",").length == 9) {
            heads = infotemplate.getHead().split(",");
        }
        model.addAttribute("heads", heads);
        return "infocontent/infocontentForm";
    }

    @RequestMapping(value = "update", method = RequestMethod.POST)
    public String update(@Valid @ModelAttribute("preloadInfocontent") Infocontent infocontent, @RequestParam(defaultValue = "0") int swidth,
            @RequestParam(defaultValue = "0") int sheight, @RequestParam(defaultValue = "0") int lwidth, @RequestParam(defaultValue = "0") int lheight,
            @RequestParam(required = false) MultipartFile smallimageFile, @RequestParam(required = false) MultipartFile largeimageFile,
            RedirectAttributes redirectAttributes, ServletRequest request, Long epggroupid) {
        String relativePath = "infocontent/";
        if (smallimageFile != null && !smallimageFile.isEmpty()) {
            File descfile = FileUploadUtil.saveFile(smallimageFile, relativePath, true, swidth, sheight);
            if (descfile != null) {
                // FileUploadUtil.delete(infocontent.getSmallimageurl());
                infocontent.setSmallimageurl((StringUtils.isEmpty(infocontent.getSmallimageurl()) ? "" : infocontent.getSmallimageurl() + ",") + relativePath
                        + descfile.getName());
            }
        }
        if (largeimageFile != null && !largeimageFile.isEmpty()) {
            File descfile = FileUploadUtil.saveFile(largeimageFile, relativePath, true, lwidth, lheight);
            if (descfile != null) {
                // FileUploadUtil.delete(infocontent.getLargeimageurl());
                infocontent.setLargeimageurl((StringUtils.isEmpty(infocontent.getLargeimageurl()) ? "" : infocontent.getLargeimageurl() + ",") + relativePath
                        + descfile.getName());
            }
        }
        infocontentService.save(infocontent);
        redirectAttributes.addFlashAttribute("message", "保存成功");
        redirectAttributes.addFlashAttribute("menucode", infocontent.getMenucode());
        return "redirect:/infocontent/treelist?epggroupid=" + epggroupid;
    }

    @RequestMapping(value = "deleteimg")
    @ResponseBody
    public String update(Long id, Integer index, String type, RedirectAttributes redirectAttributes, ServletRequest request) {
        Infocontent infocontent = infocontentService.findOne(id);
        String newurls = "";
        if ("small".endsWith(type) && infocontent.getSmallimageurl() != null) {
            String[] urls = infocontent.getSmallimageurl().split(",");
            for (int i = 0; i < urls.length; i++) {
                if (i != index) {
                    newurls += urls[i] + ",";
                } else {
                    FileUploadUtil.delete(urls[i]);
                }
            }
            infocontent.setSmallimageurl(newurls);
            infocontentService.save(infocontent);
        } else if ("large".endsWith(type) && infocontent.getLargeimageurl() != null) {
            String[] urls = infocontent.getLargeimageurl().split(",");
            for (int i = 0; i < urls.length; i++) {
                if (i != index) {
                    newurls += urls[i] + ",";
                } else {
                    FileUploadUtil.delete(urls[i]);
                }
            }
            infocontent.setLargeimageurl(newurls);
            infocontentService.save(infocontent);
        }
        return "sucess";
    }

    @RequestMapping(value = "delete/{id}")
    public String delete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes, ServletRequest request) {
        Infocontent infocontent = infocontentService.findOne(id);
        if (infocontent != null) {
            String code = infocontentService.findOne(id).getMenucode();
            infocontentService.delete(id);
            redirectAttributes.addFlashAttribute("menucode", code);
        }
        redirectAttributes.addFlashAttribute("message", "删除成功");
        return "redirect:/infocontent/treelist";
    }

    @ModelAttribute("preloadInfocontent")
    public Infocontent getInfocontent(@RequestParam(value = "id", required = false) Long id) {
        if (id != null) {
            return infocontentService.findOne(id);
        }
        return null;
    }

    @RequestMapping(value = "/treelist")
    public String treelist(Model model, @RequestParam(required = false) Long epggroupid) {
        List<Menu> menus = menuService.findAll(new Sort(new Order(Direction.ASC, "parentid"), new Order(Direction.ASC, "sequence")));
        if (menus != null && menus.size() > 0) {
            model.addAttribute("menus", menus);
            if (model.asMap().get("menucode") != null) {
                String menucode = (String) (model.asMap().get("menucode"));
                for (Menu menu : menus) {
                    if (menucode.equals(menu.getCode())) {
                        model.addAttribute("menu", menu);
                        break;
                    }
                }
            } else {
                // for(Menu menu:menus){
                // if(menu.getInfotemplate().getField()!=null){
                // model.addAttribute("menu", menu);
                // break;
                // }
                // }
                model.addAttribute("menu", menus.get(0));
            }
            model.addAttribute("menus", menus);
        }
        List<Epggroup> epggroups = epggroupService.getAll();
        if (epggroups != null && epggroupid == null && epggroups.size() > 0) {
            epggroupid = epggroups.get(0).getId();
        }
        model.addAttribute("epggroupid", epggroupid);// groupid
        model.addAttribute("epggroups", epggroups);// group
        return "infocontent/treeList";
    }

    @RequestMapping(value = "/ajaxtreelist")
    public String ajaxtreelist(Long menuid, Model model, Long epggroupid, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");
        // &search_EQ_menucode=csfg
        Menu menu = menuService.findOne(menuid);
        if (menu != null) {
            List<Infocontent> infocontents = infocontentService.getByMenucodeAndEpggroupid(menu.getCode(), epggroupid);
            model.addAttribute("infocontents", infocontents);
        } else {
            model.addAttribute("infocontents", new ArrayList<Infocontent>());
        }
        model.addAttribute("menu", menu);
        model.addAttribute("epggroupid", epggroupid);// groupid
        // 将搜索条件编码成字符串，用于排序，分页的URL
        return "infocontent/ajaxtreeList";
    }

    public static void main(String[] args) {
        String[] urls = "A".split(",");
        if (urls.length > 0 && 2 > 0) {
            ;
            System.out.println(Arrays.toString(ArrayUtils.remove(urls, 0)));
            System.out.println(ArrayUtils.toString(ArrayUtils.remove(urls, 0), ""));
        }
    }
}
