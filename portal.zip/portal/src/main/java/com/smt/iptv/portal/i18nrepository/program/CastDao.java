package com.smt.iptv.portal.i18nrepository.program;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;

import com.smt.iptv.portal.i18nentity.program.Cast;
import com.smt.iptv.portal.repository.BaseDao;

public interface CastDao extends BaseDao<Cast> {
    //@Query("select c from Cast c,Program p where  p.id=?1") 错误。这种是2个表字段一样 而不是外键关联。
    //@Query("select c from Program p inner join p.castlist c inner join c.castrole where p.id=?1")
    //public Page<Cast> getCastsByProgramid(Long programid,Pageable pageable);
}
