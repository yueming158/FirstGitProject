package com.smt.iptv.portal.service.cmp;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.i18nentity.program.Area;
import com.smt.iptv.portal.i18nrepository.program.AreaDao;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class AreaService extends BaseService<AreaDao, Area> {
    
}
