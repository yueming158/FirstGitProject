package com.smt.iptv.portal.repository.role;

import com.smt.iptv.portal.entity.role.User;
import com.smt.iptv.portal.repository.BaseDao;

public interface UserDao extends BaseDao<User> {
	User findByLoginName(String loginName);
}
