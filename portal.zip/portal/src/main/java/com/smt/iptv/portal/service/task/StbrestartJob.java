package com.smt.iptv.portal.service.task;

import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.apache.commons.lang3.Validate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.scheduling.support.CronTrigger;
import org.springside.modules.utils.Threads;

import com.smt.iptv.portal.core.StaticConstant;
import com.smt.iptv.portal.entity.Globalconfig;
import com.smt.iptv.portal.push.PushMessage;
import com.smt.iptv.portal.push.PushServer;
import com.smt.iptv.portal.service.cmp.GlobalconfigService;

/**
 * 使用Spring的ThreadPoolTaskScheduler执行Cron式任务的类.
 * 相比Spring的Task NameSpace配置方式, 不需要反射調用，并强化了退出超时控制.
 * 
 * @author calvin
 */
public class StbrestartJob implements Runnable {

	private String cronExpression;

	private int shutdownTimeout = Integer.MAX_VALUE;

	private ThreadPoolTaskScheduler threadPoolTaskScheduler;
	
	@Autowired
	GlobalconfigService globalconfigService;
	
	@PostConstruct
	public void init() {
        //Validate.notBlank(cronExpression);
	    Globalconfig config =globalconfigService.findByName(StaticConstant.CFG_STBRESTARTJOB_HOUR);
	    String hour = config!=null?config.getValue():"-1";
        try{
            Integer hournum=Integer.parseInt(hour);
            if(hournum>=0&&hournum<=23){
                    cronExpression = "0 0 "+hour+" * * ?";
                    start();
            }
        }catch (Exception e) {
            //数据库没有配置则使用配置文件 默认不启动
            //start();
        }
    }
	public void start() {
		Validate.notBlank(cronExpression);
		threadPoolTaskScheduler = new ThreadPoolTaskScheduler();
		threadPoolTaskScheduler.setThreadNamePrefix("StbrestartJob");
		threadPoolTaskScheduler.initialize();
		threadPoolTaskScheduler.schedule(this, new CronTrigger(cronExpression));
	}

	@PreDestroy
	public void stop() {
		ScheduledExecutorService scheduledExecutorService = threadPoolTaskScheduler.getScheduledExecutor();
		Threads.normalShutdown(scheduledExecutorService, shutdownTimeout, TimeUnit.SECONDS);
	}

	/**
	 * 定时打印当前用户数到日志.
	 */
	@Override
	public void run() {
	    //springTasker.executeNetDateJob();
	    //System.out.println(DateFormatUtils.format(new Date(), "HH:mm:ss")+":发送重启指令");
	    PushServer.sendMsgToAll(new PushMessage("action", "restart"));
	}

	public void setCronExpression(String cronExpression) {
		this.cronExpression = cronExpression;
	}

	public String getCronExpression() {
        return cronExpression;
    }

    /**
	 * 设置normalShutdown的等待时间,单位秒.
	 */
	public void setShutdownTimeout(int shutdownTimeout) {
		this.shutdownTimeout = shutdownTimeout;
	}
}
