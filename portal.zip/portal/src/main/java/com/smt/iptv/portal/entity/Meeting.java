package com.smt.iptv.portal.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.format.annotation.DateTimeFormat;

import com.smt.iptv.portal.core.IdEntity;
@Entity
@Table(name = "meeting")
public class Meeting extends IdEntity {
    
    public Meeting() {
    }

    public Meeting(Long id) {
        this.id = id;
    }

	private String meetingname;
	private String meetingaddress;
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date meetingtime;
	private String meetingstatus;


    public String getMeetingname() {
        return meetingname;
    }

    public void setMeetingname(String meetingname) {
        this.meetingname = meetingname;
    }

    public String getMeetingaddress() {
        return meetingaddress;
    }

    public void setMeetingaddress(String meetingaddress) {
        this.meetingaddress = meetingaddress;
    }

    public Date getMeetingtime() {
        return meetingtime;
    }

    public void setMeetingtime(Date meetingtime) {
        this.meetingtime = meetingtime;
    }

    public String getMeetingstatus() {
        return meetingstatus;
    }

    public void setMeetingstatus(String meetingstatus) {
        this.meetingstatus = meetingstatus;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}