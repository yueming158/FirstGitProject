package com.smt.iptv.portal.web.program;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.smt.iptv.portal.entity.Airlinetime;
import com.smt.iptv.portal.i18nentity.City;
import com.smt.iptv.portal.service.cmp.AirlinetimeService;
import com.smt.iptv.portal.service.cmp.CityService;

/**
 * Airlinetime管理的Controller, 使用Restful风格的Urls:
 * 
 * List page     : GET /airlinetime/
 * 
 * @author xjw
 */
@Controller
@RequestMapping(value = "/airlinetime")
public class AirlinetimeController {

	@Autowired
	private AirlinetimeService airlinetimeService;
    @Autowired
    private CityService cityService;
	@RequestMapping(value = "/list")
	public String list(Model model,String startCity,String lastCity) {
		List<Airlinetime> airlinetimes = airlinetimeService.getAndSaveByAirlinecitycode(startCity, lastCity);
		model.addAttribute("citys", cityService.getAll());
		model.addAttribute("airlinetimes", airlinetimes);
		return "airlinetime/airlinetimeList";
	}

}
