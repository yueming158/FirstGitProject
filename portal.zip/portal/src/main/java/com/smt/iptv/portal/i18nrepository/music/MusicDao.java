package com.smt.iptv.portal.i18nrepository.music;

import com.smt.iptv.portal.i18nentity.music.Music;
import com.smt.iptv.portal.repository.BaseDao;

public interface MusicDao extends BaseDao<Music> {

}
