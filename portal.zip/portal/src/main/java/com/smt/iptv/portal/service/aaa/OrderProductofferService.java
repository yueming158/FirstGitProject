package com.smt.iptv.portal.service.aaa;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.entity.aaa.Account;
import com.smt.iptv.portal.entity.aaa.Accountrecord;
import com.smt.iptv.portal.entity.aaa.Orderusage;
import com.smt.iptv.portal.entity.aaa.Productoffer;



//Spring Bean的标识.
@Component
//默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class OrderProductofferService {
	private final static Long TIME_UNTIS= 24l*1000*3600;
	@Autowired
	private AccountService accountService;
	@Autowired
	private AccountrecordService accountRecordService;
	@Autowired
	private OrderusageService orderUsageService;
	@Autowired
	private ProductofferService productofferService;
	@Transactional(readOnly = false)
	public String order(Long accountId,int balance,String productofferids[])throws Exception{
		int remainSum = 0;
		//判断账户余额是否充足等前提条件
		Account account = accountService.findOne(accountId);
		//无此账号
		if(null==account){
			return "订购失败无账号信息";
		}
		remainSum = account.getBalance();
		for (int i=0;i<productofferids.length;i++) {
			
			Productoffer productOffer = productofferService.findOne(Long.valueOf(productofferids[i]));
			//无此商品
			if(null==productOffer){
				throw new RuntimeException();
			}
			balance = account.getBalance();
			//余额是否充足
			if(balance<productOffer.getPrice()){
				throw new RuntimeException();
			}
			//订购商品(记录订购信息表,余额扣除,记录账户操作日志)
			try {
			
				Orderusage orderUsage = constructOrderUsage(productOffer,account.getId());
				orderUsageService.save(orderUsage);
				if(orderUsage.getId() <= 0){
					throw new RuntimeException();
				}
				Accountrecord accountRecord = new Accountrecord();
				accountRecord.setBalance(productOffer.getPrice());
				accountRecord.setOrderusageid(orderUsage.getId());
				accountRecord.setType(Accountrecord.TYPE_1);
				accountRecord.setAccountid(account.getId());
				accountRecord.setRecorddate(new Date());
				accountRecord = accountRecordService.save(accountRecord);
				remainSum -= productOffer.getPrice();
				if(accountRecord.getId() <=0){
					throw new RuntimeException();
				}
			} catch (Exception e) {
				throw new RuntimeException();
			}
		}
		//扣除余额
		account.setBalance(remainSum);
		accountService.save(account);
		return "订购成功"; 
	}

	private Orderusage constructOrderUsage(Productoffer productOffer,Long accountId){
		Orderusage orderUsage = new Orderusage();
		orderUsage.setAccountid(accountId);
		orderUsage.setCreationtime(new Date());
		orderUsage.setListprice(productOffer.getPrice());
		orderUsage.setOrderstarttime(orderUsage.getCreationtime());
		//如果是周期性的商品且重复购买需要累加时间 两类情况 一类 已过期 一类为过期 
		//
		if(productOffer.getStrategytype().equals("1")){
			Date lastEndDate = orderUsageService.getLastOrderusage(accountId, productOffer.getId());	
			if(null !=lastEndDate && orderUsage.getOrderstarttime().compareTo(lastEndDate)<0) {
				orderUsage.setOrderstarttime(lastEndDate);
			}
		}

		orderUsage.setOrderendtime(new Date(orderUsage.getOrderstarttime().getTime()+productOffer.getCycleduration()*TIME_UNTIS));
		orderUsage.setPaystatus("2");
		orderUsage.setProductofferid(productOffer.getId());
		orderUsage.setProductoffername(productOffer.getOffername());
		return orderUsage;
	}
	
	@Transactional(readOnly = false)
	public String deleteOderusage(Long orderusageId,Long accountId) {
		try {
			//修改订购记录支付状态
			Orderusage orderusage = orderUsageService.findOne(orderusageId);
			orderusage.setPaystatus("3");
			orderusage.setOrdercanceltime(new Date());
			orderUsageService.save(orderusage);
			//修改账户余额
			Account account = accountService.findOne(accountId);
			account.setBalance(account.getBalance()+orderusage.getListprice());
			accountService.save(account);
			//增加记录流水
			Accountrecord accountRecord = new Accountrecord();
			accountRecord.setBalance(orderusage.getListprice());
			accountRecord.setOrderusageid(orderusageId);
			accountRecord.setType(Accountrecord.TYPE_5);
			accountRecord.setAccountid(accountId);
			accountRecord.setRecorddate(new Date());
			accountRecord = accountRecordService.save(accountRecord);
			if(accountRecord.getId() <=0){
				throw new RuntimeException();
			}
		} catch (Exception e) {
			throw new RuntimeException();
		}
		
		return "退订成功！";
	}
	@Transactional(readOnly = false)
	public String accountrecharge(Long accountId, int balance) {
		Account account = new Account();
		account = accountService.findOne(accountId);
		if(null != accountId){
			account.setBalance(account.getBalance()+balance*100);
			accountService.save(account);
			//账户流水记录
			Accountrecord accountRecord = new Accountrecord();
			accountRecord.setBalance(balance*100);
			accountRecord.setType(Accountrecord.TYPE_2);
			accountRecord.setAccountid(accountId);
			accountRecord.setRecorddate(new Date());
			accountRecord = accountRecordService.save(accountRecord);
			if(accountRecord.getId() <=0){
				throw new RuntimeException();
			}
			return "success";
		}
		return "error";
	}
	
	@Transactional(readOnly = false)
	public String accountrefund(Long accountId, int balance) {
		Account account = accountService.findOne(accountId);
		if(null != accountId){
			if (account.getBalance() < balance*100) {
				return "error";
			}
			account.setBalance(account.getBalance()-balance*100);
			accountService.save(account);
			//账户流水记录
			Accountrecord accountRecord = new Accountrecord();
			accountRecord.setBalance(balance*100);
			accountRecord.setType(Accountrecord.TYPE_6);
			accountRecord.setAccountid(accountId);
			accountRecord.setRecorddate(new Date());
			accountRecord = accountRecordService.save(accountRecord);
			if(accountRecord.getId() <= 0){
				throw new RuntimeException();
			}
			return "success";
		}
		return "error";
	}
}
