package com.smt.iptv.portal.service.goods;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.i18nentity.goods.Categorygoods;
import com.smt.iptv.portal.i18nentity.goods.Goods;
import com.smt.iptv.portal.i18nrepository.goods.CategorygoodsDao;
import com.smt.iptv.portal.service.cmp.BaseService;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class CategorygoodsService extends BaseService<CategorygoodsDao, Categorygoods>{
    /**
     * 获取某个类型下 未分类的菜品
     * 
     */
    public Page<Goods> getGoodsExceptCategory(Long categoryid, int pageNumber,
            int pageSize, String sortType) {
        PageRequest pageRequest = buildPageRequest(pageNumber, pageSize, sortType);
            return dao.getGoodsExceptCategory(categoryid, pageRequest);

    }
    @Transactional(readOnly = false)
    public void deleteAll(Long [] ids) {
        if(ids!=null)
        for(Long id:ids){
            dao.delete(id);
        }
    }
}
