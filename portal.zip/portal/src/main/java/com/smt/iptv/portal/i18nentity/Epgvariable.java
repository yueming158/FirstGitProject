package com.smt.iptv.portal.i18nentity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springside.modules.mapper.JsonMapper;

import com.smt.iptv.portal.core.IdEntity;

@Entity
@Table(name = "epgvariable")
public class Epgvariable extends IdEntity {
	private Long epggroupid;
	private String type; //T文字I图片
	private Integer width;
	private Integer height;
	private String name;
	private String value;
	private String description;
	private String enabled;
	private String enumstr;
	public Epgvariable() {
	}

	public Epgvariable(Long id) {
		this.id = id;
	}

    public Long getEpggroupid() {
        return epggroupid;
    }

    public void setEpggroupid(Long epggroupid) {
        this.epggroupid = epggroupid;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getWidth() {
        return width;
    }

    public void setWidth(Integer width) {
        this.width = width;
    }

    public Integer getHeight() {
        return height;
    }

    public void setHeight(Integer height) {
        this.height = height;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getEnabled() {
        return enabled;
    }

    public void setEnabled(String enabled) {
        this.enabled = enabled;
    }

    public String getEnumstr() {
        return enumstr;
    }

    public void setEnumstr(String enumstr) {
        this.enumstr = enumstr;
    }
    @Transient
    public String getSelectedmame() {
        if("E".equals(type)&&enumstr!=null){
            int endindex =enumstr.indexOf("\",\"value\":\""+value+"\"");
            if(endindex>0){
                String namestr=enumstr.substring(0,endindex);
                int beginindex =namestr.lastIndexOf("\"");
                if(beginindex>0){
                    return namestr.substring(beginindex+1);
                }
            }
        }
        return "";
    }
    @Transient
    public List<Epgvariable> getItems() {
        if(enumstr!=null){
        JsonMapper mapper = new JsonMapper();
        List<Epgvariable> list = mapper.fromJson(enumstr, mapper.createCollectionType(ArrayList.class, Epgvariable.class));
        return list;
        }
        return null;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}