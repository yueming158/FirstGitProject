package com.smt.iptv.portal.model;

import java.util.HashMap;

public class SystemConstant {

    public static HashMap<String, String> map = new HashMap<String, String>();

    public static String getValue(String name) {
        return map.get(name);
    }

    public static String getURLValue(String name) {
        String url = map.get(name);
        if (url == null) {
            return "";
        } else {
            return url.endsWith("/") ? url : url + "/";
        }
    }
}