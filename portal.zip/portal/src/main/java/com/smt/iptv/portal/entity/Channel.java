package com.smt.iptv.portal.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.format.annotation.DateTimeFormat;

import com.smt.iptv.portal.core.IdEntity;
import com.smt.iptv.portal.i18nentity.Category;
@Entity
@Table(name = "channel")
public class Channel extends IdEntity {
    
    public Channel() {
    }

    public Channel(Long id) {
        this.id = id;
    }
    private Physicalchannel physicalchannel;
	private String channelname;
	private String cpobjectcode;
	private Integer channelnumber;
	private String callsign;
	private String timeshift;
	private String timeshiftduration;  
    
    private String status;//1活动 0暂停
    private String hdtv;
    private String casttype;
    private String recordstarttime;
    private String recordendtime;
    private String description;
    private String channeltype;  //是否虚拟频道 循环类型
    private Integer cycletime;  //从0点开始延迟周期
    private String tvmaourl;
   /* 
    private List<Category> categorylist;
    @ManyToMany(fetch=FetchType.LAZY)
    @JoinTable(
            name="categorychannel",
            joinColumns=@JoinColumn(name="channelid", referencedColumnName="id"),//控制端列
            inverseJoinColumns=@JoinColumn(name="categoryid", referencedColumnName="id")//被控制端列
            )
    public List<Category> getCategorylist() {
        return categorylist;
    }

    public void setCategorylist(List<Category> categorylist) {
        this.categorylist = categorylist;
    }*/

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "physicalchannelid")
    public Physicalchannel getPhysicalchannel() {
        return physicalchannel;
    }

    public void setPhysicalchannel(Physicalchannel physicalchannel) {
        this.physicalchannel = physicalchannel;
    }
    public String getChannelname() {
        return channelname;
    }

    public void setChannelname(String channelname) {
        this.channelname = channelname;
    }

    public String getCpobjectcode() {
        return cpobjectcode;
    }

    public void setCpobjectcode(String cpobjectcode) {
        this.cpobjectcode = cpobjectcode;
    }

    public Integer getChannelnumber() {
        return channelnumber;
    }

    public void setChannelnumber(Integer channelnumber) {
        this.channelnumber = channelnumber;
    }

    public String getCallsign() {
        return callsign;
    }

    public void setCallsign(String callsign) {
        this.callsign = callsign;
    }

    public String getTimeshift() {
        return timeshift;
    }

    public void setTimeshift(String timeshift) {
        this.timeshift = timeshift;
    }

    public String getTimeshiftduration() {
        return timeshiftduration;
    }

    public void setTimeshiftduration(String timeshiftduration) {
        this.timeshiftduration = timeshiftduration;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getHdtv() {
        return hdtv;
    }

    public void setHdtv(String hdtv) {
        this.hdtv = hdtv;
    }

    public String getCasttype() {
        return casttype;
    }

    public void setCasttype(String casttype) {
        this.casttype = casttype;
    }

    public String getRecordstarttime() {
        return recordstarttime;
    }

    public void setRecordstarttime(String recordstarttime) {
        this.recordstarttime = recordstarttime;
    }

    public String getRecordendtime() {
        return recordendtime;
    }

    public void setRecordendtime(String recordendtime) {
        this.recordendtime = recordendtime;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getChanneltype() {
        return channeltype;
    }

    public void setChanneltype(String channeltype) {
        this.channeltype = channeltype;
    }

    public Integer getCycletime() {
        return cycletime;
    }

    public void setCycletime(Integer cycletime) {
        this.cycletime = cycletime;
    }
    
    public String getTvmaourl() {
        return tvmaourl;
    }

    public void setTvmaourl(String tvmaourl) {
        this.tvmaourl = tvmaourl;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((callsign == null) ? 0 : callsign.hashCode());
        result = prime * result + ((casttype == null) ? 0 : casttype.hashCode());
       // result = prime * result + ((categorylist == null) ? 0 : categorylist.hashCode());
        result = prime * result + ((channelname == null) ? 0 : channelname.hashCode());
        result = prime * result + ((channelnumber == null) ? 0 : channelnumber.hashCode());
        result = prime * result + ((channeltype == null) ? 0 : channeltype.hashCode());
        result = prime * result + ((cpobjectcode == null) ? 0 : cpobjectcode.hashCode());
        result = prime * result + ((cycletime == null) ? 0 : cycletime.hashCode());
        result = prime * result + ((description == null) ? 0 : description.hashCode());
        result = prime * result + ((hdtv == null) ? 0 : hdtv.hashCode());
        result = prime * result + ((physicalchannel == null) ? 0 : physicalchannel.hashCode());
        result = prime * result + ((recordendtime == null) ? 0 : recordendtime.hashCode());
        result = prime * result + ((recordstarttime == null) ? 0 : recordstarttime.hashCode());
        result = prime * result + ((status == null) ? 0 : status.hashCode());
        result = prime * result + ((timeshift == null) ? 0 : timeshift.hashCode());
        result = prime * result + ((timeshiftduration == null) ? 0 : timeshiftduration.hashCode());
        result = prime * result + ((tvmaourl == null) ? 0 : tvmaourl.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        Channel other = (Channel) obj;
        if (callsign == null) {
            if (other.callsign != null)
                return false;
        } else if (!callsign.equals(other.callsign))
            return false;
        if (casttype == null) {
            if (other.casttype != null)
                return false;
        } else if (!casttype.equals(other.casttype))
            return false;
//        if (categorylist == null) {
//            if (other.categorylist != null)
//                return false;
//        } else if (!categorylist.equals(other.categorylist))
//            return false;
        if (channelname == null) {
            if (other.channelname != null)
                return false;
        } else if (!channelname.equals(other.channelname))
            return false;
        if (channelnumber == null) {
            if (other.channelnumber != null)
                return false;
        } else if (!channelnumber.equals(other.channelnumber))
            return false;
        if (channeltype == null) {
            if (other.channeltype != null)
                return false;
        } else if (!channeltype.equals(other.channeltype))
            return false;
        if (cpobjectcode == null) {
            if (other.cpobjectcode != null)
                return false;
        } else if (!cpobjectcode.equals(other.cpobjectcode))
            return false;
        if (cycletime == null) {
            if (other.cycletime != null)
                return false;
        } else if (!cycletime.equals(other.cycletime))
            return false;
        if (description == null) {
            if (other.description != null)
                return false;
        } else if (!description.equals(other.description))
            return false;
        if (hdtv == null) {
            if (other.hdtv != null)
                return false;
        } else if (!hdtv.equals(other.hdtv))
            return false;
        if (physicalchannel == null) {
            if (other.physicalchannel != null)
                return false;
        } else if (!physicalchannel.equals(other.physicalchannel))
            return false;
        if (recordendtime == null) {
            if (other.recordendtime != null)
                return false;
        } else if (!recordendtime.equals(other.recordendtime))
            return false;
        if (recordstarttime == null) {
            if (other.recordstarttime != null)
                return false;
        } else if (!recordstarttime.equals(other.recordstarttime))
            return false;
        if (status == null) {
            if (other.status != null)
                return false;
        } else if (!status.equals(other.status))
            return false;
        if (timeshift == null) {
            if (other.timeshift != null)
                return false;
        } else if (!timeshift.equals(other.timeshift))
            return false;
        if (timeshiftduration == null) {
            if (other.timeshiftduration != null)
                return false;
        } else if (!timeshiftduration.equals(other.timeshiftduration))
            return false;
        if (tvmaourl == null) {
            if (other.tvmaourl != null)
                return false;
        } else if (!tvmaourl.equals(other.tvmaourl))
            return false;
        return true;
    }
    
}