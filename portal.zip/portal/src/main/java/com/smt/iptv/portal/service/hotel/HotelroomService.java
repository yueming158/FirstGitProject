package com.smt.iptv.portal.service.hotel;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.entity.Iptvprofile;
import com.smt.iptv.portal.entity.hotel.Hotelcustomer;
import com.smt.iptv.portal.entity.hotel.Hotelroom;
import com.smt.iptv.portal.repository.IptvprofileDao;
import com.smt.iptv.portal.repository.hotel.HotelcustomerDao;
import com.smt.iptv.portal.repository.hotel.HotelroomDao;
import com.smt.iptv.portal.service.cmp.BaseService;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class HotelroomService extends BaseService<HotelroomDao, Hotelroom> {
    @Autowired
    private IptvprofileDao iptvprofileDao;
    @Autowired
    private HotelcustomerDao hotelcustomerDao;

    @Transactional(readOnly = false)
    public Hotelroom save(Hotelroom hotelroom, String iptvusername) {
        Iptvprofile iptvprofile = iptvprofileDao.getByiptvusername(iptvusername);
        if (iptvprofile != null && hotelroom.getRoomname() != null) {
            String oldRoomname = dao.getRoomNameByIptvprofileid(iptvprofile.getId());
            if (hotelroom.getRoomname().equals(oldRoomname) || oldRoomname == null) {
                hotelroom.setIptvprofile(iptvprofile);
                Hotelroom room = dao.save(hotelroom);
                try {
                    dao.getByRoomname(hotelroom.getRoomname());
                } catch (Exception e) {
                    if (e.getMessage().contains("more")) {
                        throw new RuntimeException("房间名重复");
                    } else {
                        throw new RuntimeException(e);
                    }
                }
                return room;

            }
        }
        return null;
    }

//    @Transactional(readOnly = false)
//    public Hotelroom saveRoom(String roomname, Iptvprofile iptvprofile) {
//        List<Hotelroom> oldrooms =dao.getByRoomname(roomname);
//        if(oldrooms.size()==0){
//            Hotelroom hotelroom = dao.getByIptvprofileId(iptvprofile.getId());
//            if(hotelroom!=null){
//                hotelroom.setRoomname(roomname);
//                dao.save(hotelroom);
//            }else{
//                hotelroom = new Hotelroom(roomname);
//                hotelroom.setIptvprofile(iptvprofile);
//                dao.save(hotelroom);
//            }
//            return hotelroom;
//        }
//        if(oldrooms.size()>0&&oldrooms.get(0).getIptvprofile().getId()==iptvprofile.getId()){
//            oldrooms.get(0).setRoomname(roomname);
//            Hotelroom room = dao.save(oldrooms.get(0));
//            return room;
//        }
//        return null;
//    }

    public List<Hotelroom> getByRoomname(String roomname) {
        return dao.getByRoomname(roomname);
    }
    public List<Hotelroom> getByRoomno(String roomname) {
        return dao.getByRoomno(roomname);
    }
    public String getRoomNameByIptvprofileid(Long id) {
        return dao.getRoomNameByIptvprofileid(id);
    }
    public String getRoomNameByAccount(String account) {
        return dao.getRoomNameByAccount(account);
    }
    public boolean isNotExistRoom(Long iptvprofileid) {
        if (dao.getRoomNameByIptvprofileid(iptvprofileid) == null) {
            return true;
        } else {
            return false;
        }
    }

    public void deleteByIptvprofileId(Long iptvprofileid) {
        dao.deleteByIptvprofileId(iptvprofileid);
    }

    public boolean isHasCustomer(Long roomid) {
        if (dao.isHasCustomer(roomid) > 0) {
            return true;
        } else {
            return false;
        }
    }

    public List<String> getUndividedAccount() {
        return dao.getUndividedAccount();
    }
    
    public List<Hotelroom> getAllWithCustomer(){
        List<Hotelroom> rooms = (List<Hotelroom>)dao.findAll();
        List<Hotelcustomer> customers =hotelcustomerDao.getByStatus("1");
        for(Hotelroom room:rooms){
            for(Hotelcustomer customer:customers){
                if(room.getId()==customer.getHotelroom().getId()){
                    room.setCustomername((room.getCustomername()==null?"":room.getCustomername()+",")+customer.getCustomername());
                }
            }
        }
        return rooms;
    }
}
