package com.smt.iptv.portal.web.program;

import java.io.File;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.ServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import apk.parser.ApkInfo;
import apk.parser.GetApkInfo;

import com.google.common.collect.Maps;
import com.smt.iptv.portal.core.FileUploadUtil;
import com.smt.iptv.portal.core.SystemEnum;
import com.smt.iptv.portal.entity.Appupdateinfo;
import com.smt.iptv.portal.service.cfg.ConfigService;
import com.smt.iptv.portal.service.cmp.AppupdateinfoService;
import com.smt.iptv.portal.service.cmp.GlobalenumService;
import com.smt.iptv.portal.web.vo.Message;

/**
 * Appupdateinfo管理的Controller, 使用Restful风格的Urls:
 * 
 * @author xjw
 */
@Controller
@RequestMapping(value = "/appupdateinfo")
public class AppupdateinfoController {

    private static final int PAGE_SIZE = 50;

    private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
    static {
        sortTypes.put("auto", "自动");
        sortTypes.put("appupdateinfoname", "名称");
    }

    @Autowired
    private AppupdateinfoService appupdateinfoService;
    @Autowired
    private GlobalenumService globalenumService;
    @Autowired
    private ConfigService configService;
    @RequestMapping(value = "/list")
    public String list(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");

        Page<Appupdateinfo> appupdateinfos = appupdateinfoService.getPage(searchParams, pageNumber, PAGE_SIZE, sortType);

        model.addAttribute("appupdateinfos", appupdateinfos);
        model.addAttribute("apptypes", globalenumService.getByType(SystemEnum.APPTYPE));
        model.addAttribute("sortType", sortType);
        model.addAttribute("sortTypes", sortTypes);
        // 将搜索条件编码成字符串，用于排序，分页的URL
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
        return "appupdateinfo/appupdateinfoList";
    }

    @RequestMapping(value = "create", method = RequestMethod.GET)
    public String createForm(Model model) {
        model.addAttribute("appupdateinfo", new Appupdateinfo());
        model.addAttribute("apptypes", globalenumService.getByType(SystemEnum.APPTYPE));
        model.addAttribute("action", "create");
        return "appupdateinfo/appupdateinfoForm";
    }

    @RequestMapping(value = "create", method = RequestMethod.POST)
    public String create(@Valid Appupdateinfo newAppupdateinfo, RedirectAttributes redirectAttributes, MultipartFile file) {
        String relativePath = "appinfo/";
        File descfile = FileUploadUtil.saveFile(file, relativePath, false, 0, 0);
        if (descfile != null && descfile.isFile()) {
            newAppupdateinfo.setDownloadurl(relativePath + descfile.getName());
            // 自动获取包名
            ApkInfo apk = GetApkInfo.getApkInfoByFilePath(descfile);
            if (apk != null) {
                newAppupdateinfo.setVersion(apk.getVersionName());
                newAppupdateinfo.setVersioncode(apk.getVersionCode());
                newAppupdateinfo.setPackagename(apk.getPackageName());
                //newAppupdateinfo.setProjectname(projectname);
                //newAppupdateinfo.setFingerprints(fingerprints);
              //保存文件 属性配置和模板
            } else {
                redirectAttributes.addFlashAttribute("message", "无法识别APK文件");
                return "redirect:/appupdateinfo/list";
            }
        }
        appupdateinfoService.save(newAppupdateinfo);
        configService.initConfig();
        redirectAttributes.addFlashAttribute("message", "创建成功");
        return "redirect:/appupdateinfo/list";
    }

    @RequestMapping(value = "update/{id}", method = RequestMethod.GET)
    public String updateForm(@PathVariable("id") Long id, Model model) {
        model.addAttribute("appupdateinfo", appupdateinfoService.findOne(id));
        model.addAttribute("apptypes", globalenumService.getByType(SystemEnum.APPTYPE));
        model.addAttribute("action", "update");
        return "appupdateinfo/appupdateinfoForm";
    }

    @RequestMapping(value = "update", method = RequestMethod.POST)
    public String update(@Valid @ModelAttribute("preloadAppupdateinfo") Appupdateinfo appupdateinfo, RedirectAttributes redirectAttributes, MultipartFile file) {
        String relativePath = "appinfo/";
        File descfile = FileUploadUtil.saveFile(file, relativePath, false, 0, 0);
        if (descfile != null && descfile.isFile()) {
            appupdateinfo.setDownloadurl(relativePath + descfile.getName());
            // 自动获取包名
            ApkInfo apk = GetApkInfo.getApkInfoByFilePath(descfile);
            if (apk != null) {
                appupdateinfo.setVersion(apk.getVersionName());
                appupdateinfo.setVersioncode(apk.getVersionCode());
                appupdateinfo.setPackagename(apk.getPackageName());
                //appupdateinfo.setProjectname(projectname);
                //appupdateinfo.setFingerprints(fingerprints);
                //保存文件 属性配置和模板
            } else {
                redirectAttributes.addFlashAttribute("message", "无法识别APK文件");
                return "redirect:/appupdateinfo/list";
            }
        }
        appupdateinfoService.save(appupdateinfo);
        configService.initConfig();
        redirectAttributes.addFlashAttribute("message", "保存成功");
        return "redirect:/appupdateinfo/list";
    }

    @RequestMapping(value = "delete/{id}")
    public String delete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
        appupdateinfoService.delete(id);
        redirectAttributes.addFlashAttribute("message", "删除成功");
        return "redirect:/appupdateinfo/list";
    }

    /**
     * 使用@ModelAttribute, 实现Struts2
     * Preparable二次部分绑定的效果,先根据form的id从数据库查出Appupdateinfo对象,再把Form提交的内容绑定到该对象上。
     * 因为仅update()方法的form中有id属性，因此本方法在该方法中执行.
     */
    @ModelAttribute("preloadAppupdateinfo")
    public Appupdateinfo getAppupdateinfo(@RequestParam(value = "id", required = false) Long id) {
        if (id != null) {
            return appupdateinfoService.findOne(id);
        }
        return null;
    }
    
    @RequestMapping(value = "initconfig", method = RequestMethod.GET)
    public String initconfig(RedirectAttributes redirectAttributes) {
        List<Properties> list = configService.initConfig();
        String result ="警告：";
        if(list!=null&list.size()==2){
            result +="缺少模板(";
            for(Object name:list.get(0).keySet()){
                result+=name+",";
            }
            result +=")缺少配置(";
            for(Object name:list.get(1).keySet()){
                result+=name+",";
            }
            result +=")";
        }
        redirectAttributes.addFlashAttribute("message", result);
        return "redirect:/appupdateinfo/list";
    }
}
