package com.smt.iptv.portal.repository;

import java.math.BigInteger;
import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.smt.iptv.portal.entity.Dishorder;
import com.smt.iptv.portal.entity.Dishordermap;

public interface DishorderDao extends BaseDao<Dishorder> {
    @Query("select m from Dishordermap m where m.orderid =?1")
    public List<Dishordermap> getDishListByOrder(Long orderid);
    
    @Query(nativeQuery=true,value="update dishorder set checkinstatus=?2 where username=?1 and checkinstatus<>?2")
    @Modifying
    public void updateDishorderStatus(String iptvusername,String status);
    
    @Query(nativeQuery=true,value="delete from dishcart where username=?1")
    @Modifying
    public void deleteDishcart(String iptvusername);
    @Query(nativeQuery=true,value="select count(*) from dishorder where status='1'")
    BigInteger getNewOrderCount();
}
