package com.smt.iptv.portal.service.cmp;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.entity.Bulletin;
import com.smt.iptv.portal.repository.BulletinDao;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class BulletinService extends BaseService<BulletinDao, Bulletin> {

    @Transactional(readOnly = false)
    public Bulletin save(Bulletin entity,String iptvprofileid) {
        Bulletin bulletin;
        if (entity.getId() == null) {
            if(StringUtils.isNotBlank(iptvprofileid)&&iptvprofileid.matches("(\\d+,)*\\d+")){
                bulletin = dao.save(entity);
                for(String id:iptvprofileid.split(",")){
                dao.insertBulletinstatus(bulletin.getId(),Long.parseLong(id));
                }
            }else{
                bulletin = dao.save(entity);
                dao.insertBulletinstatus(bulletin.getId());   
            }
        } else {
            bulletin = dao.save(entity);
        }
        return bulletin;
    }

    @Transactional(readOnly = false)
    @Override
    public void delete(Long id) {
        dao.deleteBulletinstatusByBulletinid(id);
        dao.delete(id);
    }

    public List<Bulletin> getByTypeAndStatus(String type,String status) {
        return dao.getByTypeAndStatus(type,status);
    }
    
    public List<Bulletin> getBulletinByType(List<String> types){
    	 return dao.getBulletinByType(types);
    }
    public List<Long> getIptvprofileidByBulletinid(Long bulletinid){
    	return dao.getIptvprofileidByBulletinid(bulletinid);
    }
    
}
