package com.smt.iptv.portal.service.excel;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PushbackInputStream;

import org.apache.poi.POIXMLDocument;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class POIExcelUtilProcess {
    
    private static Logger logger = LoggerFactory.getLogger(POIExcelUtilProcess.class);
    
    /**
     * 批量导入Excel表
     * @param is
     * @param startRow
     * @return 返回Excel表的数据矩阵Array[行][列]
     */
    public static ExcelDataArray importExcelFileToDataArray(InputStream is, int startRow){
        try {
            Workbook workBook =null;
            try {
                workBook = POIExcelUtilProcess.create(is);
            } catch (InvalidFormatException e) {
                throw new RuntimeException("excel解析对象无法创建");
            }//new XSSFWorkbook(is);
            Sheet  sheet = workBook.getSheetAt(0);
            // 获取Sheet表中所包含的最后一行行号
            int sheetRows = sheet.getLastRowNum();
            // 获取Sheet表中所包含的最后一列的列号
            int sheetLines = sheet.getRow(startRow).getLastCellNum();
            logger.debug("读取Excel表格"
                    + "总行数： " + sheetRows + "\n"
                    + "总列数： " + sheetLines + "\n"
                    + "开始行号： " + startRow + "\n");
            //实际数据字段行数
            int rowCnt = sheet.getLastRowNum() - startRow + 1;
            //实际数据字段列数
            int lineCnt = sheet.getRow(startRow).getLastCellNum();
            //初始化结果数据数组
            ExcelDataArray dataArray = new ExcelDataArray(rowCnt, lineCnt);
            
            //过滤第一行标题
            for(int rowIndex=0; rowIndex<sheetRows-startRow+1; rowIndex++){
                logger.debug("读取第" + (rowIndex) + "行数据");
                Row row = sheet.getRow(rowIndex+startRow);
                for(int lineIndex=0; lineIndex<sheetLines; lineIndex++){
                    logger.debug("读取第" + (lineIndex) + "列数据");
                    Cell cell = row.getCell(lineIndex);
                    if(cell!=null){
                        cell.setCellType(XSSFCell.CELL_TYPE_STRING);//默认都先设置为String
                        //设置值
                        dataArray.setColumn(rowIndex, lineIndex, cell.getStringCellValue());
                    }else{
                        continue;
                        //dataArray.setColumn(rowIndex, lineIndex, "");
                    }
                }
            }
            return dataArray;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public static Workbook create(InputStream in) throws     
    IOException,InvalidFormatException {
        if (!in.markSupported()) {
            in = new PushbackInputStream(in, 8);
        }
        if (POIFSFileSystem.hasPOIFSHeader(in)) {
            return new HSSFWorkbook(in);
        }
        if (POIXMLDocument.hasOOXMLHeader(in)) {
            return new XSSFWorkbook(OPCPackage.open(in));
        }
        throw new IllegalArgumentException("你的excel版本目前poi解析不了");

    }
    public static void main(String[] args) throws FileNotFoundException {
        POIExcelUtilProcess.importExcelFileToDataArray(new FileInputStream("d:/program.xlsx"), 1);
    }
}