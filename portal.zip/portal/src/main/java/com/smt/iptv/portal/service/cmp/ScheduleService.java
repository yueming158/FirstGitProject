package com.smt.iptv.portal.service.cmp;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;
import com.smt.iptv.portal.entity.Schedule;
import com.smt.iptv.portal.repository.video.ScheduleDao;
import com.smt.iptv.portal.service.excel.ExcelDataArray;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class ScheduleService extends BaseService<ScheduleDao, Schedule> {

    private ChannelService channelService;

    @Autowired
    public void setChannelService(ChannelService channelService) {
        this.channelService = channelService;
    }

    private static final Logger logger = LoggerFactory.getLogger(ScheduleService.class);

    @Transactional(readOnly = false)
    public void importdata(long channelid, ExcelDataArray excelDataArray) {
        if (excelDataArray != null) {
            for (String[] row : excelDataArray.getDataArray()) {
                this.create(new Schedule(channelid, row), "cpobjectcode", "SCH0000000000");
            }
        }
    }

    public List<Schedule> getScheduleList(Long channelid, Date now) {
        return dao.getScheduleList(channelid, now);
    }

    public void deleteByChannelId(Long id) {
        dao.deleteByChannelId(id);
    }
     //强行删除当天的和第天的数据并更新节目单。要求节目单一定是当天的和第 6天的
    @Transactional(readOnly = false)
    public void refresh(Long channelid, List<Schedule> scheduleList) {
        Calendar c = Calendar.getInstance();
        //c.add(Calendar.DAY_OF_MONTH, -1);
        //int weekday = c.get(Calendar.DAY_OF_WEEK) - 2;
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        dao.deleteDuplicate(channelid, c.getTime());
        //切换到第二天
        //删除scheduleList对应的数据 目前写死为当天天和第六天的数据
        //c.add(Calendar.DAY_OF_MONTH, 1); 
        //dao.deleteDuplicate(channelid, c.getTime());
        c.add(Calendar.DAY_OF_MONTH,5);
        dao.deleteDuplicate(channelid, c.getTime());   
        // 本周1到下周1的数据 写入数据库
        dao.save(scheduleList);
    }
    @Transactional(readOnly = false)
    public void deleteold(Date date) {
        dao.deleteold(date);
    }
    
   public List<Schedule> getScheduleByTvsouurlAndDay(String tvsouurl,Date day) {
       return dao.getScheduleByTvsouurl(tvsouurl,day);
   }
}
