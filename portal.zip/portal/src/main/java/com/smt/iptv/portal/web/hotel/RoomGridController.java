package com.smt.iptv.portal.web.hotel;

import java.util.List;
import java.util.Map;

import javax.servlet.ServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Maps;
import com.smt.iptv.portal.entity.Iptvprofile;
import com.smt.iptv.portal.entity.hotel.Hotelroom;
import com.smt.iptv.portal.service.cmp.IptvprofileService;
import com.smt.iptv.portal.service.hotel.HotelroomService;

/**
 * @author rich
 */
@Controller
@RequestMapping(value = "/roomgrid")
public class RoomGridController {


    @Autowired
    private HotelroomService hotelroomService;
    @Autowired
    private IptvprofileService iptvprofileService;

    @RequestMapping(value = "/list")
    public String list( Model model, ServletRequest request) {

        List<Hotelroom> hotelrooms = hotelroomService.getAllWithCustomer();

        model.addAttribute("hotelrooms", hotelrooms);

        return "hotelroom/roomGrid";
    }

}
