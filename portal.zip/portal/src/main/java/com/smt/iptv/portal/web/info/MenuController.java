package com.smt.iptv.portal.web.info;

import java.io.File;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.smt.iptv.portal.core.FileUploadUtil;
import com.smt.iptv.portal.i18nentity.info.Infotemplate;
import com.smt.iptv.portal.i18nentity.info.Menu;
import com.smt.iptv.portal.i18nentity.program.Picturetype;
import com.smt.iptv.portal.service.cmp.PicturetypeService;
import com.smt.iptv.portal.service.info.InfotemplateService;
import com.smt.iptv.portal.service.info.MenuService;

/**
 * @author rich
 */
@Controller
@RequestMapping(value = "/menu")
public class MenuController {

	private static final int PAGE_SIZE = 50;

	private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
	static {
		sortTypes.put("sequence", "自动");
	}

	@Autowired
	private MenuService menuService;
    @Autowired
    private InfotemplateService infotemplateService;
    @Autowired
    private PicturetypeService  picturetypeService;
	@RequestMapping(value = "/list")
	public String list(@RequestParam(value = "sortType", defaultValue = "sequence") String sortType,
			@RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
		Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");
		Page<Menu> menus = menuService.getPage( searchParams, pageNumber, PAGE_SIZE, sortType);

		model.addAttribute("menus", menus);
		model.addAttribute("sortType", sortType);
		model.addAttribute("sortTypes", sortTypes);
		model.addAttribute("parentmenus",menuService.getByParentid(0L) );
		// 将搜索条件编码成字符串，用于排序，分页的URL
		model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
		return "menu/menuList";
	}
    @RequestMapping(value = "/ajaxlist")
    public String ajaxlist(@RequestParam(value = "sortType", defaultValue = "sequence") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");
        Page<Menu> menus = menuService.getPage( searchParams, pageNumber, PAGE_SIZE, sortType);

        model.addAttribute("menus", menus);
        model.addAttribute("sortType", sortType);
        model.addAttribute("sortTypes", sortTypes);
        model.addAttribute("parentmenus",menuService.getByParentid(0L) );
        // 将搜索条件编码成字符串，用于排序，分页的URL
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
        return "menu/menuajaxList";
    }
//	@RequestMapping(value = "create", method = RequestMethod.GET)
//	public String createForm(Model model,Long parentid) {
//	    Menu menu =new Menu();
//	    menu.setParentid(parentid);
//		model.addAttribute("menu", menu);
//		model.addAttribute("action", "create");
//		model.addAttribute("parentmenus",menuService.getByParentid(0L) );
//		if(parentid>0){
//		    model.addAttribute("infotemplates",infotemplateService.getSencondTemplateList());
//		}else{
//		    model.addAttribute("infotemplates",infotemplateService.getMainTemplateList());
//		}
//        int  width =0;
//        int  height =0;
//        String size="0";
//        List<Picturetype>  ptypelist =picturetypeService.getByPicturetypecode("104");
//        if(ptypelist !=null&&ptypelist.size()==1){
//            width = ptypelist.get(0).getMaxwidth(); // 得到源图宽
//            height = ptypelist.get(0).getMaxheight(); // 得到源图长
//            size = ptypelist.get(0).getFilemaxsize(); // 得到源图大小
//        }
//        model.addAttribute("width", width);
//        model.addAttribute("height", height);
//        model.addAttribute("size", size);
//        int  width2 =0;
//        int  height2 =0;
//        String size2="0";
//        List<Picturetype>  ptypelist2 =picturetypeService.getByPicturetypecode("105");
//        if(ptypelist !=null&&ptypelist.size()==1){
//            width2 = ptypelist2.get(0).getMaxwidth(); // 得到源图宽
//            height2 = ptypelist2.get(0).getMaxheight(); // 得到源图长
//            size2 = ptypelist2.get(0).getFilemaxsize(); // 得到源图大小
//        }
//        model.addAttribute("width2", width2);
//        model.addAttribute("height2", height2);
//        model.addAttribute("size2", size2);
//		return "menu/menuForm";
//	}

	@RequestMapping(value = "create", method = RequestMethod.POST)
	public String create(Menu menu,int width ,int height,int width2 ,int height2, ServletRequest request,Long templateid,MultipartFile file, MultipartFile logo,RedirectAttributes redirectAttributes) {
	    menu.setInfotemplate(new Infotemplate(templateid));
	    String relativePath ="info/";
	    File logofile = FileUploadUtil.saveFile(logo, relativePath,true,width,height);
	    if(logofile!=null&&logofile.isFile()){   
	        //FileUploadUtil.delete(menu.getMenubg());
	        menu.setMenulogo(relativePath+logofile.getName());
	    }
	    File relfile = FileUploadUtil.saveFile(file, relativePath,true,width2,height2);
        if(relfile!=null&&relfile.isFile()){   
            //FileUploadUtil.delete(menu.getMenubg());
            menu.setMenubg(relativePath+relfile.getName());
        }
		menuService.create(menu,"code","menu00000");
		redirectAttributes.addFlashAttribute("message", "新增成功");
		redirectAttributes.addFlashAttribute("tabindex", request.getParameter("tabindex"));
		return "redirect:/menu/list" ;
	}

	@RequestMapping(value = "update/{id}", method = RequestMethod.GET)
	public String updateForm(@PathVariable("id") Long id, Model model) {
		model.addAttribute("menu", menuService.findOne(id));
		model.addAttribute("action", "update");
		model.addAttribute("parentmenus",menuService.getByParentid(0L));
        int  width =0;
        int  height =0;
        String size="0";
        List<Picturetype>  ptypelist =picturetypeService.getByPicturetypecode("104");
        if(ptypelist !=null&&ptypelist.size()==1){
            width = ptypelist.get(0).getMaxwidth(); // 得到源图宽
            height = ptypelist.get(0).getMaxheight(); // 得到源图长
            size = ptypelist.get(0).getFilemaxsize(); // 得到源图大小
        }
        model.addAttribute("width", width);
        model.addAttribute("height", height);
        model.addAttribute("size", size);
        int  width2 =0;
        int  height2 =0;
        String size2="0";
        List<Picturetype>  ptypelist2 =picturetypeService.getByPicturetypecode("105");
        if(ptypelist !=null&&ptypelist.size()==1){
            width2 = ptypelist2.get(0).getMaxwidth(); // 得到源图宽
            height2 = ptypelist2.get(0).getMaxheight(); // 得到源图长
            size2 = ptypelist2.get(0).getFilemaxsize(); // 得到源图大小
        }
        model.addAttribute("width2", width2);
        model.addAttribute("height2", height2);
        model.addAttribute("size2", size2);
		return "menu/menuForm";
	}

	@RequestMapping(value = "update", method = RequestMethod.POST)
	public String update(@ModelAttribute("preloadMenu") Menu menu,int width ,int height,int width2 ,int height2,MultipartFile file,MultipartFile logo,ServletRequest request, RedirectAttributes redirectAttributes) {
	    String relativePath ="info/";
	    File logofile = FileUploadUtil.saveFile(logo, relativePath,true,width,height);
	    if(logofile!=null&&logofile.isFile()){   
	        FileUploadUtil.delete(menu.getMenulogo());
	        menu.setMenulogo(relativePath+logofile.getName());
	    }
        File relfile = FileUploadUtil.saveFile(file, relativePath,true,width2,height2);
        if(relfile!=null&&relfile.isFile()){   
            FileUploadUtil.delete(menu.getMenubg());
            menu.setMenubg(relativePath+relfile.getName());
        }
	    menuService.save(menu);
		redirectAttributes.addFlashAttribute("message", "保存成功");
		redirectAttributes.addFlashAttribute("tabindex", request.getParameter("tabindex"));
		return "redirect:/menu/list";
	}

	@RequestMapping(value = "delete/{id}")
	public String delete(@PathVariable("id") Long id,ServletRequest request, RedirectAttributes redirectAttributes) {
		menuService.delete(id);
		redirectAttributes.addFlashAttribute("message", "删除成功");
		redirectAttributes.addFlashAttribute("tabindex", request.getParameter("tabindex"));
		return "redirect:/menu/list";
	}

	/**
	 * 使用@ModelAttribute, 实现Struts2 Preparable二次部分绑定的效果,先根据form的id从数据库查出Menu对象,再把Form提交的内容绑定到该对象上。
	 * 因为仅update()方法的form中有id属性，因此本方法在该方法中执行.
	 */
	@ModelAttribute("preloadMenu")
	public Menu getMenu(@RequestParam(value = "id", required = false) Long id) {
		if (id != null) {
			return menuService.findOne(id);
		}
		return null;
	}

	
   //多级菜单管理页面开始
	   @RequestMapping(value = "multilist", method = RequestMethod.GET)
	   public String multilist( Model model ) {
	        List<Menu> menus = menuService.findAll(new Sort(new Order(Direction.ASC,"parentid"),new Order(Direction.ASC,"sequence")));
	        List<Menu> sortmenus = Lists.newArrayList();
	        Map<Long,List<Menu>> map =bulidMap(menus);
	        
	        List<Menu> parents= Lists.newArrayList(new Menu(0L));
	        parents.get(0).setDepth(0);
	        //sortmenus.addAll(0,parents );  无需加根节点
	        addChilds(sortmenus, map, parents);

	        model.addAttribute("menus", sortmenus);
	        return "menu/multiList";
	    }
	   
	
	   @RequestMapping(value = "multicreate", method = RequestMethod.GET)
	    public String multicreateForm(Model model,Long parentid) {
	        model.addAttribute("action", "multicreate");
	        if(parentid==0){
	            Menu parentmenu = new Menu(0L);
	            parentmenu.setName("栏目根节点");
	            model.addAttribute("parentmenu",parentmenu);
	        }else{
	            model.addAttribute("parentmenu",menuService.findOne(parentid) );
	        }
	        model.addAttribute("infotemplates",infotemplateService.getEnabledAll());
	        
	        int  width =0;
	        int  height =0;
	        String size="0";
	        List<Picturetype>  ptypelist =picturetypeService.getByPicturetypecode("104");
	        if(ptypelist !=null&&ptypelist.size()==1){
	            width = ptypelist.get(0).getMaxwidth(); // 得到源图宽
	            height = ptypelist.get(0).getMaxheight(); // 得到源图长
	            size = ptypelist.get(0).getFilemaxsize(); // 得到源图大小
	        }
	        model.addAttribute("width", width);
	        model.addAttribute("height", height);
	        model.addAttribute("size", size);
	        int  width2 =0;
	        int  height2 =0;
	        String size2="0";
	        List<Picturetype>  ptypelist2 =picturetypeService.getByPicturetypecode("105");
	        if(ptypelist !=null&&ptypelist.size()==1){
	            width2 = ptypelist2.get(0).getMaxwidth(); // 得到源图宽
	            height2 = ptypelist2.get(0).getMaxheight(); // 得到源图长
	            size2 = ptypelist2.get(0).getFilemaxsize(); // 得到源图大小
	        }
	        model.addAttribute("width2", width2);
	        model.addAttribute("height2", height2);
	        model.addAttribute("size2", size2);
	        return "menu/multiForm";
	    }

	    @RequestMapping(value = "multicreate", method = RequestMethod.POST)
	    public String multicreate(Menu menu,int width ,int height,int width2 ,int height2, ServletRequest request,Long templateid,MultipartFile file, MultipartFile logo,RedirectAttributes redirectAttributes) {
	        menu.setInfotemplate(new Infotemplate(templateid));
	        String relativePath ="info/";
	        File logofile = FileUploadUtil.saveFile(logo, relativePath,true,width,height);
	        if(logofile!=null&&logofile.isFile()){   
	            //FileUploadUtil.delete(menu.getMenubg());
	            menu.setMenulogo(relativePath+logofile.getName());
	        }
	        File relfile = FileUploadUtil.saveFile(file, relativePath,true,width2,height2);
	        if(relfile!=null&&relfile.isFile()){   
	            //FileUploadUtil.delete(menu.getMenubg());
	            menu.setMenubg(relativePath+relfile.getName());
	        }
	        menuService.create(menu,"code","menu00000");
	        redirectAttributes.addFlashAttribute("message", "新增成功");
	        return "redirect:/menu/multilist" ;
	    }

	    @RequestMapping(value = "multiupdate/{id}", method = RequestMethod.GET)
	    public String multiupdateForm(@PathVariable("id") Long id, Model model) {
	        Menu menu =menuService.findOne(id);
	        model.addAttribute("menu", menu);
            if(menu.getParentid()==0){
                Menu parentmenu = new Menu(0L);
                parentmenu.setName("栏目根节点");
                model.addAttribute("parentmenu",parentmenu);
            }else{
                model.addAttribute("parentmenu",menuService.findOne(menu.getParentid()));
            }
	        model.addAttribute("action", "multiupdate");
	        model.addAttribute("infotemplates",infotemplateService.getEnabledAll());
	        int  width =0;
	        int  height =0;
	        String size="0";
	        List<Picturetype>  ptypelist =picturetypeService.getByPicturetypecode("104");
	        if(ptypelist !=null&&ptypelist.size()==1){
	            width = ptypelist.get(0).getMaxwidth(); // 得到源图宽
	            height = ptypelist.get(0).getMaxheight(); // 得到源图长
	            size = ptypelist.get(0).getFilemaxsize(); // 得到源图大小
	        }
	        model.addAttribute("width", width);
	        model.addAttribute("height", height);
	        model.addAttribute("size", size);
	        int  width2 =0;
	        int  height2 =0;
	        String size2="0";
	        List<Picturetype>  ptypelist2 =picturetypeService.getByPicturetypecode("105");
	        if(ptypelist !=null&&ptypelist.size()==1){
	            width2 = ptypelist2.get(0).getMaxwidth(); // 得到源图宽
	            height2 = ptypelist2.get(0).getMaxheight(); // 得到源图长
	            size2 = ptypelist2.get(0).getFilemaxsize(); // 得到源图大小
	        }
	        model.addAttribute("width2", width2);
	        model.addAttribute("height2", height2);
	        model.addAttribute("size2", size2);
	        return "menu/multiForm";
	    }

	    @RequestMapping(value = "multiupdate", method = RequestMethod.POST)
	    public String multiupdate(@ModelAttribute("preloadMenu") Menu menu,Long templateid,int width ,int height,int width2 ,int height2,MultipartFile file,MultipartFile logo,ServletRequest request, RedirectAttributes redirectAttributes) {
	        String relativePath ="info/";
	        File logofile = FileUploadUtil.saveFile(logo, relativePath,true,width,height);
	        if(logofile!=null&&logofile.isFile()){   
	            FileUploadUtil.delete(menu.getMenulogo());
	            menu.setMenulogo(relativePath+logofile.getName());
	        }
	        File relfile = FileUploadUtil.saveFile(file, relativePath,true,width2,height2);
	        if(relfile!=null&&relfile.isFile()){   
	            FileUploadUtil.delete(menu.getMenubg());
	            menu.setMenubg(relativePath+relfile.getName());
	        }
	        menu.setInfotemplate(new Infotemplate(templateid));
	        menuService.save(menu);
	        redirectAttributes.addFlashAttribute("message", "保存成功");
	        return "redirect:/menu/multilist";
	    }

	    @RequestMapping(value = "multidelete/{id}")
	    public String multidelete(@PathVariable("id") Long id,ServletRequest request, RedirectAttributes redirectAttributes) {
	        List<Menu> list =menuService.getByParentid(id);
	        if(list!=null&&list.size()>0){
	            redirectAttributes.addFlashAttribute("message", "存在子栏目，无法删除");
	        }else{
	            menuService.delete(id);
	            redirectAttributes.addFlashAttribute("message", "删除成功");
	        }
	        return "redirect:/menu/multilist";
	    }
	   
   //递归构建树 root节点不在树中。
    private void addChilds(List<Menu> sortmenus, Map<Long, List<Menu>> map,List<Menu> parents) {
        for(int i=0;i<parents.size();i++){
            int index =sortmenus.indexOf(parents.get(i));
            if(sortmenus.size()==0){
                index=0;
            }else{
                if(index==-1){
                    continue;
                }
                index++;
            }
            long parentid=parents.get(i).getId();
            List<Menu> childs =map.get(parentid);
            if(childs!=null&&childs.size()>0){
                setDepth(childs,parents.get(i).getDepth()+1);
                sortmenus.addAll(index,childs );
                addChilds(sortmenus,map,childs);
            }
        }
    }
   

   //把list按parentid分成若干组 方便递归构建树 
   private Map<Long,List<Menu>> bulidMap(List<Menu> menus){
       Map<Long,List<Menu>> map =Maps.newHashMap();
       for(Menu menu:menus){
           Long parentid=menu.getParentid();
           if(map.get(parentid)==null){
               map.put(parentid, Lists.newArrayList(menu));
           }else{
               map.get(parentid).add(menu);
           }
       }
       return map;
   }
   //批量设置 深度
   private void setDepth(List<Menu> list,int depth){
       if(list!=null)
       for(Menu menu:list){
           menu.setDepth(depth);
       }
   }
}
