package com.smt.iptv.portal.i18nentity;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.portal.core.IdEntity;
@Entity
@Table(name = "category")
public class Category extends IdEntity {
    
    public Category() {
    }

    public Category(Long id) {
        this.id = id;
    }
    private String menucode;
	private String categoryname;
	private Long parentid;
	private String cpobjectcode;
    private String categorytype;
    private String deleteflag;
    private Integer sequence;   

    
    public String getMenucode() {
        return menucode;
    }

    public void setMenucode(String menucode) {
        this.menucode = menucode;
    }

    public String getCategoryname() {
        return categoryname;
    }

    public void setCategoryname(String categoryname) {
        this.categoryname = categoryname;
    }

    public String getCpobjectcode() {
        return cpobjectcode;
    }

    public void setCpobjectcode(String cpobjectcode) {
        this.cpobjectcode = cpobjectcode;
    }

    public String getCategorytype() {
        return categorytype;
    }

    public void setCategorytype(String categorytype) {
        this.categorytype = categorytype;
    }

    public String getDeleteflag() {
        return deleteflag;
    }

    public void setDeleteflag(String deleteflag) {
        this.deleteflag = deleteflag;
    }

    public Integer getSequence() {
        return sequence;
    }

    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

    public Long getParentid() {
        return parentid;
    }

    public void setParentid(Long parentid) {
        this.parentid = parentid;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}