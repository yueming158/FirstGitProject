package com.smt.iptv.portal.i18nrepository.info;

import java.util.List;

import org.springframework.data.jpa.repository.Query;

import com.smt.iptv.portal.i18nentity.info.Infotemplate;
import com.smt.iptv.portal.repository.BaseDao;

public interface InfotemplateDao extends BaseDao<Infotemplate> {
    @Query(nativeQuery=true,value="select * from infotemplate where code=?1 and enabled='1'")
    Infotemplate getByCode(String code);
    @Query(nativeQuery=true,value="select * from infotemplate where enabled='1'")
    List<Infotemplate> getEnabledAll();  
}
