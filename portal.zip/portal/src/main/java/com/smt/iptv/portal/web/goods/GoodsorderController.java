package com.smt.iptv.portal.web.goods;

import java.util.List;
import java.util.Map;

import javax.servlet.ServletRequest;
import javax.validation.Valid;

import org.apache.shiro.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Maps;
import com.smt.iptv.portal.entity.Goodsorder;
import com.smt.iptv.portal.entity.Goodsordermap;
import com.smt.iptv.portal.service.account.ShiroDbRealm.ShiroUser;
import com.smt.iptv.portal.service.goods.GoodsorderService;

/**
 * Goodsorder管理的Controller, 使用Restful风格的Urls:
 * 
 * List page     : GET /goodsorder/
 * Create page   : GET /goodsorder/create
 * Create action : POST /goodsorder/create
 * Update page   : GET /goodsorder/update/{id}
 * Update action : POST /goodsorder/update
 * Delete action : GET /goodsorder/delete/{id}
 * 
 * @author xjw
 */
@Controller
@RequestMapping(value = "/goodsorder")
public class GoodsorderController {

	private static final int PAGE_SIZE = 50;

	private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
	static {
		sortTypes.put("auto", "自动");
		sortTypes.put("goodsordername", "名称");
	}

	@Autowired
	private GoodsorderService goodsorderService;

	@RequestMapping(value = "/list")
	public String list(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
			@RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
		Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");

		Page<Goodsorder> goodsorders = goodsorderService.getPage( searchParams, pageNumber, PAGE_SIZE, sortType);

		model.addAttribute("goodsorders", goodsorders);
		model.addAttribute("sortType", sortType);
		model.addAttribute("sortTypes", sortTypes);
		// 将搜索条件编码成字符串，用于排序，分页的URL
		model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
		return "goodsorder/goodsorderList";
	}

	@RequestMapping(value = "create", method = RequestMethod.GET)
	public String createForm(Model model) {
		model.addAttribute("goodsorder", new Goodsorder());
		model.addAttribute("action", "create");
		return "goodsorder/goodsorderForm";
	}

	@RequestMapping(value = "create", method = RequestMethod.POST)
	public String create(@Valid Goodsorder newGoodsorder, RedirectAttributes redirectAttributes) {

		goodsorderService.save(newGoodsorder);
		redirectAttributes.addFlashAttribute("message", "新增成功");
		return "redirect:/goodsorder/list";
	}

	@RequestMapping(value = "update/{id}", method = RequestMethod.GET)
	public String updateForm(@PathVariable("id") Long id, Model model) {
		model.addAttribute("goodsorder", goodsorderService.findOne(id));
		List<Goodsordermap> maps =goodsorderService.getGoodsListByOrder(id);
        model.addAttribute("maps", maps);
		model.addAttribute("action", "save");
		return "goodsorder/goodsorderForm";
	}

	@RequestMapping(value = "update", method = RequestMethod.POST)
	public String update(@Valid @ModelAttribute("preloadGoodsorder") Goodsorder goodsorder, RedirectAttributes redirectAttributes) {
		goodsorderService.save(goodsorder);
		redirectAttributes.addFlashAttribute("message", "保存成功");
		return "redirect:/goodsorder/list";
	}

	@RequestMapping(value = "delete/{id}")
	public String delete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
		goodsorderService.delete(id);
		redirectAttributes.addFlashAttribute("message", "删除成功");
		return "redirect:/goodsorder/list";
	}

	/**
	 * 使用@ModelAttribute, 实现Struts2 Preparable二次部分绑定的效果
	 */
	@ModelAttribute("preloadGoodsorder")
	public Goodsorder getGoodsorder(@RequestParam(value = "id", required = false) Long id) {
		if (id != null) {
			return goodsorderService.findOne(id);
		}
		return null;
	}
    @RequestMapping(value = "detail", method = RequestMethod.GET)
    public String detail(Long id, Model model) {
        Goodsorder goodsorder =goodsorderService.findOne(id);
        List<Goodsordermap> maps =goodsorderService.getGoodsListByOrder(id);
        model.addAttribute("maps", maps);
        model.addAttribute("goodsorder", goodsorder);
        return "goodsorder/detail";
    }
    
    @RequestMapping(value = "verify/{id}")
    public String response(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
        ShiroUser user = (ShiroUser) SecurityUtils.getSubject().getPrincipal();
        if (goodsorderService.verify(id,user.getName()) != null) {
            redirectAttributes.addFlashAttribute("message", "订单已核对");
        } else {
            redirectAttributes.addFlashAttribute("message", "订单核对错误");
        }
        return "redirect:/goodsorder/list";
    }
    @RequestMapping(value = "complete/{id}")
    public String complete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {

        if (goodsorderService.complete(id) != null) {
            redirectAttributes.addFlashAttribute("message", "订单完成并关闭");
        } else {
            redirectAttributes.addFlashAttribute("message", "订单关闭失败");
        }
        return "redirect:/goodsorder/list";
    }
    @RequestMapping(value = "cancel/{id}")
    public String cancel(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {

        if (goodsorderService.cancel(id) != null) {
            redirectAttributes.addFlashAttribute("message", "订单已取消");
        } else {
            redirectAttributes.addFlashAttribute("message", "订单取消失败");
        }
        return "redirect:/goodsorder/list";
    }
}
