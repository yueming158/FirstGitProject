package com.smt.iptv.portal.i18nrepository.dish;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;

import com.smt.iptv.portal.i18nentity.dish.Categorydish;
import com.smt.iptv.portal.i18nentity.dish.Dish;
import com.smt.iptv.portal.repository.BaseDao;

public interface CategorydishDao  extends BaseDao<Categorydish>{
    @Query("select DISTINCT p from Dish p where  not exists (select 1 from Categorydish cp where cp.category.id=?1 and cp.dish.id=p.id)")
    public Page<Dish>  getDishExceptCategory(Long categoryid,Pageable pageable);

}
