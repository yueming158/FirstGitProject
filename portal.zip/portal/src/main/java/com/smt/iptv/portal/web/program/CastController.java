package com.smt.iptv.portal.web.program;

import java.util.Map;

import javax.servlet.ServletRequest;
import javax.validation.Valid;

import org.apache.shiro.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Maps;
import com.smt.iptv.portal.i18nentity.program.Cast;
import com.smt.iptv.portal.i18nentity.program.Castrole;
import com.smt.iptv.portal.i18nentity.program.Program;
import com.smt.iptv.portal.service.account.ShiroDbRealm.ShiroUser;
import com.smt.iptv.portal.service.cmp.CastService;
import com.smt.iptv.portal.service.cmp.CastroleService;
import com.smt.iptv.portal.service.cmp.ProgramService;

/**
 * Cast管理的Controller, 使用Restful风格的Urls:
 * 
 * List page     : GET /cast/
 * Create page   : GET /cast/create
 * Create action : POST /cast/create
 * Update page   : GET /cast/update/{id}
 * Update action : POST /cast/update
 * Delete action : GET /cast/delete/{id}
 * 
 * @author xjw
 */
@Controller
@RequestMapping(value = "/cast")
public class CastController {

	private static final int PAGE_SIZE = 50;

	private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
	static {
		sortTypes.put("auto", "自动");
		sortTypes.put("castname", "名称");
	}

	@Autowired
	private CastService castService;
    @Autowired
    private CastroleService castroleService;
    @Autowired
    private ProgramService programService;
	@RequestMapping(value = "/list")
	public String list(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
			@RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
		Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");

		Page<Cast> casts = castService.getPage( searchParams, pageNumber, PAGE_SIZE, sortType);
		model.addAttribute("castroles", castroleService.getAll());
		model.addAttribute("casts", casts);
		model.addAttribute("sortType", sortType);
		model.addAttribute("sortTypes", sortTypes);
		// 将搜索条件编码成字符串，用于排序，分页的URL
		model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
		return "cast/castList";
	}
    @RequestMapping(value = "{programid}/{programtype}/list")
    public String listByProgram(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber,
            @PathVariable("programid") Long programid, @PathVariable("programtype") String programtype,Model model, ServletRequest request) {
//        Page<Cast> casts = castService.getCastsByProgramid( programid, pageNumber, PAGE_SIZE, sortType);
//        model.addAttribute("programtype", programtype);
//        model.addAttribute("casts", casts);
//        model.addAttribute("sortType", sortType);
//        model.addAttribute("sortTypes", sortTypes);
        return "cast/castbyprogramList";
    }
	@RequestMapping(value = "create", method = RequestMethod.GET)
	public String createForm(Model model) {
	    model.addAttribute("castroles", castroleService.getAll());
		model.addAttribute("cast", new Cast());
		model.addAttribute("action", "create");
		return "cast/castForm";
	}

	@RequestMapping(value = "create", method = RequestMethod.POST)
	public String create(@Valid Cast newCast, RedirectAttributes redirectAttributes,
	        @RequestParam(value = "castroleid") Long castroleid) {
	    newCast.setCastrole(new Castrole(castroleid));
		castService.create(newCast, "cpobjectcode", "CAST0000000000");
		redirectAttributes.addFlashAttribute("message", "新增成功");
		return "redirect:/cast/list";
	}

	@RequestMapping(value = "update/{id}", method = RequestMethod.GET)
	public String updateForm(@PathVariable("id") Long id, Model model) {
	    model.addAttribute("castroles", castroleService.getAll());
		model.addAttribute("cast", castService.findOne(id));
		model.addAttribute("action", "update");
		return "cast/castForm";
	}

	@RequestMapping(value = "update", method = RequestMethod.POST)
	public String update(@Valid @ModelAttribute("preloadCast") Cast cast, RedirectAttributes redirectAttributes,
	        @RequestParam(value = "castroleid") Long castroleid) {
	    cast.setCastrole(new Castrole(castroleid));
		castService.save(cast);
		redirectAttributes.addFlashAttribute("message", "保存成功");
		return "redirect:/cast/list";
	}

	@RequestMapping(value = "delete/{id}")
	public String delete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
		castService.delete(id);
		redirectAttributes.addFlashAttribute("message", "删除成功");
		return "redirect:/cast/list";
	}

	/**
	 * 使用@ModelAttribute, 实现Struts2 Preparable二次部分绑定的效果,先根据form的id从数据库查出Cast对象,再把Form提交的内容绑定到该对象上。
	 * 因为仅update()方法的form中有id属性，因此本方法在该方法中执行.
	 */
	@ModelAttribute("preloadCast")
	public Cast getCast(@RequestParam(value = "id", required = false) Long id) {
		if (id != null) {
			return castService.findOne(id);
		}
		return null;
	}
	/**
	 * 增加演职人员到节目
	 * @param programid
	 * @param model
	 * @param request
	 * @param sortType
	 * @param pageNumber
	 * @return
	 */
   @RequestMapping(value = "addtoprogram/{programid}/{programtype}", method = RequestMethod.GET)
    public String addtoprogrampage(@PathVariable("programid") Long programid,@PathVariable("programtype") String programtype,Model model, ServletRequest request,
            @RequestParam(value = "sortType", defaultValue = "auto") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber) {
       model.addAttribute("castroles", castroleService.getCastrolesByProgramid(programid));
       model.addAttribute("programid", programid);
       model.addAttribute("programtype", programtype);
       model.addAttribute("action", "addtoprogram");
       
       Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");
       searchParams.put("EQ_castrole.programtype", programtype);
       Page<Cast> casts = castService.getPage( searchParams, pageNumber, 10, sortType);
       model.addAttribute("casts", casts);
       model.addAttribute("sortType", sortType);
       model.addAttribute("sortTypes", sortTypes);
       // 将搜索条件编码成字符串，用于排序，分页的URL
       model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
       return "cast/castAddToProgramForm";
    }

    @RequestMapping(value = "addtoprogram/{programid}/{programtype}", method = RequestMethod.POST)
    public String addtoprogramsave(@PathVariable("programid") Long programid,@PathVariable("programtype") String programtype,@Valid Cast newCast, RedirectAttributes redirectAttributes) {
//        if(newCast.getId()!=null){
//            Program p=programService.findOne(programid);
//            p.getCastlist().add(newCast);
//            String rolename=newCast.getCastrole().getCastrolename();
//            if("导演".equals(rolename)||"作者".equals(rolename)){
//                String s=p.getWriternames();
//                if(s==null||s.isEmpty()){
//                    p.setWriternames(newCast.getCastname());
//                }else{
//                    
//                    p.setWriternames(p.getWriternames()+","+newCast.getCastname());
//                }
//            }else{
//                String s=p.getActornames();
//                if(s==null||s.isEmpty()){
//                    p.setActornames(newCast.getCastname());
//                }else{
//                    
//                    p.setActornames(p.getActornames()+","+newCast.getCastname());
//                }
//            }
//            programService.save(p);
//            redirectAttributes.addFlashAttribute("message", "添加关联成功");
//        }else{
//            redirectAttributes.addFlashAttribute("message", "未选中演职人员");
//        }
        return "redirect:/cast/"+programid+"/"+programtype+"/list/";
    }
	
    @RequestMapping(value = "deleteformprogram/{programid}/{programtype}/{id}")
    public String deleteformprogram(@PathVariable("programid") Long programid,@PathVariable("id") Long id,
            @PathVariable("programtype") String programtype,RedirectAttributes redirectAttributes) {
//       // castService.delete(id);
//        Program p=programService.findOne(programid);
//        
//        Cast cast=null;//Cast cast=new Cast(id); z这样不行 listremove不了 没有好办法只能循环
//        StringBuilder actornames=new StringBuilder();
//        StringBuilder writernames=new StringBuilder();
//        for(Cast c: p.getCastlist()){
//            if(c.getId()==id){
//                cast=c;
//            }else{
//                String rolename=  c.getCastrole().getCastrolename();
//                if("导演".equals(rolename)||"作者".equals(rolename)){
//                    actornames.append(",").append(c.getCastname());
//                }else{
//                    writernames.append(",").append(c.getCastname());
//                }
//            }
//        }
//        p.getCastlist().remove(cast);
//        if(actornames.length()>1){
//            p.setActornames(actornames.substring(1).toString());
//        }
//        if(writernames.length()>1){
//            p.setWriternames(writernames.substring(1).toString());
//        }
//        programService.save(p);
//        redirectAttributes.addFlashAttribute("message", "取消"+cast.getCastname()+"与节目关联成功");
        return "redirect:/cast/"+programid+"/"+programtype+"/list";
    }
	/**
	 * 取出Shiro中的当前用户Id.
	 */
	private Long getCurrentUserId() {
		ShiroUser user = (ShiroUser) SecurityUtils.getSubject().getPrincipal();
		return user.id;
	}
}
