package com.smt.iptv.portal.service.send;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springside.modules.mapper.JaxbMapper;

import com.google.common.collect.Lists;
import com.smt.iptv.portal.i18nentity.program.Mediacontent;
import com.smt.iptv.portal.model.SystemConstant;
import com.smt.iptv.portal.xml.ADI;
import com.smt.iptv.portal.xml.NodeObject;
import com.smt.iptv.portal.xml.NodeProperty;

//Spring Bean的标识.
@Component


public class MediaLoaderService {
    public void regist(Mediacontent e){
        if("m".equals(e.getUrltype())){
        //构造xml
        ADI adi = new ADI();
        NodeObject mediaObjs = new NodeObject(e.getId(),"Movie","REGIST");
        adi.getObjs().add(mediaObjs);
        mediaObjs.setPropertys(buildMediaPropertyList(e));
        String xml = JaxbMapper.toXml(adi, "UTF-8");
        socketClient.send("MediaContent",xml);
        }
    }
    public void update(Mediacontent e){
          //暂不支持更新 因为CDN暂不能识别是否改变了原始文件
//        if("m".equals(e.getUrltype())){
//        ADI adi = new ADI();
//        NodeObject mediaObjs = new NodeObject(e.getId(),"Movie","UPDATE");
//        adi.getObjs().add(mediaObjs);
//        mediaObjs.setPropertys(buildMediaPropertyList(e));
//        String xml = JaxbMapper.toXml(adi, "UTF-8");
//        socketClient.send("MediaContent",xml);
//        }
    }
    public void delete(Mediacontent e){
        if("m".equals(e.getUrltype())){
        ADI adi = new ADI();
        NodeObject mediaObjs = new NodeObject(e.getId(),"Movie","DELETE");
        adi.getObjs().add(mediaObjs);
        mediaObjs.getPropertys().add(new NodeProperty("CPObjectCode",e.getCpobjectcode()));
        String xml = JaxbMapper.toXml(adi, "UTF-8");
        socketClient.send("MediaContent",xml);
        }
    }
    public void delete(List<Mediacontent> list){
        for(Mediacontent m:list){
            this.delete(m);
        }
    }
    
    /**
     * 
<Property Name="ContentName">kungfupanda_720x576_h264_2</Property>
<Property Name="CPObjectCode">MOV0000000000000000008@CRI</Property>
<Property Name="MediaType">1</Property>
<Property Name="Type">1</Property>
<Property Name="ClosedCaption">1</Property>
<Property Name="HDTV">0</Property>
<Property Name="ColorCode">1</Property>
<Property Name="Status">0</Property>
<Property Name="Screen_Format">0</Property>
<Property Name="VideoType">0</Property>
<Property Name="AudioType">0</Property>
<Property Name="Vod_Drm_Type">0</Property>
<Property Name="Drm_Profile_Type">0</Property>
<Property Name="SourceFileName">ftp://sulang:sulang@124.205.88.204//opt/sulang/media/kungfupanda_720x576_h264_2.5M.ts</Property>
<Property Name="CGMS_A">0</Property>
<Property Name="HDCP">0</Property>
<Property Name="ScrambleFlag">0</Property>
<Property Name="WaterMark">0</Property>
<Property Name="FingerPrint">0</Property>指纹，Defaut '0'
<Property Name="Macrovision">0</Property>拷贝保护，Defaut '0'
<Property Name="PropagationPriority">0</Property>分发优先级，CND使用
<Property Name="Duration">122000</Property>
<Property Name="DestFileName">ftp://sulang:sulang@124.205.88.206//ts/MOV0000000000000000008@CRI.ts</Property>
     * @param e
     * @return
     */
    private List<NodeProperty> buildMediaPropertyList(Mediacontent e){
       List<NodeProperty> list = Lists.newArrayList();
       list.add(new NodeProperty("ContentName", e.getProgram().getProgramname()+" - "+e.getMediacontentname()));
       list.add(new NodeProperty("CPObjectCode", e.getCpobjectcode()));
       list.add(new NodeProperty("MediaType", "1"));
       list.add(new NodeProperty("Type", "1"));
       list.add(new NodeProperty("ClosedCaption", "1"));
       list.add(new NodeProperty("HDTV", "1"));
       list.add(new NodeProperty("ColorCode", "1"));
       list.add(new NodeProperty("Status", "0"));
       list.add(new NodeProperty("Screen_Format", "0"));
       //list.add(new MediaProperty("VideoType", value));
       //list.add(new MediaProperty("AudioType", value));
       list.add(new NodeProperty("Vod_Drm_Type", "0"));
       list.add(new NodeProperty("Drm_Profile_Type", "0"));
       list.add(new NodeProperty("SourceFileName",SystemConstant.getURLValue("media_server_ftpurl_f")+ e.getSourcefilename()));
       list.add(new NodeProperty("CGMS_A", "0"));
       list.add(new NodeProperty("HDCP", "0"));
       list.add(new NodeProperty("ScrambleFlag", "0"));
       list.add(new NodeProperty("WaterMark", "0"));
       list.add(new NodeProperty("FingerPrint", "0"));
       list.add(new NodeProperty("Macrovision", "0"));
       list.add(new NodeProperty("PropagationPriority", "0"));
       //list.add(new MediaProperty("Duration", ""));
       //list.add(new MediaProperty("DestFileName", ""));
        return list;
    }

}
