package com.smt.iptv.portal.repository.role;

import com.smt.iptv.portal.entity.role.Role;
import com.smt.iptv.portal.repository.BaseDao;


public interface RoleDao extends BaseDao<Role>{
    Role getByrole(String role);
}
