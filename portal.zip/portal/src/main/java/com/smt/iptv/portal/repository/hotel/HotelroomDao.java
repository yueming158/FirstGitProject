package com.smt.iptv.portal.repository.hotel;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.smt.iptv.portal.entity.hotel.Hotelroom;
import com.smt.iptv.portal.repository.BaseDao;

public interface HotelroomDao extends BaseDao<Hotelroom> {
    @Query("select r.roomname from Hotelroom r where r.iptvprofile.id=?1")
    public String getRoomNameByIptvprofileid(Long iptvprofileid);
    @Query("select r.roomname from Hotelroom r where r.iptvprofile.iptvusername=?1")
    String getRoomNameByAccount(String account);
    public Hotelroom getByIptvprofileId(Long iptvprofileid);
    
    @Query("delete from Hotelroom r where r.iptvprofile.id=?1")
    @Modifying
    public void deleteByIptvprofileId(Long iptvprofileid);
    public List<Hotelroom> getByRoomname(String roomname);
    public List<Hotelroom> getByRoomno(String roomno);
    @Query("SELECT p.iptvusername from Iptvprofile p WHERE not EXISTS(SELECT 1 FROM Hotelroom r WHERE r.iptvprofile.id=p.id)")
    public List<String> getUndividedAccount();
    @Query("SELECT count(c) from Hotelcustomer c where c.hotelroom.id=?1")
    public Long isHasCustomer(Long  roomid);
}
