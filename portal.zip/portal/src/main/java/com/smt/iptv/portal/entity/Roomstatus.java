package com.smt.iptv.portal.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.format.annotation.DateTimeFormat;

import com.smt.iptv.portal.core.IdEntity;
@Entity
@Table(name = "roomstatus")
public class Roomstatus extends IdEntity {
    
    public Roomstatus() {
    }

    public Roomstatus(Long id) {
        this.id = id;
    }

    private String account;
    private Date starttime; 
    private Date endtime;

    private String roomname; //额外的room名字

    @Transient
    public int getStatus() {
        if(starttime==null||endtime==null){
            return 2;
        }
        Long now =System.currentTimeMillis();
        if(now<starttime.getTime()||now >=endtime.getTime()){
            return 2;
        }else if(now>=starttime.getTime()&&now<endtime.getTime()-300000){//300000毫秒=5分钟
            return 0;
        }else {
            return 1;
        }
    }
    @Transient
    public Long getCountdownsecond() {
        if(endtime==null){
            return 0L;
        }
        Long now =System.currentTimeMillis();
        if(now<endtime.getTime()){
            return (endtime.getTime()-now)/1000;
        }else{
            return 0L;
        }
    }
    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public Date getStarttime() {
        return starttime;
    }

    public void setStarttime(Date starttime) {
        this.starttime = starttime;
    }

    public Date getEndtime() {
        return endtime;
    }

    public void setEndtime(Date endtime) {
        this.endtime = endtime;
    }

    @Transient
    public String getRoomname() {
        return roomname;
    }

    public void setRoomname(String roomname) {
        this.roomname = roomname;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}