package com.smt.iptv.portal.entity.license;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.smt.iptv.portal.core.IdEntity;

@Entity
@Table(name = "device")
public class Device extends IdEntity {
    
    public Device() {
    }

    public Device(Long id) {
        this.id = id;
    }
    private String hardwareinfo;
    private String systeminfo;
    private String appinfo;
    private Date creationtime;

    public String getHardwareinfo() {
        return hardwareinfo;
    }

    public void setHardwareinfo(String hardwareinfo) {
        this.hardwareinfo = hardwareinfo;
    }

    public String getSysteminfo() {
        return systeminfo;
    }

    public void setSysteminfo(String systeminfo) {
        this.systeminfo = systeminfo;
    }

    public String getAppinfo() {
        return appinfo;
    }

    public void setAppinfo(String appinfo) {
        this.appinfo = appinfo;
    }

    public Date getCreationtime() {
        return creationtime;
    }

    public void setCreationtime(Date creationtime) {
        this.creationtime = creationtime;
    }

}
