package com.smt.iptv.portal.repository.aaa;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;

import com.smt.iptv.portal.entity.aaa.Orderusage;
import com.smt.iptv.portal.repository.BaseDao;

public interface OrderusageDao extends BaseDao<Orderusage> {
	 @Query("select ou from Orderusage ou where ou.accountid=?1 and ou.paystatus='2' and ou.orderendtime>?2")
	 public Page<Orderusage> getOrderusageByAccountId(Long accountId,Date date,Pageable pageable);
	 @Query("select ou.productofferid from Orderusage ou,Productoffer po where po.id=ou.productofferid and ou.accountid=?1 and strategytype=?2 and ou.paystatus='2'")
	 public List<Long> getOrderusageByType(Long accountId, String type);
	 @Query("select max(ou.orderendtime) from Orderusage ou where ou.accountid=?1 and ou.productofferid=?2 and ou.paystatus='2'")
	 public Date getLastOrderusage(Long accountId, Long productoffeId);
	 @Query("select ou from Orderusage ou where ou.accountid=?1 and ou.paystatus='2' and ou.orderendtime>?2 and ou.productoffername like ?3")
	 public Page<Orderusage> getOrderusages(Long accountId,
			 Date date,String productoffername, Pageable page);
}
