package com.smt.iptv.portal.i18nentity.info;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.smt.iptv.portal.core.IdEntity;
@Entity
@Table(name = "menu")
public class Menu extends IdEntity {
    
    public Menu() {
    }

    public Menu(Long id) {
        this.id = id;
    }
    private long parentid;
	private String name;
	@JsonIgnore
	private String code;
	private String sequence;
	@JsonIgnore
	private Infotemplate infotemplate;
	@JsonIgnore
	private String zhtitle;
	@JsonIgnore
	private String entitle;
	@JsonIgnore
	private String menubg;
	@JsonIgnore
	private String menulogo;
	private String enable;
	private int depth;
    @ManyToOne
    @JoinColumn(name="templateid")
    public Infotemplate getInfotemplate() {
        return infotemplate;
    }

    public void setInfotemplate(Infotemplate infotemplate) {
        this.infotemplate = infotemplate;
    }

    public long getParentid() {
        return parentid;
    }

    public void setParentid(long parentid) {
        this.parentid = parentid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getSequence() {
        return sequence;
    }

    public void setSequence(String sequence) {
        this.sequence = sequence;
    }

    public String getEnable() {
        return enable;
    }

    public void setEnable(String enable) {
        this.enable = enable;
    }

    public String getZhtitle() {
        return zhtitle;
    }

    public void setZhtitle(String zhtitle) {
        this.zhtitle = zhtitle;
    }

    public String getEntitle() {
        return entitle;
    }

    public void setEntitle(String entitle) {
        this.entitle = entitle;
    }

    public String getMenulogo() {
        return menulogo;
    }

    public void setMenulogo(String menulogo) {
        this.menulogo = menulogo;
    }

    public String getMenubg() {
        return menubg;
    }

    public void setMenubg(String menubg) {
        this.menubg = menubg;
    }
    @Transient
    public int getDepth() {
        return depth;
    }

    public void setDepth(int depth) {
        this.depth = depth;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}