package com.smt.iptv.portal.web.program;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletRequest;
import javax.validation.Valid;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.smt.iptv.portal.core.CnToSpell;
import com.smt.iptv.portal.core.FileUploadUtil;
import com.smt.iptv.portal.core.ZipUtils;
import com.smt.iptv.portal.entity.aaa.ZipView;
import com.smt.iptv.portal.i18nentity.Category;
import com.smt.iptv.portal.i18nentity.program.Mediacontent;
import com.smt.iptv.portal.i18nentity.program.Picture;
import com.smt.iptv.portal.i18nentity.program.Picturetype;
import com.smt.iptv.portal.i18nentity.program.Program;
import com.smt.iptv.portal.model.SystemConstant;
import com.smt.iptv.portal.service.cmp.AreaService;
import com.smt.iptv.portal.service.cmp.CategoryService;
import com.smt.iptv.portal.service.cmp.CategoryprogramService;
import com.smt.iptv.portal.service.cmp.GenreService;
import com.smt.iptv.portal.service.cmp.MediacontentService;
import com.smt.iptv.portal.service.cmp.PictureService;
import com.smt.iptv.portal.service.cmp.PicturetypeService;
import com.smt.iptv.portal.service.cmp.ProgramService;

/** 
 * @author xjw
 */
@Controller
@RequestMapping(value = "/program")
public class ProgramController {

	private static final int PAGE_SIZE = 50;

	private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
	static {
		sortTypes.put("auto", "自动");
		sortTypes.put("programname", "名称");
	}

	@Autowired
	private ProgramService programService;
	@Autowired
	private MediacontentService mediacontentService;
	@Autowired
    private AreaService areaService;
	@Autowired
	private GenreService genreService;
	@Autowired
	private CategoryService categoryService;
	@Autowired
	private PicturetypeService  picturetypeService;
    @Autowired
    private PictureService  pictureService;
    @Autowired
    private CategoryprogramService categoryprogramService;
	@RequestMapping(value = "/list")
	public String list(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
			@RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) throws UnsupportedEncodingException {
		Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");

		Page<Program> programs = programService.getPage( searchParams, pageNumber, PAGE_SIZE, sortType);

		model.addAttribute("programs", programs);
		model.addAttribute("sortType", sortType);
		model.addAttribute("sortTypes", sortTypes);
		// 将搜索条件编码成字符串，用于排序，分页的URL-Dorg.mortbay.util.URI.charset=utf-8
		String sps=Servlets.encodeParameterStringWithPrefix(searchParams, "search_");
		model.addAttribute("searchParams", sps);
		return "program/programList";
	}

//	@RequestMapping(value = "create", method = RequestMethod.GET)
//	public String createForm(Model model,String sp) throws UnsupportedEncodingException {
//	    List<Area> areas =areaService.getAll();       
//	    model.addAttribute("genres", genreService.getByProgramtype("10"));
//	    model.addAttribute("areas", areas);
//		model.addAttribute("program", new Program());
//		model.addAttribute("action", "create");
//		model.addAttribute("sp",URLEncoder.encode(sp,"UTF-8")); 
//		return "program/programForm";
//	}
//
//
//	@RequestMapping(value = "create", method = RequestMethod.POST)
//	public ModelAndView create(@Valid Program newProgram, RedirectAttributes redirectAttributes,String sp) throws UnsupportedEncodingException {
//	    
//	    //新增节目
//	    newProgram.setSearchname(CnToSpell.getSimpleSpell(newProgram.getProgramname()));
//	    newProgram.setStatus("0");
//		programService.create(newProgram, "cpobjectcode", "PG0000000000");
//		//redirectAttributes.addFlashAttribute("message", "");
//		//新增节目的演职人员
//		//暂不实现关联数据 直接录入字符串即可。
//		//新增内容类型 也是直接录入字符串即可。
//		
//        Map<String, String> modelMap = buildModelMap(sp);
//        modelMap.put("message", "新增成功");
//        return new ModelAndView("redirect:/program/list").addAllObjects(modelMap);
//		//return "redirect:/program/list"+URLDecoder.decode(sp, "UTF-8");
//	}
//
//	@RequestMapping(value = "update/{id}", method = RequestMethod.GET)
//	public String updateForm(@PathVariable("id") Long id, Model model,String sp) throws UnsupportedEncodingException {
//	    List<Area> areas =areaService.getAll();
//	    List<Genre> genres =genreService.getAll();
//	    Program p = programService.findOne(id);
//	    if(genres!=null){
//	        int count =genres.size()-1;
//    	    for(int i=count;i>=0;i--){
//    	        Genre g = genres.get(i);
//    	        if(!p.getProgramtype().equals(g.getProgramtype())){
//    	            genres.remove(i);
//    	        }
//    	    }
//	    }
//	    model.addAttribute("genres", genres);
//	    model.addAttribute("areas", areas);
//		model.addAttribute("program", p);
//		model.addAttribute("action", "update");
//		model.addAttribute("sp",URLEncoder.encode(sp,"UTF-8")); 
//		return "program/programForm";
//	}
//
//	@RequestMapping(value = "update", method = RequestMethod.POST)
//	public ModelAndView update(@Valid @ModelAttribute("preloadProgram") Program program,String sp) throws UnsupportedEncodingException {
//	    program.setSearchname(CnToSpell.getSimpleSpell(program.getProgramname()));
//		programService.save(program);
//
//		Map<String, String> modelMap = buildModelMap(sp);
//		modelMap.put("message", "修改成功");
//		return new ModelAndView("redirect:/program/list").addAllObjects(modelMap);
//		//return "redirect:/program/list"+URLDecoder.decode(sp, "utf-8");
//	}


	@RequestMapping(value = "delete/{id}")
	public ModelAndView delete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes,String page,String sortType) throws UnsupportedEncodingException {
		//在所有导航中删除节目 自动的
	    //删除所有相关图片
	    //删除所有媒体数据 
	    //删除演员关系   自动的
	    //删除类型关系   自动的
	    programService.delete(id);
		
		redirectAttributes.addFlashAttribute("message", "删除成功");
        redirectAttributes.addFlashAttribute("message", "保存成功");
        Map<String,String> modelMap = new HashMap<String,String>();
        modelMap.put("page", page);
        modelMap.put("sortType", sortType);
        return new ModelAndView("redirect:/program/list").addAllObjects(modelMap);
	}

	/**
	 * 使用@ModelAttribute, 实现Struts2 Preparable二次部分绑定的效果,先根据form的id从数据库查出Program对象,再把Form提交的内容绑定到该对象上。
	 * 因为仅update()方法的form中有id属性，因此本方法在该方法中执行.
	 */
	@ModelAttribute("preloadProgram")
	public Program getProgram(@RequestParam(value = "id", required = false) Long id) {
		if (id != null) {
			return programService.findOne(id);
		}
		return null;
	}

	
    @RequestMapping(value = "detail/{id}")
    public String detail(@PathVariable("id") Long id,  Model model) {
        Program program =programService.findOne(id);
        model.addAttribute("program", program);
        //为了审阅方便 媒体内容状态必须为成功才能上线
        if(program!=null&&program.getMediacontentlist()!=null){
            
            for(Mediacontent c:program.getMediacontentlist()){
                if(!"0".equals(c.getStatus())){
                    model.addAttribute("mediastatus", "-1");
                    break;
                }
            }
        }
        model.addAttribute("program", program);
        return "program/detail";
    }
    @RequestMapping(value = "updatestatus", method = RequestMethod.POST)
    public String updatestatus(@Valid @ModelAttribute("preloadProgram") Program program, RedirectAttributes redirectAttributes) {
        programService.save(program);
        redirectAttributes.addFlashAttribute("program", program);
        redirectAttributes.addFlashAttribute("message", "操作成功");
        return "redirect:/program/detail/"+program.getId();
    }

    @RequestMapping(value = "addcategorys", method = RequestMethod.POST)
    public void addcategorys(long programid, Long [] categorydis) {
        Program program =  programService.findOne(programid);
        List<Category> list = Lists.newArrayList();
        if(categorydis!=null){
            for(Long id:categorydis){  
                list.add(new Category(id));
            }
        }
        program.setCategorylist(list);
        programService.save(program);
    }
    
    //一步新增到位
    @RequestMapping(value = "add", method = RequestMethod.GET)
    public String addForm(Model model) throws UnsupportedEncodingException {
        
        //基础属性新增
        model.addAttribute("program", new Program());
        model.addAttribute("genres", genreService.getByProgramtype("10"));
        model.addAttribute("areas", areaService.getAll());
        model.addAttribute("action", "add");
        //图片新增 
        model.addAttribute("picturetypes", picturetypeService.getByPicturetypecode("10"));
        //导航新增
        model.addAttribute("categorys", categoryService.getByCategorytype("10"));
        //媒体内容新增
        return "program/programFullForm";
    }
    
    @RequestMapping(value = "add", method = RequestMethod.POST)
    public String add(@Valid Program newProgram,String categoryids,
            MultipartFile pictureFile1,MultipartFile  pictureFile2,
            RedirectAttributes redirectAttributes) throws UnsupportedEncodingException  {
        //新增节目
        newProgram.setSearchname(CnToSpell.getSimpleSpell(newProgram.getProgramname()));
        newProgram.setStatus("0");
        programService.create(newProgram, "cpobjectcode", "progam0000000000");
        //redirectAttributes.addFlashAttribute("message", "");
        //新增节目的演职人员

        //图片新增
        List<Picturetype>  ptypelist =picturetypeService.getByPicturetypecode(newProgram.getProgramtype());
        if(ptypelist==null||ptypelist.size()==0){
            throw new RuntimeException("图片类型未设置");
        }
        if(ptypelist.size()!=2){
            throw new RuntimeException("图片类型数量不正确");
        }
        MultipartFile [] pictureFiles={pictureFile1,pictureFile2};
        for(int i=0;i<2;i++){
            if(!pictureFiles[i].isEmpty()){
                String relativePath ="program/";
                int  width = ptypelist.get(i).getMaxwidth(); // 得到源图宽
                int  height = ptypelist.get(i).getMaxheight(); // 得到源图长
                File file = FileUploadUtil.saveFile(pictureFiles[i], relativePath,true,width,height);
                if(file==null){
                    throw new RuntimeException("文件上传保存失败！");
                }
                // 将图片url等信息写入数据库
                Picture p = new Picture();
                p.setPicturetype(new Picturetype(ptypelist.get(i).getId()));
                p.setProgram(newProgram);
                p.setPictureurl(relativePath+file.getName());
                pictureService.save(p);
            }
        }
        // 图片新增 end

        //导航新增
        categoryprogramService.save(newProgram.getId(), categoryids);
        //媒体内容新增
        redirectAttributes.addFlashAttribute("message", "保存成功");
        return "redirect:/program/list";
    }

    
    //一步修改到位
    @RequestMapping(value = "edit/{id}", method = RequestMethod.GET)
    public String editForm(@PathVariable("id") Long id,Model model) throws UnsupportedEncodingException{

        //基础属性新增
        Program program =programService.findOne(id);
        model.addAttribute("program", program);
        String type=program.getProgramtype();
        model.addAttribute("genres", genreService.getByProgramtype(type));
        model.addAttribute("areas", areaService.getAll());
        model.addAttribute("action", "edit");
        //图片新增 
        model.addAttribute("picturetypes", picturetypeService.getByPicturetypecode(type));
        //导航新增
        model.addAttribute("categorys", categoryService.getByCategorytype(type));
        //媒体内容新增

        return "program/programFullForm";
    }
    
    @RequestMapping(value = "edit", method = RequestMethod.POST)
    public ModelAndView edit(@ModelAttribute("preloadProgram") Program program,String categoryids,String page,String sortType,
            MultipartFile pictureFile1,MultipartFile pictureFile2,
            RedirectAttributes redirectAttributes) throws UnsupportedEncodingException  {
        //修改基础信息
        program.setSearchname(CnToSpell.getSimpleSpell(program.getProgramname()));
        programService.save(program);

        // 图片新增
        List<Picturetype>  ptypelist =picturetypeService.getByPicturetypecode(program.getProgramtype());
        if(ptypelist==null||ptypelist.size()==0){
            throw new RuntimeException("图片类型未设置");
        }
        if(ptypelist.size()!=2){
            throw new RuntimeException("图片类型数量不正确");
        }
        MultipartFile [] pictureFiles={pictureFile1,pictureFile2};
        for(int i=0;i<pictureFiles.length;i++){
            if(!pictureFiles[i].isEmpty()){
                String relativePath ="program/";
                // 压缩图片
                int  width = ptypelist.get(i).getMaxwidth(); // 得到源图宽
                int  height = ptypelist.get(i).getMaxheight(); // 得到源图长
                File file = FileUploadUtil.saveFile(pictureFiles[i], relativePath,true,width,height);
                if(file==null){
                    throw new RuntimeException("文件上传保存失败！");
                }
                //compressImage(file, width,height);
                // 将图片url等信息写入数据库
                Picture p = pictureService.getByProgramIdAndPicturetypeId(program.getId(),ptypelist.get(i).getId());
                if(p==null){
                    p = new Picture();
                    p.setPicturetype(new Picturetype(ptypelist.get(i).getId()));
                    p.setProgram(program);
                }else{
                    FileUploadUtil.delete(p.getPictureurl());
                }
                p.setPictureurl(relativePath+file.getName());
                pictureService.save(p);
            }
        }
        // 图片新增 end
        //导航新增
        categoryprogramService.save(program.getId(), categoryids);

        //媒体内容新增
        redirectAttributes.addFlashAttribute("message", "保存成功");
        Map<String,String> modelMap = new HashMap<String,String>();
        modelMap.put("page", page);
        modelMap.put("sortType", sortType);
        return new ModelAndView("redirect:/program/list").addAllObjects(modelMap);
    }

    
    @RequestMapping(value = "ajaxgenre", method = RequestMethod.GET)
    public String ajaxgenre(Model model,String programtype,String genrenames)  {
        model.addAttribute("genrenames",genrenames);
        model.addAttribute("genres", genreService.getByProgramtype(programtype));
        return "program/genres";
    }
    
    @RequestMapping(value = "/ajaxcategory")
    public String ajaxcategory(Model model, String categorytype,Long programid) {
        List<Category> categorys =null;
        if("on".equals(SystemConstant.getValue("vod_second_category"))){
            categorys = categoryService.getByCategorytype(categorytype);
        }else{
            categorys = categoryService.getByCategorytypeAndParentid(categorytype,0L);
        }
        model.addAttribute("categorys", categorys);
        if(programid!=null){
            model.addAttribute("program", programService.findOne(programid));
        }else{
            Program p = new Program();
            p.setCategorylist(new ArrayList<Category>());
            model.addAttribute("program", new Program());
        }
        return "program/categorymultiselect";
    }
    
    //一步新增到位
    @RequestMapping(value = "batchadd", method = RequestMethod.GET)
    public String batchadd(Model model) {
        
        //基础属性新增
        model.addAttribute("program", new Program());
        model.addAttribute("genres", genreService.getByProgramtype("10"));
        model.addAttribute("areas", areaService.getAll());
        model.addAttribute("action", "add");
        //图片新增 
        model.addAttribute("picturetypes", picturetypeService.getByPicturetypecode("10"));
        //导航新增
        model.addAttribute("categorys", categoryService.getByCategorytype("10"));
        //媒体内容新增

        return "program/programbatchForm";
    }
    @RequestMapping(value = "batchadd", method = RequestMethod.POST)
    public String batchadd(String categoryids,String sourcefilename,String urltype,
            RedirectAttributes redirectAttributes)  {
        programService.batchadd(categoryids, sourcefilename, urltype);
        redirectAttributes.addFlashAttribute("message", "批量新增节目成功");
        return "redirect:/program/list";
    }
    
    
    @RequestMapping(value="export")
    public ModelAndView export() throws IOException {
    	
      Map<String,Object> map = programService.exportProgram();
	  ZipView ve = new ZipView();
	  return new ModelAndView(ve,map);
    }
    
    @RequestMapping(value="importprograms")
    public String importprograms(RedirectAttributes redirectAttributes,MultipartFile importFile) throws IOException {
    	 //解压文件
    	 String xlsPath = ZipUtils.unzip(importFile.getInputStream(),  SystemConstant.getValue("fileupload")+"/program/");
    	 programService.importprograms(xlsPath);
    	 redirectAttributes.addFlashAttribute("message", "批量新增节目成功");
    	 return "redirect:/program/list";
    }
}
