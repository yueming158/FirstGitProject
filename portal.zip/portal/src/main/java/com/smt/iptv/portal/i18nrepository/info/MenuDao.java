package com.smt.iptv.portal.i18nrepository.info;

import java.util.List;

import org.springframework.data.jpa.repository.Query;

import com.smt.iptv.portal.i18nentity.info.Menu;
import com.smt.iptv.portal.repository.BaseDao;

public interface MenuDao extends BaseDao<Menu> {
    public Menu getByCode(String code);
    @Query("select m from Menu m where m.infotemplate.field is not null")
    public List<Menu> getInfoTemplateMenu();
    public List<Menu> getByInfotemplateCode(String templatecode);
    public List<Menu> getByParentid(Long id);
    public List<Menu> getByInfotemplateId(Long id);
}
