package com.smt.iptv.portal.web.aaa;

import java.util.Map;

import javax.servlet.ServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Maps;
import com.smt.iptv.portal.entity.aaa.Attr;
import com.smt.iptv.portal.service.aaa.AttrService;

/**
 * @author xjw
 */
@Controller
@RequestMapping(value = "/attr")
public class AttrController {

	private static final int PAGE_SIZE = 50;

	private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
	static {
		sortTypes.put("auto", "自动");
	}

	@Autowired
	private AttrService attrService;

	@RequestMapping(value = "/list")
	public String list(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
			@RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
		Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");

		Page<Attr> attrs = attrService.getPageDesc( searchParams, pageNumber, PAGE_SIZE, sortType);

		model.addAttribute("attrs", attrs);
		model.addAttribute("sortType", sortType);
		model.addAttribute("sortTypes", sortTypes);
		// 将搜索条件编码成字符串，用于排序，分页的URL
		model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
		return "attr/attrList";
	}

	@RequestMapping(value = "create", method = RequestMethod.GET)
	public String createForm(Model model) {
		model.addAttribute("attr", new Attr());
		model.addAttribute("action", "create");
		return "attr/attrForm";
	}

	@RequestMapping(value = "create", method = RequestMethod.POST)
	public String create(Attr newAttr, RedirectAttributes redirectAttributes) {

		attrService.create(newAttr, "attrkey", "key000");
		redirectAttributes.addFlashAttribute("message", "新增成功");
		return "redirect:/attr/list";
	}

	@RequestMapping(value = "update/{id}", method = RequestMethod.GET)
	public String updateForm(@PathVariable("id") Long id, Model model) {
		model.addAttribute("attr", attrService.findOne(id));
		model.addAttribute("action", "update");
		return "attr/attrForm";
	}

	@RequestMapping(value = "update", method = RequestMethod.POST)
	public String update(@ModelAttribute("preloadAttr") Attr attr, RedirectAttributes redirectAttributes) {
		attrService.save(attr);
		redirectAttributes.addFlashAttribute("message", "保存成功");
		return "redirect:/attr/list";
	}

	@RequestMapping(value = "delete/{id}")
	public String delete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
		attrService.delete(id);
		redirectAttributes.addFlashAttribute("message", "删除成功");
		return "redirect:/attr/list";
	}

	/**
	 * 使用@ModelAttribute, 实现Struts2 Preparable二次部分绑定的效果,先根据form的id从数据库查出Attr对象,再把Form提交的内容绑定到该对象上。
	 * 因为仅update()方法的form中有id属性，因此本方法在该方法中执行.
	 */
	@ModelAttribute("preloadAttr")
	public Attr getAttr(@RequestParam(value = "id", required = false) Long id) {
		if (id != null) {
			return attrService.findOne(id);
		}
		return null;
	}
}
