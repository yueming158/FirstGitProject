package com.smt.iptv.portal.i18nrepository.program;

import com.smt.iptv.portal.i18nentity.program.Program;
import com.smt.iptv.portal.repository.BaseDao;

public interface ProgramDao extends BaseDao<Program>   {

}
