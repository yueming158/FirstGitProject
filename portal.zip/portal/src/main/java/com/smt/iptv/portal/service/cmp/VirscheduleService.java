package com.smt.iptv.portal.service.cmp;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.smt.iptv.portal.entity.Channel;
import com.smt.iptv.portal.entity.Virschedule;
import com.smt.iptv.portal.repository.video.VirscheduleDao;
import com.smt.iptv.portal.service.send.ScheduleLoaderService;
import com.smt.iptv.portal.xml.schedule.Schedule;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class VirscheduleService extends BaseService<VirscheduleDao, Virschedule>{
    @Autowired
    private ScheduleLoaderService scheduleLoaderService;
    @Autowired
    private ChannelService channelService;
    @Override
    @Transactional(readOnly = false)
    public void save(Iterable<Virschedule> entities) {
        if(entities!=null&&entities.iterator().hasNext()){
            dao.save(entities);
            Virschedule virschedule =dao.findOne(entities.iterator().next().getId());
            sendxml(virschedule);
        }
    }

    @Override
    @Transactional(readOnly = false)
    public void delete(Long id) {
        sendxml(dao.findOne(id));;
        dao.delete(id);
    }
    
    private void sendxml(Virschedule virschedule) {

        if(virschedule!=null){
            List<Virschedule>  list = null;
            if(virschedule.getChannel().getCpobjectcode()==null&&virschedule.getChannel().getId()!=null){
                Channel c =channelService.findOne(virschedule.getChannel().getId());
                if(c!=null){
                    
                    list=dao.getByChannelCpobjectcode(c.getCpobjectcode());
                }
            }else{
                list = dao.getByChannelCpobjectcode(virschedule.getChannel().getCpobjectcode());
            }
            List<Schedule> scheduleList =Lists.newArrayList();
            for(Virschedule v:list){
                Schedule schedule = new Schedule();
                schedule.setChanncode(v.getChannel().getCpobjectcode());
                schedule.setContcode(v.getCpobjectcode());
                schedule.setDuration(v.getDelaytime()==null?0:v.getDelaytime());
                schedule.setId(v.getId()+"");
                schedule.setSeq(v.getSeq());
                schedule.setStarttime("08:00");
                schedule.setViewname(v.getContentname());
                scheduleList.add(schedule);
            }
            scheduleLoaderService.update(scheduleList);
        }
    }
}
