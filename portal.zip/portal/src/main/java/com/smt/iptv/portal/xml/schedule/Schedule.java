package com.smt.iptv.portal.xml.schedule;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlValue;

@XmlRootElement
public class Schedule {
    
    private String id;
    
    private String channcode;
    
    private String contcode;
    
    private int duration=0;
   
    private int seq=0;
    
    private String viewname;
   
    private String starttime;
    
    @XmlElement(name="Id",defaultValue="0")
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    @XmlElement(name="ChannCode")
    public String getChanncode() {
        return channcode;
    }
    public void setChanncode(String channcode) {
        this.channcode = channcode;
    }
    @XmlElement(name="ContCode")
    public String getContcode() {
        return contcode;
    }
    public void setContcode(String contcode) {
        this.contcode = contcode;
    }
    @XmlElement(name="Duration")
    public int getDuration() {
        return duration;
    }
    public void setDuration(int duration) {
        this.duration = duration;
    }
    @XmlElement(name="Seq")
    public int getSeq() {
        return seq;
    }
    public void setSeq(int seq) {
        this.seq = seq;
    }
    @XmlElement(name="Viewname")
    public String getViewname() {
        return viewname;
    }
    public void setViewname(String viewname) {
        this.viewname = viewname;
    }
    @XmlElement(name="StartTime")
    public String getStarttime() {
        return starttime;
    }
    public void setStarttime(String starttime) {
        this.starttime = starttime;
    }
}
