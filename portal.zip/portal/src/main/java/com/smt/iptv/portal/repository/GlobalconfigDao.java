package com.smt.iptv.portal.repository;

import com.smt.iptv.portal.entity.Globalconfig;

public interface GlobalconfigDao extends BaseDao<Globalconfig> {
    Globalconfig findByName(String name);
}
