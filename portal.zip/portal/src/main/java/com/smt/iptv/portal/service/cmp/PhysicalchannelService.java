package com.smt.iptv.portal.service.cmp;

import java.text.DecimalFormat;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.core.ServiceException;
import com.smt.iptv.portal.entity.Physicalchannel;
import com.smt.iptv.portal.repository.video.PhysicalchannelDao;
import com.smt.iptv.portal.service.send.PhyChannelLoaderService;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class PhysicalchannelService extends BaseService<PhysicalchannelDao, Physicalchannel> {

    @Autowired
    private PhyChannelLoaderService phyChannelLoaderService;

    /**
     * 
     * @param entity 要新增的new状态对象 无ID
     * @param Field   新增时需要默认添加编码的字段名
     * @param dcmFmtStr    默认编码的DecimalFormat格式，根据ID得到编码值。
     */
    @Transactional(readOnly = false)
    public void create(Physicalchannel entity,String propertyName,String dcmFmtStr,String channelcode) {
        dao.save(entity);
        int index=dcmFmtStr.indexOf("0");
        dcmFmtStr =dcmFmtStr.substring(0, index)+LocaleContextHolder.getLocale().getLanguage()+dcmFmtStr.substring(index);
        DecimalFormat dcmFmt = new DecimalFormat(dcmFmtStr);
        String code =dcmFmt.format(entity.getId());
        String methodEnd = propertyName.substring(0,1).toUpperCase() + propertyName.substring(1);
            try {
                entity.getClass().getMethod("set"+methodEnd, String.class).invoke(entity, code);
            } catch (Exception e) {
                throw new ServiceException(e);
            } 
        dao.save(entity);
        phyChannelLoaderService.regist(entity, channelcode);
    }
    
    @Transactional(readOnly = false)
    public Physicalchannel save(Physicalchannel entity) {
        if(entity.getId()==null||entity.getId()==0L){ 
            //dao.save(entity);
           // phyChannelLoaderService.regist(entity, channelcode);
        }else{
            dao.save(entity);
            phyChannelLoaderService.update(entity, dao.getChannelCode(entity.getId()));
        }
        return entity;
    }

    @Transactional(readOnly = false)
    public void delete(Long id) {
        phyChannelLoaderService.delete(dao.findOne(id));
        dao.delete(id);
    }
    @Transactional(readOnly = false)
    public void delete(Physicalchannel entity) {
        phyChannelLoaderService.delete(dao.findOne(entity.getId()));
        dao.delete(entity);
    }
}
