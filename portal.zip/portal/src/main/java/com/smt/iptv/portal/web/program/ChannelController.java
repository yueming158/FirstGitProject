package com.smt.iptv.portal.web.program;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletRequest;
import javax.validation.Valid;

import org.apache.shiro.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Maps;
import com.smt.iptv.portal.entity.Channel;
import com.smt.iptv.portal.entity.Physicalchannel;
import com.smt.iptv.portal.model.SystemConstant;
import com.smt.iptv.portal.service.account.ShiroDbRealm.ShiroUser;
import com.smt.iptv.portal.service.cmp.ChannelService;
import com.smt.iptv.portal.service.cmp.CustomizedchannelnoService;
import com.smt.iptv.portal.service.cmp.PhysicalchannelService;

/**
 * Channel管理的Controller, 使用Restful风格的Urls:
 * 
 * @author xjw
 */
@Controller
@RequestMapping(value = "/channel")
public class ChannelController {

	private static final int PAGE_SIZE = 50;

	private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
	static {
		sortTypes.put("auto", "自动");
		sortTypes.put("channelname", "名称");
		sortTypes.put("channelnumber", "频道号");
	}

	@Autowired
	private ChannelService channelService;
    @Autowired
    private PhysicalchannelService physicalchannelService;
    
	@RequestMapping(value = "/list")
	public String list(@RequestParam(value = "sortType", defaultValue = "channelnumber") String sortType,
			@RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) throws UnsupportedEncodingException {
		Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");

		Page<Channel> channels = channelService.getPage( searchParams, pageNumber, PAGE_SIZE, sortType);

		model.addAttribute("channels", channels);
		model.addAttribute("sortType", sortType);
		model.addAttribute("sortTypes", sortTypes);
		// 将搜索条件编码成字符串，用于排序，分页的URL
		String sps=Servlets.encodeParameterStringWithPrefix(searchParams, "search_");
		model.addAttribute("searchParams", sps);
		model.addAttribute("sp", URLEncoder.encode("page="+(channels.getNumber()+1)+"&sortType="+sortType+"&"+sps, "UTF-8"));
		return "channel/channelList";
	}

	@RequestMapping(value = "create", method = RequestMethod.GET)
	public String createForm(Model model,String sp) throws UnsupportedEncodingException {
		model.addAttribute("channel", new Channel());
		model.addAttribute("action", "create");
		model.addAttribute("sp",URLEncoder.encode(sp,"UTF-8"));
		return "channel/channelForm";
	}

	@RequestMapping(value = "create", method = RequestMethod.POST)
	public ModelAndView create(Channel newChannel, Physicalchannel physicalchannel,
	        RedirectAttributes redirectAttributes,String sp) throws UnsupportedEncodingException {
		channelService.create(newChannel, "cpobjectcode", "TV00000000000000000000@HHZT");
        physicalchannelService.create(physicalchannel, "cpobjectcode", "PHY0000000000",newChannel.getCpobjectcode());
        physicalchannel.setUnicasturl(SystemConstant.getURLValue("CDN_server_address")+newChannel.getCpobjectcode()+";LIVE");
        //如果是新增的时候增加物理频道和频道的关联关系。
        newChannel.setPhysicalchannel(physicalchannel);
        channelService.save(newChannel);
        redirectAttributes.addFlashAttribute("message", "新增成功");
        Map<String, String> modelMap = buildModelMap(sp);
        modelMap.put("message", "新增成功");
        return new ModelAndView("redirect:/channel/list").addAllObjects(modelMap);
	}

	@RequestMapping(value = "update/{id}", method = RequestMethod.GET)
	public String updateForm(@PathVariable("id") Long id, Model model,String sp) throws UnsupportedEncodingException {
	    Channel channel = channelService.findOne(id);
		model.addAttribute("channel", channel );
		model.addAttribute("physicalchannel", channel.getPhysicalchannel());

		model.addAttribute("action", "update");
		model.addAttribute("sp",URLEncoder.encode(sp,"UTF-8")); 
		return "channel/channelForm";
	}

	@RequestMapping(value = "update", method = RequestMethod.POST)
	public ModelAndView update(@ModelAttribute("preloadChannel") Channel channel, 
	        @ModelAttribute("preloadPhysicalchannel")Physicalchannel physicalchannel,Long physicalchannelid,
	        RedirectAttributes redirectAttributes,String sp) throws UnsupportedEncodingException {
	    physicalchannel.setId(physicalchannelid);
	    channelService.save(channel);
	    physicalchannelService.save(physicalchannel);
	    redirectAttributes.addFlashAttribute("message", "保存成功");
        Map<String, String> modelMap = buildModelMap(sp);
        modelMap.put("message", "保存成功");
        return new ModelAndView("redirect:/channel/list").addAllObjects(modelMap);
	}

	@RequestMapping(value = "delete/{id}")
	public ModelAndView delete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes,String sp) throws UnsupportedEncodingException {
	    channelService.deleteAllRel(id);
		redirectAttributes.addFlashAttribute("message", "删除成功");
        Map<String, String> modelMap = buildModelMap(sp);
        modelMap.put("message", "删除成功");
        return new ModelAndView("redirect:/channel/list").addAllObjects(modelMap);
	}

	/**
	 * 使用@ModelAttribute, 实现Struts2 Preparable二次部分绑定的效果,先根据form的id从数据库查出Channel对象,再把Form提交的内容绑定到该对象上。
	 * 因为仅update()方法的form中有id属性，因此本方法在该方法中执行.
	 */
	@ModelAttribute("preloadChannel")
	public Channel getChannel(@RequestParam(value = "id", required = false) Long id) {
		if (id != null) {
			return channelService.findOne(id);
		}
		return null;
	}
    @ModelAttribute("preloadPhysicalchannel")
    public Physicalchannel getPhysicalchannel(@RequestParam(value = "physicalchannelid", required = false) Long physicalchannelid) {
        if (physicalchannelid != null) {
            return physicalchannelService.findOne(physicalchannelid);
        }
        return new Physicalchannel();
    }

    private Map<String, String> buildModelMap(String sp) throws UnsupportedEncodingException {
        Map<String,String> modelMap = new HashMap<String,String>();
        sp= URLDecoder.decode(sp, "utf-8");
        for(String obj:sp.split("&")){
            String [] param =obj.split("=");
            if(param.length==2){
                modelMap.put(param[0], param[1]);
            }
        }
        return modelMap;
    }
}
