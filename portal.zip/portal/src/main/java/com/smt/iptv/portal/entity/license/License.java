package com.smt.iptv.portal.entity.license;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.format.annotation.DateTimeFormat;

import com.smt.iptv.portal.core.CryptCore;
import com.smt.iptv.portal.core.SystemResource;

public class License {
    private static Logger logger = LoggerFactory.getLogger(License.class);
    public License(String licensecode) {
        try {
            String licensestr=SystemResource.getString("licensestr");
            String licensefile=CryptCore.decryptByDES(licensestr);
            if(licensecode.equals(licensefile.split(",")[0])){
                this.licensenumber = Integer.valueOf(licensefile.split(",")[1]);
            }
        } catch (Exception e) {
            logger.error("license文件配置错误");
        }
    }
    private String licensecode;
    private Integer licensenumber = 0;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date expires;

    public String getLicensecode() {
        return licensecode;
    }

    public void setLicensecode(String licensecode) {
        this.licensecode = licensecode;
    }

    public Integer getLicensenumber() {
        return licensenumber;
    }

    public void setLicensenumber(Integer licensenumber) {
        this.licensenumber = licensenumber;
    }

    public Date getExpires() {
        return expires;
    }

    public void setExpires(Date expires) {
        this.expires = expires;
    }

}
