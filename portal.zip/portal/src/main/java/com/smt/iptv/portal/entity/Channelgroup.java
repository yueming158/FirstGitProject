package com.smt.iptv.portal.entity;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.portal.core.IdEntity;
@Entity
@Table(name = "channelgroup")
public class Channelgroup extends IdEntity {
    
    public Channelgroup() {
    }

    public Channelgroup(Long id) {
        this.id = id;
    }
    
	private String channelgroupname;
	private String channelgroupcode;

    
    public String getChannelgroupname() {
        return channelgroupname;
    }

    public void setChannelgroupname(String channelgroupname) {
        this.channelgroupname = channelgroupname;
    }


    public String getChannelgroupcode() {
        return channelgroupcode;
    }

    public void setChannelgroupcode(String channelgroupcode) {
        this.channelgroupcode = channelgroupcode;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}