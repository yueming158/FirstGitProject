package com.smt.iptv.portal.i18nentity.program;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.portal.core.IdEntity;
@Entity
@Table(name = "genre")
public class Genre extends IdEntity {
    
    public Genre() {
    }

    public Genre(Long id) {
        this.id = id;
    }
    
	private String genrename;
	private String cpobjectcode;
	private String programtype;
	private String sequence;

    public String getGenrename() {
        return genrename;
    }

    public void setGenrename(String genrename) {
        this.genrename = genrename;
    }

    public String getCpobjectcode() {
        return cpobjectcode;
    }

    public void setCpobjectcode(String cpobjectcode) {
        this.cpobjectcode = cpobjectcode;
    }

    public String getProgramtype() {
        return programtype;
    }

    public void setProgramtype(String programtype) {
        this.programtype = programtype;
    }

    public String getSequence() {
        return sequence;
    }

    public void setSequence(String sequence) {
        this.sequence = sequence;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}