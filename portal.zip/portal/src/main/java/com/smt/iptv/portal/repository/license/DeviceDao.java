package com.smt.iptv.portal.repository.license;

import com.smt.iptv.portal.entity.license.Device;
import com.smt.iptv.portal.repository.BaseDao;


public interface DeviceDao extends BaseDao<Device>{

    Device findByHardwareinfo(String hardwareinfo);
}
