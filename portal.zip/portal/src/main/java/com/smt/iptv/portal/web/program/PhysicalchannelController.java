package com.smt.iptv.portal.web.program;

import java.util.Map;

import javax.servlet.ServletRequest;
import javax.validation.Valid;

import org.apache.shiro.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Maps;
import com.smt.iptv.portal.entity.Channel;
import com.smt.iptv.portal.entity.Physicalchannel;
import com.smt.iptv.portal.model.SystemConstant;
import com.smt.iptv.portal.service.account.ShiroDbRealm.ShiroUser;
import com.smt.iptv.portal.service.cmp.ChannelService;
import com.smt.iptv.portal.service.cmp.PhysicalchannelService;

/**
 * @author xjw
 */
@Controller
@RequestMapping(value = "/physicalchannel")
public class PhysicalchannelController {

	private static final int PAGE_SIZE = 50;

	private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
	static {
		sortTypes.put("auto", "自动");
		sortTypes.put("cpobjectcode", "编码");
	}

	@Autowired
	private PhysicalchannelService physicalchannelService;
    @Autowired
    private ChannelService channelService;
	@RequestMapping(value = "/list")
	public String list(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
			@RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
		Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");

		Page<Physicalchannel> physicalchannels = physicalchannelService.getPage( searchParams, pageNumber, PAGE_SIZE, sortType);

		model.addAttribute("physicalchannels", physicalchannels);
		model.addAttribute("sortType", sortType);
		model.addAttribute("sortTypes", sortTypes);
		// 将搜索条件编码成字符串，用于排序，分页的URL
		model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
		return "physicalchannel/physicalchannelList";
	}

	@RequestMapping(value = "create", method = RequestMethod.GET)
	public String createForm(Model model) {
		model.addAttribute("physicalchannel", new Physicalchannel());
		model.addAttribute("action", "create");
		return "physicalchannel/physicalchannelForm";
	}

	@RequestMapping(value = "create", method = RequestMethod.POST)
	public String create(@Valid Physicalchannel newPhysicalchannel, RedirectAttributes redirectAttributes) {
	    
		//physicalchannelService.save(newPhysicalchannel);1
		//redirectAttributes.addFlashAttribute("message", "新增成功");
		return "redirect:/physicalchannel/list";
	}

	@RequestMapping(value = "update/{id}", method = RequestMethod.GET)
	public String updateForm(@PathVariable("id") Long id, Model model) {
		model.addAttribute("physicalchannel", physicalchannelService.findOne(id));
		model.addAttribute("action", "update");
		return "physicalchannel/physicalchannelForm";
	}

	@RequestMapping(value = "update", method = RequestMethod.POST)
	public String update(@ModelAttribute("preloadPhysicalchannel") Physicalchannel physicalchannel, RedirectAttributes redirectAttributes) {
		physicalchannelService.save(physicalchannel);
		redirectAttributes.addFlashAttribute("message", "保存成功");
		return "redirect:/physicalchannel/list";
	}

	@RequestMapping(value = "delete/{id}")
	public String delete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
		physicalchannelService.delete(id);
		redirectAttributes.addFlashAttribute("message", "删除成功");
		return "redirect:/physicalchannel/list";
	}

	/**
	 * 使用@ModelAttribute, 实现Struts2 Preparable二次部分绑定的效果,先根据form的id从数据库查出Physicalchannel对象,再把Form提交的内容绑定到该对象上。
	 * 因为仅update()方法的form中有id属性，因此本方法在该方法中执行.
	 */
	@ModelAttribute("preloadPhysicalchannel")
	public Physicalchannel getPhysicalchannel(@RequestParam(value = "id", required = false) Long id) {
		if (id != null) {
			return physicalchannelService.findOne(id);
		}
		return new Physicalchannel();
	}
	
    @RequestMapping(value = "bychannel/{channelid}", method = RequestMethod.GET)
    public String bychannel(Model model,@PathVariable("channelid") Long channelid) {
        Channel channel =channelService.findOne(channelid);
        Physicalchannel phyChannel = channel.getPhysicalchannel();
        
//        if(phyChannel==null){
//            phyChannel =new Physicalchannel();
//            physicalchannelService.create(phyChannel, "cpobjectcode", "PHY0000000000",channel.getCpobjectcode());
//            //如果是新增的时候增加物理频道和频道的关联关系。
//            phyChannel.setUnicasturl(SystemConstant.getURLValue("CDN_server_address")+channel.getCpobjectcode());
//            channel.setPhysicalchannel(phyChannel);
//            
//            channelService.save(channel);
//        }
        if(phyChannel==null){
            phyChannel= new Physicalchannel();
            phyChannel.setUnicasturl(SystemConstant.getURLValue("CDN_server_address")+channel.getCpobjectcode());
        }
        model.addAttribute("physicalchannel", phyChannel);
        //model.addAttribute("channel",channel);
        model.addAttribute("channelid",channelid);
        model.addAttribute("action", "bychannel");
        return "physicalchannel/phychnPage";
    }
    @RequestMapping(value = "bychannel/{channelid}", method = RequestMethod.POST)
    public String bychannelSave(@PathVariable("channelid") Long channelid,
            @Valid @ModelAttribute("preloadPhysicalchannel") Physicalchannel physicalchannel,Model model) {
        Long phyId=physicalchannel.getId();
        if(phyId==null){
            Channel channel=channelService.findOne(channelid);
            physicalchannelService.create(physicalchannel, "cpobjectcode", "PHY0000000000",channel.getCpobjectcode());
            //physicalchannel.setUnicasturl(SystemConstant.getURLValue("CDN_server_address")+channel.getCpobjectcode());
            //如果是新增的时候增加物理频道和频道的关联关系。
            channel.setPhysicalchannel(physicalchannel);
            channelService.save(channel);
        }else{
            physicalchannelService.save(physicalchannel);
        }
        model.addAttribute("physicalchannel", physicalchannel);
        model.addAttribute("channelid",channelid);
        model.addAttribute("action", "bychannel");
        model.addAttribute("message", "保存成功");
        return "physicalchannel/phychnPage";
    }
	
}
