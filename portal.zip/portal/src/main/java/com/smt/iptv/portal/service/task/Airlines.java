package com.smt.iptv.portal.service.task;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

import com.google.common.collect.Lists;
import com.smt.iptv.portal.entity.Airlinetime;

@XmlRootElement(name="DataSet")
public class Airlines {
    private List<Airlinetime> airlines = Lists.newArrayList();
    @XmlElementWrapper(name="Airlines")
    @XmlElement(name = "AirlinesTime")
    public List<Airlinetime> getAirlines() {
        return airlines;
    }

    public void setAirlines(List<Airlinetime> airlines) {
        this.airlines = airlines;
    }

}
