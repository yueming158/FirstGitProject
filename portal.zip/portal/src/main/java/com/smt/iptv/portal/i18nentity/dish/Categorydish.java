package com.smt.iptv.portal.i18nentity.dish;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.smt.iptv.portal.core.IdEntity;
import com.smt.iptv.portal.i18nentity.Category;
@Entity
@Table(name = "categorydish")
public class Categorydish extends IdEntity {
    
    public Categorydish() {
    }

    public Categorydish(Long id) {
        this.id = id;
    }
    
	private Category category;
	private Dish dish;
	private Integer sequence;
	@ManyToOne
	@JoinColumn(name="categoryid")
    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }
    @ManyToOne
    @JoinColumn(name="dishid")
    public Dish getDish() {
        return dish;
    }

    public void setDish(Dish dish) {
        this.dish = dish;
    }

    public Integer getSequence() {
        return sequence;
    }

    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

}