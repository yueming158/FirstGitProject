package com.smt.iptv.portal.web.push;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springside.modules.mapper.JsonMapper;

import com.smt.iptv.portal.push.PushMessage;
import com.smt.iptv.portal.push.PushServer;

/**
 * 
 * @author xjw
 */
@Controller
@RequestMapping(value = "/push")
public class PushController {
    /**
     * 
     * @param username
     * @param type    msg action roomstatus 
     * @param content
     * @return
     */
    @RequestMapping(value = "/{type}",produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public String roomstatus( String username,@PathVariable("type")String type,String content) {
        PushMessage pm =new PushMessage(type, content);
        if("all".equals(username)){
            PushServer.sendMsgToAll(pm);
            return "sucess send all";
        }else if(username.matches("\\d{5}")){
            PushServer.sendMsg(username, pm);
            return "sucess send to "+username;
        }
        return "failure";
    }
}
