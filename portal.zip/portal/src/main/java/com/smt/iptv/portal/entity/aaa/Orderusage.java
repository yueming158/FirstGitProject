package com.smt.iptv.portal.entity.aaa;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.portal.core.IdEntity;
@Entity
@Table(name = "aaa_orderusage")
public class Orderusage extends IdEntity {
    public Orderusage() {
    }

    public Orderusage(Long id) {
        this.id = id;
    }
    private Long accountid;// 购买账号
    private Long productofferid; // 购买商品
    private String paystatus; // 支付状态
    private Date orderstarttime;// 生效时间
    private Date orderendtime;// 失效时间
    private Date ordercanceltime;// 中断时间
    private String productoffername;// 商品名称
    private Integer listprice;// 价格
    private Date creationtime;// 购买时间

    public Long getAccountid() {
        return accountid;
    }

    public void setAccountid(Long accountid) {
        this.accountid = accountid;
    }

    public Long getProductofferid() {
        return productofferid;
    }

    public void setProductofferid(Long productofferid) {
        this.productofferid = productofferid;
    }

    public String getPaystatus() {
        return paystatus;
    }

    public void setPaystatus(String paystatus) {
        this.paystatus = paystatus;
    }

    public Date getOrderstarttime() {
        return orderstarttime;
    }

    public void setOrderstarttime(Date orderstarttime) {
        this.orderstarttime = orderstarttime;
    }

    public Date getOrderendtime() {
        return orderendtime;
    }

    public void setOrderendtime(Date orderendtime) {
        this.orderendtime = orderendtime;
    }

    public Date getOrdercanceltime() {
        return ordercanceltime;
    }

    public void setOrdercanceltime(Date ordercanceltime) {
        this.ordercanceltime = ordercanceltime;
    }

    public String getProductoffername() {
        return productoffername;
    }

    public void setProductoffername(String productoffername) {
        this.productoffername = productoffername;
    }

    public Integer getListprice() {
        return listprice;
    }

    public void setListprice(Integer listprice) {
        this.listprice = listprice;
    }

    public Date getCreationtime() {
        return creationtime;
    }

    public void setCreationtime(Date creationtime) {
        this.creationtime = creationtime;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
}