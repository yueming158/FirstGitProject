package com.smt.iptv.portal.push;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.charset.Charset;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;
import org.apache.mina.core.service.IoAcceptor;
import org.apache.mina.core.service.IoHandlerAdapter;
import org.apache.mina.core.session.IdleStatus;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.filter.codec.textline.TextLineCodecFactory;
import org.apache.mina.filter.logging.LoggingFilter;
import org.apache.mina.transport.socket.nio.NioSocketAcceptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springside.modules.mapper.JsonMapper;

import com.google.common.collect.Lists;

public class PushServer {

    private static final Logger logger = LoggerFactory.getLogger(PushServer.class);
    //public static BiMap<String, IoSession> sessionMap = HashBiMap.<String, IoSession> create();
    private static PushServer  myserver=null;
    public synchronized static  void init(int port){
        logger.info("init();myserver==null:"+(myserver==null));
        if(myserver==null){
            PushServer.port=port;
            myserver= new PushServer(port);
        }
    }
    private static int port;
    private static IoAcceptor acceptor;
    public static  boolean LogRuningStatus(){
        //acceptor.getDefaultLocalAddresses();
        //acceptor.isDisposing(); //执行过dispose() 则这个方法返回true
        //acceptor.isDisposed(); //所有资源处理完
        //acceptor.isActive(); //是否活动又没人连接
        //acceptor.isCloseOnDeactivation();//是否在服务失效时关闭所有会话
//        logger.info("acceptor.isActive()="+acceptor.isActive()
//                +";acceptor.isDisposing()="+acceptor.isDisposing()
//                +";acceptor.getActivationTime()="+new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.sss").format(new Date(acceptor.getActivationTime()))
//                );
         if(!acceptor.isActive()){
             logger.info("acceptor.unbind()");
             acceptor.unbind();
             logger.info("acceptor.bind(new InetSocketAddress(port))");
             try {
                acceptor.bind(new InetSocketAddress(port));
            } catch (IOException e) {
                e.printStackTrace();
            }
         }
         return acceptor.isActive();
    }
    private PushServer(int port){
        acceptor = new NioSocketAcceptor();
        acceptor.getSessionConfig().setBothIdleTime(60); 
        acceptor.getFilterChain().addLast("logger", new LoggingFilter());
        acceptor.getFilterChain().addLast("codec", 
                 new ProtocolCodecFilter(
                         new TextLineCodecFactory(Charset.forName("UTF-8"))
                 )
         );
        //acceptor.getFilterChain().addLast("codec", new ProtocolCodecFilter(new ObjectSerializationCodecFactory()));
         //acceptor.getFilterChain().addLast("json", new JsonFilter());
        acceptor.setHandler(new IoHandlerAdapter() {

            @Override
            public void sessionCreated(IoSession session) throws Exception {
                logger.info("server created");
            }

            @Override
            public void sessionOpened(IoSession session) throws Exception {
                logger.info("server opened");
            }

            @Override
            public void sessionClosed(IoSession session) throws Exception {
                logger.info("sessionClosed");
                //sessionMap.inverse().remove(session);
                session.close(false);
                // clientMap.remove();
            }

            @Override
            public void sessionIdle(IoSession session, IdleStatus status) throws Exception {
                //sessionMap.inverse().remove(session);
                session.close(false);
                logger.info("server idle");
            }

            @Override
            public void exceptionCaught(IoSession session, Throwable cause) throws Exception {
                //sessionMap.inverse().remove(session);
                session.close(false);
                logger.info(cause.getMessage(), cause);
            }

            @Override
            public void messageReceived(IoSession session, Object message) throws Exception {
                if("0".equals(message)){
                    session.write("0");
                    logger.info("heartbeat");
                }else{
                    PushMessage pushMessage = new JsonMapper().fromJson((String) message, PushMessage.class);
                    if ("login".equals(pushMessage.getType())) {
                        //sessionMap.remove(pushMessage.getContent());
                        //sessionMap.put(pushMessage.getContent(), session);
                        session.write(new JsonMapper().toJson( new PushMessage("ack",pushMessage.getMsgid())) );
                        
                        Map<Long, IoSession>  map =acceptor.getManagedSessions();
                        for(Entry<Long, IoSession> entry:map.entrySet()){
                            String account = (String)entry.getValue().getAttribute("account");
                            if(pushMessage.getContent().equals(account)){
                                logger.info("pushMessage.getContent().equals(account)="+pushMessage.getContent());
                                logger.info("entry.getValue().getId()="+entry.getValue().getId()+".close(false)");
                                entry.getValue().close(false);
                            }
                        }
                        session.setAttribute("account", pushMessage.getContent());

                        logger.info("用户" + pushMessage.getContent() + "成功连接服务器，sessionId=" + session.getId());
                    } else if ("ack".equals(pushMessage.getType())) {
                        logger.info("客户端收到消息的ACK:" + pushMessage.getContent());
                    } else {
                        logger.info("客户端收到消息" + pushMessage.getContent());
                    }
                }
            }

            @Override
            public void messageSent(IoSession session, Object message) throws Exception {
                logger.info("Sent message " + message);
            }
        });

        try {
            acceptor.bind(new InetSocketAddress(port));
        } catch (IOException ex) {
            logger.info(ex.getMessage(), ex);
        }
    }

    public static void sendMsg(String userId,PushMessage msg){
        logger.info("ready sendMsg userId="+userId+",content:"+msg.getContent());
        Map<Long, IoSession>  map =acceptor.getManagedSessions();
        for(Entry<Long, IoSession> entry:map.entrySet()){
            String account = (String)entry.getValue().getAttribute("account");
            if(userId.equals(account)){
                entry.getValue().write(new JsonMapper().toJson(msg));
                logger.info("userId="+userId+",msgtype="+msg.getType()+"msgcontent="+msg.getContent());
                break;
            }
        }
    }
    public static void sendMsgToAll(PushMessage msg){
//        Map<Long, IoSession>  map =acceptor.getManagedSessions();
//        for(Entry<Long, IoSession> entry:map.entrySet()){
//            String account = (String)entry.getValue().getAttribute("account");
//        }
        acceptor.broadcast(new JsonMapper().toJson(msg));
        logger.info("sendMsgToAll,msg="+new JsonMapper().toJson(msg));
//        for (String userId : PushServer.sessionMap.keySet()) {
//            if (PushServer.sessionMap.get(userId) != null) {
//                PushServer.sessionMap.get(userId).write(msg);
//            }
//        }
    }
    public static void  close(){
        logger.info("close()");
        acceptor.dispose();
    }
    
    
    public static List<String> getLonginUsers(){
        List<String> users =Lists.newArrayList();
        Map<Long, IoSession>  map =PushServer.acceptor.getManagedSessions();
        for(Entry<Long, IoSession> entry:map.entrySet()){
            String account = (String)entry.getValue().getAttribute("account");
            if(StringUtils.isNotEmpty(account)){
                users.add(account);
            }
        }
        return users;
    }
    public static void main(String[] args) throws IOException, InterruptedException {
        PushServer.init(10000);
         for(int i=0;i<100;i++){
             Map<Long, IoSession>  map =PushServer.acceptor.getManagedSessions();
             for(Entry<Long, IoSession> entry:map.entrySet()){
                 String account = (String)entry.getValue().getAttribute("account");
             }
             Thread.sleep(10000);
         }
    }
}   