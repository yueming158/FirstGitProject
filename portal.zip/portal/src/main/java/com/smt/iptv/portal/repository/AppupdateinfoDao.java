package com.smt.iptv.portal.repository;

import org.springframework.data.jpa.repository.Query;

import com.smt.iptv.portal.entity.Appupdateinfo;

public interface AppupdateinfoDao extends BaseDao<Appupdateinfo> {
    @Query(nativeQuery=true,value="SELECT * FROM appupdateinfo WHERE apptype = '1' and (accnts is null or accnts='') ORDER BY version DESC limit 1")
    public Appupdateinfo getAppupdateinfoForInitConfig();
}
