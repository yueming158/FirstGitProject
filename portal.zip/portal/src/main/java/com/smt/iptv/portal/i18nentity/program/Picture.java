package com.smt.iptv.portal.i18nentity.program;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.portal.core.IdEntity;
import com.smt.iptv.portal.model.SystemConstant;
@Entity
@Table(name = "picture")
public class Picture extends IdEntity {
    
    public Picture() {
    }

    public Picture(Long id) {
        this.id = id;
    }
    
	private String picturename;
	private String cpobjectcode;
    private String pictureurl;
    private String size;
    private Integer width;   
    private Integer height;
    private Picturetype picturetype;
    private Program program;
    private String fullUrl;
    
    @ManyToOne
    @JoinColumn(name ="programid")
    public Program getProgram() {
        return program;
    }

    public void setProgram(Program program) {
        this.program = program;
    }

    @ManyToOne
    @JoinColumn(name ="picturetypeid")
    public Picturetype getPicturetype() {
        return picturetype;
    }
    @Transient
    public String getFullUrl() {
        return this.fullUrl=SystemConstant.getURLValue("image_server_httpprefix")+this.pictureurl;
    }

    public void setFullUrl(String fullUrl) {
        this.fullUrl = SystemConstant.getURLValue("image_server_httpprefix")+this.pictureurl;
    }

    public void setPicturetype(Picturetype picturetype) {
        this.picturetype = picturetype;
    }

    
    public String getPicturename() {
        return picturename;
    }

    public void setPicturename(String picturename) {
        this.picturename = picturename;
    }

    public String getCpobjectcode() {
        return cpobjectcode;
    }

    public void setCpobjectcode(String cpobjectcode) {
        this.cpobjectcode = cpobjectcode;
    }

    public String getPictureurl() {
        return pictureurl;
    }

    public void setPictureurl(String pictureurl) {
        this.pictureurl = pictureurl;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public Integer getWidth() {
        return width;
    }

    public void setWidth(Integer width) {
        this.width = width;
    }

    public Integer getHeight() {
        return height;
    }

    public void setHeight(Integer height) {
        this.height = height;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}