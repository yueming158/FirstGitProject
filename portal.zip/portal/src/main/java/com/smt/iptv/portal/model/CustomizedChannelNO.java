package com.smt.iptv.portal.model;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.portal.core.IdEntity;


public class CustomizedChannelNO extends IdEntity {


	public CustomizedChannelNO() {
	}

	public CustomizedChannelNO(Long id) {
		this.id = id;
	}
	private String servicegroup;
	private String channelid;
	private int channelnumber;

    public String getChannelid() {
        return channelid;
    }
    
    public void setChannelid(String channelid) {
        this.channelid = channelid;
    }

    public String getServicegroup() {
        return servicegroup;
    }

    public void setServicegroup(String servicegroup) {
        this.servicegroup = servicegroup;
    }

    public int getChannelnumber() {
        return channelnumber;
    }

    public void setChannelnumber(int channelnumber) {
        this.channelnumber = channelnumber;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}