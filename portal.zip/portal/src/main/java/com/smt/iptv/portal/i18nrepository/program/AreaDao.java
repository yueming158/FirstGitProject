package com.smt.iptv.portal.i18nrepository.program;

import com.smt.iptv.portal.i18nentity.program.Area;
import com.smt.iptv.portal.repository.BaseDao;


public interface AreaDao extends BaseDao<Area> {

}
