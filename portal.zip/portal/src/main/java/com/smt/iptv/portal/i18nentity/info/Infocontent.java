package com.smt.iptv.portal.i18nentity.info;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.hibernate.engine.internal.Cascade;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.smt.iptv.portal.core.IdEntity;
@Entity
@Table(name = "infocontent")
public class Infocontent extends IdEntity {
    
    public Infocontent() {
    }

    public Infocontent(Long id) {
        this.id = id;
    }
    
	private String menucode;
	private String templatetype;
	private String text1;
	private String text2;
	private String text3;
	private String text4;
	private String text5;
	private String areatext;
	private String smallimageurl;
	private String largeimageurl; 
	private String videourl;
	private Long epggroupid;
    public String getMenucode() {
        return menucode;
    }

    public void setMenucode(String menucode) {
        this.menucode = menucode;
    }

    public String getTemplatetype() {
        return templatetype;
    }

    public void setTemplatetype(String templatetype) {
        this.templatetype = templatetype;
    }

    public String getText1() {
        return text1;
    }

    public void setText1(String text1) {
        this.text1 = text1;
    }

    public String getText2() {
        return text2;
    }

    public void setText2(String text2) {
        this.text2 = text2;
    }

    public String getText3() {
        return text3;
    }

    public void setText3(String text3) {
        this.text3 = text3;
    }

    public String getText4() {
        return text4;
    }

    public void setText4(String text4) {
        this.text4 = text4;
    }

    public String getText5() {
        return text5;
    }

    public void setText5(String text5) {
        this.text5 = text5;
    }

    public String getAreatext() {
        return areatext;
    }

    public void setAreatext(String areatext) {
        this.areatext = areatext;
    }

    public String getSmallimageurl() {
        return smallimageurl;
    }

    public void setSmallimageurl(String smallimageurl) {
        this.smallimageurl = smallimageurl;
    }

    public String getLargeimageurl() {
        return largeimageurl;
    }

    public void setLargeimageurl(String largeimageurl) {
        this.largeimageurl = largeimageurl;
    }

    public String getVideourl() {
        return videourl;
    }

    public void setVideourl(String videourl) {
        this.videourl = videourl;
    }

    public Long getEpggroupid() {
        return epggroupid;
    }

    public void setEpggroupid(Long epggroupid) {
        this.epggroupid = epggroupid;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}