package com.smt.iptv.portal.repository.video;

import com.smt.iptv.portal.entity.Slavearea;
import com.smt.iptv.portal.repository.BaseDao;

public interface SlaveareaDao extends BaseDao<Slavearea> {

}
