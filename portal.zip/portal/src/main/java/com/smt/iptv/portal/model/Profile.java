package com.smt.iptv.portal.model;

import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.smt.iptv.portal.core.IdEntity;

public class Profile extends IdEntity {
    
    public Profile() {
    }

    public Profile(Long id) {
        this.id = id;
    }
    
   
    private String iptvuserid;
    @JsonIgnore
    private String iptvpassword;
    private String servicegroup;
    private String roomname;
    private String roomnumber;
    private String guestno;
    private String sta;
    private String customername;
    private String aliasname;
    private String room_type;
    private Date chkin_date;
    private Date chkout_date;
    private String welcomecontent;
    
    
    public String getIptvuserid() {
        return iptvuserid;
    }

    public void setIptvuserid(String iptvuserid) {
        this.iptvuserid = iptvuserid;
    }

    public String getIptvpassword() {
        return iptvpassword;
    }

    public void setIptvpassword(String iptvpassword) {
        this.iptvpassword = iptvpassword;
    }

    public String getServicegroup() {
        return servicegroup;
    }

    public void setServicegroup(String servicegroup) {
        this.servicegroup = servicegroup;
    }

    public String getRoomname() {
        return roomname;
    }

    public void setRoomname(String roomname) {
        this.roomname = roomname;
    }

    public String getRoomnumber() {
        return roomnumber;
    }

    public void setRoomnumber(String roomnumber) {
        this.roomnumber = roomnumber;
    }

    public String getGuestno() {
        return guestno;
    }

    public void setGuestno(String guestno) {
        this.guestno = guestno;
    }

    public String getSta() {
        return sta;
    }

    public void setSta(String sta) {
        this.sta = sta;
    }

    public String getCustomername() {
        return customername;
    }

    public void setCustomername(String customername) {
        this.customername = customername;
    }

    public String getAliasname() {
        return aliasname;
    }

    public void setAliasname(String aliasname) {
        this.aliasname = aliasname;
    }

    public String getRoom_type() {
        return room_type;
    }

    public void setRoom_type(String roomType) {
        room_type = roomType;
    }

    public Date getChkin_date() {
        return chkin_date;
    }

    public void setChkin_date(Date chkinDate) {
        chkin_date = chkinDate;
    }

    public Date getChkout_date() {
        return chkout_date;
    }

    public void setChkout_date(Date chkoutDate) {
        chkout_date = chkoutDate;
    }

    public String getWelcomecontent() {
        return welcomecontent;
    }

    public void setWelcomecontent(String welcomecontent) {
        this.welcomecontent = welcomecontent;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}