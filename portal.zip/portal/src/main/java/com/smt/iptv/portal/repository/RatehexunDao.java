package com.smt.iptv.portal.repository;

import com.smt.iptv.portal.entity.Ratehexun;

public interface RatehexunDao extends BaseDao<Ratehexun> {

}
