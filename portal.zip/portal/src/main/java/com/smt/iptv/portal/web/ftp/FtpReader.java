package com.smt.iptv.portal.web.ftp;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.SocketException;
import java.util.List;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPReply;
import org.springside.modules.mapper.JsonMapper;

import com.google.common.collect.Lists;
import com.smt.iptv.portal.web.model.FileNode;

public class FtpReader {

    /*
     * var zNodes =[
    { id:1, pId:0, name:"父节点1 - 展开", open:true,click:false},
    { id:11, pId:1, name:"父节点11 - 折叠",click:false},
    { id:111, pId:11, name:"叶子节点111"},
    { id:112, pId:11, name:"叶子节点112"}
    ];*/
//  ftp://river:123456@192.168.1.92/ctl/request/
	public static void main(String[] args) throws SocketException, IOException {
        FTPClient ftp = new FTPClient();
        ftp.setConnectTimeout(3000);
        ftp.connect("192.168.1.92", 21);
        ftp.login("river", "123456");
        FTPFile parent = new FTPFile();
        List<FileNode> nodes =Lists.newArrayList();
	    readfolder(ftp,new FileNode(),nodes,"gb2312");
	    JsonMapper mapper = new JsonMapper();
    }
	
	/**
	 * 递归读取ftp文件夹下所有文件 并添加到NodeList中，供页面的ztree控件使用
	 * @param ftp
	 * @param parent
	 * @param nodes
	 * @throws SocketException
	 * @throws IOException
	 */
    public static void readfolder(FTPClient ftp, FileNode parent, List<FileNode> nodes, String charsetName) throws SocketException, IOException {


        FTPFile[] directories = ftp.listDirectories();
        for (FTPFile f : directories) {
            if (!f.getName().equals(".") && !f.getName().equals("..")) {
                FileNode node = new FileNode(nodes.size() + 1, parent.getId(), f.getName(), false);
                nodes.add(node);
                int code = ftp.cwd(new String(f.getName().getBytes(charsetName), "iso8859-1"));// ftp.cwd(f.getName());//
                if (code == 250) {
                    if (ftp.listFiles().length > 0) {
                        readfolder(ftp, node, nodes, charsetName);
                    } else {
                        node.setParent(true);
                        ftp.cdup();
                    }
                }
            }
        }
        FTPFile[] fils = ftp.listFiles();
        for (FTPFile f : fils) {
            if (f.isFile()) {
                nodes.add(new FileNode(nodes.size() + 1, parent.getId(), f.getName(), true));
            }
        }
        ftp.cdup();
    }

    public static long getLastModifyTime(FTPClient ftp ,long time ,String charsetName) throws SocketException, IOException {

        FTPFile[] directories = ftp.listDirectories();
        for (FTPFile f : directories) {
            if (!f.getName().equals(".") && !f.getName().equals("..")) {
                time=f.getTimestamp().getTimeInMillis()>time?f.getTimestamp().getTimeInMillis():time;
                int code = ftp.cwd(new String(f.getName().getBytes(charsetName), "iso8859-1"));// ftp.cwd(f.getName());//
                if (code == 250) {
                    if (ftp.listFiles().length > 0) {
                        long t =getLastModifyTime(ftp, time,charsetName);
                        time=t>time?t:time;
                    } else {
                        ftp.cdup();
                    }
                }
            }
        }
        ftp.cdup();
        return time;
    }
    public static long compareLastModifyTime(FTPClient ftp ,long time ,String charsetName) throws SocketException, IOException {

        FTPFile[] directories = ftp.listDirectories();
        for (FTPFile f : directories) {
            if (!f.getName().equals(".") && !f.getName().equals("..")) {
                if(f.getTimestamp().getTimeInMillis()>time){
                    return f.getTimestamp().getTimeInMillis();
                }
                int code = ftp.cwd(new String(f.getName().getBytes(charsetName), "iso8859-1"));// ftp.cwd(f.getName());//
                if (code == 250) {
                    if (ftp.listFiles().length > 0) {
                        long t =getLastModifyTime(ftp, time,charsetName);
                        if(t>time){
                            return t;
                        }
                    } else {
                        ftp.cdup();
                    }
                }
            }
        }
        ftp.cdup();
        return time;
    }
	   /**
     * Description: 从FTP服务器下载文件
     * @Version1.0 Jul 27, 2008 5:32:36 PM by 崔红保（cuihongbao@d-heaven.com）创建
     * @param url FTP服务器hostname
     * @param port FTP服务器端口
     * @param username FTP登录账号
     * @param password FTP登录密码
     * @param remotePath FTP服务器上的相对路径
     * @param fileName 要下载的文件名
     * @param localPath 下载后保存到本地的路径
     * @return
     */
    public static boolean downFile(String url, int port,String username, String password, String remotePath,String fileName,String localPath) {
        boolean success = false;
        FTPClient ftp = new FTPClient();
        try {
            int reply;
            ftp.connect(url, port);
            //如果采用默认端口，可以使用ftp.connect(url)的方式直接连接FTP服务器
            ftp.login(username, password);//登录
            reply = ftp.getReplyCode();
            if (!FTPReply.isPositiveCompletion(reply)) {
                ftp.disconnect();
                return success;
            }
            ftp.changeWorkingDirectory(new String(remotePath.getBytes("utf-8"), "iso8859-1"));//转移到FTP服务器目录
            FTPFile[] fs = ftp.listFiles();
            for(FTPFile ff:fs){
                if(ff.getName().equals(fileName)){
                    File localFile = new File(localPath+"/"+ff.getName());
                    
                    OutputStream is = new FileOutputStream(localFile); 
                    ftp.retrieveFile(ff.getName(), is);
                    is.close();
                }
            }
            
            ftp.logout();
            success = true;
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (ftp.isConnected()) {
                try {
                    ftp.disconnect();
                } catch (IOException ioe) {
                }
            }
        }
        return success;
    }

    /**
  * Description: 从FTP服务器下载文件
  * @Version1.0 Jul 27, 2008 5:32:36 PM by 崔红保（cuihongbao@d-heaven.com）创建
  * @param url FTP服务器hostname
  * @param port FTP服务器端口
  * @param username FTP登录账号
  * @param password FTP登录密码
  * @param remotePath FTP服务器上的相对路径
  * @param fileName 要下载的文件名
  * @param localPath 下载后保存到本地的路径
  * @return
  */
 public static boolean downFile(String ftpurl,String localPath) {
     //ftp://hhzt:123456@192.168.1.247/content/xx/xx/xx.xlsx;
     String username= ftpurl.split("@")[0].split(":")[1].substring(2);
     String pwd= ftpurl.split("@")[0].split(":")[2];
     String ip= ftpurl.split("@")[1].split("/")[0];
     String path= ftpurl.split("@")[1].substring(ip.length());//   content/xx/xx/xx.xlsx
     int lastindex =path.lastIndexOf("/");
     String remotePath="";
     String fileName="";
     if(lastindex==-1){
         fileName=path;
     }else{
         remotePath=path.substring(0, lastindex);
         fileName=path.substring(lastindex+1);
     }
     return downFile(ip, 21, username, pwd, remotePath, fileName, localPath);
 }
    /**
     * Description: 向FTP服务器上传文件
     * @Version1.0 Jul 27, 2008 4:31:09 PM by 崔红保（cuihongbao@d-heaven.com）创建
     * @param url FTP服务器hostname
     * @param port FTP服务器端口
     * @param username FTP登录账号
     * @param password FTP登录密码
     * @param path FTP服务器保存目录
     * @param filename 上传到FTP服务器上的文件名
     * @param input 输入流
     * @return 成功返回true，否则返回false
     */
    public static boolean uploadFile(String url,int port,String username, String password, String path, String filename, InputStream input) {
        boolean success = false;
        FTPClient ftp = new FTPClient();
        try {
            int reply;
            ftp.connect(url, port);//连接FTP服务器
            //如果采用默认端口，可以使用ftp.connect(url)的方式直接连接FTP服务器
            ftp.login(username, password);//登录
            reply = ftp.getReplyCode();
            if (!FTPReply.isPositiveCompletion(reply)) {
                ftp.disconnect();
                return success;
            }
            ftp.changeWorkingDirectory(path);
            ftp.storeFile(filename, input);         
            
            input.close();
            ftp.logout();
            success = true;
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (ftp.isConnected()) {
                try {
                    ftp.disconnect();
                } catch (IOException ioe) {
                }
            }
        }
        return success;
    }
}

