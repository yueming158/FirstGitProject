package com.smt.iptv.portal.service.music;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.i18nentity.music.Music;
import com.smt.iptv.portal.i18nentity.music.Musiccategorymap;
import com.smt.iptv.portal.i18nrepository.music.MusiccategorymapDao;
import com.smt.iptv.portal.service.cmp.BaseService;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class MusiccategorymapService extends BaseService<MusiccategorymapDao, Musiccategorymap> {
    /**
     * 获取某个类型下 未分类的音乐
     */
    public Page<Music> getMusicExceptCategory(Long categoryid, int pageNumber,
            int pageSize, String sortType) {
        PageRequest pageRequest = buildPageRequest(pageNumber, pageSize, sortType);
        return dao.getMusicExceptCategory(categoryid, pageRequest);
    }
    
    @Transactional(readOnly = false)
    public void updateAllSequence(Integer offset,Long categoryid){
        dao.updateAllSequence(offset,categoryid);
    }
    @Transactional(readOnly = false)
    public void deleteAll(Long [] ids) {
        if(ids!=null)
        for(Long id:ids){
            dao.delete(id);
        }
    }
}
