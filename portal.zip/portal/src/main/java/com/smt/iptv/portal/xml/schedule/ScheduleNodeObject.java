package com.smt.iptv.portal.xml.schedule;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.google.common.collect.Lists;

/**
 * 使用JAXB2.0标注的待转换Java Bean.
 */
@XmlType(propOrder = { "elementType", "id","action","schedules"})
public class ScheduleNodeObject {
    
    public ScheduleNodeObject() {
        
    }
    
	public ScheduleNodeObject(Long id, String elementType, String action) {
        super();
        this.id = id;
        this.elementType = elementType;
        this.action = action;
    }


    private Long id;
   
	private String elementType;
   
	private String action;
    
    private List<Schedule> schedules = Lists.newArrayList();
    
    @XmlAttribute(name="ID")
	public Long getId() {
        return id;
    }


    public void setId(Long id) {
        this.id = id;
    }

    @XmlAttribute(name="ElementType")
    public String getElementType() {
        return elementType;
    }


    public void setElementType(String elementType) {
        this.elementType = elementType;
    }

    @XmlAttribute(name="Action")
    public String getAction() {
        return action;
    }


    public void setAction(String action) {
        this.action = action;
    }

    public List<Schedule> getSchedules() {
        return schedules;
    }

    public void setSchedules(List<Schedule> schedules) {
        this.schedules = schedules;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
