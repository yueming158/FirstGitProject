package com.smt.iptv.portal.entity.hotel;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.format.annotation.DateTimeFormat;

import com.smt.iptv.portal.core.IdEntity;
@Entity
@Table(name = "hotelcustomer")
public class Hotelcustomer extends IdEntity {
    
    public Hotelcustomer() {
    }

    public Hotelcustomer(Long id) {
        this.id = id;
    }
    
    private Hotelroom hotelroom;
	private String customername;
	private String englishname;
	private String identitycard;
	private String sex;
	private String status;//1 入住 2退房
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date checkintime;
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date checkouttime;
	private String welcome;
    @ManyToOne
    @JoinColumn(name = "hotelroomid")
    public Hotelroom getHotelroom() {
        return hotelroom;
    }

    public void setHotelroom(Hotelroom hotelroom) {
        this.hotelroom = hotelroom;
    }

    public String getCustomername() {
        return customername;
    }

    public void setCustomername(String customername) {
        this.customername = customername;
    }

    public String getEnglishname() {
        return englishname;
    }

    public void setEnglishname(String englishname) {
        this.englishname = englishname;
    }

    public String getIdentitycard() {
        return identitycard;
    }

    public void setIdentitycard(String identitycard) {
        this.identitycard = identitycard;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public Date getCheckintime() {
        return checkintime;
    }

    public void setCheckintime(Date checkintime) {
        this.checkintime = checkintime;
    }

    public Date getCheckouttime() {
        return checkouttime;
    }

    public void setCheckouttime(Date checkouttime) {
        this.checkouttime = checkouttime;
    }
    
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getWelcome() {
        return welcome;
    }

    public void setWelcome(String welcome) {
        this.welcome = welcome;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

}