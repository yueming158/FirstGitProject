package com.smt.iptv.portal.web.program;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletRequest;
import javax.validation.Valid;

import org.apache.shiro.SecurityUtils;
import org.quartz.SchedulerException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Maps;
import com.smt.iptv.portal.entity.Bulletin;
import com.smt.iptv.portal.entity.hotel.Hotelroom;
import com.smt.iptv.portal.push.PushMessage;
import com.smt.iptv.portal.push.PushServer;
import com.smt.iptv.portal.service.aaa.ScheduleJobService;
import com.smt.iptv.portal.service.account.ShiroDbRealm.ShiroUser;
import com.smt.iptv.portal.service.cmp.BulletinService;
import com.smt.iptv.portal.service.cmp.EpggroupService;
import com.smt.iptv.portal.service.cmp.IptvprofileService;
import com.smt.iptv.portal.service.hotel.HotelroomService;

/**
 * Bulletin管理的Controller, 使用Restful风格的Urls:
 * 
 * @author xjw
 */
@Controller
@RequestMapping(value = "/bulletin")
public class BulletinController {
    @Autowired
    private EpggroupService epggroupService;
    @Autowired
	private IptvprofileService iptvprofileService;


	private static final int PAGE_SIZE = 50;

	private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
	static {
		sortTypes.put("auto", "自动");
		//sortTypes.put("title", "标题");
	}

	@Autowired
	private BulletinService bulletinService;
	@Autowired
	private HotelroomService hotelroomService;
	@Autowired
	private ScheduleJobService scheduleJobService; 
	
	@RequestMapping(value = "/list")
	public String list(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
			@RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
		Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");
		Page<Bulletin> bulletins = bulletinService.getPage( searchParams, pageNumber, PAGE_SIZE, sortType);
		model.addAttribute("bulletins", bulletins);
		model.addAttribute("sortType", sortType);
		model.addAttribute("sortTypes", sortTypes);
		// 将搜索条件编码成字符串，用于排序，分页的URL
		model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
		return "bulletin/bulletinList";
	}

	@RequestMapping(value = "create", method = RequestMethod.GET)
	public String createForm(Model model) {
		model.addAttribute("bulletin", new Bulletin());
		model.addAttribute("action", "create");
		model.addAttribute("epggroups", epggroupService.getAll());//group
		return "bulletin/bulletinForm";
	}

	@RequestMapping(value = "create", method = RequestMethod.POST)
	public String create(@Valid Bulletin newBulletin,String iptvprofileid, RedirectAttributes redirectAttributes,String cycletime) {
        if("1".equals(newBulletin.getType())||"3".equals(newBulletin.getType())||"7".equals(newBulletin.getType())){
            newBulletin.setReleasetime(new Date());
            newBulletin.setStatus("2");
            bulletinService.save(newBulletin,iptvprofileid);
            sendMsg(newBulletin,iptvprofileid);
            redirectAttributes.addFlashAttribute("message", "发布成功");
        }else if("2".equals(newBulletin.getType())||"4".equals(newBulletin.getType())||"8".equals(newBulletin.getType())){
            //开启定时器 或者另一个Task周期性扫描数据库算了

            if(newBulletin.getReleasetime()!=null&&newBulletin.getReleasetime().getTime()>System.currentTimeMillis()+30000){
                newBulletin.getReleasetime().setSeconds(0);
                newBulletin.setStatus("1");
                bulletinService.save(newBulletin,iptvprofileid);
                redirectAttributes.addFlashAttribute("message", "新增成功");
            }else{
                redirectAttributes.addFlashAttribute("message", "发布时间不正确，新增失败");//发布时间没有大于当前时间30秒以上
            }
        }else if("5".equals(newBulletin.getType())||"6".equals(newBulletin.getType())||"9".equals(newBulletin.getType())){
        	 newBulletin.setStatus("2");
        	 String time[] = cycletime.split(":");
        	 
        	 StringBuffer cornexpression = new StringBuffer("0 ");
        	 cornexpression.append(time[1]);
        	 cornexpression.append(" ");
        	 cornexpression.append(time[0]);
        	 cornexpression.append(" ? * *");
        	 newBulletin.setCronexpression(cornexpression.toString());
             bulletinService.save(newBulletin,iptvprofileid);
             try {
				scheduleJobService.addJob(newBulletin);
			} catch (SchedulerException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
		return "redirect:/bulletin/list";
	}

	private void sendMsg(Bulletin newBulletin, String iptvprofileid) {
		if("1".equals(newBulletin.getType())) {
			PushServer.sendMsgToAll(new PushMessage("msg", newBulletin.getContent()));
		}else if("3".equals(newBulletin.getType())) {
			if(null != iptvprofileid) {
				String[] profileids = iptvprofileid.split(",");
				if(null != profileids && profileids.length>0) {
					for (String id : profileids) {
						PushServer.sendMsg(iptvprofileService.findOne(Long.valueOf(id)).getIptvusername(), new PushMessage("msg", newBulletin.getContent()));
					}
				}
			}
		}else if("7".equals(newBulletin.getType())){
			List<String> iptvprofileids = iptvprofileService.getProfileIdByGroup(newBulletin.getEpggroupid());
			if(null!=iptvprofileids && iptvprofileids.size()>0) {
				for (String id : iptvprofileids) {
					PushServer.sendMsg(id, new PushMessage("msg", newBulletin.getContent()));
				}
			}
		}
		
	}

	@RequestMapping(value = "update/{id}", method = RequestMethod.GET)
	public String updateForm(@PathVariable("id") Long id, Model model) {
		Bulletin bulletin =  bulletinService.findOne(id);
		String cycletime = "";
		String cronexpression = bulletin.getCronexpression();
		if(null!=cronexpression && !"".equals(cronexpression.trim())){
			String times[] = cronexpression.split(" ");
			if(times.length>2) {
				cycletime = times[1]+":"+times[2];
			}
		}
		model.addAttribute("cycletime",cycletime);
		model.addAttribute("bulletin",bulletin);
		model.addAttribute("epggroups", epggroupService.getAll());//group
		model.addAttribute("action", "update");
		return "bulletin/bulletinForm";
	}

	@RequestMapping(value = "update", method = RequestMethod.POST)
	public String update(@Valid @ModelAttribute("preloadBulletin") Bulletin bulletin, String iptvprofileid,RedirectAttributes redirectAttributes,String cycletime) {

        if("1".equals(bulletin.getType())||"3".equals(bulletin.getType())||"7".equals(bulletin.getType())){
            bulletin.setReleasetime(new Date());
            bulletin.setStatus("2");
            bulletinService.save(bulletin,iptvprofileid);
            //PushServer.sendMsgToAll(new PushMessage("msg", bulletin.getContent()));
            redirectAttributes.addFlashAttribute("message", "发布成功");
        }else  if("2".equals(bulletin.getType())||"4".equals(bulletin.getType())||"8".equals(bulletin.getType())){
            //开启定时器 或者另一个Task周期性扫描数据库算了
            if(bulletin.getReleasetime()!=null&&bulletin.getReleasetime().getTime()>System.currentTimeMillis()+300000){
                bulletin.getReleasetime().setSeconds(0);
                bulletin.setStatus("1");
                bulletinService.save(bulletin,iptvprofileid);
                redirectAttributes.addFlashAttribute("message", "新增成功");
            }else{
                redirectAttributes.addFlashAttribute("message", "发布时间不正确，新增失败");
            }
        }else if("5".equals(bulletin.getType())||"6".equals(bulletin.getType())||"9".equals(bulletin.getType())){
       	 bulletin.getReleasetime().setSeconds(0);
       	 bulletin.setStatus("2");
       	 String time[] = cycletime.split(":");
       	 
       	 StringBuffer cornexpression = new StringBuffer("0 ");
       	 if(time[1].indexOf("0")==0){
       		 time[1] = time[1].substring(0, 0);
       	 }
       	 cornexpression.append(time[1]);
       	 cornexpression.append(" ");
       	if(time[0].indexOf("0")==0){
      		 time[0] = time[0].substring(0, 0);
      	 }
       	 cornexpression.append(time[0]);
       	 cornexpression.append(" ? * *");
       	 bulletin.setCronexpression(cornexpression.toString());
            bulletinService.save(bulletin,iptvprofileid);
            try {
				scheduleJobService.addJob(bulletin);
			} catch (SchedulerException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
       }
		return "redirect:/bulletin/list";
	}

	@RequestMapping(value = "delete/{id}")
	public String delete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
		bulletinService.delete(id);
		redirectAttributes.addFlashAttribute("message", "删除成功");
		return "redirect:/bulletin/list";
	}

	/**
	 * 使用@ModelAttribute, 实现Struts2 Preparable二次部分绑定的效果,先根据form的id从数据库查出Bulletin对象,再把Form提交的内容绑定到该对象上。
	 * 因为仅update()方法的form中有id属性，因此本方法在该方法中执行.
	 */
	@ModelAttribute("preloadBulletin")
	public Bulletin getBulletin(@RequestParam(value = "id", required = false) Long id) {
		if (id != null) {
			return bulletinService.findOne(id);
		}
		return null;
	}

	/**
	 * 取出Shiro中的当前用户Id.
	 */
	private Long getCurrentUserId() {
		ShiroUser user = (ShiroUser) SecurityUtils.getSubject().getPrincipal();
		return user.id;
	}
	
    //添加推荐
    @RequestMapping(value = "/select",method = RequestMethod.GET)
    public String select(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");
        Page<Hotelroom> hotelrooms = hotelroomService.getPage(searchParams, pageNumber, PAGE_SIZE, sortType);
        model.addAttribute("hotelrooms", hotelrooms);
        model.addAttribute("sortType", sortType);
        model.addAttribute("sortTypes", sortTypes);
        // 将搜索条件编码成字符串，用于排序，分页的URL
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
        return "bulletin/hotelroomSelect";
    }
}
