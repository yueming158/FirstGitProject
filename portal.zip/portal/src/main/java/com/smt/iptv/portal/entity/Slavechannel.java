package com.smt.iptv.portal.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.portal.core.IdEntity;
@Entity
@Table(name = "slavechannel")
public class Slavechannel extends IdEntity {
    
    public Slavechannel() {
    }

    public Slavechannel(Long id) {
        this.id = id;
    }
    
    private Channel channel;   
    private String areacode;
    
    @ManyToOne
    @JoinColumn(name="channelid")
    public Channel getChannel() {
        return channel;
    }

    public void setChannel(Channel channel) {
        this.channel = channel;
    }

    public String getAreacode() {
        return areacode;
    }

    public void setAreacode(String areacode) {
        this.areacode = areacode;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}