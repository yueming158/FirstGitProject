package com.smt.iptv.portal.i18nrepository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;

import com.smt.iptv.portal.entity.Channel;
import com.smt.iptv.portal.i18nentity.Category;
import com.smt.iptv.portal.i18nentity.Game;
import com.smt.iptv.portal.i18nentity.Info;
import com.smt.iptv.portal.i18nentity.program.Program;
import com.smt.iptv.portal.repository.BaseDao;

public interface CategoryDao extends BaseDao<Category> {
    @Query("select p from Program p inner join p.categorylist c where c.id=?1")
    public Page<Program>  getProgramByCategory(Long categoryid,Pageable pageable);
    
    @Query("select p from Program p inner join p.categorylist c where c.id=?1 and p.programname like ?2")
    public Page<Program>  getProgramByCategory(Long categoryid,String programname,Pageable pageable);

    @Query("select DISTINCT p from Program p where p.programtype=?2 and not exists (select 1 from Categoryprogram cp where cp.category.id=?1 and cp.program.id=p.id)")
    public Page<Program>  getProgramExceptCategory(Long categoryid,String programtype,Pageable pageable);
    
    @Query("select DISTINCT p from Program p where p.programtype=?2 and p.programname like ?3 and not exists (select 1 from Categoryprogram cp where cp.category.id=?1 and cp.program.id=p.id)")
    public Page<Program>  getProgramExceptCategory(Long categoryid,String programtype,String name,Pageable pageable);


    @Query("select c.id from Category c  where c.id=?1 and not exists(select 1 from Categoryprogram cp where cp.category.id=?1) and not exists ( select 1 from Category c2 where c2.parentid=?1)")
    public Long getDeleteProgramCategory(Long categoryid);

    @Query("select c.id from Category c  where c.id=?1 and not exists(select 1 from Categorydish ci where ci.category.id=?1)")
    public Long getDeleteDishCategory(Long categoryid);    
    
    @Query("select c.id from Category c  where c.id=?1 and not exists(select 1 from Categorygoods ci where ci.category.id=?1)")
    public Long getDeleteGoodsCategory(Long categoryid);    

    public List<Category> getByCategorytype(String categorytype);
    
    public List<Category> getByCategorytypeAndParentid(String categorytype,Long parentid);
}
