package com.smt.iptv.portal.web.goods;

import java.util.Map;

import javax.servlet.ServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Maps;
import com.smt.iptv.portal.i18nentity.goods.Goodsfeatured;
import com.smt.iptv.portal.service.goods.GoodsfeaturedService;
import com.smt.iptv.portal.web.vo.Message;

/**
 * @author rich
 */
@Controller
@RequestMapping(value = "/goodsfeatured")
public class GoodsfeaturedController {

    private static final int PAGE_SIZE = 50;

    private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
    static {
        sortTypes.put("sequence", "自动");
    }

    @Autowired
    private GoodsfeaturedService goodsfeaturedService;

    @RequestMapping(value = "/list")
    public String list(@RequestParam(value = "sortType", defaultValue = "sequence") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");
        Page<Goodsfeatured> goodsfeatureds = goodsfeaturedService.getPage(searchParams, pageNumber, 10000, sortType);
        model.addAttribute("goodsfeatureds", goodsfeatureds);
        model.addAttribute("sortType", sortType);
        model.addAttribute("sortTypes", sortTypes);
        // 将搜索条件编码成字符串，用于排序，分页的URL
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
        return "goods/goodsfeaturedList";
    }

    @RequestMapping(value = "add")
    @ResponseBody
    public Message create(@Valid Goodsfeatured newGoodsfeatured, RedirectAttributes redirectAttributes) {
        //不能重复加
        if(newGoodsfeatured!=null
                &&newGoodsfeatured.getGoods()!=null
                &&newGoodsfeatured.getGoods().getId()!=null
                &&goodsfeaturedService.getByGoodsId(newGoodsfeatured.getGoods().getId())==null){
            newGoodsfeatured.setSequence(0);
            goodsfeaturedService.save(newGoodsfeatured);
            return new Message("添加成功");
        }else{
            return new Message("不能重复添加");
        }
    }

    @RequestMapping(value = "updatesort")
    public String update( Integer [] sequences,Long [] ids, RedirectAttributes redirectAttributes) {
        if(ids!=null&&sequences!=null&&ids.length==sequences.length){
            for(int i=0;i<ids.length;i++){
                Goodsfeatured goodsfeatured =goodsfeaturedService.findOne(ids[i]);
                goodsfeatured.setSequence(sequences[i]);
                goodsfeaturedService.save(goodsfeatured);
            }
        }
        redirectAttributes.addFlashAttribute("message", "保存成功");
        return "redirect:/goodsfeatured/list";
    }

    @RequestMapping(value = "delete/{id}")
    public String delete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
        goodsfeaturedService.delete(id);
        redirectAttributes.addFlashAttribute("message", "删除成功");
        return "redirect:/goodsfeatured/list";
    }

    @ModelAttribute("preloadGoodsfeatured")
    public Goodsfeatured getGoodsfeatured(@RequestParam(value = "id", required = false) Long id) {
        if (id != null) {
            return goodsfeaturedService.findOne(id);
        }
        return null;
    }

}
