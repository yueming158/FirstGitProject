package com.smt.iptv.portal.service.account;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.entity.role.Role;
import com.smt.iptv.portal.repository.role.RoleDao;
import com.smt.iptv.portal.service.cmp.BaseService;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class RoleService extends BaseService<RoleDao, Role> {
    @Autowired
    private ResourceService resourceService;
    
    public Set<String> findRoles(String... roleNames) {
        Set<String> roles = new HashSet<String>();
        for(String roleName : roleNames) {
            Role role = dao.getByrole(roleName);
            if(role != null) {
                roles.add(role.getRole());
            }
        }
        return roles;
    }

    public Set<String> findPermissions(List<String> roleNames) {
        Set<Long> resourceIds = new HashSet<Long>();
        for(String roleName : roleNames) {
            Role role = dao.getByrole(roleName);
            if(role != null) {
                String resourceIdsStr = role.getResourceids();
                if(StringUtils.isNotEmpty(resourceIdsStr)) {
                    String[] resourceIdStrs = resourceIdsStr.split(",");
                    for(String resourceIdStr : resourceIdStrs) {
                        if(StringUtils.isEmpty(resourceIdStr)) {
                            continue;
                        }
                        resourceIds.add(Long.valueOf(resourceIdStr));
                    }
                }
            }
        }
        return resourceService.findPermissions(resourceIds);
    }
}
