package com.smt.iptv.portal.service.send;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springside.modules.mapper.JaxbMapper;

import com.google.common.collect.Lists;
import com.smt.iptv.portal.entity.Physicalchannel;
import com.smt.iptv.portal.xml.ADI;
import com.smt.iptv.portal.xml.NodeObject;
import com.smt.iptv.portal.xml.NodeProperty;

//Spring Bean的标识.
@Component


public class PhyChannelLoaderService {
    public void regist(Physicalchannel e,String channelCode){
        //构造xml
        ADI adi = new ADI();
        NodeObject mediaObjs = new NodeObject(e.getId(),"PhysicalChannel","REGIST");
        adi.getObjs().add(mediaObjs);
        mediaObjs.setPropertys(buildPhyChannelPropertyList(e,channelCode));
        String xml = JaxbMapper.toXml(adi, "UTF-8");
        //socketClient.send("PhyMediaContent",xml);
    }
    public void update(Physicalchannel e,String channelCode){
        ADI adi = new ADI();
        NodeObject mediaObjs = new NodeObject(e.getId(),"PhysicalChannel","UPDATE");
        adi.getObjs().add(mediaObjs);
        mediaObjs.setPropertys(buildPhyChannelPropertyList(e,channelCode));
        String xml = JaxbMapper.toXml(adi, "UTF-8");
        //socketClient.send("PhyMediaContent",xml);
    }
    public void delete(Physicalchannel e){
        ADI adi = new ADI();
        NodeObject mediaObjs = new NodeObject(e.getId(),"PhysicalChannel","DELETE");
        adi.getObjs().add(mediaObjs);
        mediaObjs.getPropertys().add(new NodeProperty("CPObjectCode",e.getCpobjectcode()));
        String xml = JaxbMapper.toXml(adi, "UTF-8");
        //socketClient.send("PhyMediaContent",xml);
    }
    public void delete(List<Physicalchannel> list){
        for(Physicalchannel m:list){
            this.delete(m);
        }
    }
    
    /**
     * 
    <Property Name="ChannelCode">TV00000000000000000003@CRI</Property>
    <Property Name="CPObjectCode">PHYTV00000000000000009@CRI</Property>
    <Property Name="BitRate">2</Property>
    <Property Name="IP">225.0.0.1</Property>
    <Property Name="Port">1001</Property>
    <Property Name="SourceIP">225.0.0.1</Property>
    <Property Name="SourcePort">1001</Property>
    <Property Name="EncoderIP">225.0.0.1</Property>
    <Property Name="EncoderPort">1001</Property>
    <Property Name="DRMRecvPort">0</Property>
    <Property Name="Frequency">0</Property>
    <Property Name="PMTPID">0</Property>
    <Property Name="ChannelURL">rtp://225.0.0.1:1001</Property>
    <Property Name="TimeshiftURL">rtsp://60.194.136.206:554/TV00000000000000000003@CRI</Property>
     * @param e
     * @return
     */
    private List<NodeProperty> buildPhyChannelPropertyList(Physicalchannel phyChannel,String channelCode){
        List<NodeProperty> list = Lists.newArrayList();
       list.add(new NodeProperty("ChannelCode", channelCode));
       list.add(new NodeProperty("CPObjectCode", phyChannel.getCpobjectcode()));
       list.add(new NodeProperty("BitRate", phyChannel.getBitratedef()));
       list.add(new NodeProperty("IP", phyChannel.getIp()));
       list.add(new NodeProperty("Port", phyChannel.getPort()));
       list.add(new NodeProperty("SourceIP", phyChannel.getSourceip()));
       list.add(new NodeProperty("SourcePort", phyChannel.getSourceport()));
       list.add(new NodeProperty("EncoderIP", phyChannel.getEncoderip()));
       list.add(new NodeProperty("EncoderPort", phyChannel.getEncoderport()));
       //list.add(new NodeProperty("DRMRecvPort", phyChannel.getDrmrecvport()));
       list.add(new NodeProperty("Frequency",""+ (phyChannel.getFrequency()==null?0:phyChannel.getFrequency())));
       list.add(new NodeProperty("PMTPID",""+(phyChannel.getPmtpid()==null?0:phyChannel.getPmtpid())));
       list.add(new NodeProperty("ChannelURL", phyChannel.getChannelurl()));
       if(StringUtils.isNotEmpty(phyChannel.getTimeshifturl())){
           list.add(new NodeProperty("TimeshiftURL", phyChannel.getTimeshifturl()));
       }
        return list;
    }
}
