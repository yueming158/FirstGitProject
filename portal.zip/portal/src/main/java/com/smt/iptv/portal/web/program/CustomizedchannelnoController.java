package com.smt.iptv.portal.web.program;

import java.util.LinkedList;
import java.util.List;

import javax.servlet.ServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.smt.iptv.portal.entity.Channel;
import com.smt.iptv.portal.entity.Channelgroup;
import com.smt.iptv.portal.entity.Customizedchannelno;
import com.smt.iptv.portal.service.cmp.ChannelService;
import com.smt.iptv.portal.service.cmp.ChannelgroupService;
import com.smt.iptv.portal.service.cmp.CustomizedchannelnoService;

/**
 * @author xjw
 */
@Controller
@RequestMapping(value = "/customizedchannelno")
public class CustomizedchannelnoController {
    private static final String VIEW_FALSE="0";
    private static final String VIEW_TRUE="1";
    @Autowired
    private CustomizedchannelnoService customizedchannelnoService;
    @Autowired
    private ChannelService channelService;
    @Autowired
    private ChannelgroupService channelgroupService;
    /**
     * 按频道分组获取客户化频道总列表
     * @param model
     * @param channelgroup
     * @return
     */
    @RequestMapping(value = "/list")
    public String list(Model model, @RequestParam(value = "channelgroup", required = true) String channelgroup) {
        List<Channel> channels = channelService.getAll();
//        List<Channelgroup> channelgroups = channelgroupService.getAll();
//        if (channelgroup == null) {
//            if (channelgroups.size() > 0) {
//                channelgroup = channelgroups.get(0).getChannelgroupcode();
//            }
//        }
        List<Customizedchannelno> olds = customizedchannelnoService.findByChannelgroup(channelgroup);
        if (olds.size() != channels.size()) {
            // 新增 修改 删除 客户化频道
            List<Customizedchannelno> adds=new LinkedList<Customizedchannelno>();
            for (int i = 0; i < channels.size(); i++) {
                long channelid=channels.get(i).getId().longValue();
                boolean existsFlag = false;//当做不存在
                for (int j = 0; j < olds.size(); j++) {
                    if(olds.get(j).getChannel().getId().longValue()==channelid){
                        olds.remove(j);
                        existsFlag = true;//存在
                        break;
                    }
                }
                if(!existsFlag){//如果不存在;则需要新增
                    Customizedchannelno addcc = new Customizedchannelno();
                    addcc.setChannelgroup(channelgroup);
                    //addcc.setChannel(new Channel(channelid));
                    addcc.setChannel(channels.get(i));
                    addcc.setChannelnumber(channels.get(i).getChannelnumber()+"");
                    addcc.setView(VIEW_FALSE);
                    adds.add(addcc);
                }
            }
            customizedchannelnoService.delete(olds); //删除多余的
            customizedchannelnoService.save(adds);//添加新增的
            olds = customizedchannelnoService.findByChannelgroup(channelgroup);//更新完成后重新获取一次最新的
        }
        
        model.addAttribute("channels", channels);
        model.addAttribute("channelgroup", channelgroup);
        //model.addAttribute("channelgroups", channelgroups);
        model.addAttribute("customizedchannelnos", olds);

        return "customizedchannelno/customizedchannelnoList";
    }
    /**
     * 更新频道列表以及频道号
     * @param custchnids
     * @param data
     * @param channelgroup
     * @param redirectAttributes
     * @param request
     * @return
     */
    @RequestMapping(value = "update", method = RequestMethod.POST)
    public String update(@RequestParam(value = "custchnids") String[] custchnids,
            @RequestParam(value = "channelnumbers") String[] data,
            @RequestParam(value = "channelgroup") String channelgroup, RedirectAttributes redirectAttributes,
            ServletRequest request) {
        // 批量更新频道号
        // customizedchannelnoService.save(null);
        List<Customizedchannelno> customizedchannelnos = customizedchannelnoService.findByChannelgroup(channelgroup);
        for (int i = 0; i < customizedchannelnos.size(); i++) {
            // String newnumber
            // =request.getParameter("id_"+customizedchannelnos.get(i).getId());
            String newnumber = data[i].trim();
            customizedchannelnos.get(i).setChannelnumber(newnumber);
            String view =VIEW_FALSE;
            for(String id:custchnids){
                if((customizedchannelnos.get(i).getId()+"").equals(id)){
                    view=VIEW_TRUE;
                    break;
                }
            }
            customizedchannelnos.get(i).setView(view);
        }
        customizedchannelnoService.save(customizedchannelnos);
        redirectAttributes.addFlashAttribute("message", "保存成功");
        return "redirect:/customizedchannelno/list?channelgroup="+channelgroup;
    }
    
    
    
    /**
     * 按频道分组获取客户化频道已经被选中的列表
     * @param model
     * @param channelgroup
     * @return
     */
    @RequestMapping(value = "/listselected")
    public String listselected(Model model, @RequestParam(value = "channelgroup", required = false) String channelgroup) {
        List<Channel> channels = channelService.getAll();
        List<Channelgroup> channelgroups = channelgroupService.getAll();
        if (channelgroup == null) {
            if (channelgroups.size() > 0) {
                channelgroup = channelgroups.get(0).getChannelgroupcode();
            }
        }
        List<Customizedchannelno> olds = customizedchannelnoService.findByChannelgroupAndView(channelgroup,VIEW_TRUE);

        model.addAttribute("channels", channels);
        model.addAttribute("channelgroup", channelgroup);
        model.addAttribute("channelgroups", channelgroups);
        model.addAttribute("customizedchannelnos", olds);

        return "customizedchannelno/sortchannelnoList";
    }
    /**
     * 重排频道号，不修改频道分组中频道列表
     * @param custchnids
     * @param data
     * @param channelgroup
     * @param redirectAttributes
     * @param request
     * @return
     */
    @RequestMapping(value = "sort", method = RequestMethod.POST)
    public String sort(@RequestParam(value = "channelnumbers") String[] data,
            @RequestParam(value = "channelgroup") String channelgroup, RedirectAttributes redirectAttributes,
            ServletRequest request) {
        // 批量更新频道号
        List<Customizedchannelno> customizedchannelnos = customizedchannelnoService.findByChannelgroupAndView(channelgroup,VIEW_TRUE);
        for (int i = 0; i < customizedchannelnos.size(); i++) {
            String newnumber = data[i].trim();
            customizedchannelnos.get(i).setChannelnumber(newnumber);
        }
        customizedchannelnoService.save(customizedchannelnos);
        redirectAttributes.addFlashAttribute("message", "保存成功");
        return "redirect:/customizedchannelno/listselected?channelgroup="+channelgroup;
    }
    
    /**
     * 在弹出窗口重排频道
     * @param model
     * @param channelgroup
     * @return
     */
    @RequestMapping(value = "/sortwindow", method = RequestMethod.GET)
    public String listselectedwindow(Model model,String channelgroup) {
        List<Channel> channels = channelService.getAll();
        List<Customizedchannelno> olds = customizedchannelnoService.findByChannelgroupAndView(channelgroup,VIEW_TRUE);
        model.addAttribute("channels", channels);
        model.addAttribute("channelgroup", channelgroup);
        model.addAttribute("customizedchannelnos", olds);
        return "customizedchannelno/sort";
    }
    /**
     * 在弹出窗口重排频道
     * @param custchnids
     * @param data
     * @param channelgroup
     * @param redirectAttributes
     * @param request
     * @return
     */
    @RequestMapping(value = "sortwindow", method = RequestMethod.POST)
    public String sortwindow(@RequestParam(value = "channelnumbers") String[] data,
            String channelgroup, RedirectAttributes redirectAttributes) {
        // 批量更新频道号
        List<Customizedchannelno> customizedchannelnos = customizedchannelnoService.findByChannelgroupAndView(channelgroup,VIEW_TRUE);
        for (int i = 0; i < customizedchannelnos.size(); i++) {
            String newnumber = data[i].trim();
            customizedchannelnos.get(i).setChannelnumber(newnumber);
        }
        customizedchannelnoService.save(customizedchannelnos);
        redirectAttributes.addFlashAttribute("message", "保存成功");
        return "redirect:/customizedchannelno/sortwindow?channelgroup="+channelgroup;
    }
}
