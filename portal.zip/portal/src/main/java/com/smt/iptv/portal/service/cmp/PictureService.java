package com.smt.iptv.portal.service.cmp;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.i18nentity.program.Picture;
import com.smt.iptv.portal.i18nrepository.program.PictureDao;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class PictureService extends BaseService<PictureDao, Picture> {

    @Transactional(readOnly = false)
    public void deleteByProgramId(Long programId) {
        dao.deleteByProgramId(programId);
    }
    
    @Transactional(readOnly = false)
    public void deleteByProgramIdAndPicturetypeid(Long programId,Long picturetypeId) {
        dao.deleteByProgramIdAndPicturetypeid(programId,picturetypeId);
    }

    public Picture getByProgramIdAndPicturetypeId(Long programId,Long picturetypeId) {
        return dao.getByProgramIdAndPicturetypeId(programId,picturetypeId);
    }
}
