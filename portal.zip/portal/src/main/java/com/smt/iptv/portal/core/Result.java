package com.smt.iptv.portal.core;

public class Result{
	
	public Result()
	{
	}
	public Result(Boolean result,String desc)
	{
		this.result=result;
		this.desc=desc;
	}
	private Boolean result=true; //执行是否成功
	private String desc=""; //情况说明
	
	public Boolean getResult() {
		return result;
	}
	public void setResult(Boolean result) {
		this.result = result;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}

	
	
}
