package com.smt.iptv.portal.i18nentity;

import java.util.Comparator;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.portal.core.IdEntity;
@Entity
@Table(name = "globalenum")
public class Globalenum extends IdEntity implements Cloneable, Comparator {
    
    public Globalenum() {
    }

    public Globalenum(Long id) {
        this.id = id;
    }
    
    public Globalenum clone()
    {
        Globalenum cloned =null;
        try {
            cloned = (Globalenum) super.clone();
        } catch (CloneNotSupportedException e) {
        }
        return cloned;
    }
    
	private String name;
	private String code;
    private String type;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

    @Override
    public int compare(Object o1, Object o2) {
        return ((Globalenum)o1).getName().compareToIgnoreCase(((Globalenum)o2).getName());
    }
}