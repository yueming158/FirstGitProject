package com.smt.iptv.portal.repository.aaa;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;

import com.smt.iptv.portal.entity.aaa.Productoffer;
import com.smt.iptv.portal.repository.BaseDao;

public interface ProductofferDao extends BaseDao<Productoffer> {
	@Query("select po from Productoffer po where po.offername like ?1 and po.productoffertype=?2 and po.status='1' and po.id not in(?3)")
	Page<Productoffer> getProductoffers(String productofferName,
			String productofferType, List<Long> productofferIds,
			Pageable page);
	@Query("select po from Productoffer po where po.offername like ?1 and po.productoffertype=?2 and po.strategytype=?3 and po.status='1' and po.id not in(?4)")
	Page<Productoffer> getProductoffers(String productofferName,
			String productofferType, String strategytype , List<Long> productofferIds,
			Pageable page);
}
