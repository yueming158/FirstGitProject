package com.smt.iptv.portal.service.send;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springside.modules.mapper.JaxbMapper;

import com.google.common.collect.Lists;
import com.smt.iptv.portal.xml.schedule.Schedule;
import com.smt.iptv.portal.xml.schedule.ScheduleADI;
import com.smt.iptv.portal.xml.schedule.ScheduleNodeObject;

//Spring Bean的标识.
@Component
public class ScheduleLoaderService {

    public void update(List<Schedule> schedules) {
        ScheduleADI adi = new ScheduleADI();
        ScheduleNodeObject mediaObjs = new ScheduleNodeObject(1L, "Schedule", "UPDATE");
        adi.getObjs().add(mediaObjs);
        mediaObjs.setSchedules(schedules);
        String xml = JaxbMapper.toXml(adi, "UTF-8");
        //socketClient.send("Schedule",xml);
    }

    public static void main(String[] args) {
        ScheduleLoaderService loader = new ScheduleLoaderService();
        List<Schedule> schedules =Lists.newArrayList();
        Schedule s= new Schedule();
        s.setChanncode("123");
        s.setContcode("123");
        s.setDuration(12);
        s.setId(1L+"");
        s.setSeq(1);
        s.setStarttime("starttime");
        s.setViewname("viewname");
        schedules.add(s);
        schedules.add(new Schedule());
        schedules.add(new Schedule());
        schedules.add(new Schedule());
        schedules.add(new Schedule());
        loader.update(schedules);
    }
}
