package com.smt.iptv.portal.repository.video;

import java.util.List;

import com.smt.iptv.portal.entity.Virtualcontentinfo;
import com.smt.iptv.portal.repository.BaseDao;

public interface VirtualcontentinfoDao extends BaseDao<Virtualcontentinfo> {
    public List<Virtualcontentinfo> findByChannCode(String channCode);
}
