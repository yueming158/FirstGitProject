package com.smt.iptv.portal.push;

import java.io.Serializable;
import java.util.UUID;

public class PushMessage implements Serializable {

    private static final long serialVersionUID = 1L;
    private String msgid;
    private String type;
    private String content;

    public PushMessage() {
        super();
    }
    public PushMessage(String type, String content) {
        super();
        //this.msgid=Long.toString(System.currentTimeMillis());
        this.msgid=UUID.randomUUID().toString();
        this.type = type;
        this.content = content;
    }

    public String getMsgid() {
        return msgid;
    }

    public void setMsgid(String msgid) {
        this.msgid = msgid;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

}
