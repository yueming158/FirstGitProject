package com.smt.iptv.portal.xml;

import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

/**
 * 使用JAXB2.0标注的待转换Java Bean.
 */
//根节点
@XmlRootElement(name="ADI")
//指定子节点的顺序
@XmlType(propOrder = {"namespace","cpCode","staffID", "objs", "mps"})
public class ADI {
    
    private String cpCode ="iptv";
    
    private String staffID="admin";
    
	private List<NodeObject> objs = Lists.newArrayList();
    
	private List<Mapping> mps = Lists.newArrayList();
	
    private String namespace ="http://www.w3.org/2001/XMLSchema-instance";
	

    @XmlAttribute(name="StaffID")
    public String getStaffID() {
        return staffID;
    }

    @XmlAttribute(name="CPCode")
    public String getCpCode() {
        return cpCode;
    }

    public void setCpCode(String cpCode) {
        this.cpCode = cpCode;
    }

    public void setStaffID(String staffID) {
        this.staffID = staffID;
    }

    @XmlElementWrapper(name = "Objects")
    @XmlElement(name = "Object")
    public List<NodeObject> getObjs() {
        return objs;
    }


    public void setObjs(List<NodeObject> objs) {
        this.objs = objs;
    }

    @XmlElementWrapper(name="Mappings")
    @XmlElement(name = "Mapping")
    public List<Mapping> getMps() {
        return mps;
    }


    public void setMps(List<Mapping> mps) {
        this.mps = mps;
    }

    
    @XmlAttribute(name="xmlns:xsi")
    public String getNamespace() {
        return namespace;
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
