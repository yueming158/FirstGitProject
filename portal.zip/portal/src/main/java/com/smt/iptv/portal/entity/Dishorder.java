package com.smt.iptv.portal.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.smt.iptv.portal.core.IdEntity;
@Entity
@Table(name = "dishorder")
public class Dishorder extends IdEntity {

    private String username;
    private String roomname;
    private String ordercode;
    private String totalprice;
    private String status;//1待处理 2已核对 3已送达 4已完成 5已取消
    @JsonIgnore
    private Date creationtime;
    @JsonIgnore
    private String verifypeople;
    @JsonIgnore
    private Date verifytime;
    @JsonIgnore
    private String deliverpeople;
    @JsonIgnore
    private Date delivertime;
    @JsonIgnore
    private Date completetime;
    private String tel;
    
    
    public String getRoomname() {
        return roomname;
    }

    public void setRoomname(String roomname) {
        this.roomname = roomname;
    }

    public String getOrdercode() {
        return ordercode;
    }

    public void setOrdercode(String ordercode) {
        this.ordercode = ordercode;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getTotalprice() {
        return totalprice;
    }

    public void setTotalprice(String totalprice) {
        this.totalprice = totalprice;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getCreationtime() {
        return creationtime;
    }

    public void setCreationtime(Date creationtime) {
        this.creationtime = creationtime;
    }

    public String getVerifypeople() {
        return verifypeople;
    }

    public void setVerifypeople(String verifypeople) {
        this.verifypeople = verifypeople;
    }

    public String getDeliverpeople() {
        return deliverpeople;
    }
    
    public Date getVerifytime() {
        return verifytime;
    }

    public void setVerifytime(Date verifytime) {
        this.verifytime = verifytime;
    }

    public void setDeliverpeople(String deliverpeople) {
        this.deliverpeople = deliverpeople;
    }

    public Date getDelivertime() {
        return delivertime;
    }

    public void setDelivertime(Date delivertime) {
        this.delivertime = delivertime;
    }

    public Date getCompletetime() {
        return completetime;
    }

    public void setCompletetime(Date completetime) {
        this.completetime = completetime;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }



    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
}