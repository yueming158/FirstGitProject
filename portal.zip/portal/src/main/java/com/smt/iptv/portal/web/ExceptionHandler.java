package com.smt.iptv.portal.web;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;

public class ExceptionHandler implements HandlerExceptionResolver {

    private static Logger logger = LoggerFactory.getLogger(ExceptionHandler.class);
    @Override
    public ModelAndView resolveException(HttpServletRequest request,
            HttpServletResponse response, Object handler, Exception ex) {
        ModelAndView mv = new ModelAndView("error/exception");
        //生成错误号 记录异常 打印
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss,SSS");
        mv.addObject("time", sdf.format(new Date()));
        if(ex.getMessage().contains("SizeLimitExceededException")){
            mv.addObject("ex", "上传文件过大！");
        }else{
            mv.addObject("ex", "请联系系统管理员,理由"+ex.getMessage());
        }
        
        
        //if(ex instanceof RuntimeException){
        //    logger.error(ex.getMessage());
        //}else{
            logger.error(request.getRequestURL().toString(), ex);
        //}
        return mv;
    }
}