package com.smt.iptv.portal.service.cmp;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.i18nentity.program.Cast;
import com.smt.iptv.portal.i18nrepository.program.CastDao;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class CastService extends BaseService<CastDao, Cast> {

//    public Page<Cast> getCastsByProgramid(Long programid, int pageNumber, int pageSize,
//            String sortType) {
//        Sort sort = null;
//        if ("auto".equals(sortType)) {
//            sort = new Sort(Direction.DESC, "id");
//        } else {
//            sort = new Sort(Direction.ASC, sortType);
//        }
//        PageRequest pageRequest = new PageRequest(pageNumber - 1, pageSize, sort);
//        return dao.getCastsByProgramid(programid,pageRequest);
//    }
}
