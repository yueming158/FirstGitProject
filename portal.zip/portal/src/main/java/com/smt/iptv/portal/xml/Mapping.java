package com.smt.iptv.portal.xml;

import javax.xml.bind.annotation.XmlAttribute;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * 使用JAXB2.0标注的待转换Java Bean.
 */
public class Mapping {
	private Long id;
	private String name;

	public Mapping() {
	}

	public Mapping(Long id, String name) {
		this.id = id;
		this.name = name;
	}

	@XmlAttribute
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@XmlAttribute
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
