package com.smt.iptv.portal.web.hotel;

import java.util.Map;

import javax.servlet.ServletRequest;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Maps;
import com.smt.iptv.portal.entity.hotel.Hotelcall;
import com.smt.iptv.portal.service.hotel.HotelcallService;

/**
 * @author rich
 */
@Controller
@RequestMapping(value = "/hotelcall")
public class HotelcallController {

    private static final int PAGE_SIZE = 50;

    private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
    static {
        sortTypes.put("auto", "自动");
        sortTypes.put("appointmenttime", "服务时间");
    }

    @Autowired
    private HotelcallService hotelcallService;

    @RequestMapping(value = "/list")
    public String list(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");
        if(!searchParams.containsKey("EQ_reqstatus")||"".equals(searchParams.get("EQ_reqstatus"))){
            searchParams.put("NOTEQ_reqstatus", "4");
        }
        Page<Hotelcall> hotelcalls = hotelcallService.getPage(searchParams, pageNumber, PAGE_SIZE, sortType);

        model.addAttribute("hotelcalls", hotelcalls);
        model.addAttribute("sortType", sortType);
        model.addAttribute("sortTypes", sortTypes);
        // 将搜索条件编码成字符串，用于排序，分页的URL
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
        return "hotelcall/hotelcallList";
    }
    @RequestMapping(value = "/ajaxlist")
    public String ajaxlist(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");
        if(!searchParams.containsKey("EQ_reqstatus")||"".equals(searchParams.get("EQ_reqstatus"))){
                searchParams.put("NOTEQ_reqstatus", "4");
        }
        Page<Hotelcall> hotelcalls = hotelcallService.getPage(searchParams, pageNumber, PAGE_SIZE, sortType);

        model.addAttribute("hotelcalls", hotelcalls);
        model.addAttribute("sortType", sortType);
        model.addAttribute("sortTypes", sortTypes);
        // 将搜索条件编码成字符串，用于排序，分页的URL
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
        return "hotelcall/hotelcallajaxList";
    }
    @RequestMapping(value = "update/{id}", method = RequestMethod.GET)
    public String updateForm(@PathVariable("id") Long id, Model model) {
        model.addAttribute("hotelcall", hotelcallService.findOne(id));
        model.addAttribute("action", "update");
        return "hotelcall/hotelcallForm";
    }

    @RequestMapping(value = "update", method = RequestMethod.POST)
    public String update(@Valid @ModelAttribute("preloadHotelcall") Hotelcall hotelcall, RedirectAttributes redirectAttributes, MultipartFile imgfile,
            MultipartFile file) {
        hotelcallService.save(hotelcall);
        redirectAttributes.addFlashAttribute("message", "保存成功");
        return "redirect:/hotelcall/list";
    }

    @RequestMapping(value = "delete/{id}")
    public String delete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
        hotelcallService.delete(id);
        redirectAttributes.addFlashAttribute("message", "删除成功");
        return "redirect:/hotelcall/list";
    }

    @ModelAttribute("preloadHotelcall")
    public Hotelcall getHotelcall(@RequestParam(value = "id", required = false) Long id) {
        if (id != null) {
            return hotelcallService.findOne(id);
        }
        return null;
    }

    @RequestMapping(value = "response/{id}")
    public String response(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {

        if (hotelcallService.response(id) != null) {
            redirectAttributes.addFlashAttribute("message", "状态更新成功");
        } else {
            redirectAttributes.addFlashAttribute("message", "状态更新失败");
        }
        return "redirect:/hotelcall/list";
    }

    @RequestMapping(value = "complete/{id}")
    public String complete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
        if (hotelcallService.complete(id) != null) {
            redirectAttributes.addFlashAttribute("message", "状态更新成功");
        } else {
            redirectAttributes.addFlashAttribute("message", "状态更新失败");
        }
        return "redirect:/hotelcall/list";
    }
    @RequestMapping(value = "cancel/{id}")
    public String cancel(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
        if (hotelcallService.cancel(id) != null) {
            redirectAttributes.addFlashAttribute("message", "取消成功");
        } else {
            redirectAttributes.addFlashAttribute("message", "取消失败");
        }
        return "redirect:/hotelcall/list";
    }
}
