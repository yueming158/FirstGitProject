package com.smt.iptv.portal.model;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.smt.iptv.portal.core.IdEntity;

public class Category extends IdEntity {
    
    public Category() {
    }

    public Category(Long id) {
        this.id = id;
    }
    
	private String categoryname;
	 @JsonIgnore
	private String cpobjectcode;
	 @JsonIgnore
    private String categorytype;
    @JsonIgnore
    private String deleteflag;
    private int sequence;   

    public String getCategoryname() {
        return categoryname;
    }

    public void setCategoryname(String categoryname) {
        this.categoryname = categoryname;
    }

    public String getCpobjectcode() {
        return cpobjectcode;
    }

    public void setCpobjectcode(String cpobjectcode) {
        this.cpobjectcode = cpobjectcode;
    }

    public String getCategorytype() {
        return categorytype;
    }

    public void setCategorytype(String categorytype) {
        this.categorytype = categorytype;
    }

    public String getDeleteflag() {
        return deleteflag;
    }

    public void setDeleteflag(String deleteflag) {
        this.deleteflag = deleteflag;
    }

    public int getSequence() {
        return sequence;
    }

    public void setSequence(int sequence) {
        this.sequence = sequence;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}