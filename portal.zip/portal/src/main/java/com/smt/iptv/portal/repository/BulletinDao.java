package com.smt.iptv.portal.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.smt.iptv.portal.entity.Bulletin;

public interface BulletinDao extends BaseDao<Bulletin> {
    @Query(nativeQuery=true,value="delete from bulletinstatus where bulletinid=?1")
    @Modifying
    void deleteBulletinstatusByBulletinid(Long id);
    @Query(nativeQuery=true,value="insert into bulletinstatus(bulletinid,iptvprofileid,readstatus,expirestatus) select ?1,iptvprofile.id,'0','0' from iptvprofile")
    @Modifying
    Integer insertBulletinstatus(Long id);
    @Query(nativeQuery=true,value="insert into bulletinstatus(bulletinid,iptvprofileid,readstatus,expirestatus) select ?1,iptvprofile.id,'0','0' from iptvprofile where iptvprofile.id =?2")
    @Modifying
    Integer insertBulletinstatus(Long id,Long ids);
    
    List<Bulletin> getByTypeAndStatus(String type,String status);
    
    @Query(nativeQuery=true,value="select iptvprofileid from bulletinstatus where bulletinid=?1")
    List<Long> getIptvprofileidByBulletinid(Long bulletinid);
    @Query("select b from Bulletin b where type in(?1)")
	List<Bulletin> getBulletinByType(List<String> types);
}
