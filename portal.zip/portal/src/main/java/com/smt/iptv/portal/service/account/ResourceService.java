package com.smt.iptv.portal.service.account;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.smt.iptv.portal.entity.role.Resource;
import com.smt.iptv.portal.repository.role.ResourceDao;
import com.smt.iptv.portal.service.cmp.BaseService;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class ResourceService extends BaseService<ResourceDao, Resource> {
    public Set<String> findPermissions(Set<Long> resourceIds) {
        Set<String> permissions = new HashSet<String>();
        for (Long resourceId : resourceIds) {
            Resource resource = findOne(resourceId);
            if (resource != null && !StringUtils.isEmpty(resource.getPermission()) && "1".equals(resource.getEnabled())) {
                permissions.add(resource.getPermission());
            }
        }
        return permissions;
    }

    public List<Resource> getByEnabled() {
        return dao.getByEnabled("1");
    }
}
