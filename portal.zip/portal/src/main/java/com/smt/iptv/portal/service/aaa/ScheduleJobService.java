package com.smt.iptv.portal.service.aaa;


import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.quartz.CronScheduleBuilder;
import org.quartz.CronTrigger;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.TriggerBuilder;
import org.quartz.TriggerKey;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;
import org.springframework.stereotype.Service;

import com.smt.iptv.portal.entity.Bulletin;
import com.smt.iptv.portal.service.cmp.BulletinService;

@Service
public class ScheduleJobService {
	@Autowired
	private SchedulerFactoryBean schedulerFactoryBean;
	@Autowired
	private BulletinService bulletinService;
	
	/**
	 * 增加一个job
	 * @param job
	 * @throws SchedulerException
	 */
	public void addJob(Bulletin job) throws SchedulerException{
		 if (job == null) {  
			 return;  
		 } 
		 Scheduler scheduler = schedulerFactoryBean.getScheduler();
		 //使用job id 作为 trigger key
		 TriggerKey triggerKey = TriggerKey.triggerKey(job.getId().toString());
		 //定义一个计划
		 CronTrigger trigger = (CronTrigger) scheduler.getTrigger(triggerKey);
		 //创建一个以job id为key的jobDetail
		 JobDetail  jobDetail = JobBuilder.newJob(PushJob.class).withIdentity(job.getId().toString()).build(); 
		 jobDetail.getJobDataMap().put("scheduleJob", job);
		 CronScheduleBuilder scheduleBuilder = CronScheduleBuilder.cronSchedule(job.getCronexpression());
		 trigger = TriggerBuilder.newTrigger().withIdentity(job.getId().toString()).withSchedule(scheduleBuilder).build();
		 //将计划放置到计划工厂
		 scheduler.scheduleJob(jobDetail, trigger);
	 }
	
	/**
	 * 删除一个job
	 * 
	 * @param scheduleJob
	 * @throws SchedulerException
	 */
	public void deleteJob(Bulletin scheduleJob) throws SchedulerException {
		Scheduler scheduler = schedulerFactoryBean.getScheduler();
		JobKey jobKey = JobKey.jobKey(scheduleJob.getId().toString());
		scheduler.deleteJob(jobKey);

	}
	/**
	 * 更新
	 * @throws SchedulerException 
	 */
	public void updateJob(Bulletin scheduleJob) throws SchedulerException {
		deleteJob(scheduleJob);
		addJob(scheduleJob);
	}
	
	
	
	/**
	 * 刷新
	 * @throws SchedulerException 
	 */
	public void flushJob(Bulletin scheduleJob) throws Exception {
		Scheduler scheduler = schedulerFactoryBean.getScheduler();
		scheduler.clear();
		init();
	}
	
	
	@PostConstruct
	public void init() throws Exception {

		List<String> types = new ArrayList<String>();
		types.add("5");
		types.add("6");
		types.add("9");
		// 这里获取任务信息数据
		List<Bulletin> jobList = bulletinService.getBulletinByType(types);
	
		for (Bulletin job : jobList) {
			addJob(job);
		}
	}
}
