package com.smt.iptv.portal.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.portal.core.IdEntity;
@Entity
@Table(name = "rate")
public class Ratehexun extends IdEntity {
    
    public Ratehexun() {
    }

    public Ratehexun(Long id) {
        this.id = id;
    }
    /*
    {bank:'中国银行',
    currency:'英镑',
    code:'GBP',
    currencyUnit:'',
    cenPrice:'947.0000',
    buyPrice1:'927.8300',
    sellPrice1:'935.2900',
    buyPrice2:'899.1900',
    sellPrice2:'935.2900',
    releasedate:'2013/5/18 0:08:25'}
    */
    private String bank;
    private String currencyUnit;
    private String sellPrice2;
    private String selfsymbol="RMB";
    private String selfname="人民币";
    private String code;
    private String currency;
    private String buyPrice1;
    private String buyPrice2;  
    private String sellPrice1;
    private String cenPrice;
    private Date releasedate;

    @Transient
    public String getBank() {
        return bank;
    }

    public void setBank(String bank) {
        this.bank = bank;
    }
    @Transient
    public String getCurrencyUnit() {
        return currencyUnit;
    }

    public void setCurrencyUnit(String currencyUnit) {
        this.currencyUnit = currencyUnit;
    }
    @Transient
    public String getSellPrice2() {
        return sellPrice2;
    }

    public void setSellPrice2(String sellPrice2) {
        this.sellPrice2 = sellPrice2;
    }

    public String getSelfsymbol() {
        return selfsymbol;
    }

    public void setSelfsymbol(String selfsymbol) {
        this.selfsymbol = selfsymbol;
    }

    public String getSelfname() {
        return selfname;
    }
    public void setSelfname(String selfname) {
        this.selfname = selfname;
    }
    @Column(name ="symbol")
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
    
    @Column(name="name")
    public String getCurrency() {
        return currency;
    }
    public void setCurrency(String currency) {
        this.currency = currency;
    }
    
    @Column(name="mbuyprice")
    public String getBuyPrice1() {
        return buyPrice1;
    }
    public void setBuyPrice1(String buyPrice1) {
        this.buyPrice1 = buyPrice1;
    }
    
    @Column(name="fbuyprice")
    public String getBuyPrice2() {
        return buyPrice2;
    } 
    public void setBuyPrice2(String buyPrice2) {
        this.buyPrice2 = buyPrice2;
    }
    
    @Column(name="sellprice")
    public String getSellPrice1() {
        return sellPrice1;
    }
    public void setSellPrice1(String sellPrice1) {
        this.sellPrice1 = sellPrice1;
    }
    
    @Column(name="baseprice")
    public String getCenPrice() {
        return cenPrice;
    }
    public void setCenPrice(String cenPrice) {
        this.cenPrice = cenPrice;
    }
    
    @Column(name="date")
    public Date getReleasedate() {
        return releasedate;
    }
    public void setReleasedate(Date releasedate) {
        this.releasedate = releasedate;
    }
    
    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
}