package com.smt.iptv.portal.core;

public enum SystemEnum {
    APPTYPE,
    PROGRAMTYPE,
    INFOTYPE,
    MUSICCATEGORY
}
