package com.smt.iptv.portal.entity;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.portal.core.IdEntity;
@Entity
@Table(name = "virtualchannel")
public class Virtualchannel extends IdEntity {
    
    public Virtualchannel() {
    }

    public Virtualchannel(Long id) {
        this.id = id;
    }
	private int channId=0;;
	private String channCode;
	private String multicastIp;
	private Integer multicastPort;
   
    public int getChannId() {
        return channId;
    }

    public void setChannId(int channId) {
        this.channId = channId;
    }

    public String getChannCode() {
        return channCode;
    }

    public void setChannCode(String channCode) {
        this.channCode = channCode;
    }


    public String getMulticastIp() {
        return multicastIp;
    }

    public void setMulticastIp(String multicastIp) {
        this.multicastIp = multicastIp;
    }

    public Integer getMulticastPort() {
        return multicastPort;
    }

    public void setMulticastPort(Integer multicastPort) {
        this.multicastPort = multicastPort;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}