package com.smt.iptv.portal.service.cmp;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.entity.Timezone;
import com.smt.iptv.portal.repository.TimezoneDao;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class TimezoneService extends BaseService<TimezoneDao, Timezone> {

}
