package com.smt.iptv.portal.i18nentity.program;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.smt.iptv.portal.core.IdEntity;
@Entity
@Table(name = "picturetype")
public class Picturetype extends IdEntity {
    
    public Picturetype() {
    }

    public Picturetype(Long id) {
        this.id = id;
    }
    
    private String picturetypename;
    private String cpobjectcode;
    private String picturetypecode;
    private String description;
    private String filemaxsize;
    private Integer minwidth;   
    private Integer minheight;   
    private Integer maxwidth;   
    private Integer maxheight;
    
    public String getPicturetypename() {
        return picturetypename;
    }

    public void setPicturetypename(String picturetypename) {
        this.picturetypename = picturetypename;
    }

    public String getCpobjectcode() {
        return cpobjectcode;
    }

    public void setCpobjectcode(String cpobjectcode) {
        this.cpobjectcode = cpobjectcode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getFilemaxsize() {
        return filemaxsize;
    }

    public void setFilemaxsize(String filemaxsize) {
        this.filemaxsize = filemaxsize;
    }

    public Integer getMinwidth() {
        return minwidth;
    }

    public void setMinwidth(Integer minwidth) {
        this.minwidth = minwidth;
    }

    public Integer getMinheight() {
        return minheight;
    }

    public void setMinheight(Integer minheight) {
        this.minheight = minheight;
    }

    public Integer getMaxwidth() {
        return maxwidth;
    }

    public void setMaxwidth(Integer maxwidth) {
        this.maxwidth = maxwidth;
    }

    public Integer getMaxheight() {
        return maxheight;
    }

    public void setMaxheight(Integer maxheight) {
        this.maxheight = maxheight;
    }

    public String getPicturetypecode() {
        return picturetypecode;
    }

    public void setPicturetypecode(String picturetypecode) {
        this.picturetypecode = picturetypecode;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}