package com.smt.iptv.portal.i18nrepository.goods;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;

import com.smt.iptv.portal.i18nentity.goods.Categorygoods;
import com.smt.iptv.portal.i18nentity.goods.Goods;
import com.smt.iptv.portal.repository.BaseDao;

public interface CategorygoodsDao  extends BaseDao<Categorygoods>{
    @Query("select DISTINCT p from Goods p where  not exists (select 1 from Categorygoods cp where cp.category.id=?1 and cp.goods.id=p.id)")
    public Page<Goods>  getGoodsExceptCategory(Long categoryid,Pageable pageable);

}
