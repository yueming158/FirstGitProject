package com.smt.iptv.portal.i18nentity.goods;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.portal.core.IdEntity;
import com.smt.iptv.portal.i18nentity.Category;
import com.smt.iptv.portal.model.SystemConstant;
@Entity
@Table(name = "goods")
public class Goods extends IdEntity {

    public Goods() {
    }

    public Goods(Long id) {
        this.id = id;
    }
    
    private String name;
    private String image;

    private Integer price;
    private String saletype;
    private String cuisine;
    private String description;
    private String recommend;
    private List<Category> categorylist;
    
    @ManyToMany
    @JoinTable(
            name="categorygoods",
            joinColumns=@JoinColumn(name="goodsid", referencedColumnName="id"),//控制端列
            inverseJoinColumns=@JoinColumn(name="categoryid", referencedColumnName="id")//被控制端列
            )
    public List<Category> getCategorylist() {
        return categorylist;
    }

    public void setCategorylist(List<Category> categorylist) {
        this.categorylist = categorylist;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public String getSaletype() {
        return saletype;
    }

    public void setSaletype(String saletype) {
        this.saletype = saletype;
    }

    public String getCuisine() {
        return cuisine;
    }

    public void setCuisine(String cuisine) {
        this.cuisine = cuisine;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getRecommend() {
        return recommend;
    }

    public void setRecommend(String recommend) {
        this.recommend = recommend;
    }
    
    @Transient
    public String getImageurl() {
        return SystemConstant.getURLValue("image_server_httpprefix")+image;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
}