package com.smt.iptv.portal.core;

import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;

public class ImageUtil {
    public static void createPreviewImage(String srcFile, String destFile, final  int IMAGE_SIZE) {   
        try {   
            File fi = new File(srcFile); // src   
            File fo = new File(destFile); // dest   
            BufferedImage bis = ImageIO.read(fi);   
  
           int w = bis.getWidth();   
            int h = bis.getHeight();   
            double scale = (double) w / h;   
            int nw = IMAGE_SIZE; // final int IMAGE_SIZE = 120;   
            int nh = (nw * h) / w;   
            if (nh > IMAGE_SIZE) {   
                nh = IMAGE_SIZE;   
                nw = (nh * w) / h;   
           }   
            double sx = (double) nw / w;   
            double sy = (double) nh / h;   
            AffineTransform transform = new AffineTransform();//这句有问题
            transform.setToScale(sx, sy);   
            AffineTransformOp ato = new AffineTransformOp(transform, null);   
            BufferedImage bid = new BufferedImage(nw, nh,   
                    BufferedImage.TYPE_3BYTE_BGR);   
            ato.filter(bis, bid);   
            ImageIO.write(bid, " jpeg ", fo);   
        } catch (Exception e) {   
            e.printStackTrace();   
            throw new RuntimeException(   
                    " Failed in create preview image. Error:  "  
                            + e.getMessage());   
        }   
    }  
}
