package com.smt.iptv.portal.service.hotel;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.entity.Meeting;
import com.smt.iptv.portal.repository.MeetingDao;
import com.smt.iptv.portal.service.cmp.BaseService;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class MeetingService extends BaseService<MeetingDao, Meeting> {
}
