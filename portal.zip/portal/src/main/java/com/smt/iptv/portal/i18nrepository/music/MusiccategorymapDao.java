package com.smt.iptv.portal.i18nrepository.music;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.smt.iptv.portal.i18nentity.music.Music;
import com.smt.iptv.portal.i18nentity.music.Musiccategorymap;
import com.smt.iptv.portal.repository.BaseDao;

public interface MusiccategorymapDao extends BaseDao<Musiccategorymap> {
    @Query("select DISTINCT m from Music m where  not exists (select 1 from Musiccategorymap map where map.musiccategory.id=?1 and map.music.id=m.id)")
    Page<Music> getMusicExceptCategory(Long categoryid, Pageable pageable);
    @Query("update Musiccategorymap cp set cp.sequence=cp.sequence+?1 where musiccategoryid=?2")
    @Modifying
    public void updateAllSequence(Integer offset,Long categoryid);
}
