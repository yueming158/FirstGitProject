package com.smt.iptv.portal.core;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;

import org.apache.commons.codec.binary.Base64;

/**
 * 经典的数字签名算法RSA
 * 数字签名
 * @author kongqz
 * */
public class HHZTRSALicenseGenerater {
    //数字签名，密钥算法
    public static final String KEY_ALGORITHM="RSA";
    
    /**
     * 数字签名
     * 签名/验证算法
     * */
    public static final String SIGNATURE_ALGORITHM="MD5withRSA";

    //私钥
    private static final String PRIVATE_KEY="MIIBUwIBADANBgkqhkiG9w0BAQEFAASCAT0wggE5AgEAAkEA5RPHXeCmA7dUHCwPO3bDloDRLEtg1aShK2la0AIMF/fWBGDesHI8Dety/iGgdP7OujBkW9mdLpcIqD/ILErzlwIDAQABAj8nXz7k47ek692I+gmkLsVvGLTa6Bm8no8U5wa0uaVaeOsIrnw5h+UWpSVd3PYQ9v4McC+AAXSCPb2aGMYRtUECIQD5KiVT8R8w1iplhHWZQJsJ9NPQHwZ9P3bglyUOoBfeHwIhAOtcj8tK3fv6bjvzzQedjCeaIQj15NcfcCj6xxWsTkuJAiAZeQGP71qs93gmIMCVBlHTVsBAyqszKsXQeCNFt4A5KQIgOKCUmDzzG+UtEI+gDO0DA6Q5voYrAPc3bSSpMbW7QMECIQCpGcUDLZPoG++zWnq/MyUvTV+bCgDa5sXzXCeV1qaTpA==";
    //公钥
    private static final String PUBLIC_KEY="MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAOUTx13gpgO3VBwsDzt2w5aA0SxLYNWkoStpWtACDBf31gRg3rByPA3rcv4hoHT+zrowZFvZnS6XCKg/yCxK85cCAwEAAQ==";

    /**
     * 签名
     * @param data待签名数据
     * @param privateKey 密钥
     * @return byte[] 数字签名
     * */
    public static String sign(String data) {
        //取得私钥
        try{
            PKCS8EncodedKeySpec pkcs8KeySpec=new PKCS8EncodedKeySpec(Base64.decodeBase64(PRIVATE_KEY));
            KeyFactory keyFactory=KeyFactory.getInstance(KEY_ALGORITHM);
            //生成私钥
            PrivateKey priKey=keyFactory.generatePrivate(pkcs8KeySpec);
            //实例化Signature
            Signature signature = Signature.getInstance(SIGNATURE_ALGORITHM);
            //初始化Signature
            signature.initSign(priKey);
            //更新
            signature.update(data.getBytes());
            return PUBLIC_KEY+","+Base64.encodeBase64String(signature.sign());
        }catch (Exception e) {
            throw new RuntimeException("加密解密出错");
        }
    }
    /**
     * @param args
     * @throws Exception 
     */
    public static void main(String[] args) throws Exception {

        String license=HHZTRSALicenseGenerater.sign("asdfasdafasdfasdfasdfaer3qsdfasdfqwerfsdfsadfasdfaqwerfdfsdafasdfasdfsdfe");
        System.out.println(license);
        
    }
}
