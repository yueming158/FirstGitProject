package com.smt.iptv.portal.i18nrepository.goods;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.smt.iptv.portal.i18nentity.goods.Goods;
import com.smt.iptv.portal.repository.BaseDao;

public interface GoodsDao extends BaseDao<Goods> {
    @Query(nativeQuery=true,value="delete from goodscart where goodsid=?1")
    @Modifying
    void deleteCartWithGoodsId(Long goodsId);
    
    @Query("delete from Goodsfeatured where goods.id=?1")
    @Modifying
    void deleteFeatured(Long goodsId);
}
