package com.smt.iptv.portal.repository;

import com.smt.iptv.portal.entity.Timezone;

public interface TimezoneDao extends BaseDao<Timezone> {

}
