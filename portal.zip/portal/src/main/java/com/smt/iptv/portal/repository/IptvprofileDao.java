package com.smt.iptv.portal.repository;

import java.math.BigInteger;
import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.smt.iptv.portal.entity.Iptvprofile;

public interface IptvprofileDao extends BaseDao<Iptvprofile> {
//    @Query("select count(p) from Iptvprofile p where p.customer.id=?1")
//    public Long getCountByCustomerId(Long cid);
//    @Query("select count(p) from Iptvprofile p where p.servicegroup.id=?1")
//    public Long getCountByServicegroupId(Long gid);
    @Modifying
    @Query("update Iptvprofile p set p.status=?2 where p.id=?1")
    public void changeStatus(Long id,String status);
    @Modifying
    @Query("update Iptvprofile p set p.macaddress=NULL,p.token=NULL where p.id=?1")
    public void clearmac(Long id);
    public Iptvprofile getByiptvusername(String iptvusername);
    public Iptvprofile getBymacaddress(String macaddress);
    @Query(nativeQuery =true,value="select max(CONVERT(p.iptvusername,SIGNED)) from Iptvprofile p")
    BigInteger getMaxIptvusername();
    @Query("SELECT p.iptvusername from Iptvprofile p WHERE p.epggroupid=?1")
    public List<String> getProfileIdByGroup(Long epggroupid);
}
