package com.smt.iptv.portal.repository;

import com.smt.iptv.portal.entity.Rate;

public interface RateDao extends BaseDao<Rate> {

}
