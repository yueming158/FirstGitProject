package com.smt.iptv.portal.service.cmp;

import java.text.DecimalFormat;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.core.ServiceException;
import com.smt.iptv.portal.i18nentity.program.Mediacontent;
import com.smt.iptv.portal.i18nrepository.program.MediacontentDao;
import com.smt.iptv.portal.service.send.MediaLoaderService;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class MediacontentService extends BaseService<MediacontentDao, Mediacontent> {
    @Autowired
    private VirscheduleService virscheduleService;
    
    @Autowired
    private MediaLoaderService mediaLoaderService;
    
    
    public Long getCountByProgramId(Long programId){
        return dao.getCountByProgramId(programId);
    }
    public List<Mediacontent> getByIds(List<Long> ids){
        return (List<Mediacontent>) dao.findAll(ids);
    }
    @Transactional(readOnly = false)
    public void create(Mediacontent entity,String propertyName,String dcmFmtStr) {
        dao.save(entity);
        int index=dcmFmtStr.indexOf("0");
        dcmFmtStr =dcmFmtStr.substring(0, index)+LocaleContextHolder.getLocale().getLanguage().toUpperCase()+dcmFmtStr.substring(index);
        DecimalFormat dcmFmt = new DecimalFormat(dcmFmtStr);
        String code =dcmFmt.format(entity.getId());
        String methodEnd = propertyName.substring(0,1).toUpperCase() + propertyName.substring(1);
            try {
                entity.getClass().getMethod("set"+methodEnd, String.class).invoke(entity, code);
            } catch (Exception e) {
                throw new ServiceException(e);
            } 
        dao.save(entity);
        mediaLoaderService.regist(entity);
    }
    
    
    @Transactional(readOnly = false)
    public Mediacontent save(Mediacontent entity) {
        
        // 新增或者修改loader
        if(entity.getId()==null||entity.getId()==0L){ 
            dao.save(entity);
            mediaLoaderService.regist(entity);
        }else{
            dao.save(entity);
            mediaLoaderService.update(entity);
        }
        return entity;
    }
    @Transactional(readOnly = false)
    public void deleteByProgramId(Long programId){
        List<Mediacontent> list = dao.getByProgramId(programId);
        mediaLoaderService.delete(list);
        // 删除loader
        dao.deleteByProgramId(programId);
        
    }
    @Transactional(readOnly = false)
    public void delete(Long id) {
        //删除loader
        mediaLoaderService.delete(dao.findOne(id));
        dao.delete(id);
        
       
    }
    @Transactional(readOnly = false)
    public void delete(Mediacontent entity) {
        //删除loader
        mediaLoaderService.delete(dao.findOne(entity.getId()));
        
        dao.delete(entity);
        
        //删除 loader
    }
}