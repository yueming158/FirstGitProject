package com.smt.iptv.portal.service.send;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.net.ftp.FTPClient;

import com.smt.iptv.portal.core.SystemResource;
import com.smt.iptv.portal.model.SystemConstant;

public class socketClient 
{ 

	private Socket cSocket;

	InputStream g_is;
	OutputStream g_dataOut;
	DataInputStream g_in;
	
	public  boolean IniLink(String url,String ip,int port){		
		try 
		{ 	
			cSocket   =   new Socket(); 
			cSocket.connect(new InetSocketAddress(ip,port),3000);
			//cSocket.connect(new InetSocketAddress("192.168.1.87",9000),3000);
			cSocket.setSoTimeout(5000);
			g_is = cSocket.getInputStream();
			g_dataOut = cSocket.getOutputStream();
			//url ="ftp://xjw:123456@60.194.136.206/home/xjw/MediaContent_20130719191826103.xml";
			byte SendData[]= new byte[264];
			int SendDataLen = 264;
			SendData[0] = 29; //0x1d  魔术数
			SendData[1] = 122;  //0x7a
			SendData[2] = 73;//0x49
            SendData[3] = 85;//0x55
            
            SendData[4] = 1; 
            SendData[5] = 0;   //REQ  1  RSP 0
            SendData[6] = 0;            
            SendData[7] = 0; //预留
			
			short length =(short)url.length();
			
			SendData[8] = (byte) length;
			SendData[9] = (byte) (length >> 8); //长度
			
			SendData[10] = 0;  
			SendData[11] = 16;//消息类型
			
			//	SendData[12]-[19] sessoinid
			byte session[]= String.valueOf(Math.random()).substring(2,10).getBytes();
			System.arraycopy(session,0,SendData,12,session.length);
			System.arraycopy(url.getBytes(),0,SendData,20,url.length());//源数组,源数组中的起始位置,目标数组,目标数据中的起始位置,要复制的数组元素的数量
			//先读出总长度再按长度读取 总长度为协议约定	
			g_dataOut.write(SendData, 0, SendDataLen);
			
			g_is.close();
            g_dataOut.close();
            cSocket.close();
		} 
		catch(SocketException e) 
		{
		    throw new RuntimeException("连接CMPS服务失败,CMPS服务可能未启动或已过期,请检查");
		} catch (IOException e) {
            // TODO Auto-generated catch block
		    throw new RuntimeException("连接CMPS服务IO异常");
        } 	
		return true;
	}
	
	/**
	* @returntype void
	* @param n
	*            待转换的short变量
	* @param buf
	*            转换后存放的byte数组
	* @param offset偏移量，字节数组中开始存放的位置
	*/
	public static void short2byte(short n, byte buf[], int offset) {
	   buf[offset] = (byte) (n >> 8);
	   buf[offset + 1] = (byte) n;
	}


	public static void send(String prefix,String xml) {
	    if(!"off".equals(SystemConstant.getValue("needsendcmps"))){
            // 上传xml
            String ftpurl =SystemConstant.getValue("XML_server_ftpurl");//ftp://xjw:123456@60.194.136.206/home/xjw
            
            String username= ftpurl.split("@")[0].split(":")[1].substring(2);
            String pwd= ftpurl.split("@")[0].split(":")[2];
            String ip= ftpurl.split("@")[1].split("/")[0];
            String home= ftpurl.split("@")[1].substring(ip.length());
            String fileName = prefix+"_" + new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date()) + ".xml";
            
            FTPClient ftp = new FTPClient();
            try {
                ftp.connect(ip, 21);
                // 如果采用默认端口，可以使用ftp.connect(url)的方式直接连接FTP服务器
                ftp.login(username, pwd);// 登录
                ftp.changeWorkingDirectory(home);
                
    //            SmtFtpClient sftpClient = new SmtFtpClient();
    //            sftpClient.connectServer(ip, 21, username, pwd, home);
    //            sftpClient.uploadContent(xml, fileName);
    //            sftpClient.closeConnect();
                OutputStream out = ftp.storeUniqueFileStream(fileName);
                if(out!=null){
                out.write(xml.getBytes("UTF-8"));
                out.flush();
                out.close();
                }else{
                    throw new RuntimeException("ftp写文件失败!");
                }
                ftp.abort();
            } catch (SocketException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            // 发送消息到cms
            socketClient s = new socketClient();
            String url =ftpurl + fileName;//String url = "ftp://xjw:123456@60.194.136.206/home/xjw/" + fileName;
            s.IniLink(url,SystemConstant.getValue("CMPS_server_ip"),Integer.parseInt(SystemConstant.getValue("CMPS_server_port")));//s.IniLink(url,"192.168.1.199",5556);
	    }
	}
	
}