package com.smt.iptv.portal.i18nrepository.program;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.smt.iptv.portal.i18nentity.program.Picturetype;
import com.smt.iptv.portal.repository.BaseDao;

public interface PicturetypeDao extends BaseDao<Picturetype> {
    public List<Picturetype> getByPicturetypecode(String picturetypecode);
    @Query("select count(p) from Picture p where p.picturetype.id=?1")
    public Long getByPictureCountByType(Long picturetypeid);
}
