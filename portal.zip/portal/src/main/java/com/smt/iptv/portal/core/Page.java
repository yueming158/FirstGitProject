/**
 * Copyright (c) 2005-2010 springside.org.cn
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * 
 * $Id: Page.java 1183 2010-08-28 08:05:49Z calvinxiu $
 */
package com.smt.iptv.portal.core;

import java.util.ArrayList;
import java.util.List;

import org.springframework.util.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * 与具体ORM实现无关的分页参数及查询结果封装.
 * 
 * 注意所有序号从1开始.
 * 
 * @param <T>
 *            Page中记录的类型.
 * 
 * @author xjw
 */
public class Page<T> {
    // -- 公共变量 --//
    @JsonIgnore
    public static final String ASC = "asc";
    @JsonIgnore
    public static final String DESC = "desc";

    // -- 分页参数 --//
    protected int pageNo = 1;
    protected int pageSize = -1;
    @JsonIgnore
    protected String orderBy = null;
    @JsonIgnore
    protected String order = null;
    @JsonIgnore
    protected boolean autoCount = true;
    @JsonIgnore
    protected int queryMoreRecordFlag = 0;// 是否多查询一条记录来判断是否还有下一页 只能是0和1
    
    protected boolean nextFlag = false;
    
    // -- 返回结果 --//
    protected List<T> result = new ArrayList<T>();
    protected long totalCount = -1;
     // ibatis查询只能带一个条件参数 又分页是必带的参数，所以把查询参数封装到Page中
    @JsonIgnore
    protected Object queryValue1;
    @JsonIgnore
    protected Object queryValue2;
    @JsonIgnore
    protected Object queryValue3;
    @JsonIgnore
    protected Object queryValue4;
    @JsonIgnore
    protected Object queryValue5;
    // -- 构造函数 --//
    public Page() {
    }

    public Page(int pageSize) {
        this.pageSize = pageSize;
    }
    public Page(int pageNo,int pageSize) {
        this.setPageNo(pageNo);
        this.pageSize = pageSize;
    }
    public Page(int pageNo,int pageSize,boolean more) {
        if(more){
            queryMoreRecordFlag=1;
        }
        this.setPageNo(pageNo);
        this.pageSize = pageSize;
    }
    
    // -- 分页参数访问函数 --//
    /**
     * 获得当前页的页号,序号从1开始,默认为1.
     */
    public int getPageNo() {
        return pageNo;
    }

    /**
     * 设置当前页的页号,序号从1开始,低于1时自动调整为1.
     */
    public void setPageNo(final int pageNo) {
        this.pageNo = pageNo;

        if (pageNo < 1) {
            this.pageNo = 1;
        }
    }

    /**
     * 返回Page对象自身的setPageNo函数,可用于连续设置。
     */
    public Page<T> pageNo(final int thePageNo) {
        setPageNo(thePageNo);
        return this;
    }

    /**
     * 获得每页的记录数量, 默认为-1.
     */
    public int getPageSize() {
        return pageSize;
    }

    /**
     * 设置每页的记录数量.
     */
    public void setPageSize(final int pageSize) {
        this.pageSize = pageSize;
    }

    /**
     * 返回Page对象自身的setPageSize函数,可用于连续设置。
     */
    public Page<T> pageSize(final int thePageSize) {
        setPageSize(thePageSize);
        return this;
    }

    /**
     * 根据pageNo和pageSize计算当前页第一条记录在总结果集中的位置,序号从0开始.
     */
    public int getFirst() {
        return ((pageNo - 1) * pageSize);
    }

    /**
     * 获得排序字段,无默认值. 多个排序字段时用','分隔.
     */
    public String getOrderBy() {
        return orderBy;
    }

    /**
     * 设置排序字段,多个排序字段时用','分隔.
     */
    public void setOrderBy(final String orderBy) {
        this.orderBy = orderBy;
    }

    /**
     * 返回Page对象自身的setOrderBy函数,可用于连续设置。
     */
    public Page<T> orderBy(final String theOrderBy) {
        setOrderBy(theOrderBy);
        return this;
    }

    /**
     * 获得排序方向, 无默认值.
     */
    public String getOrder() {
        return order;
    }

    /**
     * 设置排序方式向.
     * 
     * @param order
     *            可选值为desc或asc,多个排序字段时用','分隔.
     */
    public void setOrder(final String order) {
        String lowcaseOrder = order.toLowerCase();

        // 检查order字符串的合法值
        String[] orders = StringUtils.split(lowcaseOrder, ",");
        for (String orderStr : orders) {
            if (!DESC.equals(orderStr) && !ASC.equals(orderStr)) {
                throw new IllegalArgumentException("排序方向" + orderStr + "不是合法值");
            }
        }

        this.order = lowcaseOrder;
    }

    /**
     * 返回Page对象自身的setOrder函数,可用于连续设置。
     */
    public Page<T> order(final String theOrder) {
        setOrder(theOrder);
        return this;
    }

    /**
     * 是否已设置排序字段,无默认值.
     */
    @JsonIgnore
    public boolean isOrderBySetted() {
        return (StringUtils.hasText(orderBy) && StringUtils.hasText(order));
    }

    /**
     * 获得查询对象时是否先自动执行count查询获取总记录数, 默认为false.
     */
    public boolean isAutoCount() {
        return autoCount;
    }

    /**
     * 设置查询对象时是否自动先执行count查询获取总记录数.
     */
    public void setAutoCount(final boolean autoCount) {
        this.autoCount = autoCount;
    }

    /**
     * 返回Page对象自身的setAutoCount函数,可用于连续设置。
     */
    public Page<T> autoCount(final boolean theAutoCount) {
        setAutoCount(theAutoCount);
        return this;
    }

    // -- 访问查询结果函数 --//

    /**
     * 获得页内的记录列表.
     */
    public List<T> getResult() {
        return result;
    }

    /**
     * 设置页内的记录列表.
     */
    public void setResult(final List<T> result) {
        this.result = result;
    }

    /**
     * 获得总记录数, 默认值为-1.
     */
    public long getTotalCount() {
        return totalCount;
    }

    /**
     * 设置总记录数.
     */
    public void setTotalCount(final long totalCount) {
        this.totalCount = totalCount;
    }

    /**
     * 根据pageSize与totalCount计算总页数, 默认值为-1.
     */
    public long getTotalPages() {
        if (totalCount < 0) {
            return -1;
        }

        long count = totalCount / pageSize;
        if (totalCount % pageSize > 0) {
            count++;
        }
        return count;
    }

    /**
     * 是否还有下一页.
     */
    public boolean isHasNext() {
        if (queryMoreRecordFlag == 0) {
            nextFlag = (pageNo + 1 <= getTotalPages());
        }
        return nextFlag;
    }

    public void setNextFlag(boolean nextFlag) {
        this.nextFlag = nextFlag;
    }

    public int getQueryMoreRecordFlag() {
        return queryMoreRecordFlag;
    }

    public void setQueryMoreRecordFlag(int queryMoreRecordFlag) {
        if (queryMoreRecordFlag != 0) {
            this.queryMoreRecordFlag = 1;
        } else {
            this.queryMoreRecordFlag = 0;
        }
    }
    
    /**
     * 查询时使用的每页记录数
     * @return
     */
    protected int getQuerySize(){
        return pageSize+queryMoreRecordFlag;
    }
    /**
     * 取得下页的页号, 序号从1开始. 当前页为尾页时仍返回尾页序号.
     */
    public int getNextPage() {
        if (isHasNext()) {
            return pageNo + 1;
        } else {
            return pageNo;
        }
    }

    /**
     * 是否还有上一页.
     */
    public boolean isHasPre() {
        return (pageNo - 1 >= 1);
    }

    /**
     * 取得上页的页号, 序号从1开始. 当前页为首页时返回首页序号.
     */
    public int getPrePage() {
        if (isHasPre()) {
            return pageNo - 1;
        } else {
            return pageNo;
        }
    }

    public Object getQueryValue1() {
        return queryValue1;
    }

    public void setQueryValue1(Object queryValue1) {
        this.queryValue1 = queryValue1;
    }

    public Object getQueryValue2() {
        return queryValue2;
    }

    public void setQueryValue2(Object queryValue2) {
        this.queryValue2 = queryValue2;
    }

    public Object getQueryValue3() {
        return queryValue3;
    }

    public void setQueryValue3(Object queryValue3) {
        this.queryValue3 = queryValue3;
    }

    public Object getQueryValue4() {
        return queryValue4;
    }

    public void setQueryValue4(Object queryValue4) {
        this.queryValue4 = queryValue4;
    }

    public Object getQueryValue5() {
        return queryValue5;
    }

    public void setQueryValue5(Object queryValue5) {
        this.queryValue5 = queryValue5;
    }
    public void initqueryValue(Object [] objects ){
        for(int i=0;i<objects.length;i++){
            switch (i) {
            case 0:
                this.queryValue1=objects[i];
                break;
            case 1:
                this.queryValue2=objects[i];
                break;
            case 2:
                this.queryValue3=objects[i];
                break;
            case 3:
                this.queryValue4=objects[i];
                break;
            case 4:
                this.queryValue5=objects[i];
                break;
            default:
                break;
            }
        }
    }
}
