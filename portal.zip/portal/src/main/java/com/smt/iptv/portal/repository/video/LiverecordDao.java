package com.smt.iptv.portal.repository.video;

import java.math.BigInteger;
import java.util.Date;

import org.springframework.data.jpa.repository.Query;

import com.smt.iptv.portal.entity.Liverecord;
import com.smt.iptv.portal.repository.BaseDao;

public interface LiverecordDao extends BaseDao<Liverecord> {
    @Query(nativeQuery=true,value="select count(id) from liverecord r where r.chancode=?1 and r.starttime>=?2 and r.starttime<?3")
    BigInteger getInnerCrossTimeRecor(String chancode,Date starttime,Date endtime);
    
    @Query(nativeQuery=true,value="select count(id) from liverecord r where r.chancode=?1 and r.starttime<=?2 and r.endtime>?2")
    BigInteger getOuterCrossTimeRecord(String chancode,Date starttime);
    
    @Query(nativeQuery=true,value="select count(id) from liverecord r where r.id<>?1 and r.chancode=?2 and r.starttime>=?3 and r.starttime<?4 ")
    BigInteger getInnerCrossTimeRecor(Long id,String chancode,Date starttime,Date endtime);
    
    @Query(nativeQuery=true,value="select count(id) from liverecord r where r.id<>?1 and r.chancode=?2 and r.starttime<=?3 and r.endtime>?3")
    BigInteger getOuterCrossTimeRecord(Long id,String chancode,Date starttime);
}
