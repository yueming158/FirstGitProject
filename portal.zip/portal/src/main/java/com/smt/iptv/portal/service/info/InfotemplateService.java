package com.smt.iptv.portal.service.info;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.i18nentity.info.Infotemplate;
import com.smt.iptv.portal.i18nrepository.info.InfotemplateDao;
import com.smt.iptv.portal.service.cmp.BaseService;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class InfotemplateService {//extends BaseService<InfotemplateDao, Infotemplate> {
    @Autowired
    private InfotemplateDao dao;
    
    public Infotemplate getByCode(String code){
        return dao.getByCode(code);
    }
    @Transactional(readOnly = false)
    public void save(Iterable<Infotemplate> entities) {
        dao.save(entities);
    }
    public List<Infotemplate> getAll() {
        return (List<Infotemplate>) dao.findAll();
    }
    public List<Infotemplate> getEnabledAll() {
        return (List<Infotemplate>) dao.getEnabledAll();
    }
    public Infotemplate buildInfotemplate(String name){
        return null;
    }
}
