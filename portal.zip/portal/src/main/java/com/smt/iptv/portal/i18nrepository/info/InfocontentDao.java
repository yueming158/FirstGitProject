package com.smt.iptv.portal.i18nrepository.info;

import java.util.List;

import com.smt.iptv.portal.i18nentity.info.Infocontent;
import com.smt.iptv.portal.repository.BaseDao;

public interface InfocontentDao extends BaseDao<Infocontent> {
    List<Infocontent> getByMenucodeAndEpggroupid(String code,Long epggroupid);
}
