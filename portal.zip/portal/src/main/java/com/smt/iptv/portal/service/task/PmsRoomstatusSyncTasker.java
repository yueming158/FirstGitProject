package com.smt.iptv.portal.service.task;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketException;
import java.text.ParseException;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springside.modules.mapper.JaxbMapper;

import com.smt.iptv.portal.core.Result;
import com.smt.iptv.portal.entity.hotel.Hotelcustomer;
import com.smt.iptv.portal.entity.hotel.Hotelroom;
import com.smt.iptv.portal.model.SystemConstant;
import com.smt.iptv.portal.push.MyClient;
import com.smt.iptv.portal.service.hotel.HotelcustomerService;
import com.smt.iptv.portal.service.hotel.HotelroomService;

@Component
public class PmsRoomstatusSyncTasker {
    private static final Logger logger = LoggerFactory.getLogger(MyClient.class);
    private final static String requestXML = "<IpmsRequest><RoomStatuses></RoomStatuses></IpmsRequest>";
    private final static String datePattern = "yyyy-MM-dd HH:mm";
    private final static String myatePattern = "yyyy-MM-dd HH:mm:ss";
    @Autowired
    private HotelcustomerService hotelcustomerService;

    @Autowired
    private HotelroomService hotelroomService;
    /**
     * 同步房间状态
     */
    public void syncRoomstatus() {
        String pmsip=SystemConstant.getValue("luopanpms_ip");
        int pmsport=9871;
        try{
            pmsport= Integer.parseInt(SystemConstant.getValue("luopanpms_port"));
        }catch (Exception e) {
        }
        String str=refreshRommstatus(pmsip, pmsport);
        //System.out.println(str);
        int index=str.lastIndexOf("</RoomStatus>");
        //str=str.substring(0, index)+"</RoomStatus></RoomStatuses></IpmsResponse>"; 
        RoomstatusResponse response = JaxbMapper.fromXml(str, RoomstatusResponse.class);
        for(RoomStatus roomStatus:response.getRoomStatuses()){
            if(StringUtils.isNotEmpty(roomStatus.getRoomNo())){
                Hotelcustomer hotelcustomer = hotelcustomerService.getLastGuestByRoomno(roomStatus.getRoomNo());
                if(hotelcustomer!=null&&"2".equals(hotelcustomer.getStatus())){//数据库未入住
                    if(StringUtils.isNotEmpty(roomStatus.getGuestName())){//PMS已经入住
                        //更新
                        //System.out.println("1:"+roomStatus.getRoomNo());
                        try {
                            pmsacheckin(roomStatus.getRoomNo(), roomStatus.getGuestName(), roomStatus.getIdCardNo(),
                                   roomStatus.getCheckInTime()+":00" , roomStatus.getCheckOutTime()+":00", "1", "30", null);
                        } catch (Exception e) {
                            logger.error(e.getMessage());
                        }
                    }
                    //System.out.println("5:"+roomStatus.getRoomNo());
                }else{//
                    if(hotelcustomer!=null&&hotelcustomer.getCheckintime()!=null&&hotelcustomer.getCustomername()!=null
                            &&DateFormatUtils.format(hotelcustomer.getCheckintime(), datePattern).equals(roomStatus.getCheckInTime())
                                &&hotelcustomer.getCustomername().equals(roomStatus.getGuestName())){
                        //不做刷新
                        //System.out.println("2:"+roomStatus.getRoomNo());
                    }else{
                        //做刷新  
                        if(StringUtils.isNotEmpty(roomStatus.getGuestName())){
                            //System.out.println("3:"+roomStatus.getRoomNo());
                            try {
                                pmsacheckin(roomStatus.getRoomNo(), roomStatus.getGuestName(), roomStatus.getIdCardNo(),
                                        roomStatus.getCheckInTime()+":00" , roomStatus.getCheckOutTime()+":00", "1", "30", null);
                            } catch (Exception e) {
                                logger.error(e.getMessage());
                            }
                        }else{
                            //System.out.println("4:"+roomStatus.getRoomNo());
                            pmsacheckout(roomStatus.getRoomNo(), DateFormatUtils.format(new Date(), myatePattern));
                        }
                    }
                    
                }
                
                
            }
        }
    }

    public static void main(String[] args) {

        
        
    }

    public static String refreshRommstatus(String ip, int port) {
        String response="";
        try {
            Socket cSocket = new Socket();
            cSocket.connect(new InetSocketAddress(ip, port), 3000);
            // cSocket.connect(new InetSocketAddress("192.168.1.87",9000),3000);
            cSocket.setSoTimeout(5000);
            cSocket.setReceiveBufferSize(255 * 255);
            InputStream g_is = cSocket.getInputStream();
            OutputStream g_dataOut = cSocket.getOutputStream();
            byte[] responselenth = new byte[2];
            // 先读出总长度再按长度读取 总长度为协议约定
            g_dataOut.write(requestXML.getBytes(), 0, requestXML.getBytes().length);
            g_is.read(responselenth);

            byte[] lengthArr = { 0, 0, responselenth[0], responselenth[1] };
            int length = bytesToInt2(lengthArr, 0);
            byte[] data = new byte[length];
            
            //为了防止网络丢包问题 代替g_is.read(data);
            int nIdx = 0;
            int nTotalLen = data.length;
            int nReadLen = 0; 
            while (nIdx < nTotalLen)
            {
                nReadLen = g_is.read(data, nIdx, nTotalLen - nIdx);
               
                if (nReadLen > 0)
                {
                    nIdx = nIdx + nReadLen;
                }
                else
                {
                    break;
                }
            }
            //g_is.read(data);
            //数据读取结束
            
            response= new String(data, "UTF-8");
            g_is.close();
            g_dataOut.close();
            cSocket.close();
        } catch (SocketException e) {
            throw new RuntimeException("连接罗盘PMS服务失败");
        } catch (IOException e) {
            // TODO Auto-generated catch block
            throw new RuntimeException("连接罗盘PMS服务IO异常");
        }
        return response;
    }

    private static byte[] intToBytes(int value) {
        byte[] src = new byte[4];
        src[3] = (byte) ((value >> 24) & 0xFF);
        src[2] = (byte) ((value >> 16) & 0xFF);
        src[1] = (byte) ((value >> 8) & 0xFF);
        src[0] = (byte) (value & 0xFF);
        return src;
    }

    /**
     * 将int数值转换为占四个字节的byte数组，本方法适用于(高位在前，低位在后)的顺序。 和bytesToInt2（）配套使用
     */
    private static byte[] intToBytes2(int value) {
        byte[] src = new byte[4];
        src[0] = (byte) ((value >> 24) & 0xFF);
        src[1] = (byte) ((value >> 16) & 0xFF);
        src[2] = (byte) ((value >> 8) & 0xFF);
        src[3] = (byte) (value & 0xFF);
        return src;
    }

    /**
     * byte数组中取int数值，本方法适用于(低位在前，高位在后)的顺序，和和intToBytes（）配套使用
     * 
     * @param src
     *            byte数组
     * @param offset
     *            从数组的第offset位开始
     * @return int数值
     */
    private static int bytesToInt(byte[] src, int offset) {
        int value;
        value = (int) ((src[offset] & 0xFF) | ((src[offset + 1] & 0xFF) << 8) | ((src[offset + 2] & 0xFF) << 16) | ((src[offset + 3] & 0xFF) << 24));
        return value;
    }

    /**
     * byte数组中取int数值，本方法适用于(低位在后，高位在前)的顺序。和intToBytes2（）配套使用
     */
    private static int bytesToInt2(byte[] src, int offset) {
        int value;
        value = (int) (((src[offset] & 0xFF) << 24) | ((src[offset + 1] & 0xFF) << 16) | ((src[offset + 2] & 0xFF) << 8) | (src[offset + 3] & 0xFF));
        return value;
    }
    


    public Result pmsacheckin(String roomNo,String name, String identityCard,
            String beginTime,String endTime,String sex,String age,HttpServletRequest request) throws ParseException, UnsupportedEncodingException {
        //name = URLDecoder.decode(name,"utf-8");
        if(roomNo==null||name==null){
            return new Result(false, "");
        }
        synchronized (this) {   
            List<Hotelcustomer> list =hotelcustomerService.getByRoomnoNotEpmpty(roomNo);
            if(list!=null&&list.size()>0){
                for(Hotelcustomer hc:list){
                    if("1".equals(hc.getStatus())){
                           //重复的入住消息
                        if(name.equals(hc.getCustomername())||name.equals(hc.getEnglishname())){
                                return new Result();
                        }else{
                            hotelcustomerService.checkout(hc);
                        }
                    }
                }
            }
            List<Hotelroom> rooms = hotelroomService.getByRoomno(roomNo);
            if(rooms!=null&&rooms.size()>0){
                for(Hotelroom room:rooms){
                    Hotelcustomer newHotelcustomer=new Hotelcustomer();
                    Long hotelroomid=room.getId();
                    newHotelcustomer.setCheckintime(DateUtils.parseDate(beginTime, "yyyy-MM-dd HH:mm:ss"));;
                    newHotelcustomer.setCheckouttime(DateUtils.parseDate(endTime, "yyyy-MM-dd HH:mm:ss"));
                    newHotelcustomer.setCustomername(name);
                    newHotelcustomer.setEnglishname(name);
                    newHotelcustomer.setHotelroom(new Hotelroom(hotelroomid));
                    newHotelcustomer.setIdentitycard(identityCard);
                    newHotelcustomer.setSex(sex);
                    newHotelcustomer.setStatus("1");
                    hotelcustomerService.checkin(newHotelcustomer);
                }
            }
        }
        return new Result();
    }
    
    public Result pmsacheckout(String roomNo,String ckoutTime) {
        List<Hotelcustomer> list =hotelcustomerService.getByRoomnoNotEpmpty(roomNo);
        if(list!=null&&list.size()>0){
            for(Hotelcustomer hc:list){
                 hotelcustomerService.checkout(hc);
            }
        }
        return new Result();
    }
    
    
    
    
    
    
}
