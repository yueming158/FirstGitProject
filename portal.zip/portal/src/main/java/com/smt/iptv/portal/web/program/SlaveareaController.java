package com.smt.iptv.portal.web.program;

import java.util.List;
import java.util.Map;

import javax.servlet.ServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Maps;
import com.smt.iptv.portal.entity.Slavearea;
import com.smt.iptv.portal.entity.Slavechannel;
import com.smt.iptv.portal.service.cmp.SlaveareaService;
import com.smt.iptv.portal.service.cmp.SlavechannelService;

/**
 * @author xjw
 */
@Controller
@RequestMapping(value = "/slavearea")
public class SlaveareaController {

	private static final int PAGE_SIZE = 50;

	private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
	static {
		sortTypes.put("id", "编码");
		sortTypes.put("name", "名称");
	}

	@Autowired
	private SlaveareaService slaveareaService;
	@Autowired
	private SlavechannelService slavechannelService;
	@RequestMapping(value = "/list")
	public String list(@RequestParam(value = "sortType", defaultValue = "id") String sortType,
			@RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
		Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");

		Page<Slavearea> slaveareas = slaveareaService.getPage( searchParams, pageNumber, PAGE_SIZE, sortType);

		model.addAttribute("slaveareas", slaveareas);
		model.addAttribute("sortType", sortType);
		model.addAttribute("sortTypes", sortTypes);
		// 将搜索条件编码成字符串，用于排序，分页的URL
		model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
		return "slavearea/slaveareaList";
	}

	@RequestMapping(value = "create", method = RequestMethod.GET)
	public String createForm(Model model) {
		model.addAttribute("slavearea", new Slavearea());
		model.addAttribute("action", "create");
		return "slavearea/slaveareaForm";
	}

	@RequestMapping(value = "create", method = RequestMethod.POST)
	public String create(@Valid Slavearea slavearea, RedirectAttributes redirectAttributes) {
	    slaveareaService.save(slavearea);
		redirectAttributes.addFlashAttribute("message", "新增成功");
		return "redirect:/slavearea/list";
	}

	@RequestMapping(value = "update/{id}", method = RequestMethod.GET)
	public String updateForm(@PathVariable("id") Long id,Model model) {
		model.addAttribute("slavearea", slaveareaService.findOne(id));
		model.addAttribute("action", "update");
		return "slavearea/slaveareaForm";
	}

	@RequestMapping(value = "update", method = RequestMethod.POST)
	public String update(@Valid @ModelAttribute("preloadArea") Slavearea slavearea,String channelid, RedirectAttributes redirectAttributes) {
	    slaveareaService.save(slavearea);
		redirectAttributes.addFlashAttribute("message", "保存成功");
		//return "redirect:/slavearea/list";
		return "redirect:/slavearea/list";
	}

	@RequestMapping(value = "delete/{id}")
	public String delete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
	    slaveareaService.delete(id);
		redirectAttributes.addFlashAttribute("message", "删除成功");
		return "redirect:/slavearea/list";
	}

	/**
	 * 使用@ModelAttribute, 实现Struts2 Preparable二次部分绑定的效果,先根据form的id从数据库查出Area对象,再把Form提交的内容绑定到该对象上。
	 * 因为仅update()方法的form中有id属性，因此本方法在该方法中执行.
	 */
	@ModelAttribute("preloadArea")
	public Slavearea getSlavearea(@RequestParam(value = "id", required = false) Long id) {
		if (id != null) {
			return slaveareaService.findOne(id);
		}
		return null;
	}
	
	
    @RequestMapping(value = "updateslave", method = RequestMethod.GET)
    public String updateslave(Long channelid, Model model) {
       // model.addAttribute("customers", customerService.getAll());
        Slavechannel slavechannel = slavechannelService.getByChannelId(channelid);
        List<Slavearea> slaveareas = slaveareaService.getAll();
        if(slaveareas!=null&&slavechannel!=null)
            for(Slavearea slavearea :slaveareas){
                if(slavechannel.getAreacode().indexOf("all")!=-1){
                    slavearea.setSelected(true);
                }else if(slavechannel.getAreacode().indexOf(slavearea.getId()+"")!=-1){
                    slavearea.setSelected(true);
                }else{
                    slavearea.setSelected(false);
                }
            }
        model.addAttribute("slavechannel",slavechannel);
        model.addAttribute("slaveareas",slaveareas );
        return "slavearea/updatechannelslave";
    }

    @RequestMapping(value = "updateslave", method = RequestMethod.POST)
    public String updateslave(Slavechannel slavechannel,String [] slavearea,String allarea, RedirectAttributes redirectAttributes) {
        String areacode =",";

        if(slavearea!=null)
        for(String code:slavearea){
            areacode+=code+",";
        }
        slavechannel.setAreacode(areacode);
        if(allarea!=null){
            slavechannel.setAreacode("all");
        }
        slavechannelService.save(slavechannel);
        redirectAttributes.addFlashAttribute("message", "保存成功");
        return "redirect:/slavearea/updateslave?channelid="+slavechannel.getChannel().getId();
        
    }
	
}
