package com.smt.iptv.portal.repository.video;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.smt.iptv.portal.entity.Schedule;
import com.smt.iptv.portal.repository.BaseDao;

public interface ScheduleDao extends BaseDao<Schedule> {
    @Query("select s from Schedule s where s.channel.id=?1 and s.scheduledate=?2")
    List<Schedule> getScheduleList(Long channelid, Date now);
    @Query("delete from Schedule s where s.channel.id=?1")
    @Modifying
    void deleteByChannelId(Long id);
    
    @Query("delete from Schedule s where s.channel.id=?1 and s.scheduledate=?2")
    @Modifying
    void deleteDuplicate(Long channelid,Date date);
    
    @Query("delete from Schedule s where s.scheduledate<?1")
    @Modifying
    void deleteold(Date date);

    @Query("select s from Schedule s where s.channel.tvmaourl=?1 and s.scheduledate=?2")
    List<Schedule>  getScheduleByTvsouurl(String tvsouurl ,Date date);
}
