package com.smt.iptv.portal.entity;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.smt.iptv.portal.core.IdEntity;
@Entity
@Table(name = "schedule")
public class Schedule extends IdEntity {
    
    public Schedule() {
    }

    public Schedule(Long id) {
        this.id = id;
    }
    public Schedule(Long channelid,String [] dataArr){
        if(dataArr==null||(dataArr.length!=4&&dataArr.length!=3)){
            throw new RuntimeException("excel导入数据格式不正确");
        }
        this.channel = new Channel(channelid);
        this.schedulename=dataArr[0];
        //this.searchname =CnToSpell.getSimpleSpell(this.schedulename);
        try {
            if(dataArr[1].contains("-")){
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                this.starttime=sdf.parse(dataArr[1]);
                this.endtime=sdf.parse(dataArr[2]);
            }else if(dataArr[1].contains(".")){
                SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss");
                this.starttime=sdf2.parse(dataArr[1]);
                this.endtime=sdf2.parse(dataArr[2]);
            }else{
                throw new RuntimeException("excel导入数据时间格式不正确");
            }
            this.scheduledate =this.starttime;
            this.duration= (int)(this.endtime.getTime()-this.starttime.getTime());
        } catch (ParseException e) {
            throw new RuntimeException("excel导入数据时间格式不正确");
        }
        this.hotflag="1";//dataArr[3].substring(0,1);
        this.deleteflag ="1";
    }
    
    public Schedule(Long channelid,Date starttime,String schedulename){
        this.channel = new Channel(channelid);
        this.schedulename=schedulename;
        this.starttime=starttime;
        this.scheduledate =this.starttime;
        this.hotflag="1";
        this.deleteflag ="1";
    }
    @JsonIgnore
    private Channel channel;
	private String schedulename;
	@JsonIgnore
	private String cpobjectcode;
	@JsonIgnore
	private String searchname;
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date scheduledate;
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date starttime;
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonIgnore
	private Date endtime;
	private String hotflag;
	@JsonIgnore
	private Integer duration;
	private String deleteflag;
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date createdate;
	@JsonIgnore
    private String description;

    @ManyToOne
    @JoinColumn(name = "channelid")
    public Channel getChannel() {
        return channel;
    }

    public void setChannel(Channel channel) {
        this.channel = channel;
    }

    public String getSchedulename() {
        return schedulename;
    }

    public void setSchedulename(String schedulename) {
        this.schedulename = schedulename;
    }

    public String getCpobjectcode() {
        return cpobjectcode;
    }

    public void setCpobjectcode(String cpobjectcode) {
        this.cpobjectcode = cpobjectcode;
    }

    public String getSearchname() {
        return searchname;
    }

    public void setSearchname(String searchname) {
        this.searchname = searchname;
    }

    public Date getScheduledate() {
        return scheduledate;
    }

    public void setScheduledate(Date scheduledate) {
        this.scheduledate = scheduledate;
    }

    public Date getStarttime() {
        return starttime;
    }

    public void setStarttime(Date starttime) {
        this.starttime = starttime;
    }

    public Date getEndtime() {
        return endtime;
    }

    public void setEndtime(Date endtime) {
        this.endtime = endtime;
    }

    public String getHotflag() {
        return hotflag;
    }

    public void setHotflag(String hotflag) {
        this.hotflag = hotflag;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public String getDeleteflag() {
        return deleteflag;
    }

    public void setDeleteflag(String deleteflag) {
        this.deleteflag = deleteflag;
    }

    public Date getCreatedate() {
        return createdate;
    }

    public void setCreatedate(Date createdate) {
        this.createdate = createdate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}