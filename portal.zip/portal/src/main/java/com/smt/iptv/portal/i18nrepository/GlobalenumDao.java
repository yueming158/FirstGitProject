package com.smt.iptv.portal.i18nrepository;

import java.util.List;

import com.smt.iptv.portal.i18nentity.Globalenum;
import com.smt.iptv.portal.repository.BaseDao;

public interface GlobalenumDao extends BaseDao<Globalenum>{
    public List<Globalenum> getByType(String type);
}
