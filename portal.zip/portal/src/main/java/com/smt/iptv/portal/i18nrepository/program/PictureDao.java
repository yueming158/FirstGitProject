package com.smt.iptv.portal.i18nrepository.program;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.smt.iptv.portal.i18nentity.program.Picture;
import com.smt.iptv.portal.repository.BaseDao;

public interface PictureDao extends BaseDao<Picture> {
    @Query("delete from Picture p where p.program.id=?1")
    @Modifying
    public void deleteByProgramId(Long programId);
    @Query("delete from Picture p where p.program.id=?1 and p.picturetype.id=?2")
    @Modifying
    public void deleteByProgramIdAndPicturetypeid(Long programId,Long picturetypeId);
    
    public Picture getByProgramIdAndPicturetypeId(Long programId,Long picturetypeId);
}
