package com.smt.iptv.portal.web.program;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Maps;
import com.smt.iptv.portal.core.SystemResource;
import com.smt.iptv.portal.entity.Channelgroup;
import com.smt.iptv.portal.entity.Iptvprofile;
import com.smt.iptv.portal.entity.aaa.Account;
import com.smt.iptv.portal.entity.aaa.Attr;
import com.smt.iptv.portal.entity.hotel.Hotelroom;
import com.smt.iptv.portal.push.PushServer;
import com.smt.iptv.portal.service.aaa.AttrService;
import com.smt.iptv.portal.service.cmp.ChannelgroupService;
import com.smt.iptv.portal.service.cmp.EpggroupService;
import com.smt.iptv.portal.service.cmp.IptvprofileService;
import com.smt.iptv.portal.service.excel.ExcelDataArray;
import com.smt.iptv.portal.service.excel.POIExcelUtilProcess;
import com.smt.iptv.portal.service.hotel.HotelroomService;

/**
 * @author xjw
 */
@Controller
@RequestMapping(value = "/iptvprofile")
public class IptvprofileController {
	private static final String PERSONAL_USER_TYPE="1";
    private static final int PAGE_SIZE = 100;

    private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
    static {
        sortTypes.put("auto", "自动");
        sortTypes.put("iptvusername", "名称");
    }

    @Autowired
    private IptvprofileService iptvprofileService;
    @Autowired
    private HotelroomService hotelroomService;
    @Autowired
    private ChannelgroupService channelgroupService;
    @Autowired
    private EpggroupService epggroupService;
    @Autowired
    private AttrService attrService;
    @RequestMapping(value = "/list")
    public String list(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");

        Page<Hotelroom> hotelrooms = hotelroomService.getPage(searchParams, pageNumber, PAGE_SIZE, sortType);
        if (hotelrooms != null) {
            List<String> usernames = PushServer.getLonginUsers();
            for (Hotelroom hotelroom : hotelrooms.getContent()) {
                for (String username : usernames) {
                    if (hotelroom.getIptvprofile().getIptvusername().equals(username)) {
                        hotelroom.getIptvprofile().setLoginstatus("O");
                        break;
                    }
                }
            }
        }
        model.addAttribute("hotelrooms", hotelrooms);
        model.addAttribute("epggroups", epggroupService.getAll());//group
        model.addAttribute("sortType", sortType);
        model.addAttribute("sortTypes", sortTypes);
        // 将搜索条件编码成字符串，用于排序，分页的URL
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
        model.addAttribute("hotspot", SystemResource.getString("hotspot"));
        model.addAttribute("vodfree", SystemResource.getString("vodfree"));
        model.addAttribute("onlylive", SystemResource.getString("onlylive"));
        return "iptvprofile/iptvprofileList";
    }

    @RequestMapping(value = "/create", method = RequestMethod.GET)
    public String createForm(Model model) {
        Hotelroom hotelroom = new Hotelroom();
        Iptvprofile p = new Iptvprofile();
        p.setAttrList(attrService.getByUsetype(Attr.TYPE_USER));
        hotelroom.setIptvprofile(p);
        p.setIptvusername(String.valueOf(iptvprofileService.getMaxIptvusername()+ 1));
        model.addAttribute("hotelroom", hotelroom);
        List<Channelgroup> channelgroups = channelgroupService.getAll();
        model.addAttribute("channelgroups", channelgroups);
        model.addAttribute("epggroups", epggroupService.getAll());//group
        model.addAttribute("action", "create");
        model.addAttribute("hotspot", SystemResource.getString("hotspot"));
        model.addAttribute("vodfree", SystemResource.getString("vodfree"));
        model.addAttribute("onlylive", SystemResource.getString("onlylive"));
        return "iptvprofile/iptvprofileForm";
    }

    @RequestMapping(value = "create", method = RequestMethod.POST)
    public String create(Hotelroom hotelroom, RedirectAttributes redirectAttributes, Long channelgroupid, String roomname,HttpServletRequest request) {
        Iptvprofile newIptvprofile =hotelroom.getIptvprofile();
        
        List<Attr> attrsList=attrService.getByUsetype(Attr.TYPE_USER);
        if(attrsList!=null){
            for(Attr attr:attrsList){
                attr.setValue(request.getParameter(attr.getAttrkey()));
            }
        }
        newIptvprofile.setAttrList(attrsList);
        
        newIptvprofile.setChannelgroup(new Channelgroup(channelgroupid));
        newIptvprofile.setStatus("0");// 默认状态未激活
        newIptvprofile.setIptvpassword("111111");// 默认密码
        if (StringUtils.isBlank(newIptvprofile.getMacaddress())) {
            newIptvprofile.setMacaddress(null);
        } else {
            newIptvprofile.setMacaddress(newIptvprofile.getMacaddress().toUpperCase());
        }
        
        //如果是个人用户
        //如果是个人用户 设置默认房间名
        if(PERSONAL_USER_TYPE.equals(hotelroom.getUsetype())){
            hotelroom.setRoomname("P"+newIptvprofile.getIptvusername());
            hotelroom.setRoomno("P"+newIptvprofile.getIptvusername());
        }
        //如果是个人用户 end
        hotelroomService.save(hotelroom);	
        redirectAttributes.addFlashAttribute("message", "创建用户成功");
        return "redirect:/iptvprofile/list";
    }

    @RequestMapping(value = "update/{id}", method = RequestMethod.GET)
    public String updateForm(@PathVariable("id") Long id, Model model) {
        Hotelroom hotelroom = hotelroomService.findOne(id);
        List<Attr> oldattrs=hotelroom.getIptvprofile().getAttrList();
        List<Attr> newattrs=attrService.getByUsetype(Attr.TYPE_USER);
        if(oldattrs!=null&&newattrs!=null){
            for(Attr attr: newattrs){
                for(int i=0;i<oldattrs.size();i++){
                    Attr old =oldattrs.get(i);
                    if(attr.getAttrkey()!=null&&attr.getAttrkey().equals(old.getAttrkey())){
                        attr.setValue(old.getValue());
                        oldattrs.remove(i);
                        break;
                    }
                }
            }
        }
        hotelroom.getIptvprofile().setAttrList(newattrs);
        model.addAttribute("hotelroom", hotelroom);
        model.addAttribute("channelgroups", channelgroupService.getAll());
        model.addAttribute("epggroups", epggroupService.getAll());//group
        model.addAttribute("action", "update");
        model.addAttribute("hotspot", SystemResource.getString("hotspot"));
        model.addAttribute("vodfree", SystemResource.getString("vodfree"));
        model.addAttribute("onlylive", SystemResource.getString("onlylive"));
        return "iptvprofile/iptvprofileForm";
    }

    @RequestMapping(value = "update", method = RequestMethod.POST)
    public ModelAndView update(@Valid @ModelAttribute("preloadHotelroom") Hotelroom hotelroom, Long channelgroupid, String page,String sortType,
            HttpServletRequest request,RedirectAttributes redirectAttributes) {
        Iptvprofile iptvprofile = hotelroom.getIptvprofile();
        
        List<Attr> attrsList=attrService.getByUsetype(Attr.TYPE_USER);
        if(attrsList!=null){
            for(Attr attr:attrsList){
                attr.setValue(request.getParameter(attr.getAttrkey()));
            }
        }
        iptvprofile.setAttrList(attrsList);
        
        iptvprofile.setChannelgroup(new Channelgroup(channelgroupid));
        if (StringUtils.isBlank(iptvprofile.getMacaddress())) {
            iptvprofile.setMacaddress(null);
        } else {
            iptvprofile.setMacaddress(iptvprofile.getMacaddress().toUpperCase());
        }
        //如果是个人用户 设置默认房间名
        if(PERSONAL_USER_TYPE.equals(hotelroom.getUsetype())){
            hotelroom.setRoomname("P"+iptvprofile.getIptvusername());
            hotelroom.setRoomno("P"+iptvprofile.getIptvusername());
        }
        //如果是个人用户 end
        hotelroomService.save(hotelroom);	
        redirectAttributes.addFlashAttribute("message", "更新用户成功");

        Map<String,String> modelMap = new HashMap<String,String>();
        modelMap.put("page", page);
        modelMap.put("sortType", sortType);
        return new ModelAndView("redirect:/iptvprofile/list").addAllObjects(modelMap);
    }
    //当前实现其实是删房间 账号自动删掉
    @RequestMapping(value = "delete/{id}")
    public String delete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
        if(hotelroomService.isHasCustomer(id)){
            redirectAttributes.addFlashAttribute("message", "不能删除使用中的房间");
        }else{
            hotelroomService.delete(id);
            redirectAttributes.addFlashAttribute("message", "删除成功");
        }
        return "redirect:/iptvprofile/list";
    }

    /**
     * 使用@ModelAttribute, 实现Struts2
     * Preparable二次部分绑定的效果,先根据form的id从数据库查出Iptvprofile对象,再把Form提交的内容绑定到该对象上。
     * 因为仅update()方法的form中有id属性，因此本方法在该方法中执行.
     */
    @ModelAttribute("preloadHotelroom")
    public Hotelroom getHotelroom(@RequestParam(value = "id", required = false) Long id) {
        if (id != null) {
            return hotelroomService.findOne(id);
        }
        return null;
    }

    @RequestMapping(value = "changestatus/{id}/{status}")
    public String changestatus(@PathVariable("id") Long id, @PathVariable("status") String status, RedirectAttributes redirectAttributes) {
        iptvprofileService.changeStatus(id, status);
        redirectAttributes.addFlashAttribute("message", "保存成功");
        return "redirect:/iptvprofile/list";
    }

    // 检查用户名
    @RequestMapping(value = "checkname")
    @ResponseBody
    public boolean checkname(@RequestParam(value = "iptvusername") String iptvusername, @RequestParam(value = "oldname") String oldname) {
        if (!oldname.isEmpty() && oldname.equals(iptvusername)) {
            return true;
        }
        iptvusername = iptvusername.trim();
        if (iptvusername.matches("[123456789]\\d+")) {
            Iptvprofile p = iptvprofileService.getByiptvusername(iptvusername);
            if (p == null) {
                return true;
            }
        }
        return false;
    }

    // 检查mac地址
    @RequestMapping(value = "checkmac")
    @ResponseBody
    public boolean checkmac(@RequestParam(value = "mac") String mac, @RequestParam(value = "oldmac") String oldmac) {
        if (!oldmac.isEmpty() && oldmac.equals(mac)) {
            return true;
        }
        mac = mac.trim().toUpperCase();
        // if(mac.matches("([0-9A-F][0-9A-F]:){5}[0-9A-F][0-9A-F]")){
        Iptvprofile p = iptvprofileService.getBymacaddress(mac);
        if (p == null) {
            return true;
        } else {
            return false;
        }
        // }
        // return false;
    }

    //检查用户名
    @RequestMapping(value = "checkroomname")
    @ResponseBody
    public boolean checkroomname(String roomname,String oldroomname) {
        roomname=roomname.trim();
        if (!oldroomname.isEmpty() && oldroomname.equals(roomname)) {
            return true;
        }

        List<Hotelroom> p =hotelroomService.getByRoomname(roomname);
        if(p==null||p.size()==0){
            return true;
        }else{
            return false;
        }
    }

    @RequestMapping(value = "/import", method = RequestMethod.GET)
    public String importuser(Model model) {
        model.addAttribute("iptvprofile", new Iptvprofile());

        List<Channelgroup> channelgroups = channelgroupService.getAll();
        model.addAttribute("channelgroups", channelgroups);
        return "iptvprofile/import";
    }

    @RequestMapping(value = "import", method = RequestMethod.POST)
    public String importiptvuser(Long servicegroupid, Long channelgroupid, Model model, MultipartFile file, RedirectAttributes redirectAttributes) {
        ExcelDataArray excelDataArray = null;
        if (file != null && file.getOriginalFilename() != null && file.getOriginalFilename().length() > 4) {
            try {
                final int startRow = 0; // Excel数据开始的行数
                excelDataArray = POIExcelUtilProcess.importExcelFileToDataArray(file.getInputStream(), startRow);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        try {
            iptvprofileService.importdata(channelgroupid, excelDataArray);
            redirectAttributes.addFlashAttribute("message", "保存成功");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("message", "导入失败:" + e.getMessage());
        }
        return "redirect:/iptvprofile/list";
    }
}
