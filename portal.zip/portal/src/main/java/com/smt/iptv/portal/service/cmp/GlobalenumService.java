package com.smt.iptv.portal.service.cmp;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.core.SystemEnum;
import com.smt.iptv.portal.i18nentity.Globalenum;
import com.smt.iptv.portal.i18nrepository.GlobalenumDao;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class GlobalenumService extends BaseService<GlobalenumDao, Globalenum> {

    public List<Globalenum> getByType(SystemEnum type){
        return dao.getByType(type.name().toLowerCase());
    }
    
}
