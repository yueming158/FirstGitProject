package com.smt.iptv.portal.entity;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.smt.iptv.portal.core.IdEntity;
@Entity
@Table(name = "appupdateinfo")
public class Appupdateinfo extends IdEntity {
    
    public Appupdateinfo() {
    }

    public Appupdateinfo(Long id) {
        this.id = id;
    }
    
	private String appupdateinfoname;
	private String versioncode;
	private String version;
    private String needupdate;
    private String forceupdate;
    private String downloadurl;
    private String description;
    private String apptype;
    private String accnts;
    private String packagename;
    private String fingerprints;
    private String projectname;
    public String getAppupdateinfoname() {
        return appupdateinfoname;
    }

    public void setAppupdateinfoname(String appupdateinfoname) {
        this.appupdateinfoname = appupdateinfoname;
    }

    public String getVersioncode() {
        return versioncode;
    }

    public void setVersioncode(String versioncode) {
        this.versioncode = versioncode;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getNeedupdate() {
        return needupdate;
    }

    public void setNeedupdate(String needupdate) {
        this.needupdate = needupdate;
    }

    public String getForceupdate() {
        return forceupdate;
    }

    public void setForceupdate(String forceupdate) {
        this.forceupdate = forceupdate;
    }

    public String getDownloadurl() {
        return downloadurl;
    }

    public void setDownloadurl(String downloadurl) {
        this.downloadurl = downloadurl;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getApptype() {
        return apptype;
    }

    public void setApptype(String apptype) {
        this.apptype = apptype;
    }

    public String getAccnts() {
        return accnts;
    }

    public void setAccnts(String accnts) {
        this.accnts = accnts;
    }

    public String getPackagename() {
        return packagename;
    }

    public void setPackagename(String packagename) {
        this.packagename = packagename;
    }

    public String getFingerprints() {
        return fingerprints;
    }

    public void setFingerprints(String fingerprints) {
        this.fingerprints = fingerprints;
    }

    public String getProjectname() {
        return projectname;
    }

    public void setProjectname(String projectname) {
        this.projectname = projectname;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}