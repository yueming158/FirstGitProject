package com.smt.iptv.portal.web.license;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smt.iptv.portal.core.HHZTRSALicenseGenerater;
import com.smt.iptv.portal.core.Result;
import com.smt.iptv.portal.entity.license.Device;
import com.smt.iptv.portal.entity.license.License;
import com.smt.iptv.portal.service.license.DeviceService;

/**
 * License管理的Controller, 使用Restful风格的Urls:
 * 
 * @author xjw
 */
@Controller
@RequestMapping(value = "/json/auth")
public class AuthenticationController {

    @Autowired
    private DeviceService deviceService;
    //license鉴权 如果设备曾经激活 则返回license字符串  如果设备未激活 服务器记录该设备新增再返回license字符串
    @RequestMapping(value = "first")
    @ResponseBody
    public Result first(String licensecode, String hardwareinfo, String systeminfo, String appinfo) {
        try {
            Device device = deviceService.findByHardwareinfo(hardwareinfo);
            if (device != null) {
                if ((appinfo != null && !appinfo.equals(device.getAppinfo())) || (systeminfo != null && !systeminfo.equals(device.getSysteminfo()))) {
                    device.setSysteminfo(systeminfo);
                    device.setAppinfo(appinfo);
                    deviceService.save(device);
                }
                return new Result(true, HHZTRSALicenseGenerater.sign(hardwareinfo));
            } else {
                License license = new License(licensecode);
                if (license != null||license.getLicensenumber()==0) {
                    if (deviceService.count() < license.getLicensenumber()) {
                        device = new Device();
                        device.setHardwareinfo(hardwareinfo);
                        device.setSysteminfo(systeminfo);
                        device.setAppinfo(appinfo);
                        device.setCreationtime(new Date());
                        deviceService.save(device);
                        return new Result(true, HHZTRSALicenseGenerater.sign(hardwareinfo));
                    }else{
                        return new Result(false, "授权数量已满");
                    }
                }else{
                    return new Result(false, "授权码不正确");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new Result(false, "服务器异常");
    }
    //不带客户授权码来进行激活，每次都带上好了，感觉不需要这个接口
    @RequestMapping(value = "again")
    @ResponseBody
    public Result again(String hardwareinfo,String systeminfo, String appinfo) {
        try {
            Device device = deviceService.findByHardwareinfo(hardwareinfo);
            if (device != null) {
                if ((appinfo != null && !appinfo.equals(device.getAppinfo())) || (systeminfo != null && !systeminfo.equals(device.getSysteminfo()))) {
                    device.setSysteminfo(systeminfo);
                    device.setAppinfo(appinfo);
                    deviceService.save(device);
                }
                return new Result(true, HHZTRSALicenseGenerater.sign(hardwareinfo));
            }
            return new Result(false, "设备未激活");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new Result(false, "服务器异常");
    }

}
