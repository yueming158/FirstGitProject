package com.smt.iptv.portal.web.hotel;

import java.util.List;
import java.util.Map;

import javax.servlet.ServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Maps;
import com.smt.iptv.portal.entity.Iptvprofile;
import com.smt.iptv.portal.entity.hotel.Hotelroom;
import com.smt.iptv.portal.service.cmp.IptvprofileService;
import com.smt.iptv.portal.service.hotel.HotelroomService;

/**
 * @author rich
 */
@Controller
@RequestMapping(value = "/hotelroom")
public class HotelroomController {

    private static final int PAGE_SIZE = 50;

    private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
    static {
        sortTypes.put("auto", "自动");
        sortTypes.put("roomname", "名称");
    }

    @Autowired
    private HotelroomService hotelroomService;
    @Autowired
    private IptvprofileService iptvprofileService;

    @RequestMapping(value = "/list")
    public String list(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");

        Page<Hotelroom> hotelrooms = hotelroomService.getPage(searchParams, pageNumber, PAGE_SIZE, sortType);

        model.addAttribute("hotelrooms", hotelrooms);
        model.addAttribute("sortType", sortType);
        model.addAttribute("sortTypes", sortTypes);
        // 将搜索条件编码成字符串，用于排序，分页的URL
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
        return "hotelroom/hotelroomList";
    }

    @RequestMapping(value = "create", method = RequestMethod.GET)
    public String createForm(Model model) {
        List<String> names = hotelroomService.getUndividedAccount();
        model.addAttribute("names", names);
        model.addAttribute("hotelroom", new Hotelroom());
        model.addAttribute("action", "create");
        return "hotelroom/hotelroomForm";
    }

    @RequestMapping(value = "create", method = RequestMethod.POST)
    public String create(@Valid Hotelroom newHotelroom, String iptvusername, RedirectAttributes redirectAttributes) {
        Iptvprofile iptvprofile = iptvprofileService.getByiptvusername(iptvusername);
        if (iptvprofile != null) {
            if (hotelroomService.save(newHotelroom,iptvusername) != null) {
                redirectAttributes.addFlashAttribute("message", "新增成功");
                return "redirect:/hotelroom/list";
            } else {
                redirectAttributes.addFlashAttribute("message", "设备账号已使用");
                return "redirect:/hotelroom/create";
            }
        } else {
            redirectAttributes.addFlashAttribute("message", "设备账号不存在");
            return "redirect:/hotelroom/create";
        }

    }

    @RequestMapping(value = "update/{id}", method = RequestMethod.GET)
    public String updateForm(@PathVariable("id") Long id, Model model) {
        List<String> names = hotelroomService.getUndividedAccount();
        model.addAttribute("names", names);
        model.addAttribute("hotelroom", hotelroomService.findOne(id));
        model.addAttribute("action", "update");
        return "hotelroom/hotelroomForm";
    }

    @RequestMapping(value = "update", method = RequestMethod.POST)
    public String update(@Valid @ModelAttribute("preloadHotelroom") Hotelroom hotelroom,String iptvusername, RedirectAttributes redirectAttributes) {
        Iptvprofile iptvprofile = iptvprofileService.getByiptvusername(iptvusername);
        if (iptvprofile != null) {
            if (hotelroomService.save(hotelroom,iptvusername) != null) {
                redirectAttributes.addFlashAttribute("message", "新增成功");
                return "redirect:/hotelroom/list";
            } else {
                redirectAttributes.addFlashAttribute("message", "设备账号已使用");
                return "redirect:/hotelroom/update/"+hotelroom.getId();
            }
        } else {
            redirectAttributes.addFlashAttribute("message", "设备账号不存在");
            return "redirect:/hotelroom/update/"+hotelroom.getId();
        }
    }

    @RequestMapping(value = "delete/{id}")
    public String delete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
        if(hotelroomService.isHasCustomer(id)){
            redirectAttributes.addFlashAttribute("message", "不能删除使用中的房间");
        }else{
            hotelroomService.delete(id);
            redirectAttributes.addFlashAttribute("message", "删除成功");
        }
        return "redirect:/hotelroom/list";
    }

    /**
     * 使用@ModelAttribute, 实现Struts2
     * Preparable二次部分绑定的效果,先根据form的id从数据库查出Hotelroom对象,再把Form提交的内容绑定到该对象上。
     * 因为仅update()方法的form中有id属性，因此本方法在该方法中执行.
     */
    @ModelAttribute("preloadHotelroom")
    public Hotelroom getHotelroom(@RequestParam(value = "id", required = false) Long id) {
        if (id != null) {
            return hotelroomService.findOne(id);
        }
        return null;
    }
    
    //检查用户名
    @RequestMapping(value = "checkname")
    @ResponseBody
    public boolean checkname(String roomname
            ,Long id) {
        roomname=roomname.trim();
        if(id!=null){
            Hotelroom room = hotelroomService.findOne(id);
            if(room!=null&&roomname.equals(room.getRoomname()))
            {
                return true;
            }
        }
        List<Hotelroom> p =hotelroomService.getByRoomname(roomname);
        if(p==null||p.size()==0){
            return true;
        }else{
            return false;
        }
    }

}
