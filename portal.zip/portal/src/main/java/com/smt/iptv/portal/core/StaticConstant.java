package com.smt.iptv.portal.core;



public class StaticConstant {


    public static String CFG_STBRESTARTJOB_HOUR ="stbrestartjob_hour";
   

}