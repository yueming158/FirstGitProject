package com.smt.iptv.portal.web.account;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * 
 * @author xjw
 */
@Controller
@RequestMapping(value = "/home")
public class HomeController {

	@RequestMapping(method = RequestMethod.GET)
	public String login() {
		return "account/home";
	}
    @RequestMapping(value="401",method = RequestMethod.GET)
    public String error401() {
        return "error/401";
    }
}
