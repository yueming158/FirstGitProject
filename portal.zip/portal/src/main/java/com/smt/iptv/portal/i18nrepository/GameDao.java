package com.smt.iptv.portal.i18nrepository;

import com.smt.iptv.portal.i18nentity.Game;
import com.smt.iptv.portal.repository.BaseDao;

public interface GameDao extends BaseDao<Game> {
}
