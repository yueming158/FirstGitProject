package com.smt.iptv.portal.i18nentity;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.smt.iptv.portal.core.IdEntity;
import com.smt.iptv.portal.model.SystemConstant;

@Entity
@Table(name = "game")
public class Game extends IdEntity {
    
    
    public Game() {
    }

    public Game(Long id) {
        this.id = id;
    }
    private String gamename;
    private Integer gamesize;
    private Integer downnum;
    private String downurl;
    private String imgurl;
    private String entrance;
    private String gamepackage;
    private String description;
    private String apptype;
    public String getGamename() {
        return gamename;
    }
    public void setGamename(String gamename) {
        this.gamename = gamename;
    }
    public Integer getGamesize() {
        return gamesize;
    }
    public void setGamesize(Integer gamesize) {
        this.gamesize = gamesize;
    }
    public Integer getDownnum() {
        return downnum;
    }
    public void setDownnum(Integer downnum) {
        this.downnum = downnum;
    }
    public String getDownurl() {
        return downurl;
    }
    public void setDownurl(String downurl) {
        this.downurl = downurl;
    }
    public String getEntrance() {
        return entrance;
    }
    public void setEntrance(String entrance) {
        this.entrance = entrance;
    }
    public String getGamepackage() {
        return gamepackage;
    }
    public void setGamepackage(String gamepackage) {
        this.gamepackage = gamepackage;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public String getImgurl() {
        return imgurl;
    }
    public void setImgurl(String imgurl) {
        this.imgurl = imgurl;
    }
    @Transient
    public String getImageurl() {
        return SystemConstant.getURLValue("image_server_httpprefix")+this.imgurl;
    }
    @Transient
    public String getDownloadurl() {
        return SystemConstant.getURLValue("image_server_httpprefix")+this.downurl;
    }

    public String getApptype() {
        return apptype;
    }

    public void setApptype(String apptype) {
        this.apptype = apptype;
    }
    
}