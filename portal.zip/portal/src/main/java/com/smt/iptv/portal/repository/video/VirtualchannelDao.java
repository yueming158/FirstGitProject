package com.smt.iptv.portal.repository.video;

import com.smt.iptv.portal.entity.Virtualchannel;
import com.smt.iptv.portal.repository.BaseDao;

public interface VirtualchannelDao extends BaseDao<Virtualchannel> {

}
