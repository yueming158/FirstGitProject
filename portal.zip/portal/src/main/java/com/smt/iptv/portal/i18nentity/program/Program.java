package com.smt.iptv.portal.i18nentity.program;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.smt.iptv.portal.core.IdEntity;
import com.smt.iptv.portal.i18nentity.Category;

//JPA标识
//programname
//searchname
//createdate
//status
//year
//starrating
//areaname
//programtype
//genrenames
//actornames
//writernames
//description
//cpobjectcode
//playurl
//duration
@Entity
@Table(name = "program")
public class Program extends IdEntity {
    
    public Program() {
    }

    public Program(Long id) {
        this.id = id;
    }

    //private List<Cast> castlist;
    private List<Mediacontent> mediacontentlist;
    private List<Picture> picturelist;
    private List<Category> categorylist;
    private String programname;
    @JsonIgnore
    private String cpobjectcode;
    private String searchname;
    private Date creattime;
    private String status;
    private String year;
    private String starrating;
    private String areaname;
    private String programtype;
    private String genrenames;
    private String actornames;
    private String writernames;
    private String description;
    private Integer price;
    private Integer level;
    private String vip;
    
//    @ManyToMany()
//    @JoinTable(
//    name="programcast",
//    joinColumns=@JoinColumn(name="programid", referencedColumnName="id"),//控制端列
//    inverseJoinColumns=@JoinColumn(name="castid", referencedColumnName="id")//被控制端列
//    )
//    public List<Cast> getCastlist() {
//        return castlist;
//    }
//
//    public void setCastlist(List<Cast> castlist) {
//        this.castlist = castlist;
//    }
    
    @OneToMany(mappedBy="program")
    public List<Mediacontent> getMediacontentlist() {
        return mediacontentlist;
    }

    public void setMediacontentlist(List<Mediacontent> mediacontentlist) {
        this.mediacontentlist = mediacontentlist;
    }
    
    @OneToMany(mappedBy="program")
    public List<Picture> getPicturelist() {
        return picturelist;
    }

    public void setPicturelist(List<Picture> picturelist) {
        this.picturelist = picturelist;
    }

    @ManyToMany
    @JoinTable(
            name="categoryprogram",
            joinColumns=@JoinColumn(name="programid", referencedColumnName="id"),//控制端列
            inverseJoinColumns=@JoinColumn(name="categoryid", referencedColumnName="id")//被控制端列
            )
    public List<Category> getCategorylist() {
        return categorylist;
    }

    public void setCategorylist(List<Category> categorylist) {
        this.categorylist = categorylist;
    }

    public String getProgramname() {
        return programname;
    }

    public void setProgramname(String programname) {
        this.programname = programname;
    }

    public String getCpobjectcode() {
        return cpobjectcode;
    }

    public void setCpobjectcode(String cpobjectcode) {
        this.cpobjectcode = cpobjectcode;
    }

    public String getSearchname() {
        return searchname;
    }

    public void setSearchname(String searchname) {
        this.searchname = searchname;
    }

    public Date getCreattime() {
        return creattime;
    }

    public void setCreattime(Date creattime) {
        this.creattime = creattime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getStarrating() {
        return starrating;
    }

    public void setStarrating(String starrating) {
        this.starrating = starrating;
    }

    public String getAreaname() {
        return areaname;
    }

    public void setAreaname(String areaname) {
        this.areaname = areaname;
    }

    public String getProgramtype() {
        return programtype;
    }

    public void setProgramtype(String programtype) {
        this.programtype = programtype;
    }

    public String getGenrenames() {
        return genrenames;
    }

    public void setGenrenames(String genrenames) {
        this.genrenames = genrenames;
    }

    public String getActornames() {
        return actornames;
    }

    public void setActornames(String actornames) {
        this.actornames = actornames;
    }

    public String getWriternames() {
        return writernames;
    }

    public void setWriternames(String writernames) {
        this.writernames = writernames;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public Integer getLevel() {
        return level;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }

    public String getVip() {
		return vip;
	}

	public void setVip(String vip) {
		this.vip = vip;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}