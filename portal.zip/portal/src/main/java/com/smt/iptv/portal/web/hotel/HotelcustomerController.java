package com.smt.iptv.portal.web.hotel;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.smt.iptv.portal.entity.hotel.Hotelcustomer;
import com.smt.iptv.portal.entity.hotel.Hotelroom;
import com.smt.iptv.portal.service.hotel.EpgvariableService;
import com.smt.iptv.portal.service.hotel.HotelcustomerService;

/**
 * @author rich
 */
@Controller
@RequestMapping(value = "/hotelcustomer")
public class HotelcustomerController {

    private static final int PAGE_SIZE = 50;

    private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
    static {
        sortTypes.put("auto", "自动");
        sortTypes.put("hotelroom.roomname", "房间名称");
        sortTypes.put("customername", "客户名称");
    }

    @Autowired
    private HotelcustomerService hotelcustomerService;

    @Autowired
    private EpgvariableService epgvariableService;
    @RequestMapping(value = "/list")
    public String list(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");

        Page<Hotelcustomer> hotelcustomers = hotelcustomerService.getPage(searchParams, pageNumber, PAGE_SIZE, sortType);

        model.addAttribute("hotelcustomers", hotelcustomers);
        model.addAttribute("sortType", sortType);
        model.addAttribute("sortTypes", sortTypes);
        // 将搜索条件编码成字符串，用于排序，分页的URL
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
        return "hotelcustomer/hotelcustomerList";
    }

    @RequestMapping(value = "create", method = RequestMethod.GET)
    public String createForm(Model model) {
        Hotelcustomer hc =new Hotelcustomer();
        hc.setWelcome(epgvariableService.getByEpggroupidAndName(1L, "default_welcome").getValue());
        model.addAttribute("hotelrooms", hotelcustomerService.getEmptyRoomList());
        model.addAttribute("hotelcustomer", hc);
        model.addAttribute("action", "create");
        return "hotelcustomer/hotelcustomerForm";
    }

    @RequestMapping(value = "create", method = RequestMethod.POST)
    public String create(@Valid Hotelcustomer newHotelcustomer, Long hotelroomid, RedirectAttributes redirectAttributes) {
        newHotelcustomer.setHotelroom(new Hotelroom(hotelroomid));
        newHotelcustomer.setCheckintime(new Date());
        //如果是默认欢迎词则置空 <fmt:message key="welcome_prefix" />${hotelname}<fmt:message key="welcome_suffix" />
        String def =epgvariableService.getByEpggroupidAndName(1L, "default_welcome").getValue();
        if(def.equals(newHotelcustomer.getWelcome())){
            newHotelcustomer.setWelcome("");
        }
        if(newHotelcustomer.getCheckouttime()==null||newHotelcustomer.getCheckouttime().getTime()<=System.currentTimeMillis()){
            redirectAttributes.addFlashAttribute("message", "客人入住成功失败，预计退房时间不正确");
        }else{
            hotelcustomerService.checkin(newHotelcustomer);
            redirectAttributes.addFlashAttribute("message", "客人入住成功");
        }
        return "redirect:/hotelcustomer/list";
    }

    @RequestMapping(value = "update/{id}", method = RequestMethod.GET)
    public String updateForm(@PathVariable("id") Long id, Model model) {
        Hotelroom room =hotelcustomerService.findOne(id).getHotelroom();
        List<Hotelroom> roomlist =Lists.newArrayList();
        if(room!=null){
            roomlist.add(room);
        }
        List<Hotelroom> emptyroomlist =       hotelcustomerService.getEmptyRoomList();
        if(emptyroomlist!=null){
            roomlist.addAll(emptyroomlist);
        }
        model.addAttribute("hotelrooms",roomlist );
        model.addAttribute("hotelcustomer", hotelcustomerService.findOne(id));
        model.addAttribute("action", "update");
        return "hotelcustomer/hotelcustomerForm";
    }

    @RequestMapping(value = "update", method = RequestMethod.POST)
    public String update(@Valid @ModelAttribute("preloadHotelcustomer") Hotelcustomer hotelcustomer, Long hotelroomid, RedirectAttributes redirectAttributes) {
        hotelcustomer.setHotelroom(new Hotelroom(hotelroomid));
        hotelcustomerService.save(hotelcustomer);
        redirectAttributes.addFlashAttribute("message", "保存成功");
        return "redirect:/hotelcustomer/list";
    }

    @RequestMapping(value = "delete/{id}")
    public String delete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
        hotelcustomerService.delete(id);
        redirectAttributes.addFlashAttribute("message", "删除成功");
        return "redirect:/hotelcustomer/list";
    }

    /**
     * 使用@ModelAttribute, 实现Struts2
     * Preparable二次部分绑定的效果,先根据form的id从数据库查出Hotelcustomer对象,再把Form提交的内容绑定到该对象上。
     * 因为仅update()方法的form中有id属性，因此本方法在该方法中执行.
     */
    @ModelAttribute("preloadHotelcustomer")
    public Hotelcustomer getHotelcustomer(@RequestParam(value = "id", required = false) Long id) {
        if (id != null) {
            return hotelcustomerService.findOne(id);
        }
        return null;
    }
    /**
     * @param model
     * @param id
     * @return
     */
    @RequestMapping(value = "checkout", method = RequestMethod.GET)
    public String checkoutForm(Model model,Long id) {
        model.addAttribute("hotelcustomer", hotelcustomerService.findOne(id));
        return "hotelcustomer/checkoutForm";
    }

    @RequestMapping(value = "checkout", method = RequestMethod.POST)
    public String checkout(@Valid @ModelAttribute("preloadHotelcustomer") Hotelcustomer hotelcustomer,RedirectAttributes redirectAttributes) {
        hotelcustomerService.checkout(hotelcustomer);
        redirectAttributes.addFlashAttribute("message", "退房成功");
        return "redirect:/hotelcustomer/list";
    }

}
