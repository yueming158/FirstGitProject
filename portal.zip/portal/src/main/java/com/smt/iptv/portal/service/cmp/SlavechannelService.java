package com.smt.iptv.portal.service.cmp;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.smt.iptv.portal.entity.Slavechannel;
import com.smt.iptv.portal.repository.video.SlavechannelDao;

//Spring Bean的标识.
@Component
// 默认将类中的所有public函数纳入事务管理.
@Transactional(readOnly = true)
public class SlavechannelService extends BaseService<SlavechannelDao, Slavechannel> {
    
    public Slavechannel getByChannelId(Long channelid){
        return dao.getByChannelId(channelid);
    }
}
