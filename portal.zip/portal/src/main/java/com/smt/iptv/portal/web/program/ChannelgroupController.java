package com.smt.iptv.portal.web.program;

import java.util.Map;

import javax.servlet.ServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.Servlets;

import com.google.common.collect.Maps;
import com.smt.iptv.portal.entity.Channelgroup;
import com.smt.iptv.portal.service.cmp.ChannelgroupService;

/**
 * Channelgroup管理的Controller, 使用Restful风格的Urls:
 * 
 * List page : GET /channelgroup/ Create page : GET /channelgroup/create Create
 * action : POST /channelgroup/create Update page : GET
 * /channelgroup/update/{id} Update action : POST /channelgroup/update Delete
 * action : GET /channelgroup/delete/{id}
 * 
 * @author xjw
 */
@Controller
@RequestMapping(value = "/channelgroup")
public class ChannelgroupController {

    private static final int PAGE_SIZE = 50;

    private static Map<String, String> sortTypes = Maps.newLinkedHashMap();
    static {
        sortTypes.put("auto", "自动");
        sortTypes.put("channelgroupname", "名称");
    }

    @Autowired
    private ChannelgroupService channelgroupService;

    @RequestMapping(value = "/list")
    public String list(@RequestParam(value = "sortType", defaultValue = "auto") String sortType,
            @RequestParam(value = "page", defaultValue = "1") int pageNumber, Model model, ServletRequest request) {
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");

        Page<Channelgroup> channelgroups = channelgroupService.getPage(searchParams, pageNumber, PAGE_SIZE, sortType);

        model.addAttribute("channelgroups", channelgroups);
        model.addAttribute("sortType", sortType);
        model.addAttribute("sortTypes", sortTypes);
        // 将搜索条件编码成字符串，用于排序，分页的URL
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
        return "channelgroup/channelgroupList";
    }

    @RequestMapping(value = "create", method = RequestMethod.GET)
    public String createForm(Model model) {
        model.addAttribute("channelgroup", new Channelgroup());
        model.addAttribute("action", "create");
        return "channelgroup/channelgroupForm";
    }

    @RequestMapping(value = "create", method = RequestMethod.POST)
    public String create(@Valid Channelgroup newChannelgroup, RedirectAttributes redirectAttributes) {

        channelgroupService.save(newChannelgroup);
        redirectAttributes.addFlashAttribute("message", "创建成功");
        return "redirect:/channelgroup/list";
    }

    @RequestMapping(value = "update/{id}", method = RequestMethod.GET)
    public String updateForm(@PathVariable("id") Long id, Model model) {
        model.addAttribute("channelgroup", channelgroupService.findOne(id));
        model.addAttribute("action", "update");
        return "channelgroup/channelgroupForm";
    }

    @RequestMapping(value = "update", method = RequestMethod.POST)
    public String update(@Valid @ModelAttribute("preloadChannelgroup") Channelgroup channelgroup,
            RedirectAttributes redirectAttributes) {
        channelgroupService.save(channelgroup);
        redirectAttributes.addFlashAttribute("message", "保存成功");
        return "redirect:/channelgroup/list";
    }

    @RequestMapping(value = "delete/{id}")
    public String delete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
        // channelgroupService.delete(id);
        // redirectAttributes.addFlashAttribute("message", "删除成功");
        boolean sucess = channelgroupService.deleteSingle(id);
        if (sucess) {
            redirectAttributes.addFlashAttribute("message", "删除成功");
        } else {
            redirectAttributes.addFlashAttribute("message", "该分组下存在用户，不能删除该客户");
        }
        return "redirect:/channelgroup/list";
    }

    /**
     * 使用@ModelAttribute, 实现Struts2
     * Preparable二次部分绑定的效果,先根据form的id从数据库查出Channelgroup对象,再把Form提交的内容绑定到该对象上。
     * 因为仅update()方法的form中有id属性，因此本方法在该方法中执行.
     */
    @ModelAttribute("preloadChannelgroup")
    public Channelgroup getChannelgroup(@RequestParam(value = "id", required = false) Long id) {
        if (id != null) {
            return channelgroupService.findOne(id);
        }
        return null;
    }

    @RequestMapping(value = "checkcode")
    @ResponseBody
    public boolean checkcode(@RequestParam(value = "channelgroupcode") String channelgroupcode
            ,@RequestParam(value = "oldname") String oldname) {
        if(!oldname.isEmpty()&&oldname.equals(channelgroupcode))
        {
            return true;
        }
        channelgroupcode=channelgroupcode.trim();
        if (channelgroupcode.matches("[A-Za-z0-9]+_zh")||channelgroupcode.matches("[A-Za-z0-9]+_en")) {
            Channelgroup c = channelgroupService.getBychannelgroupcode(channelgroupcode);
            if (c == null) {
                return true;
            }
        }
        return false;
    }
}
