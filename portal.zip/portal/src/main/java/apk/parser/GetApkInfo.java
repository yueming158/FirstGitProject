// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 
// Source File Name:   GetApkInfo.java

package apk.parser;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

public class GetApkInfo
{
    private static final String CONFIG_TEMPLATE = "assets/template";
    private static final String CONFIG_PROJECT = "assets/project";
    private static final String CONFIG_STB = "assets/config";

    public static ApkInfo getApkInfoByFilePath(File apkFile)
    {
        ApkInfo apkInfo = null;
        try
        {
            SAXParserFactory parserFactory = SAXParserFactory.newInstance();
            parserFactory.setValidating(false);
            parserFactory.setNamespaceAware(false);
            MyXmlResolve myXmlResolve = new MyXmlResolve();
            String strContent = AXMLPrinter.getManifestXMLFromAPK(apkFile);//.parse(stream);
            byte by[] = strContent.getBytes("utf-8");
            ByteArrayInputStream bais = new ByteArrayInputStream(by);
            SAXParser parser = parserFactory.newSAXParser();
            parser.parse(bais, myXmlResolve);
            bais.close();
            parser = null;
            apkInfo = myXmlResolve.getApkInfo();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return apkInfo;
    }
    public static Properties getTemplateConfig(File apkFile) {
        Properties p1 = new Properties();
        try {
            ZipFile file = new ZipFile(apkFile, ZipFile.OPEN_READ);
            ZipEntry entry1 = file.getEntry(CONFIG_TEMPLATE);
            if (entry1 != null) {
                InputStream is1 = file.getInputStream(entry1);
                p1.load(new BufferedReader(new    InputStreamReader(is1,"UTF-8")));
            }
        } catch (IOException e) {
        }
        return p1;
    }
    public static Properties getStbconfig(File apkFile) {
        Properties p1 = new Properties();
        try {
            ZipFile file = new ZipFile(apkFile, ZipFile.OPEN_READ);
            ZipEntry entry1 = file.getEntry(CONFIG_STB);
            if (entry1 != null) {
                InputStream is1 = file.getInputStream(entry1);
                p1.load(new BufferedReader(new    InputStreamReader(is1,"UTF-8")));
            }
        } catch (IOException e) {
        }
        return p1;
    }
    public static void main(String[] arguments) {

        File apkFile = new File("D:/LVB_X.apk");
        // File apkFile = new File("D:/LVB_X_20141019_Ver1.17.10.3.apk");
        Properties config = GetApkInfo.getTemplateConfig(apkFile);
        System.out.println(config.stringPropertyNames().size());
        for (Object key : config.keySet()) {
            System.out.println(key);
        }
    }
}
