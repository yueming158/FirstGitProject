// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 
// Source File Name:   MyXmlResolve.java

package apk.parser;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MyXmlResolve extends DefaultHandler
{

    private ApkInfo apkInfo;

    public MyXmlResolve()
    {
    }

    public void characters(char ch[], int start, int length)
        throws SAXException
    {
        super.characters(ch, start, length);
    }

    public void endDocument()
        throws SAXException
    {
        super.endDocument();
    }

    public void endElement(String uri, String localName, String qName)
        throws SAXException
    {
        super.endElement(uri, localName, qName);
    }

    public void startDocument()
        throws SAXException
    {
        super.startDocument();
    }
    private String android_name;
    public void startElement(String uri, String localName, String qName, Attributes attributes)
        throws SAXException
    {
        if(qName.equals("manifest"))
        {
            apkInfo = new ApkInfo();
            for(int i = 0; i < attributes.getLength(); i++)
            {
                String strQname = attributes.getQName(i);
                if(strQname.equals("package"))
                    apkInfo.setPackageName(attributes.getValue(strQname));
                if(strQname.equals("android:versionName"))
                    apkInfo.setVersionName(attributes.getValue(strQname));
                if(strQname.equals("android:versionCode"))
                    apkInfo.setVersionCode(attributes.getValue(strQname));
            }
        }else if(qName.equals("activity")){
            for(int i = 0; i < attributes.getLength(); i++)
            {
                String strQname = attributes.getQName(i);
                if(strQname.equals("android:name")){
                    android_name=attributes.getValue(strQname);
                    break;
                }
                
            }
        }else if(qName.equals("action")){
            for(int i = 0; i < attributes.getLength(); i++)
            {
                String strQname = attributes.getQName(i);
                if(strQname.equals("android:name")){
                    if("android.intent.action.MAIN".equals(attributes.getValue(strQname))){
                        if(android_name.startsWith(".")){
                            apkInfo.setMainName(apkInfo.getPackageName()+android_name);
                        }else{
                            apkInfo.setMainName(android_name);
                        }
                        return;
                    }

                }
                
            }
        }
        //
//      <activity android:theme="@android:01030007" android:label="@7F060000" android:name="com.hhzt.iptv.ui.SplashActivity" android:clearTaskOnLaunch="true" android:stateNotNeeded="true" android:launchMode="2" android:screenOrientation="0" android:configChanges="0x000000B4">
//      <intent-filter>
//          <action android:name="">
//          </action>
//          <category android:name="android.intent.category.HOME">
//          </category>
//          <category android:name="android.intent.category.DEFAULT">
//          </category>
//          <category android:name="android.intent.category.LAUNCHER">
//          </category>
//      </intent-filter>
//      </activity>
        super.startElement(uri, localName, qName, attributes);
    }

    public ApkInfo getApkInfo()
    {
        return apkInfo;
    }
}
