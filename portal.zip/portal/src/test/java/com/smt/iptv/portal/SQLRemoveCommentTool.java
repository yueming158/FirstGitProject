package com.smt.iptv.portal;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.commons.io.FileUtils;

public class SQLRemoveCommentTool {
  
    public static void main(String args []) throws IOException {
        File file= new File("D:/iptv.sql");
        removeCOMMENT(file);
        removeinsert(file);
        File file2= new File("D:/iptv2.sql");
        haveinsert(file2);
    }
    
    
    public static void removeCOMMENT(File file) throws IOException {
        
        List<String> lines =FileUtils.readLines(file, "utf-8");
        for(int i=0;i<lines.size();i++){
            String line =lines.get(i);
            if(line.indexOf(" COMMENT=")!=-1){
                line=line.substring(0, line.indexOf(" COMMENT="))+";";
                lines.set(i, line);
            }
            else if(line.indexOf(" COMMENT ")!=-1){
                line=line.substring(0, line.indexOf(" COMMENT "))+",";
                lines.set(i, line);
            }
        }
        FileUtils.writeLines(file, "utf-8", lines);
    }
    
    public static void removeinsert(File file) throws IOException {
        List<String> lines =FileUtils.readLines(file, "utf-8");
        for(int i=lines.size()-1;i>=0;i--){
            String line =lines.get(i);
            if(line.startsWith("INSERT INTO")){
                lines.remove(i);
            }
            else if(line.startsWith(") ENGINE=InnoDB")){
                lines.set(i, ") ENGINE=InnoDB DEFAULT CHARSET=utf8;");
            }
            else if(line.startsWith(") ENGINE=MyISAM")){
                lines.set(i, ") ENGINE=MyISAM DEFAULT CHARSET=utf8;");
            }
        }
        FileUtils.writeLines(file, "utf-8", lines);
    }
    
    public static void haveinsert(File file) throws IOException {

        List<String> lines =FileUtils.readLines(file, "utf-8");
        for(int i=lines.size()-1;i>=0;i--){
            String line =lines.get(i);
            if(!line.startsWith("INSERT INTO")){
                lines.remove(i);
            }
        }
        FileUtils.writeLines(file, "utf-8", lines);
    }
}


