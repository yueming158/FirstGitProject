package com.smt.iptv.portal;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

/**
 * 
 */
public class SimpleMailService {
	private static Logger logger = LoggerFactory.getLogger(SimpleMailService.class);

	private JavaMailSenderImpl mailSender;

	/**
	 * 发送纯文本的用户修改通知邮件.
	 */
	public void sendNotificationMail(String content) {
		SimpleMailMessage msg = new SimpleMailMessage();
		msg.setFrom("hhztom@szhhzt.com");
		msg.setTo(new String []{"xujw@szhhzt.com","wujc@szhhzt.com"});
		msg.setSubject("智能互动视讯系统报警信息");
		// 将用户名与当期日期格式化到邮件内容的字符串模板
		//String content = String.format(textTemplate, userName, new Date());
		msg.setText(content);
		try {
			mailSender.send(msg);
			if (logger.isInfoEnabled()) {
				logger.info("纯文本邮件已发送至{}", StringUtils.join(msg.getTo(), ","));
			}
		} catch (Exception e) {
			logger.error("发送邮件失败", e);
		}
	}

	/**
	 * Spring的MailSender.
	 */
	public void setMailSender(JavaMailSenderImpl mailSender) {
		this.mailSender = mailSender;
	}
}
