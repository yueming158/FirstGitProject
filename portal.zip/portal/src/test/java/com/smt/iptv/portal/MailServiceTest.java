package com.smt.iptv.portal;

import java.util.Properties;

import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

public class MailServiceTest {
/*
 * <bean id="mailSender" class="org.springframework.mail.javamail.JavaMailSenderImpl">
            <property name="host" value="smtp.gmail.com" />
            <property name="username" value="springside3.demo@gmail.com" />
            <property name="password" value="demoforyou" />
            <property name="defaultEncoding" value="UTF-8"/>
            <property name="javaMailProperties">
                <props>
                    <prop key="mail.smtp.auth">true</prop>
                    <!-- 使用gmail smtp server的必须参数 -->
                    <prop key="mail.smtp.starttls.enable">true</prop>
                </props>
            </property>
        </bean>
 */
	public static void main(String[] args) {
	    SimpleMailService simpleMailService  =new SimpleMailService();
	    JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
	    mailSender.setHost("smtp.qq.com");
	    mailSender.setUsername("hhztom@szhhzt.com");
	    mailSender.setPassword("hhzt168");
	    mailSender.setDefaultEncoding("UTF-8");
	    Properties javaMailProperties = new Properties();
	    javaMailProperties.put("mail.smtp.auth", "true");
	    javaMailProperties.put("mail.smtp.starttls.enable", "true");
	    mailSender.setJavaMailProperties(javaMailProperties);
	    simpleMailService.setMailSender(mailSender);
        simpleMailService.sendNotificationMail("警告：服务器247已经崩溃");
        System.out.println("123");
    }
}
