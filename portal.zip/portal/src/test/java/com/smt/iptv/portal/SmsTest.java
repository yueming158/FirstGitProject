package com.smt.iptv.portal;

import java.net.HttpURLConnection;
import java.net.URL;

public class SmsTest  {
    private static int sucess=0;
    private static int fail=0;
    public static void main(String[] args) {

        while(true){
            SmsTest.executeHttpGet("http://192.168.1.136:8080/TV00000000000000000001@CRI;LIVE", "utf-8");
            System.out.println("sucess:"+sucess+"fail:"+fail);
        }
    }
    private static byte [] stream = new byte[1024];
    public static String executeHttpGet(String urlString,String charsetName) {
        String result = null;
        URL url = null;
        HttpURLConnection connection = null;
        try {
            url = new URL(urlString);
            connection = (HttpURLConnection) url.openConnection();
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(5000);
            connection.getInputStream().read(stream);
            sucess++;
            return new String(new byte[]{stream[0],stream[1],stream[2],stream[3],stream[4],stream[5],stream[6],stream[7],stream[8]});  
        } catch (Exception e) {
            fail++;
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
        return result;
    }
}
