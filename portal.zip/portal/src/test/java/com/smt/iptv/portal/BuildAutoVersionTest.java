package com.smt.iptv.portal;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.time.DateFormatUtils;



public class BuildAutoVersionTest {

  @org.junit.Test
  public void autoVersion() throws IOException {
      //<div style="display:hidden">PORTAL_HT_HHZT888_HHZT001_Ver1.1.1.1_140918</div>
      File home = new File("src/main/webapp/views/account/login.jsp");
      List<String> lines = FileUtils.readLines(home,"UTF-8");
      if(lines!=null)
      for(int i =0;i<lines.size();i++){
          String content =lines.get(i);
          if(content.indexOf("<div class=\"version\">")!=-1){
              String [] versions =content.split("\\.");
              String version = versions[0]+"."+versions[1]+"."+(Integer.parseInt(versions[2])+1);
              String date =DateFormatUtils.format(System.currentTimeMillis(), ".yyyyMMdd.HHmm");
              lines.set(i, version+date+"</div>" ); 
          }
      }
      FileUtils.writeLines(home, "UTF-8", lines);
  }

    public static void main(String[] args) throws IOException {
        new BuildAutoVersionTest().autoVersion();
 
    }
}


