package com.smt.iptv.portal;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.net.telnet.TelnetClient;

//@RunWith(SpringJUnit4ClassRunner.class) 
//@ContextConfiguration(locations = {"classpath*:/applicationContext.xml"})
//@TransactionConfiguration(defaultRollback = false)
//@ActiveProfiles("production") 
public class Test {// extends AbstractJUnit4SpringContextTests{//Transactional

    // @Autowired
    // private MusiccategoryService musiccategoryService;
    //
    // @org.junit.Test
    // public void testDao() {
    // int i = musiccategoryService.deleteCheckRel(10L);
    // System.out.println(i);
    // int j = musiccategoryService.deleteCheckRel(111L);
    // System.out.println(j);
    // }

    public static void main(String[] args) throws IOException {
        
        System.out.println(getNetworkAddrPrefix("192.168.122.100","255.255.248.0"));
    }

    public static String getNetworkAddrPrefix(String selfip, String selfmask) {
        if(selfip!=null &&selfip.split("\\.").length==4||selfmask!=null &&selfip.split("\\.").length==4&&maskvaliditycheck(selfmask)){
            String [] ipArr = selfip.split("\\.");
            String [] maskArr =selfmask.split("\\.");
            Integer ip1 =Integer.valueOf(ipArr[0])& Integer.valueOf(maskArr[0]);
            Integer ip2 =Integer.valueOf(ipArr[1])& Integer.valueOf(maskArr[1]);
            Integer ip3 =Integer.valueOf(ipArr[2])& Integer.valueOf(maskArr[2]);
            return  ip1+"."+ip2+"."+ip3;

        }
        return null;
    }
    
    private static boolean maskvaliditycheck(String mask){
        String[] masks = mask.split("\\.");  
        String binaryVal = "";  
        for (int i = 0; i < masks.length; i++)  
        {  
            String binaryStr = Integer.toBinaryString(Integer.parseInt(masks[i]));  
            Integer times = 8 - binaryStr.length();  
            for(int j = 0; j < times; j++)  
            {  
                binaryStr = "0" +  binaryStr;  
            }  
            binaryVal += binaryStr;  
        }  
        String regx = "^[1]*[0]*$";  
        return binaryVal.matches(regx);
    }
    
    public static boolean getHostStatus(String ip,int port) {
        TelnetClient telnet = new TelnetClient();
        telnet.setConnectTimeout(1000);
        telnet.setDefaultTimeout(1000);
        try {   
            telnet.connect(ip,port);
        } catch (IOException e) {
            return false;
        }
        try {
            telnet.disconnect();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return true;
    }
}
